/*

  This is a simple MJPEG streaming webserver implemented for AI-Thinker ESP32-CAM
  and ESP-EYE modules.
  This is tested to work with VLC and Blynk video widget and can support up to 10
  simultaneously connected streaming clients.
  Simultaneous streaming is implemented with FreeRTOS tasks.

  Inspired by and based on this Instructable: $9 RTSP Video Streamer Using the ESP32-CAM Board
  (https://www.instructables.com/id/9-RTSP-Video-Streamer-Using-the-ESP32-CAM-Board/)

  Board: AI-Thinker ESP32-CAM or ESP-EYE
  Compile as:
   ESP32 Dev Module
   CPU Freq: 240
   Flash Freq: 80
   Flash mode: QIO
   Flash Size: 4Mb
   Patrition: Minimal SPIFFS
   PSRAM: Enabled
*/

// ESP32 has two cores: APPlication core and PROcess core (the one that runs ESP32 SDK stack)
#define APP_CPU 1
#define PRO_CPU 0

#include "OV2640.h"
#include <WiFi.h>
#include <WebServer.h>
#include <WiFiClient.h>

#include <esp_bt.h>
#include <esp_wifi.h>
#include <esp_sleep.h>
#include <driver/rtc_io.h>

// Select camera model
//#define CAMERA_MODEL_WROVER_KIT
//#define CAMERA_MODEL_ESP_EYE
//#define CAMERA_MODEL_M5STACK_PSRAM
//#define CAMERA_MODEL_M5STACK_WIDE
#define CAMERA_MODEL_AI_THINKER

#include "camera_pins.h"

/*
  Next one is an include with wifi credentials.
  This is what you need to do:

  1. Create a file called "home_wifi_multi.h" in the same folder   OR   under a separate subfolder of the "libraries" folder of Arduino IDE. (You are creating a "fake" library really - I called it "MySettings").
  2. Place the following text in the file:
  #define SSID1 "replace with your wifi ssid"
  #define PWD1 "replace your wifi password"
  3. Save.

  Should work then
*/
#include "home_wifi_multi.h"

OV2640 cam;

WebServer server(80);

// ===== rtos task handles =========================
// Streaming is implemented with 3 tasks:
TaskHandle_t tMjpeg;   // handles client connections to the webserver
TaskHandle_t tCam;     // handles getting picture frames from the camera and storing them locally
TaskHandle_t tStream;  // actually streaming frames to all connected clients
TaskHandle_t tCloudPush; // pushes camera frames to the public server

// frameSync semaphore is used to prevent streaming buffer as it is replaced with the next frame
SemaphoreHandle_t frameSync = NULL;
SemaphoreHandle_t cameraAccess = NULL;

// Queue stores currently connected clients to whom we are streaming
QueueHandle_t streamingClients;

// We will try to achieve 25 FPS frame rate
const int FPS = 15;

// ===== Cloud push settings ==========================================
// Server receiver endpoint: http://YOUR_SERVER_HOST/api/esp32cam/stream
const bool CLOUD_PUSH_ENABLED = true;
const char CLOUD_PUSH_HOST[] = "YOUR_SERVER_HOST";
const uint16_t CLOUD_PUSH_PORT = 80;
const char CLOUD_PUSH_PATH[] = "/api/esp32cam/stream";
const char CLOUD_UPLOAD_BOUNDARY[] = "esp32camupload";
const char CLOUD_DEVICE_ID[] = "esp32cam-01";
const char CLOUD_STREAM_KEY[] = "CHANGE_ME_STREAM_KEY";
const int CLOUD_PUSH_FPS = 8;
const uint32_t CLOUD_PUSH_HTTP_TIMEOUT_MS = 3000;

// VGA + quality 12 is a better balance for remote monitoring than the previous
// QVGA + quality 18, which produced very small and visibly blocky frames.
const framesize_t CAMERA_FRAME_SIZE = FRAMESIZE_VGA;
const int CAMERA_JPEG_QUALITY = 12;
const int CAMERA_FB_COUNT = 2;

// ===== Camera orientation ============================================
// The installed module image is upside down, so flip it vertically here.
const bool CAMERA_VFLIP = true;
const bool CAMERA_HMIRROR = false;

// ===== External work-enable input ===================================
// AI-Thinker ESP32-CAM: GPIO13 is free when the microSD card is not used.
// Wire STM32 PA8 to ESP32-CAM GPIO13, and connect the two boards' GND together.
// HIGH = camera module works, LOW = camera module stops capturing/pushing.
const int MODULE_ENABLE_PIN = 13;
const int MODULE_ENABLE_ACTIVE_LEVEL = HIGH;
const int MODULE_ENABLE_PIN_MODE = INPUT_PULLDOWN;
const uint32_t MODULE_ENABLE_POLL_MS = 100;
volatile bool moduleEnabled = true;

bool isModuleEnabled();
void updateModuleEnableState(bool forceLog = false);
void closeStreamingClients();
void cloudPushCB(void* pvParameters);
uint32_t checksumFrame(const uint8_t* data, size_t length);
bool openCloudStream(WiFiClient& client);
bool pushFrameToCloudStream(WiFiClient& client, const uint8_t* frame, size_t frameSize);
bool writeHttpChunk(WiFiClient& client, const uint8_t* data, size_t length);

// We will handle web client requests every 50 ms (20 Hz)
const int WSINTERVAL = 100;


// ======== Server Connection Handler Task ==========================
void mjpegCB(void* pvParameters) {
  TickType_t xLastWakeTime;
  const TickType_t xFrequency = pdMS_TO_TICKS(WSINTERVAL);

  // Creating frame synchronization semaphore and initializing it
  frameSync = xSemaphoreCreateBinary();
  xSemaphoreGive( frameSync );

  // Creating a queue to track all connected clients
  streamingClients = xQueueCreate( 10, sizeof(WiFiClient*) );

  //=== setup section  ==================

  //  Creating RTOS task for grabbing frames from the camera
  xTaskCreatePinnedToCore(
    camCB,        // callback
    "cam",        // name
    4096,         // stacj size
    NULL,         // parameters
    2,            // priority
    &tCam,        // RTOS task handle
    APP_CPU);     // core

  //  Creating task to push the stream to all connected clients
  xTaskCreatePinnedToCore(
    streamCB,
    "strmCB",
    4 * 1024,
    NULL, //(void*) handler,
    2,
    &tStream,
    APP_CPU);

  //  Registering webserver handling routines
  server.on("/mjpeg/1", HTTP_GET, handleJPGSstream);
  server.on("/jpg", HTTP_GET, handleJPG);
  server.onNotFound(handleNotFound);

  //  Starting webserver
  server.begin();

  //=== loop() section  ===================
  xLastWakeTime = xTaskGetTickCount();
  for (;;) {
    server.handleClient();

    //  After every server client handling request, we let other tasks run and then pause
    taskYIELD();
    vTaskDelayUntil(&xLastWakeTime, xFrequency);
  }
}


// Commonly used variables:
volatile size_t camSize;    // size of the current frame, byte
volatile char* camBuf;      // pointer to the current frame


// ==== RTOS task to grab frames from the camera =========================
void camCB(void* pvParameters) {

  TickType_t xLastWakeTime;

  //  A running interval associated with currently desired frame rate
  const TickType_t xFrequency = pdMS_TO_TICKS(1000 / FPS);

  // Mutex for the critical section of swithing the active frames around
  portMUX_TYPE xSemaphore = portMUX_INITIALIZER_UNLOCKED;

  //  Pointers to the 2 frames, their respective sizes and index of the current frame
  char* fbs[2] = { NULL, NULL };
  size_t fSize[2] = { 0, 0 };
  int ifb = 0;

  //=== loop() section  ===================
  xLastWakeTime = xTaskGetTickCount();

  for (;;) {

    if (!isModuleEnabled()) {
      vTaskDelay(pdMS_TO_TICKS(MODULE_ENABLE_POLL_MS));
      continue;
    }

    //  Grab a frame from the camera and query its size
    xSemaphoreTake(cameraAccess, portMAX_DELAY);
    cam.run();
    size_t s = cam.getSize();

    //  If frame size is more that we have previously allocated - request  125% of the current frame space
    if (s > fSize[ifb]) {
      fSize[ifb] = s * 4 / 3;
      fbs[ifb] = allocateMemory(fbs[ifb], fSize[ifb]);
    }

    //  Copy current frame into local buffer
    char* b = (char*) cam.getfb();
    if (b != NULL && s > 0) {
      memcpy(fbs[ifb], b, s);
    }
    xSemaphoreGive(cameraAccess);

    //  Let other tasks run and wait until the end of the current frame rate interval (if any time left)
    taskYIELD();
    vTaskDelayUntil(&xLastWakeTime, xFrequency);

    //  Only switch frames around if no frame is currently being streamed to a client
    //  Wait on a semaphore until client operation completes
    xSemaphoreTake( frameSync, portMAX_DELAY );

    //  Do not allow interrupts while switching the current frame
    portENTER_CRITICAL(&xSemaphore);
    camBuf = fbs[ifb];
    camSize = s;
    ifb++;
    ifb &= 1;  // this should produce 1, 0, 1, 0, 1 ... sequence
    portEXIT_CRITICAL(&xSemaphore);

    //  Let anyone waiting for a frame know that the frame is ready
    xSemaphoreGive( frameSync );

    //  Technically only needed once: let the streaming task know that we have at least one frame
    //  and it could start sending frames to the clients, if any
    xTaskNotifyGive( tStream );

    //  Immediately let other (streaming) tasks run
    taskYIELD();

    //  If streaming task has suspended itself (no active clients to stream to)
    //  there is no need to grab frames from the camera. We can save some juice
    //  by suspedning the tasks
    if ( eTaskGetState( tStream ) == eSuspended ) {
      vTaskSuspend(NULL);  // passing NULL means "suspend yourself"
    }
  }
}


// ==== Memory allocator that takes advantage of PSRAM if present =======================
char* allocateMemory(char* aPtr, size_t aSize) {

  //  Since current buffer is too smal, free it
  if (aPtr != NULL) free(aPtr);


  size_t freeHeap = ESP.getFreeHeap();
  char* ptr = NULL;

  // If memory requested is more than 2/3 of the currently free heap, try PSRAM immediately
  if ( aSize > freeHeap * 2 / 3 ) {
    if ( psramFound() && ESP.getFreePsram() > aSize ) {
      ptr = (char*) ps_malloc(aSize);
    }
  }
  else {
    //  Enough free heap - let's try allocating fast RAM as a buffer
    ptr = (char*) malloc(aSize);

    //  If allocation on the heap failed, let's give PSRAM one more chance:
    if ( ptr == NULL && psramFound() && ESP.getFreePsram() > aSize) {
      ptr = (char*) ps_malloc(aSize);
    }
  }

  // Finally, if the memory pointer is NULL, we were not able to allocate any memory, and that is a terminal condition.
  if (ptr == NULL) {
    ESP.restart();
  }
  return ptr;
}


bool isModuleEnabled()
{
  return moduleEnabled;
}


void updateModuleEnableState(bool forceLog)
{
  const int level = digitalRead(MODULE_ENABLE_PIN);
  const bool enabled = (level == MODULE_ENABLE_ACTIVE_LEVEL);
  const bool wasEnabled = moduleEnabled;

  if (forceLog || enabled != moduleEnabled) {
    moduleEnabled = enabled;
    Serial.print(F("Module enable GPIO"));
    Serial.print(MODULE_ENABLE_PIN);
    Serial.print(F("="));
    Serial.print(level);
    Serial.println(enabled ? F(" -> enabled") : F(" -> disabled"));
  }

  if (wasEnabled && !enabled) {
    closeStreamingClients();
  }
}


// ==== STREAMING ======================================================
const char HEADER[] = "HTTP/1.1 200 OK\r\n" \
                      "Access-Control-Allow-Origin: *\r\n" \
                      "Content-Type: multipart/x-mixed-replace; boundary=123456789000000000000987654321\r\n";
const char BOUNDARY[] = "\r\n--123456789000000000000987654321\r\n";
const char CTNTTYPE[] = "Content-Type: image/jpeg\r\nContent-Length: ";
const int hdrLen = strlen(HEADER);
const int bdrLen = strlen(BOUNDARY);
const int cntLen = strlen(CTNTTYPE);


// ==== Handle connection request from clients ===============================
void handleJPGSstream(void)
{
  if (!isModuleEnabled()) {
    server.send(503, "text/plain", "Camera module disabled by control input\n");
    return;
  }

  //  Can only acommodate 10 clients. The limit is a default for WiFi connections
  if ( !uxQueueSpacesAvailable(streamingClients) ) return;


  //  Create a new WiFi Client object to keep track of this one
  WiFiClient* client = new WiFiClient();
  *client = server.client();

  //  Immediately send this client a header
  client->write(HEADER, hdrLen);
  client->write(BOUNDARY, bdrLen);

  // Push the client to the streaming queue
  xQueueSend(streamingClients, (void *) &client, 0);

  // Wake up streaming tasks, if they were previously suspended:
  if ( eTaskGetState( tCam ) == eSuspended ) vTaskResume( tCam );
  if ( eTaskGetState( tStream ) == eSuspended ) vTaskResume( tStream );
}


void closeStreamingClients()
{
  if (streamingClients == NULL) {
    return;
  }

  WiFiClient* client = NULL;
  while (xQueueReceive(streamingClients, (void*)&client, 0) == pdTRUE) {
    if (client != NULL) {
      client->stop();
      delete client;
    }
  }
}


// ==== Actually stream content to all connected clients ========================
void streamCB(void * pvParameters) {
  char buf[16];
  TickType_t xLastWakeTime;
  TickType_t xFrequency;

  //  Wait until the first frame is captured and there is something to send
  //  to clients
  ulTaskNotifyTake( pdTRUE,          /* Clear the notification value before exiting. */
                    portMAX_DELAY ); /* Block indefinitely. */

  xLastWakeTime = xTaskGetTickCount();
  for (;;) {
    // Default assumption we are running according to the FPS
    xFrequency = pdMS_TO_TICKS(1000 / FPS);

    if (!isModuleEnabled()) {
      taskYIELD();
      vTaskDelayUntil(&xLastWakeTime, xFrequency);
      continue;
    }

    //  Only bother to send anything if there is someone watching
    UBaseType_t activeClients = uxQueueMessagesWaiting(streamingClients);
    if ( activeClients ) {
      // Adjust the period to the number of connected clients
      xFrequency /= activeClients;

      //  Since we are sending the same frame to everyone,
      //  pop a client from the the front of the queue
      WiFiClient *client;
      xQueueReceive (streamingClients, (void*) &client, 0);

      //  Check if this client is still connected.

      if (!client->connected()) {
        //  delete this client reference if s/he has disconnected
        //  and don't put it back on the queue anymore. Bye!
        delete client;
      }
      else {

        //  Ok. This is an actively connected client.
        //  Let's grab a semaphore to prevent frame changes while we
        //  are serving this frame
        xSemaphoreTake( frameSync, portMAX_DELAY );

        client->write(CTNTTYPE, cntLen);
        sprintf(buf, "%d\r\n\r\n", camSize);
        client->write(buf, strlen(buf));
        client->write((char*) camBuf, (size_t)camSize);
        client->write(BOUNDARY, bdrLen);

        // Since this client is still connected, push it to the end
        // of the queue for further processing
        xQueueSend(streamingClients, (void *) &client, 0);

        //  The frame has been served. Release the semaphore and let other tasks run.
        //  If there is a frame switch ready, it will happen now in between frames
        xSemaphoreGive( frameSync );
        taskYIELD();
      }
    }
    else {
      //  Since there are no connected clients, there is no reason to waste battery running
      vTaskSuspend(NULL);
    }
    //  Let other tasks run after serving every client
    taskYIELD();
    vTaskDelayUntil(&xLastWakeTime, xFrequency);
  }
}



const char JHEADER[] = "HTTP/1.1 200 OK\r\n" \
                       "Content-disposition: inline; filename=capture.jpg\r\n" \
                       "Content-type: image/jpeg\r\n\r\n";
const int jhdLen = strlen(JHEADER);

// ==== Serve up one JPEG frame =============================================
void handleJPG(void)
{
  WiFiClient client = server.client();

  if (!client.connected()) return;
  if (!isModuleEnabled()) {
    server.send(503, "text/plain", "Camera module disabled by control input\n");
    return;
  }
  xSemaphoreTake(cameraAccess, portMAX_DELAY);
  cam.run();
  client.write(JHEADER, jhdLen);
  client.write((char*)cam.getfb(), cam.getSize());
  xSemaphoreGive(cameraAccess);
}


// ==== Handle invalid URL requests ============================================
void handleNotFound()
{
  String message = "Server is running!\n\n";
  message += "URI: ";
  message += server.uri();
  message += "\nMethod: ";
  message += (server.method() == HTTP_GET) ? "GET" : "POST";
  message += "\nArguments: ";
  message += server.args();
  message += "\n";
  server.send(200, "text / plain", message);
}


// ==== Push JPEG frames to the public server ================================
uint32_t checksumFrame(const uint8_t* data, size_t length)
{
  uint32_t hash = 2166136261UL;
  for (size_t i = 0; i < length; i++) {
    hash ^= data[i];
    hash *= 16777619UL;
  }
  return hash;
}


void cloudPushCB(void* pvParameters)
{
  TickType_t xLastWakeTime = xTaskGetTickCount();
  const TickType_t xFrequency = pdMS_TO_TICKS(1000 / CLOUD_PUSH_FPS);
  char* pushBuf = NULL;
  size_t pushBufSize = 0;
  size_t lastPushedFrameSize = 0;
  uint32_t lastPushedFrameChecksum = 0;
  uint32_t okCount = 0;
  uint32_t failCount = 0;
  uint32_t duplicateSkipCount = 0;
  uint32_t reconnectCount = 0;
  uint32_t lastLogMs = 0;
  WiFiClient cloudClient;

  Serial.print(F("Cloud push endpoint: http://"));
  Serial.print(CLOUD_PUSH_HOST);
  Serial.print(F(":"));
  Serial.print(CLOUD_PUSH_PORT);
  Serial.println(CLOUD_PUSH_PATH);

  for (;;) {
    if (!isModuleEnabled()) {
      cloudClient.stop();
      lastPushedFrameSize = 0;
      lastPushedFrameChecksum = 0;
      duplicateSkipCount = 0;
      vTaskDelay(pdMS_TO_TICKS(MODULE_ENABLE_POLL_MS));
      continue;
    }

    if (WiFi.status() == WL_CONNECTED) {
      size_t frameSize = 0;

      xSemaphoreTake(cameraAccess, portMAX_DELAY);
      cam.run();
      frameSize = cam.getSize();
      uint8_t* frame = cam.getfb();

      if (frame != NULL && frameSize > 0) {
        if (frameSize > pushBufSize) {
          pushBufSize = frameSize * 4 / 3;
          pushBuf = allocateMemory(pushBuf, pushBufSize);
        }
        memcpy(pushBuf, frame, frameSize);
      }
      xSemaphoreGive(cameraAccess);

      if (pushBuf != NULL && frameSize > 0) {
        const uint32_t frameChecksum = checksumFrame((const uint8_t*)pushBuf, frameSize);
        const bool duplicateFrame =
          lastPushedFrameSize == frameSize &&
          lastPushedFrameChecksum == frameChecksum;

        if (duplicateFrame) {
          duplicateSkipCount++;
          if (duplicateSkipCount == 1 || duplicateSkipCount % 30 == 0) {
            Serial.print(F("Cloud push skipped duplicate frame count="));
            Serial.println(duplicateSkipCount);
          }
          vTaskDelayUntil(&xLastWakeTime, xFrequency);
          continue;
        }

        if (!cloudClient.connected()) {
          cloudClient.stop();
          if (openCloudStream(cloudClient)) {
            reconnectCount++;
          }
          else {
            failCount++;
          }
        }

        if (cloudClient.connected() && pushFrameToCloudStream(cloudClient, (const uint8_t*)pushBuf, frameSize)) {
          okCount++;
          lastPushedFrameSize = frameSize;
          lastPushedFrameChecksum = frameChecksum;
          duplicateSkipCount = 0;
        }
        else {
          failCount++;
          cloudClient.stop();
        }
      }
    }
    else {
      failCount++;
      cloudClient.stop();
      lastPushedFrameSize = 0;
      lastPushedFrameChecksum = 0;
      duplicateSkipCount = 0;
      WiFi.reconnect();
      vTaskDelay(pdMS_TO_TICKS(1000));
    }

    if (millis() - lastLogMs > 5000) {
      lastLogMs = millis();
      Serial.print(F("Cloud push ok="));
      Serial.print(okCount);
      Serial.print(F(", fail="));
      Serial.print(failCount);
      Serial.print(F(", reconnect="));
      Serial.print(reconnectCount);
      Serial.print(F(", free heap="));
      Serial.println(ESP.getFreeHeap());
    }

    vTaskDelayUntil(&xLastWakeTime, xFrequency);
  }
}


bool openCloudStream(WiFiClient& client)
{
  client.setTimeout(CLOUD_PUSH_HTTP_TIMEOUT_MS);

  if (!client.connect(CLOUD_PUSH_HOST, CLOUD_PUSH_PORT)) {
    Serial.println(F("Cloud push: connect failed"));
    return false;
  }
  client.setNoDelay(true);

  client.print(F("POST "));
  client.print(CLOUD_PUSH_PATH);
  client.println(F(" HTTP/1.1"));
  client.print(F("Host: "));
  client.println(CLOUD_PUSH_HOST);
  client.println(F("User-Agent: ESP32-CAM"));
  client.print(F("Content-Type: multipart/x-mixed-replace; boundary="));
  client.println(CLOUD_UPLOAD_BOUNDARY);
  client.println(F("Transfer-Encoding: chunked"));
  client.print(F("X-Device-Id: "));
  client.println(CLOUD_DEVICE_ID);
  client.print(F("X-Stream-Key: "));
  client.println(CLOUD_STREAM_KEY);
  client.println(F("Connection: keep-alive"));
  client.println();
  return true;
}


bool pushFrameToCloudStream(WiFiClient& client, const uint8_t* frame, size_t frameSize)
{
  if (!client.connected()) {
    return false;
  }

  char partHeader[160];
  int headerLen = snprintf(
    partHeader,
    sizeof(partHeader),
    "--%s\r\nContent-Type: image/jpeg\r\nContent-Length: %u\r\nX-Frame-Millis: %lu\r\n\r\n",
    CLOUD_UPLOAD_BOUNDARY,
    (unsigned int)frameSize,
    (unsigned long)millis());

  if (headerLen <= 0 || headerLen >= (int)sizeof(partHeader)) {
    Serial.println(F("Cloud push: part header too long"));
    return false;
  }

  if (!writeHttpChunk(client, (const uint8_t*)partHeader, (size_t)headerLen)) return false;
  if (!writeHttpChunk(client, frame, frameSize)) return false;

  const uint8_t frameEnd[] = "\r\n";
  if (!writeHttpChunk(client, frameEnd, 2)) return false;

  return true;
}


bool writeHttpChunk(WiFiClient& client, const uint8_t* data, size_t length)
{
  char chunkHeader[16];
  int headerLen = snprintf(chunkHeader, sizeof(chunkHeader), "%X\r\n", (unsigned int)length);
  if (headerLen <= 0 || headerLen >= (int)sizeof(chunkHeader)) {
    return false;
  }

  if (client.write((const uint8_t*)chunkHeader, (size_t)headerLen) != (size_t)headerLen) return false;
  if (length > 0 && client.write(data, length) != length) return false;
  if (client.write((const uint8_t*)"\r\n", 2) != 2) return false;

  return true;
}



// ==== SETUP method ==================================================================
void setup()
{

  // Setup Serial connection:
  Serial.begin(115200);
  delay(1000); // wait for a second to let Serial connect
  Serial.println();
  Serial.println(F("Booting ESP32-CAM MJPEG server"));
  Serial.printf("Free heap: %u bytes, PSRAM: %s\r\n", ESP.getFreeHeap(), psramFound() ? "found" : "not found");
  pinMode(MODULE_ENABLE_PIN, MODULE_ENABLE_PIN_MODE);
  updateModuleEnableState(true);


  // Configure the camera
  Serial.println(F("Initializing camera..."));
  camera_config_t config;
  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer = LEDC_TIMER_0;
  config.pin_d0 = Y2_GPIO_NUM;
  config.pin_d1 = Y3_GPIO_NUM;
  config.pin_d2 = Y4_GPIO_NUM;
  config.pin_d3 = Y5_GPIO_NUM;
  config.pin_d4 = Y6_GPIO_NUM;
  config.pin_d5 = Y7_GPIO_NUM;
  config.pin_d6 = Y8_GPIO_NUM;
  config.pin_d7 = Y9_GPIO_NUM;
  config.pin_xclk = XCLK_GPIO_NUM;
  config.pin_pclk = PCLK_GPIO_NUM;
  config.pin_vsync = VSYNC_GPIO_NUM;
  config.pin_href = HREF_GPIO_NUM;
  config.pin_sscb_sda = SIOD_GPIO_NUM;
  config.pin_sscb_scl = SIOC_GPIO_NUM;
  config.pin_pwdn = PWDN_GPIO_NUM;
  config.pin_reset = RESET_GPIO_NUM;
  config.xclk_freq_hz = 20000000;
  config.pixel_format = PIXFORMAT_JPEG;

  // Frame parameters: pick one
  //  config.frame_size = FRAMESIZE_UXGA;
  //  config.frame_size = FRAMESIZE_SVGA;
  //  config.frame_size = FRAMESIZE_QVGA;
  config.frame_size = CAMERA_FRAME_SIZE;
  config.jpeg_quality = CAMERA_JPEG_QUALITY;
  config.fb_count = CAMERA_FB_COUNT;

#if defined(CAMERA_MODEL_ESP_EYE)
  pinMode(13, INPUT_PULLUP);
  pinMode(14, INPUT_PULLUP);
#endif

  if (cam.init(config) != ESP_OK) {
    Serial.println("Error initializing the camera");
    delay(10000);
    ESP.restart();
  }
  sensor_t* sensor = esp_camera_sensor_get();
  if (sensor != NULL) {
    sensor->set_vflip(sensor, CAMERA_VFLIP ? 1 : 0);
    sensor->set_hmirror(sensor, CAMERA_HMIRROR ? 1 : 0);
    Serial.print(F("Camera orientation: vflip="));
    Serial.print(CAMERA_VFLIP ? 1 : 0);
    Serial.print(F(", hmirror="));
    Serial.println(CAMERA_HMIRROR ? 1 : 0);
  }
  Serial.println(F("Camera initialized"));

  cameraAccess = xSemaphoreCreateMutex();
  if (cameraAccess == NULL) {
    Serial.println(F("Error creating camera mutex"));
    delay(10000);
    ESP.restart();
  }


  //  Configure and connect to WiFi
  IPAddress ip;

  WiFi.persistent(false);
  WiFi.disconnect(true);
  delay(200);
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.begin(SSID1, PWD1);
  Serial.print(F("Connecting to WiFi SSID: "));
  Serial.println(SSID1);

  const unsigned long wifiStartMs = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - wifiStartMs < 20000)
  {
    delay(500);
    Serial.print(F("."));
  }
  Serial.println();

  if (WiFi.status() != WL_CONNECTED) {
    Serial.print(F("WiFi connection failed, status="));
    Serial.println(WiFi.status());
    Serial.println(F("Check that the router is 2.4GHz, SSID/password are correct, and signal is strong."));
    delay(5000);
    ESP.restart();
  }

  ip = WiFi.localIP();
  Serial.println(F("WiFi connected"));
  Serial.println("");
  Serial.print("Stream Link: http://");
  Serial.print(ip);
  Serial.println("/mjpeg/1");


  // Start mainstreaming RTOS task
  xTaskCreatePinnedToCore(
    mjpegCB,
    "mjpeg",
    4 * 1024,
    NULL,
    2,
    &tMjpeg,
    APP_CPU);

  if (CLOUD_PUSH_ENABLED) {
    xTaskCreatePinnedToCore(
      cloudPushCB,
      "cloudPush",
      8 * 1024,
      NULL,
      1,
      &tCloudPush,
      APP_CPU);
  }
}


void loop() {
  updateModuleEnableState();
  vTaskDelay(pdMS_TO_TICKS(MODULE_ENABLE_POLL_MS));
}

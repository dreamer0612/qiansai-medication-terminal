#include <rtthread.h>
#include <rtdevice.h>
#include "app_max30102.h"
#include "app_ram.h"

#define MAX30102_I2C_BUS_NAME          "i2c1"
#define MAX30102_I2C_ADDR              0x57

#define MAX30102_REG_INTR_STATUS_1     0x00
#define MAX30102_REG_INTR_STATUS_2     0x01
#define MAX30102_REG_INTR_ENABLE_1     0x02
#define MAX30102_REG_INTR_ENABLE_2     0x03
#define MAX30102_REG_FIFO_WR_PTR       0x04
#define MAX30102_REG_OVF_COUNTER       0x05
#define MAX30102_REG_FIFO_RD_PTR       0x06
#define MAX30102_REG_FIFO_DATA         0x07
#define MAX30102_REG_FIFO_CONFIG       0x08
#define MAX30102_REG_MODE_CONFIG       0x09
#define MAX30102_REG_SPO2_CONFIG       0x0A
#define MAX30102_REG_LED1_PA           0x0C
#define MAX30102_REG_LED2_PA           0x0D
#define MAX30102_REG_PILOT_PA          0x10
#define MAX30102_REG_PART_ID           0xFF

#define BUFFER_SIZE                    300
#define MA4_SIZE                       4
#define HAMMING_SIZE                   5
#define UPDATE_SIZE                    50

#define SAMPLE_DELAY_MS                10
#define RED_FINGER_THRESHOLD           10000
#define IR_FINGER_THRESHOLD            30000

#define HR_MIN_VALID                   45
#define HR_MAX_VALID                   120
#define SPO2_MIN_VALID                 85
#define SPO2_MAX_VALID                 100
#define MEASURE_VALID_MIN              2
#define MEASURE_VALID_MAX              3
#define HR_STABLE_RANGE                10
#define SPO2_STABLE_RANGE              3
#define FINGER_WAIT_DELAY_MS           200
#define FINGER_COMMAND_TIMEOUT_MS      30000
#define MEASURE_COMMAND_TIMEOUT_MS     15000
#define MAX30102_THREAD_STACK_SIZE     4096

#ifndef min
#define min(a,b)                       ((a) < (b) ? (a) : (b))
#endif

static struct rt_i2c_bus_device *max30102_i2c = RT_NULL;

static rt_uint32_t aun_ir_buffer[BUFFER_SIZE];
static rt_uint32_t aun_red_buffer[BUFFER_SIZE];

static int32_t an_dx[BUFFER_SIZE - MA4_SIZE];
static int32_t an_x[BUFFER_SIZE];
static int32_t an_y[BUFFER_SIZE];

static int32_t n_spo2 = 0;
static int8_t ch_spo2_valid = 0;
static int32_t n_heart_rate = 0;
static int8_t ch_hr_valid = 0;

static int32_t last_hr = 0;
static int32_t last_spo2 = 0;
static rt_bool_t result_ready = RT_FALSE;
static rt_bool_t max30102_started = RT_FALSE;
static int request_result_hr = 0;
static int request_result_spo2 = 0;
static int request_result_status = -1;

static struct rt_mutex max30102_data_lock;
static rt_uint8_t max30102_data_lock_inited = 0;
static struct rt_semaphore max30102_request_sem;
static struct rt_semaphore max30102_done_sem;
static struct rt_mutex max30102_request_lock;
static struct rt_thread max30102_thread;
ALIGN(RT_ALIGN_SIZE)
static rt_uint8_t max30102_thread_stack[MAX30102_THREAD_STACK_SIZE] APP_CCMRAM;

static const rt_uint16_t auw_hamm[HAMMING_SIZE] = {41, 276, 512, 276, 41};

static const rt_uint8_t uch_spo2_table[184] =
{
    95, 95, 95, 96, 96, 96, 97, 97, 97, 97,
    97, 98, 98, 98, 98, 98, 99, 99, 99, 99,
    99, 99, 99, 99, 100, 100, 100, 100, 100, 100,
    100, 100, 100, 100, 100, 100, 100, 100, 100, 100,
    100, 100, 100, 100, 99, 99, 99, 99, 99, 99,
    99, 99, 98, 98, 98, 98, 98, 98, 97, 97,
    97, 97, 96, 96, 96, 96, 95, 95, 95, 94,
    94, 94, 93, 93, 93, 92, 92, 92, 91, 91,
    90, 90, 89, 89, 89, 88, 88, 87, 87, 86,
    86, 85, 85, 84, 84, 83, 82, 82, 81, 81,
    80, 80, 79, 78, 78, 77, 76, 76, 75, 74,
    74, 73, 72, 72, 71, 70, 69, 69, 68, 67,
    66, 66, 65, 64, 63, 62, 62, 61, 60, 59,
    58, 57, 56, 56, 55, 54, 53, 52, 51, 50,
    49, 48, 47, 46, 45, 44, 43, 42, 41, 40,
    39, 38, 37, 36, 35, 34, 33, 31, 30, 29,
    28, 27, 26, 25, 23, 22, 21, 20, 19, 17,
    16, 15, 14, 12, 11, 10, 9, 7, 6, 5,
    3, 2, 1, 0
};

static rt_err_t max30102_write_reg(rt_uint8_t reg, rt_uint8_t data)
{
    rt_uint8_t buf[2];

    buf[0] = reg;
    buf[1] = data;

    if (rt_i2c_master_send(max30102_i2c, MAX30102_I2C_ADDR, 0, buf, 2) == 2)
    {
        return RT_EOK;
    }

    return -RT_ERROR;
}

static rt_err_t max30102_read_reg(rt_uint8_t reg, rt_uint8_t *data)
{
    struct rt_i2c_msg msgs[2];

    msgs[0].addr  = MAX30102_I2C_ADDR;
    msgs[0].flags = RT_I2C_WR;
    msgs[0].buf   = &reg;
    msgs[0].len   = 1;

    msgs[1].addr  = MAX30102_I2C_ADDR;
    msgs[1].flags = RT_I2C_RD;
    msgs[1].buf   = data;
    msgs[1].len   = 1;

    if (rt_i2c_transfer(max30102_i2c, msgs, 2) == 2)
    {
        return RT_EOK;
    }

    return -RT_ERROR;
}

static rt_err_t max30102_read_regs(rt_uint8_t reg, rt_uint8_t *buf, rt_uint16_t len)
{
    struct rt_i2c_msg msgs[2];

    msgs[0].addr  = MAX30102_I2C_ADDR;
    msgs[0].flags = RT_I2C_WR;
    msgs[0].buf   = &reg;
    msgs[0].len   = 1;

    msgs[1].addr  = MAX30102_I2C_ADDR;
    msgs[1].flags = RT_I2C_RD;
    msgs[1].buf   = buf;
    msgs[1].len   = len;

    if (rt_i2c_transfer(max30102_i2c, msgs, 2) == 2)
    {
        return RT_EOK;
    }

    return -RT_ERROR;
}

static void max30102_clear_fifo(void)
{
    max30102_write_reg(MAX30102_REG_FIFO_WR_PTR, 0x00);
    max30102_write_reg(MAX30102_REG_OVF_COUNTER, 0x00);
    max30102_write_reg(MAX30102_REG_FIFO_RD_PTR, 0x00);
}

static void max30102_led_off(void)
{
    max30102_write_reg(MAX30102_REG_LED1_PA, 0x00);
    max30102_write_reg(MAX30102_REG_LED2_PA, 0x00);
    max30102_write_reg(MAX30102_REG_PILOT_PA, 0x00);
    max30102_write_reg(MAX30102_REG_MODE_CONFIG, 0x02);
}

static int max30102_init(void)
{
    rt_uint8_t id = 0;
    rt_uint8_t status = 0;

    if (max30102_read_reg(MAX30102_REG_PART_ID, &id) != RT_EOK)
    {
        rt_kprintf("MAX30102 read id failed\n");
        return -RT_ERROR;
    }

    rt_kprintf("MAX30102 PART ID = 0x%02X\n", id);

    if (id != 0x15)
    {
        rt_kprintf("MAX30102 id error\n");
        return -RT_ERROR;
    }

    max30102_write_reg(MAX30102_REG_MODE_CONFIG, 0x40);
    max30102_write_reg(MAX30102_REG_MODE_CONFIG, 0x40);
    rt_thread_mdelay(100);

    max30102_read_reg(MAX30102_REG_INTR_STATUS_1, &status);
    max30102_read_reg(MAX30102_REG_INTR_STATUS_2, &status);

    max30102_write_reg(MAX30102_REG_INTR_ENABLE_1, 0xC0);
    max30102_write_reg(MAX30102_REG_INTR_ENABLE_2, 0x00);

    max30102_clear_fifo();

    max30102_write_reg(MAX30102_REG_FIFO_CONFIG, 0x0F);
    max30102_write_reg(MAX30102_REG_MODE_CONFIG, 0x03);
    max30102_write_reg(MAX30102_REG_SPO2_CONFIG, 0x27);

    max30102_write_reg(MAX30102_REG_LED1_PA, 0x24);
    max30102_write_reg(MAX30102_REG_LED2_PA, 0x24);
    max30102_write_reg(MAX30102_REG_PILOT_PA, 0x7F);

    rt_kprintf("MAX30102 init success\n");

    return RT_EOK;
}

static rt_err_t max30102_read_fifo(rt_uint32_t *red, rt_uint32_t *ir)
{
    rt_uint8_t temp[6];
    rt_uint8_t status;

    max30102_read_reg(MAX30102_REG_INTR_STATUS_1, &status);
    max30102_read_reg(MAX30102_REG_INTR_STATUS_2, &status);

    if (max30102_read_regs(MAX30102_REG_FIFO_DATA, temp, 6) != RT_EOK)
    {
        return -RT_ERROR;
    }

    *red = ((rt_uint32_t)(temp[0] & 0x03) << 16) |
           ((rt_uint32_t)temp[1] << 8) |
           temp[2];

    *ir = ((rt_uint32_t)(temp[3] & 0x03) << 16) |
          ((rt_uint32_t)temp[4] << 8) |
          temp[5];

    return RT_EOK;
}

static void maxim_sort_ascend(int32_t *pn_x, int32_t n_size)
{
    int32_t i, j, n_temp;

    for (i = 1; i < n_size; i++)
    {
        n_temp = pn_x[i];

        for (j = i; j > 0 && n_temp < pn_x[j - 1]; j--)
        {
            pn_x[j] = pn_x[j - 1];
        }

        pn_x[j] = n_temp;
    }
}

static void maxim_sort_indices_descend(int32_t *pn_x, int32_t *pn_indx, int32_t n_size)
{
    int32_t i, j, n_temp;

    for (i = 1; i < n_size; i++)
    {
        n_temp = pn_indx[i];

        for (j = i; j > 0 && pn_x[n_temp] > pn_x[pn_indx[j - 1]]; j--)
        {
            pn_indx[j] = pn_indx[j - 1];
        }

        pn_indx[j] = n_temp;
    }
}

static void maxim_peaks_above_min_height(int32_t *pn_locs,
                                         int32_t *pn_npks,
                                         int32_t *pn_x,
                                         int32_t n_size,
                                         int32_t n_min_height)
{
    int32_t i = 1;
    int32_t n_width;

    *pn_npks = 0;

    while (i < n_size - 1)
    {
        if (pn_x[i] > n_min_height && pn_x[i] > pn_x[i - 1])
        {
            n_width = 1;

            while (i + n_width < n_size && pn_x[i] == pn_x[i + n_width])
            {
                n_width++;
            }

            if (i + n_width < n_size &&
                pn_x[i] > pn_x[i + n_width] &&
                (*pn_npks) < 15)
            {
                pn_locs[(*pn_npks)++] = i;
                i += n_width + 1;
            }
            else
            {
                i += n_width;
            }
        }
        else
        {
            i++;
        }
    }
}

static void maxim_remove_close_peaks(int32_t *pn_locs,
                                     int32_t *pn_npks,
                                     int32_t *pn_x,
                                     int32_t n_min_distance)
{
    int32_t i, j, n_old_npks, n_dist;

    maxim_sort_indices_descend(pn_x, pn_locs, *pn_npks);

    for (i = -1; i < *pn_npks; i++)
    {
        n_old_npks = *pn_npks;
        *pn_npks = i + 1;

        for (j = i + 1; j < n_old_npks; j++)
        {
            n_dist = pn_locs[j] - (i == -1 ? -1 : pn_locs[i]);

            if (n_dist > n_min_distance || n_dist < -n_min_distance)
            {
                pn_locs[(*pn_npks)++] = pn_locs[j];
            }
        }
    }

    maxim_sort_ascend(pn_locs, *pn_npks);
}

static void maxim_find_peaks(int32_t *pn_locs,
                             int32_t *pn_npks,
                             int32_t *pn_x,
                             int32_t n_size,
                             int32_t n_min_height,
                             int32_t n_min_distance,
                             int32_t n_max_num)
{
    maxim_peaks_above_min_height(pn_locs, pn_npks, pn_x, n_size, n_min_height);
    maxim_remove_close_peaks(pn_locs, pn_npks, pn_x, n_min_distance);
    *pn_npks = min(*pn_npks, n_max_num);
}

static void maxim_heart_rate_and_oxygen_saturation(rt_uint32_t *pun_ir_buffer,
                                                   int32_t n_ir_buffer_length,
                                                   rt_uint32_t *pun_red_buffer,
                                                   int32_t *pn_spo2,
                                                   int8_t *pch_spo2_valid,
                                                   int32_t *pn_heart_rate,
                                                   int8_t *pch_hr_valid)
{
    rt_uint32_t un_ir_mean;
    rt_uint32_t un_only_once;
    int32_t k, n_i_ratio_count;
    int32_t i, s, m, n_exact_ir_valley_locs_count, n_middle_idx;
    int32_t n_th1, n_npks, n_c_min;
    int32_t an_ir_valley_locs[15];
    int32_t an_exact_ir_valley_locs[15];
    int32_t an_dx_peak_locs[15];
    int32_t n_peak_interval_sum;
    int32_t n_y_ac, n_x_ac;
    int32_t n_spo2_calc;
    int32_t n_y_dc_max, n_x_dc_max;
    int32_t n_y_dc_max_idx = 0, n_x_dc_max_idx = 0;
    int32_t an_ratio[5], n_ratio_average;
    int32_t n_nume, n_denom;

    un_ir_mean = 0;

    for (k = 0; k < n_ir_buffer_length; k++)
    {
        un_ir_mean += pun_ir_buffer[k];
    }

    un_ir_mean = un_ir_mean / n_ir_buffer_length;

    for (k = 0; k < n_ir_buffer_length; k++)
    {
        an_x[k] = (int32_t)pun_ir_buffer[k] - (int32_t)un_ir_mean;
    }

    for (k = 0; k < BUFFER_SIZE - MA4_SIZE; k++)
    {
        n_denom = an_x[k] + an_x[k + 1] + an_x[k + 2] + an_x[k + 3];
        an_x[k] = n_denom / 4;
    }

    for (k = 0; k < BUFFER_SIZE - MA4_SIZE - 1; k++)
    {
        an_dx[k] = an_x[k + 1] - an_x[k];
    }

    for (k = 0; k < BUFFER_SIZE - MA4_SIZE - 2; k++)
    {
        an_dx[k] = (an_dx[k] + an_dx[k + 1]) / 2;
    }

    for (i = 0; i < BUFFER_SIZE - HAMMING_SIZE - MA4_SIZE - 2; i++)
    {
        s = 0;

        for (k = i; k < i + HAMMING_SIZE; k++)
        {
            s -= an_dx[k] * auw_hamm[k - i];
        }

        an_dx[i] = s / 1146;
    }

    n_th1 = 0;

    for (k = 0; k < BUFFER_SIZE - HAMMING_SIZE; k++)
    {
        n_th1 += ((an_dx[k] > 0) ? an_dx[k] : (0 - an_dx[k]));
    }

    n_th1 = n_th1 / (BUFFER_SIZE - HAMMING_SIZE);

    maxim_find_peaks(an_dx_peak_locs,
                     &n_npks,
                     an_dx,
                     BUFFER_SIZE - HAMMING_SIZE,
                     n_th1,
                     8,
                     5);

    n_peak_interval_sum = 0;

    if (n_npks >= 2)
    {
        for (k = 1; k < n_npks; k++)
        {
            n_peak_interval_sum += an_dx_peak_locs[k] - an_dx_peak_locs[k - 1];
        }

        n_peak_interval_sum = n_peak_interval_sum / (n_npks - 1);

        *pn_heart_rate = 6000 / n_peak_interval_sum;
        *pch_hr_valid = 1;
    }
    else
    {
        *pn_heart_rate = -999;
        *pch_hr_valid = 0;
    }

    for (k = 0; k < n_npks; k++)
    {
        an_ir_valley_locs[k] = an_dx_peak_locs[k] + HAMMING_SIZE / 2;
    }

    for (k = 0; k < n_ir_buffer_length; k++)
    {
        an_x[k] = pun_ir_buffer[k];
        an_y[k] = pun_red_buffer[k];
    }

    n_exact_ir_valley_locs_count = 0;

    for (k = 0; k < n_npks; k++)
    {
        un_only_once = 1;
        m = an_ir_valley_locs[k];
        n_c_min = 16777216;

        if (m + 5 < BUFFER_SIZE - HAMMING_SIZE && m - 5 > 0)
        {
            for (i = m - 5; i < m + 5; i++)
            {
                if (an_x[i] < n_c_min)
                {
                    if (un_only_once > 0)
                    {
                        un_only_once = 0;
                    }

                    n_c_min = an_x[i];
                    an_exact_ir_valley_locs[k] = i;
                }
            }

            if (un_only_once == 0)
            {
                n_exact_ir_valley_locs_count++;
            }
        }
    }

    if (n_exact_ir_valley_locs_count < 2)
    {
        *pn_spo2 = -999;
        *pch_spo2_valid = 0;
        return;
    }

    for (k = 0; k < BUFFER_SIZE - MA4_SIZE; k++)
    {
        an_x[k] = (an_x[k] + an_x[k + 1] + an_x[k + 2] + an_x[k + 3]) / 4;
        an_y[k] = (an_y[k] + an_y[k + 1] + an_y[k + 2] + an_y[k + 3]) / 4;
    }

    n_ratio_average = 0;
    n_i_ratio_count = 0;

    for (k = 0; k < 5; k++)
    {
        an_ratio[k] = 0;
    }

    for (k = 0; k < n_exact_ir_valley_locs_count; k++)
    {
        if (an_exact_ir_valley_locs[k] > BUFFER_SIZE)
        {
            *pn_spo2 = -999;
            *pch_spo2_valid = 0;
            return;
        }
    }

    for (k = 0; k < n_exact_ir_valley_locs_count - 1; k++)
    {
        n_y_dc_max = -16777216;
        n_x_dc_max = -16777216;

        if (an_exact_ir_valley_locs[k + 1] - an_exact_ir_valley_locs[k] > 10)
        {
            for (i = an_exact_ir_valley_locs[k]; i < an_exact_ir_valley_locs[k + 1]; i++)
            {
                if (an_x[i] > n_x_dc_max)
                {
                    n_x_dc_max = an_x[i];
                    n_x_dc_max_idx = i;
                }

                if (an_y[i] > n_y_dc_max)
                {
                    n_y_dc_max = an_y[i];
                    n_y_dc_max_idx = i;
                }
            }

            n_y_ac = (an_y[an_exact_ir_valley_locs[k + 1]] -
                      an_y[an_exact_ir_valley_locs[k]]) *
                     (n_y_dc_max_idx - an_exact_ir_valley_locs[k]);

            n_y_ac = an_y[an_exact_ir_valley_locs[k]] +
                     n_y_ac / (an_exact_ir_valley_locs[k + 1] - an_exact_ir_valley_locs[k]);

            n_y_ac = an_y[n_y_dc_max_idx] - n_y_ac;

            n_x_ac = (an_x[an_exact_ir_valley_locs[k + 1]] -
                      an_x[an_exact_ir_valley_locs[k]]) *
                     (n_x_dc_max_idx - an_exact_ir_valley_locs[k]);

            n_x_ac = an_x[an_exact_ir_valley_locs[k]] +
                     n_x_ac / (an_exact_ir_valley_locs[k + 1] - an_exact_ir_valley_locs[k]);

            n_x_ac = an_x[n_y_dc_max_idx] - n_x_ac;

            n_nume = (n_y_ac * n_x_dc_max) >> 7;
            n_denom = (n_x_ac * n_y_dc_max) >> 7;

            if (n_denom > 0 && n_i_ratio_count < 5 && n_nume != 0)
            {
                an_ratio[n_i_ratio_count] = (n_nume * 20) / n_denom;
                n_i_ratio_count++;
            }
        }
    }

    maxim_sort_ascend(an_ratio, n_i_ratio_count);
    n_middle_idx = n_i_ratio_count / 2;

    if (n_middle_idx > 1)
    {
        n_ratio_average = (an_ratio[n_middle_idx - 1] + an_ratio[n_middle_idx]) / 2;
    }
    else
    {
        n_ratio_average = an_ratio[n_middle_idx];
    }

    if (n_ratio_average > 2 && n_ratio_average < 184)
    {
        n_spo2_calc = uch_spo2_table[n_ratio_average];
        *pn_spo2 = n_spo2_calc;
        *pch_spo2_valid = 1;
    }
    else
    {
        *pn_spo2 = -999;
        *pch_spo2_valid = 0;
    }
}

static int collect_samples(int start, int end)
{
    int i;
    rt_uint32_t red;
    rt_uint32_t ir;

    for (i = start; i < end; i++)
    {
        if (max30102_read_fifo(&red, &ir) == RT_EOK)
        {
            aun_red_buffer[i] = red;
            aun_ir_buffer[i] = ir;
        }
        else
        {
            i--;
            max30102_clear_fifo();
        }

        rt_thread_mdelay(SAMPLE_DELAY_MS);
    }

    return RT_EOK;
}

static rt_bool_t max30102_sample_has_finger(rt_uint32_t red, rt_uint32_t ir)
{
    if ((red < RED_FINGER_THRESHOLD) || (ir < IR_FINGER_THRESHOLD))
    {
        return RT_FALSE;
    }

    return RT_TRUE;
}

static rt_bool_t max30102_buffer_has_finger(void)
{
    return max30102_sample_has_finger(aun_red_buffer[BUFFER_SIZE - 1],
                                      aun_ir_buffer[BUFFER_SIZE - 1]);
}

static rt_bool_t max30102_read_finger_status(void)
{
    rt_uint32_t red;
    rt_uint32_t ir;

    if (max30102_read_fifo(&red, &ir) != RT_EOK)
    {
        max30102_clear_fifo();
        return RT_FALSE;
    }

    max30102_clear_fifo();

    return max30102_sample_has_finger(red, ir);
}

static void app_max30102_clear_value(void)
{
    if (max30102_data_lock_inited)
    {
        rt_mutex_take(&max30102_data_lock, RT_WAITING_FOREVER);
        if (result_ready == RT_FALSE)
        {
            last_hr = 0;
            last_spo2 = 0;
        }
        rt_mutex_release(&max30102_data_lock);
    }
    else
    {
        if (result_ready == RT_FALSE)
        {
            last_hr = 0;
            last_spo2 = 0;
        }
    }
}

static void app_max30102_publish_value(int heart_rate, int spo2)
{
    if (max30102_data_lock_inited)
    {
        rt_mutex_take(&max30102_data_lock, RT_WAITING_FOREVER);
        last_hr = heart_rate;
        last_spo2 = spo2;
        result_ready = RT_TRUE;
        rt_mutex_release(&max30102_data_lock);
    }
    else
    {
        last_hr = heart_rate;
        last_spo2 = spo2;
        result_ready = RT_TRUE;
    }
}

static rt_bool_t max30102_calc_valid_value(int32_t *heart_rate, int32_t *spo2)
{
    maxim_heart_rate_and_oxygen_saturation(aun_ir_buffer,
                                            BUFFER_SIZE,
                                            aun_red_buffer,
                                            &n_spo2,
                                            &ch_spo2_valid,
                                            &n_heart_rate,
                                            &ch_hr_valid);

    if ((ch_hr_valid == 1) &&
        (ch_spo2_valid == 1) &&
        (n_heart_rate >= HR_MIN_VALID) &&
        (n_heart_rate <= HR_MAX_VALID) &&
        (n_spo2 >= SPO2_MIN_VALID) &&
        (n_spo2 <= SPO2_MAX_VALID))
    {
        *heart_rate = n_heart_rate;
        *spo2 = n_spo2;
        return RT_TRUE;
    }

    return RT_FALSE;
}

static void max30102_shift_buffer(void)
{
    int i;

    for (i = UPDATE_SIZE; i < BUFFER_SIZE; i++)
    {
        aun_red_buffer[i - UPDATE_SIZE] = aun_red_buffer[i];
        aun_ir_buffer[i - UPDATE_SIZE] = aun_ir_buffer[i];
    }
}

static int max30102_measure_once(void)
{
    int32_t hr;
    int32_t spo2;
    int32_t hr_sum = 0;
    int32_t spo2_sum = 0;
    int32_t hr_min = HR_MAX_VALID;
    int32_t hr_max = HR_MIN_VALID;
    int32_t spo2_min = SPO2_MAX_VALID;
    int32_t spo2_max = SPO2_MIN_VALID;
    int valid_count = 0;
    rt_tick_t started_at = rt_tick_get();
    rt_tick_t timeout_ticks = rt_tick_from_millisecond(MEASURE_COMMAND_TIMEOUT_MS);

    rt_kprintf("MAX30102 measuring once...\n");

    while (1)
    {
        if (max30102_buffer_has_finger() == RT_FALSE)
        {
            app_max30102_clear_value();
            rt_kprintf("No finger\n");
            return APP_MAX30102_ERR_FINGER_LOST;
        }

        if (max30102_calc_valid_value(&hr, &spo2) == RT_TRUE)
        {
            hr_sum += hr;
            spo2_sum += spo2;
            valid_count++;

            if (hr < hr_min)
            {
                hr_min = hr;
            }

            if (hr > hr_max)
            {
                hr_max = hr;
            }

            if (spo2 < spo2_min)
            {
                spo2_min = spo2;
            }

            if (spo2 > spo2_max)
            {
                spo2_max = spo2;
            }

            rt_kprintf("MAX30102 sample %d: Heart Rate = %d bpm, SpO2 = %d%%\n",
                       valid_count,
                       hr,
                       spo2);

            if ((valid_count >= MEASURE_VALID_MIN) &&
                (((hr_max - hr_min) <= HR_STABLE_RANGE &&
                  (spo2_max - spo2_min) <= SPO2_STABLE_RANGE) ||
                 (valid_count >= MEASURE_VALID_MAX)))
            {
                hr = (hr_sum + valid_count / 2) / valid_count;
                spo2 = (spo2_sum + valid_count / 2) / valid_count;

                app_max30102_publish_value(hr, spo2);

                rt_kprintf("MAX30102 final: Heart Rate = %d bpm, SpO2 = %d%%\n",
                           hr,
                           spo2);
                return 0;
            }
        }
        else
        {
            rt_kprintf("Measuring...\n");
        }

        max30102_shift_buffer();
        collect_samples(BUFFER_SIZE - UPDATE_SIZE, BUFFER_SIZE);

        if ((rt_tick_t)(rt_tick_get() - started_at) >= timeout_ticks)
        {
            rt_kprintf("MAX30102 measurement timeout\n");
            return APP_MAX30102_ERR_UNSTABLE;
        }
    }
}

static void max30102_thread_entry(void *parameter)
{
    while (max30102_i2c == RT_NULL)
    {
        max30102_i2c = rt_i2c_bus_device_find(MAX30102_I2C_BUS_NAME);
        if (max30102_i2c == RT_NULL)
        {
            rt_kprintf("cannot find %s, retrying\n", MAX30102_I2C_BUS_NAME);
            rt_thread_mdelay(1000);
        }
    }

    rt_kprintf("find %s success\n", MAX30102_I2C_BUS_NAME);

    if (max30102_init() == RT_EOK)
    {
        max30102_led_off();
    }
    else
    {
        rt_kprintf("MAX30102 initial init failed, wait command retry\n");
    }

    while (1)
    {
        rt_tick_t wait_started;
        rt_bool_t finger_found = RT_FALSE;

        rt_sem_take(&max30102_request_sem, RT_WAITING_FOREVER);
        if (max30102_init() != RT_EOK)
        {
            request_result_status = APP_MAX30102_ERR_NOT_READY;
            rt_sem_release(&max30102_done_sem);
            continue;
        }
        app_max30102_clear_value();
        rt_kprintf("MAX30102 command received, place finger\n");
        wait_started = rt_tick_get();

        while ((rt_tick_t)(rt_tick_get() - wait_started) <
               rt_tick_from_millisecond(FINGER_COMMAND_TIMEOUT_MS))
        {
            if (max30102_read_finger_status() == RT_TRUE)
            {
                finger_found = RT_TRUE;
                break;
            }
            rt_thread_mdelay(FINGER_WAIT_DELAY_MS);
        }

        request_result_status = APP_MAX30102_ERR_NO_FINGER;
        if (finger_found == RT_TRUE)
        {
            rt_kprintf("Finger detected, collecting samples...\n");
            collect_samples(0, BUFFER_SIZE);
            request_result_status = max30102_measure_once();
        }
        else
        {
            rt_kprintf("MAX30102 wait finger timeout\n");
        }

        rt_mutex_take(&max30102_data_lock, RT_WAITING_FOREVER);
        request_result_hr = last_hr;
        request_result_spo2 = last_spo2;
        rt_mutex_release(&max30102_data_lock);
        max30102_led_off();
        rt_sem_release(&max30102_done_sem);
    }
}

int app_max30102_measure(int *heart_rate, int *spo2, rt_int32_t timeout_ms)
{
    rt_err_t ret;

    if (heart_rate == RT_NULL || spo2 == RT_NULL || max30102_started == RT_FALSE)
    {
        return APP_MAX30102_ERR_NOT_READY;
    }

    if (rt_mutex_take(&max30102_request_lock, 0) != RT_EOK)
    {
        return APP_MAX30102_ERR_BUSY;
    }

    while (rt_sem_trytake(&max30102_done_sem) == RT_EOK)
    {
    }
    rt_sem_release(&max30102_request_sem);
    ret = rt_sem_take(&max30102_done_sem,
                      timeout_ms < 0 ? RT_WAITING_FOREVER :
                      rt_tick_from_millisecond(timeout_ms));

    if (ret == RT_EOK && request_result_status == 0)
    {
        *heart_rate = request_result_hr;
        *spo2 = request_result_spo2;
        ret = RT_EOK;
    }
    else
    {
        *heart_rate = 0;
        *spo2 = 0;
        if (ret != RT_EOK)
        {
            request_result_status = APP_MAX30102_ERR_TIMEOUT;
        }
    }

    rt_mutex_release(&max30102_request_lock);
    return ret == RT_EOK && request_result_status == 0 ? 0 : request_result_status;
}

int app_max30102_get(int *heart_rate, int *spo2)
{
    if (heart_rate == RT_NULL || spo2 == RT_NULL)
    {
        return -1;
    }

    if (max30102_data_lock_inited)
    {
        rt_mutex_take(&max30102_data_lock, RT_WAITING_FOREVER);
        if (result_ready == RT_TRUE)
        {
            *heart_rate = last_hr;
            *spo2 = last_spo2;
            result_ready = RT_FALSE;
        }
        else
        {
            *heart_rate = 0;
            *spo2 = 0;
        }
        rt_mutex_release(&max30102_data_lock);
    }
    else
    {
        if (result_ready == RT_TRUE)
        {
            *heart_rate = last_hr;
            *spo2 = last_spo2;
            result_ready = RT_FALSE;
        }
        else
        {
            *heart_rate = 0;
            *spo2 = 0;
        }
    }

    if (*heart_rate <= 0 || *spo2 <= 0)
    {
        return -1;
    }

    return 0;
}

int app_max30102_start(void)
{
    rt_err_t ret;

    if (max30102_started == RT_TRUE)
    {
        return 0;
    }

    if (!max30102_data_lock_inited)
    {
        rt_mutex_init(&max30102_data_lock,
                      "maxdata",
                      RT_IPC_FLAG_FIFO);

        max30102_data_lock_inited = 1;
    }

    ret = rt_mutex_init(&max30102_request_lock,
                        "max_req",
                        RT_IPC_FLAG_FIFO);
    if (ret != RT_EOK)
    {
        rt_kprintf("MAX30102 request mutex init failed, ret=%d\n", ret);
        return -1;
    }
    rt_sem_init(&max30102_request_sem, "max_go", 0, RT_IPC_FLAG_FIFO);
    rt_sem_init(&max30102_done_sem, "max_done", 0, RT_IPC_FLAG_FIFO);

    ret = rt_thread_init(&max30102_thread,
                         "max30102",
                         max30102_thread_entry,
                         RT_NULL,
                         max30102_thread_stack,
                         sizeof(max30102_thread_stack),
                         20,
                         10);

    if (ret == RT_EOK)
    {
        max30102_started = RT_TRUE;
        rt_thread_startup(&max30102_thread);
        rt_kprintf("MAX30102 thread started\n");
        return 0;
    }

    rt_kprintf("MAX30102 thread init failed, ret=%d\n", ret);
    rt_mutex_detach(&max30102_request_lock);
    return -1;
}

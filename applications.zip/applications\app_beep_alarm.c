#include <rtthread.h>
#include <rtdevice.h>
#include <board.h>
#include <stdio.h>
#include <string.h>

#include "app_time.h"
#include "app_beep_alarm.h"
#include "app_esp32_slave.h"
#include "app_k230_auth.h"
#include "app_v100c.h"
#include "app_ram.h"

#define DBG_TAG "app.beep"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>

#define BEEP_PIN            GET_PIN(B, 0)

#define BEEP_ON_LEVEL       PIN_HIGH
#define BEEP_OFF_LEVEL      PIN_LOW

#define ALARM_COUNT         APP_MEDICINE_PLAN_MAX_COUNT
#define ALARM_WEB_PLAN_COUNT 3
#define ALARM_TRIGGER_WINDOW_SEC 59
#define ALARM_BEEP_TIMEOUT_MS 60000U
#define ALARM_FACE_CHECK_MS 500U
#define ALARM_CALL_DELAY_MS 120000U
#define ALARM_RESPONSE_CHECK_MS 1000U
#define ALARM_SMS_TEXT      "该吃药了"

typedef struct
{
    int sec;
    rt_bool_t done;
    rt_bool_t enabled;
    app_medicine_plan_t plan;
} alarm_plan_t;

static alarm_plan_t alarm_list[ALARM_COUNT] =
{
    {0, RT_FALSE, RT_TRUE,  {1, 8,  0, "patient", "", 0, {{0}}}},
    {0, RT_FALSE, RT_TRUE,  {2, 12, 0, "patient", "", 0, {{0}}}},
    {0, RT_FALSE, RT_TRUE,  {3, 20, 47, "patient", "", 0, {{0}}}},
    {0, RT_FALSE, RT_FALSE, {4, 0,  0, "patient", "", 0, {{0}}}},
    {0, RT_FALSE, RT_FALSE, {5, 0,  0, "patient", "", 0, {{0}}}},
    {0, RT_FALSE, RT_FALSE, {6, 0,  0, "patient", "", 0, {{0}}}},
};
static int alarm_taken_day[ALARM_COUNT] = {0};
static int alarm_response_day[ALARM_COUNT] = {0};

static rt_bool_t beep_alarm_started = RT_FALSE;
static struct rt_thread beep_alarm_thread;
static rt_uint8_t beep_alarm_stack[2048] APP_CCMRAM;

static int time_string_to_hms(const char *time_str, int *hour, int *min, int *sec);
static int alarm_current_day(void);
static rt_bool_t alarm_slot_taken_today(int index);
static rt_bool_t alarm_slot_responded_today(int index);
static rt_bool_t alarm_wait_for_approach(int alarm_index);
static rt_bool_t alarm_wait_for_medicine_response(int plan_slot);
static int alarm_send_sms_reminder(const app_medicine_plan_t *plan);
static int alarm_call_user_reminder(const app_medicine_plan_t *plan);

static void beep_on(void)
{
    rt_pin_write(BEEP_PIN, BEEP_ON_LEVEL);
}

static void beep_off(void)
{
    rt_pin_write(BEEP_PIN, BEEP_OFF_LEVEL);
}

void app_beep_alarm_set_time(int index, int hour, int min)
{
    if (index < 0 || index >= ALARM_COUNT)
    {
        return;
    }

    if (hour < 0 || hour > 23 || min < 0 || min > 59)
    {
        return;
    }

    alarm_list[index].plan.plan_slot = index + 1;
    alarm_list[index].plan.hour = hour;
    alarm_list[index].plan.min = min;
    alarm_list[index].plan.earliest_hour = hour;
    alarm_list[index].plan.earliest_min = min;
    alarm_list[index].plan.latest_hour = hour;
    alarm_list[index].plan.latest_min = min;
    alarm_list[index].sec = 0;
    alarm_list[index].done = alarm_slot_taken_today(index);
    alarm_list[index].enabled = RT_TRUE;

    LOG_I("alarm %d update to %02d:%02d", index + 1, hour, min);
}

void app_beep_alarm_set_user(int index, const char *user_name)
{
    if (index < 0 || index >= ALARM_COUNT)
    {
        return;
    }

    if (user_name == RT_NULL || user_name[0] == '\0')
    {
        rt_snprintf(alarm_list[index].plan.user_name,
                    sizeof(alarm_list[index].plan.user_name),
                    "patient");
        return;
    }

    rt_snprintf(alarm_list[index].plan.user_name,
                sizeof(alarm_list[index].plan.user_name),
                "%s",
                user_name);

    LOG_I("alarm %d user update to %s", index + 1, alarm_list[index].plan.user_name);
}

void app_beep_alarm_disable(int index)
{
    if (index < 0 || index >= ALARM_COUNT)
    {
        return;
    }

    alarm_list[index].enabled = RT_FALSE;
    alarm_list[index].done = RT_FALSE;
}

int app_beep_alarm_set_plan(const app_medicine_plan_t *plan)
{
    int index;

    if (plan == RT_NULL || plan->plan_slot < 1 ||
        plan->plan_slot > ALARM_COUNT)
    {
        return -1;
    }

    if (plan->hour < 0 || plan->hour > 23 || plan->min < 0 || plan->min > 59)
    {
        return -1;
    }

    index = plan->plan_slot - 1;
    alarm_list[index].plan = *plan;
    alarm_list[index].plan.plan_slot = plan->plan_slot;
    if (alarm_list[index].plan.earliest_hour < 0 ||
        alarm_list[index].plan.earliest_hour > 23 ||
        alarm_list[index].plan.earliest_min < 0 ||
        alarm_list[index].plan.earliest_min > 59)
    {
        alarm_list[index].plan.earliest_hour = plan->hour;
        alarm_list[index].plan.earliest_min = plan->min;
    }
    if (alarm_list[index].plan.latest_hour < 0 ||
        alarm_list[index].plan.latest_hour > 23 ||
        alarm_list[index].plan.latest_min < 0 ||
        alarm_list[index].plan.latest_min > 59)
    {
        alarm_list[index].plan.latest_hour = plan->hour;
        alarm_list[index].plan.latest_min = plan->min;
    }
    if (alarm_list[index].plan.user_name[0] == '\0')
    {
        rt_snprintf(alarm_list[index].plan.user_name,
                    sizeof(alarm_list[index].plan.user_name),
                    "patient");
    }
    alarm_list[index].sec = 0;
    alarm_list[index].done = RT_FALSE;
    alarm_list[index].enabled = RT_TRUE;

    LOG_I("cloud alarm plan %d update to %02d:%02d window=%02d:%02d-%02d:%02d user=%s medicines=%d",
          plan->plan_slot,
          plan->hour,
          plan->min,
          alarm_list[index].plan.earliest_hour,
          alarm_list[index].plan.earliest_min,
          alarm_list[index].plan.latest_hour,
          alarm_list[index].plan.latest_min,
          alarm_list[index].plan.user_name,
          alarm_list[index].plan.medicine_count);
    return 0;
}

int app_beep_alarm_get_plan(int plan_slot, app_medicine_plan_t *plan)
{
    int index;

    if (plan == RT_NULL || plan_slot < 1 || plan_slot > ALARM_COUNT)
    {
        return -1;
    }

    index = plan_slot - 1;
    if (alarm_list[index].enabled != RT_TRUE)
    {
        return -1;
    }

    *plan = alarm_list[index].plan;
    return 0;
}

int app_beep_alarm_get_current_plan(app_medicine_plan_t *plan)
{
    char time_buf[16];
    int hour = 0;
    int min = 0;
    int sec = 0;
    int now_min;
    int i;

    if (plan == RT_NULL)
    {
        return -1;
    }

    app_time_get_string(RT_NULL, 0, time_buf, sizeof(time_buf));
    if (time_string_to_hms(time_buf, &hour, &min, &sec) != 3)
    {
        return -1;
    }

    now_min = hour * 60 + min;
    for (i = 0; i < ALARM_WEB_PLAN_COUNT && i < ALARM_COUNT; i++)
    {
        int earliest_min;
        int latest_min;

        if (alarm_list[i].enabled != RT_TRUE ||
            alarm_list[i].plan.medicine_count <= 0)
        {
            continue;
        }

        earliest_min = alarm_list[i].plan.earliest_hour * 60 +
                       alarm_list[i].plan.earliest_min;
        latest_min = alarm_list[i].plan.latest_hour * 60 +
                     alarm_list[i].plan.latest_min;
        if (earliest_min <= latest_min)
        {
            if (now_min >= earliest_min && now_min <= latest_min)
            {
                *plan = alarm_list[i].plan;
                return 0;
            }
        }
        else
        {
            if (now_min >= earliest_min || now_min <= latest_min)
            {
                *plan = alarm_list[i].plan;
                return 0;
            }
        }
    }

    return -1;
}

static int time_string_to_hms(const char *time_str, int *hour, int *min, int *sec)
{
    if (time_str == RT_NULL || hour == RT_NULL || min == RT_NULL || sec == RT_NULL)
    {
        return -1;
    }

    return sscanf(time_str, "%d:%d:%d", hour, min, sec);
}

static int date_string_to_day(const char *date_str, int *day)
{
    int year;
    int month;

    if (date_str == RT_NULL || day == RT_NULL)
    {
        return -1;
    }

    return sscanf(date_str, "%d-%d-%d", &year, &month, day);
}

static int alarm_current_day(void)
{
    char date_buf[16];
    char time_buf[16];
    int day = -1;

    app_time_get_string(date_buf, sizeof(date_buf), time_buf, sizeof(time_buf));
    if (date_string_to_day(date_buf, &day) != 3)
    {
        return -1;
    }

    return day;
}

static rt_bool_t alarm_slot_taken_today(int index)
{
    int day;

    if (index < 0 || index >= ALARM_COUNT)
    {
        return RT_FALSE;
    }

    day = alarm_current_day();
    if (day < 1)
    {
        return RT_FALSE;
    }

    return alarm_taken_day[index] == day ? RT_TRUE : RT_FALSE;
}

static rt_bool_t alarm_slot_responded_today(int index)
{
    int day;

    if (index < 0 || index >= ALARM_COUNT)
    {
        return RT_FALSE;
    }

    day = alarm_current_day();
    if (day < 1)
    {
        return RT_FALSE;
    }

    return alarm_response_day[index] == day ? RT_TRUE : RT_FALSE;
}

void app_beep_alarm_mark_taken(int plan_slot)
{
    int index = plan_slot - 1;
    int day;

    if (index < 0 || index >= ALARM_COUNT)
    {
        return;
    }

    day = alarm_current_day();
    if (day < 1)
    {
        return;
    }

    alarm_taken_day[index] = day;
    alarm_response_day[index] = day;
    alarm_list[index].done = RT_TRUE;
    LOG_I("alarm %d marked taken for day %d", plan_slot, day);
}

void app_beep_alarm_mark_response(int plan_slot)
{
    int index = plan_slot - 1;
    int day;

    if (index < 0 || index >= ALARM_COUNT)
    {
        return;
    }

    day = alarm_current_day();
    if (day < 1)
    {
        return;
    }

    alarm_response_day[index] = day;
    LOG_I("alarm %d medicine request response marked for day %d",
          plan_slot,
          day);
}

rt_bool_t app_beep_alarm_is_taken(int plan_slot)
{
    return alarm_slot_taken_today(plan_slot - 1);
}

static void alarm_done_clear(void)
{
    int i;

    for (i = 0; i < ALARM_COUNT; i++)
    {
        alarm_list[i].done = RT_FALSE;
        alarm_taken_day[i] = 0;
        alarm_response_day[i] = 0;
    }
}

static rt_bool_t alarm_k230_registered_face_detected(rt_tick_t start_tick,
                                                     rt_tick_t timeout_tick)
{
    app_k230_auth_status_t status;

    if (app_k230_get_status(&status) != 0)
    {
        return RT_FALSE;
    }

    if ((status.update_tick - start_tick) >= timeout_tick)
    {
        return RT_FALSE;
    }

    if (strcmp(status.trigger_type, "recognized_face") == 0 &&
        strcmp(status.permission, "allowed") == 0 &&
        strcmp(status.user_name, "unknown") != 0)
    {
        return RT_TRUE;
    }

    return RT_FALSE;
}

static rt_bool_t alarm_wait_for_approach(int alarm_index)
{
    rt_tick_t start_tick;
    rt_tick_t timeout_tick;

    start_tick = rt_tick_get();
    timeout_tick = rt_tick_from_millisecond(ALARM_BEEP_TIMEOUT_MS);

    beep_on();

    while ((rt_tick_get() - start_tick) < timeout_tick)
    {
        if (alarm_k230_registered_face_detected(start_tick, timeout_tick) == RT_TRUE)
        {
            beep_off();
            app_esp32_slave_send_medicine_reminder_stop(&alarm_list[alarm_index].plan,
                                                        "recognized_face");
            LOG_I("alarm %d stopped, registered face detected",
                  alarm_index + 1);
            return RT_TRUE;
        }

        rt_thread_mdelay(ALARM_FACE_CHECK_MS);
    }

    beep_off();
    LOG_I("alarm %d no approach within %d seconds",
          alarm_index + 1,
          ALARM_BEEP_TIMEOUT_MS / 1000U);

    return RT_FALSE;
}

static int alarm_send_sms_reminder(const app_medicine_plan_t *plan)
{
    if (plan == RT_NULL)
    {
        return -1;
    }

    if (plan->user_phone[0] == '\0')
    {
        LOG_W("alarm %d no approach, but user phone is empty",
              plan->plan_slot);
        return -1;
    }

    LOG_I("alarm %d no approach, send sms to %s",
          plan->plan_slot,
          plan->user_phone);

    return app_v100c_send_sms(plan->user_phone, ALARM_SMS_TEXT);
}

static rt_bool_t alarm_wait_for_medicine_response(int plan_slot)
{
    rt_tick_t start_tick;
    rt_tick_t timeout_tick;
    int index = plan_slot - 1;

    if (index < 0 || index >= ALARM_COUNT)
    {
        return RT_FALSE;
    }

    start_tick = rt_tick_get();
    timeout_tick = rt_tick_from_millisecond(ALARM_CALL_DELAY_MS);

    while ((rt_tick_get() - start_tick) < timeout_tick)
    {
        if (alarm_slot_responded_today(index) == RT_TRUE ||
            alarm_slot_taken_today(index) == RT_TRUE)
        {
            LOG_I("alarm %d user responded after sms, skip call", plan_slot);
            return RT_TRUE;
        }

        rt_thread_mdelay(ALARM_RESPONSE_CHECK_MS);
    }

    return RT_FALSE;
}

static int alarm_call_user_reminder(const app_medicine_plan_t *plan)
{
    if (plan == RT_NULL)
    {
        return -1;
    }

    if (plan->user_phone[0] == '\0')
    {
        LOG_W("alarm %d no response after sms, but user phone is empty",
              plan->plan_slot);
        return -1;
    }

    LOG_I("alarm %d no response after sms, call user %s",
          plan->plan_slot,
          plan->user_phone);

    return app_v100c_call(plan->user_phone);
}

static void beep_alarm_entry(void *parameter)
{
    char date_buf[16];
    char time_buf[16];

    int hour = 0;
    int min = 0;
    int sec = 0;
    int cur_day = -1;
    int last_day = -1;
    int i;

    rt_thread_mdelay(5000);

    LOG_I("beep alarm thread start");

    rt_pin_mode(BEEP_PIN, PIN_MODE_OUTPUT);
    beep_off();

    while (1)
    {
        app_time_get_string(date_buf, sizeof(date_buf), time_buf, sizeof(time_buf));

        if ((time_string_to_hms(time_buf, &hour, &min, &sec) == 3) &&
            (date_string_to_day(date_buf, &cur_day) == 3))
        {
            if (cur_day != last_day)
            {
                last_day = cur_day;
                alarm_done_clear();
            }

            for (i = 0; i < ALARM_COUNT; i++)
            {
                if ((alarm_list[i].enabled == RT_TRUE) &&
                    (alarm_list[i].done == RT_FALSE) &&
                    alarm_slot_taken_today(i) == RT_TRUE)
                {
                    alarm_list[i].done = RT_TRUE;
                    LOG_I("alarm %d skipped, medicine already taken today",
                          i + 1);
                    continue;
                }

                if ((alarm_list[i].enabled == RT_TRUE) &&
                    (alarm_list[i].done == RT_FALSE) &&
                    (hour == alarm_list[i].plan.hour) &&
                    (min  == alarm_list[i].plan.min) &&
                    (sec >= alarm_list[i].sec) &&
                    (sec <= ALARM_TRIGGER_WINDOW_SEC))
                {
                    rt_bool_t approached;

                    LOG_I("alarm %d time arrived: %s %s, beep up to %d seconds",
                          i + 1,
                          date_buf,
                          time_buf,
                          ALARM_BEEP_TIMEOUT_MS / 1000U);

                    app_esp32_slave_send_medicine_reminder(&alarm_list[i].plan);

                    approached = alarm_wait_for_approach(i);
                    if (approached != RT_TRUE)
                    {
                        if (alarm_send_sms_reminder(&alarm_list[i].plan) == 0 &&
                            alarm_wait_for_medicine_response(
                                alarm_list[i].plan.plan_slot) != RT_TRUE)
                        {
                            alarm_call_user_reminder(&alarm_list[i].plan);
                        }
                    }

                    alarm_list[i].done = RT_TRUE;
                }
            }
        }

        rt_thread_mdelay(200);
    }
}

int app_beep_alarm_start(void)
{
    rt_err_t ret;

    if (beep_alarm_started == RT_TRUE)
    {
        return 0;
    }

    ret = rt_thread_init(&beep_alarm_thread,
                         "beep_alarm",
                         beep_alarm_entry,
                         RT_NULL,
                         beep_alarm_stack,
                         sizeof(beep_alarm_stack),
                         21,
                         10);

    if (ret == RT_EOK)
    {
        beep_alarm_started = RT_TRUE;
        rt_thread_startup(&beep_alarm_thread);
        return 0;
    }

    LOG_E("init beep alarm thread failed, ret=%d", ret);

    return -1;
}

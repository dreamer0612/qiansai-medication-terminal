#ifndef __APP_SENSOR_H__
#define __APP_SENSOR_H__

int app_sensor_start(void);
int app_sensor_get(int *temperature, int *humidity);

#endif

#include <rtthread.h>
#include <rtdevice.h>
#include <board.h>
#include <aht10.h>

#include "app_sensor.h"

#define DBG_TAG "app.sensor"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>

#define AHT10_I2C_BUS_NAME "i2c3"
#define SENSOR_LOG_EVERY_N 15

static aht10_device_t aht10_dev = RT_NULL;
static int sensor_temperature = 0;
static int sensor_humidity = 0;
static rt_mutex_t sensor_mutex = RT_NULL;
static rt_bool_t sensor_started = RT_FALSE;
static rt_bool_t sensor_valid = RT_FALSE;

static int app_sensor_init(void)
{
    if (aht10_dev != RT_NULL)
    {
        return 0;
    }

    aht10_dev = aht10_init(AHT10_I2C_BUS_NAME);

    if (aht10_dev == RT_NULL)
    {
        LOG_E("aht10 init failed, i2c bus: %s", AHT10_I2C_BUS_NAME);
        return -1;
    }

    LOG_I("aht10 init success, i2c bus: %s", AHT10_I2C_BUS_NAME);

    rt_thread_mdelay(2000);

    return 0;
}

static void sensor_value_update(int temp, int humi)
{
    if (sensor_mutex != RT_NULL)
    {
        rt_mutex_take(sensor_mutex, RT_WAITING_FOREVER);
    }

    sensor_temperature = temp;
    sensor_humidity = humi;
    sensor_valid = RT_TRUE;

    if (sensor_mutex != RT_NULL)
    {
        rt_mutex_release(sensor_mutex);
    }
}

static void app_sensor_entry(void *parameter)
{
    float temp;
    float humi;
    int log_count = 0;

    if (app_sensor_init() != 0)
    {
        return;
    }

    while (1)
    {
        temp = aht10_read_temperature(aht10_dev);

        rt_thread_mdelay(1000);

        humi = aht10_read_humidity(aht10_dev);

        if (temp > -40 && temp < 85 && humi >= 0 && humi <= 100)
        {
            sensor_value_update((int)temp, (int)humi);

            log_count++;
            if (log_count >= SENSOR_LOG_EVERY_N)
            {
                log_count = 0;
                LOG_I("temperature=%d, humidity=%d", (int)temp, (int)humi);
            }
        }
        else
        {
            LOG_E("aht10 read invalid, temperature=%d, humidity=%d",
                  (int)temp,
                  (int)humi);
        }

        rt_thread_mdelay(3000);
    }
}

int app_sensor_start(void)
{
    rt_thread_t tid;

    if (sensor_started == RT_TRUE)
    {
        return 0;
    }

    if (sensor_mutex == RT_NULL)
    {
        sensor_mutex = rt_mutex_create("sen_mtx", RT_IPC_FLAG_FIFO);
    }

    tid = rt_thread_create("sensor",
                           app_sensor_entry,
                           RT_NULL,
                           2048,
                           21,
                           10);

    if (tid != RT_NULL)
    {
        sensor_started = RT_TRUE;
        rt_thread_startup(tid);
        return 0;
    }

    LOG_E("sensor thread create failed");

    return -1;
}

int app_sensor_get(int *temperature, int *humidity)
{
    if (temperature == RT_NULL || humidity == RT_NULL)
    {
        return -1;
    }

    if (sensor_mutex != RT_NULL)
    {
        rt_mutex_take(sensor_mutex, RT_WAITING_FOREVER);
    }

    *temperature = sensor_temperature;
    *humidity = sensor_humidity;

    if (sensor_mutex != RT_NULL)
    {
        rt_mutex_release(sensor_mutex);
    }

    if (sensor_valid != RT_TRUE)
    {
        return -1;
    }

    return 0;
}

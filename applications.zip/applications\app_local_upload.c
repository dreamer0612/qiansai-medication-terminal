#include <rtthread.h>
#include <rtdevice.h>
#include <board.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <cJSON.h>

#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>

#include "app_sensor.h"
#include "app_time.h"
#include "app_beep_alarm.h"
#include "app_body_temp.h"
#include "app_max30102.h"
#include "app_local_upload.h"
#include "app_esp32cam_ctrl.h"
#include "app_ram.h"
#include "app_k230_auth.h"

#define DBG_TAG "local.upload"
#define DBG_LVL DBG_INFO
#include <rtdbg.h>

#define LOCAL_SERVER_HOST "YOUR_SERVER_HOST"
#define LOCAL_SERVER_PORT "3000"
#define LOCAL_SERVER_UPLOAD_PATH "/api/device/upload"
#define LOCAL_SERVER_PLAN_PATH   "/api/device/medicine-plans"
#define LOCAL_SERVER_PLAN_FALLBACK_PATH "/api/medicine/plans"
#define LOCAL_SERVER_TAKEN_PATH  "/api/medicine/taken"
#define LOCAL_SERVER_TAKEN_STATUS_PATH "/api/device/medicine-taken-status"
#define LOCAL_SERVER_PUT_CONTEXT_PATH "/api/device/put-medicine-context"
#define LOCAL_SERVER_PUT_DONE_PATH "/api/device/put-medicine-done"
#define LOCAL_SERVER_CAMERA_CONTROL_PATH "/api/device/camera/control"
#define LOCAL_SERVER_CAMERA_RECORDING_START_PATH "/api/device/camera/medicine-recording/start"
#define LOCAL_SERVER_CAMERA_RECORDING_FINISH_PATH "/api/device/camera/medicine-recording/finish"
#define LOCAL_UPLOAD_INTERVAL_MS 5000
#define LOCAL_CAMERA_CONTROL_INTERVAL_MS 1000
#define LOCAL_CAMERA_RECORDING_HTTP_RETRY_COUNT 3
#define LOCAL_CAMERA_RECORDING_HTTP_RETRY_DELAY_MS 500
#define LOCAL_PLAN_REFRESH_UPLOAD_CYCLES 12

#define LOCAL_UPLOAD_THREAD_STACK_SIZE 4096
#define LOCAL_CAMERA_CONTROL_THREAD_STACK_SIZE 2048
#define LOCAL_HTTP_REQUEST_SIZE        1024
#define LOCAL_HTTP_RESPONSE_SIZE       512
#define LOCAL_PLAN_RESPONSE_SIZE       8192
#define LOCAL_UPLOAD_JSON_SIZE         384

static rt_bool_t upload_started = RT_FALSE;
static rt_mutex_t local_http_lock = RT_NULL;
static rt_mutex_t local_box_lock = RT_NULL;
static char local_http_request[LOCAL_HTTP_REQUEST_SIZE];
static char local_http_response[LOCAL_HTTP_RESPONSE_SIZE];
static char local_camera_control_response[LOCAL_HTTP_RESPONSE_SIZE];
static char local_plan_response[LOCAL_PLAN_RESPONSE_SIZE];
static char local_upload_json[LOCAL_UPLOAD_JSON_SIZE];
static struct rt_thread local_upload_thread;
static struct rt_thread local_camera_control_thread;
ALIGN(RT_ALIGN_SIZE)
static rt_uint8_t local_upload_stack[LOCAL_UPLOAD_THREAD_STACK_SIZE] APP_CCMRAM;
ALIGN(RT_ALIGN_SIZE)
static rt_uint8_t local_camera_control_stack[LOCAL_CAMERA_CONTROL_THREAD_STACK_SIZE] APP_CCMRAM;
static app_medicine_box_state_t local_medicine_boxes[APP_MEDICINE_PLAN_MAX_COUNT];
static app_family_contact_t local_family_contact;

static int local_parse_box_array_lightweight(const char *json_text);

static rt_bool_t local_medicine_box_equal(const app_medicine_box_state_t *a,
                                          const app_medicine_box_state_t *b)
{
    if (a == RT_NULL || b == RT_NULL)
    {
        return RT_FALSE;
    }

    return a->box_id == b->box_id &&
           a->quantity == b->quantity &&
           a->low_threshold == b->low_threshold &&
           strcmp(a->name, b->name) == 0 &&
           strcmp(a->box_name, b->box_name) == 0 ?
           RT_TRUE : RT_FALSE;
}

static void local_notify_k230_medicine_box(const app_medicine_box_state_t *state)
{
    const char *medicine_name;

    if (state == RT_NULL ||
        state->box_id < 1 ||
        state->box_id > APP_MEDICINE_PLAN_MAX_COUNT)
    {
        return;
    }

    medicine_name = state->name[0] != '\0' ? state->name : state->box_name;
    if (medicine_name == RT_NULL || medicine_name[0] == '\0')
    {
        return;
    }

    if (app_k230_send_medicine_stock(state->box_id,
                                     medicine_name,
                                     state->quantity) == 0)
    {
        LOG_I("k230 medicine stock notified: box=%d name=%s quantity=%d",
              state->box_id,
              medicine_name,
              state->quantity);
    }
    else
    {
        LOG_W("k230 medicine stock notify failed: box=%d name=%s quantity=%d",
              state->box_id,
              medicine_name,
              state->quantity);
    }
}

static const char *local_strcasestr(const char *haystack, const char *needle)
{
    int needle_len;
    int i;

    if (haystack == RT_NULL || needle == RT_NULL)
    {
        return RT_NULL;
    }

    needle_len = strlen(needle);
    if (needle_len <= 0)
    {
        return haystack;
    }

    while (*haystack != '\0')
    {
        rt_bool_t match = RT_TRUE;

        for (i = 0; i < needle_len; i++)
        {
            char a = haystack[i];
            char b = needle[i];

            if (a >= 'A' && a <= 'Z')
            {
                a = (char)(a - 'A' + 'a');
            }
            if (b >= 'A' && b <= 'Z')
            {
                b = (char)(b - 'A' + 'a');
            }

            if (a != b)
            {
                match = RT_FALSE;
                break;
            }
        }

        if (match == RT_TRUE)
        {
            return haystack;
        }
        haystack++;
    }

    return RT_NULL;
}

static int local_http_content_length(const char *response)
{
    const char *header;

    header = local_strcasestr(response, "Content-Length:");
    if (header == RT_NULL)
    {
        return -1;
    }

    header += strlen("Content-Length:");
    while (*header == ' ' || *header == '\t')
    {
        header++;
    }

    return atoi(header);
}

static int socket_send_all(int sock, const char *buf, int len)
{
    int sent = 0;

    while (sent < len)
    {
        int ret;

        ret = send(sock, buf + sent, len - sent, 0);

        if (ret <= 0)
        {
            return -1;
        }

        sent += ret;
    }

    return 0;
}

static int local_tcp_connect(void)
{
    struct addrinfo hints;
    struct addrinfo *res = RT_NULL;
    struct addrinfo *p;
    int sock = -1;
    int ret;

    memset(&hints, 0, sizeof(hints));

    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;

    ret = getaddrinfo(LOCAL_SERVER_HOST, LOCAL_SERVER_PORT, &hints, &res);

    if (ret != 0 || res == RT_NULL)
    {
        LOG_D("getaddrinfo failed");
        return -1;
    }

    for (p = res; p != RT_NULL; p = p->ai_next)
    {
        sock = socket(p->ai_family, p->ai_socktype, p->ai_protocol);

        if (sock < 0)
        {
            continue;
        }

        if (connect(sock, p->ai_addr, p->ai_addrlen) == 0)
        {
            break;
        }

        closesocket(sock);
        sock = -1;
    }

    freeaddrinfo(res);

    if (sock < 0)
    {
        LOG_E("tcp connect failed");
        return -1;
    }

    return sock;
}

static int local_http_post(const char *path, const char *json)
{
    int sock;
    int ret;
    int json_len;

    json_len = strlen(json);

    if (local_http_lock != RT_NULL)
    {
        rt_mutex_take(local_http_lock, RT_WAITING_FOREVER);
    }

    sock = local_tcp_connect();

    if (sock < 0)
    {
        if (local_http_lock != RT_NULL)
        {
            rt_mutex_release(local_http_lock);
        }
        return -1;
    }

    rt_snprintf(local_http_request,
                sizeof(local_http_request),
                "POST %s HTTP/1.1\r\n"
                "Host: %s:%s\r\n"
                "Content-Type: application/json\r\n"
                "Content-Length: %d\r\n"
                "Connection: close\r\n"
                "\r\n"
                "%s",
                path,
                LOCAL_SERVER_HOST,
                LOCAL_SERVER_PORT,
                json_len,
                json);

    LOG_D("post json: %s", json);

    ret = socket_send_all(sock, local_http_request, strlen(local_http_request));

    if (ret < 0)
    {
        LOG_E("send http request failed");
        closesocket(sock);
        if (local_http_lock != RT_NULL)
        {
            rt_mutex_release(local_http_lock);
        }
        return -1;
    }

    memset(local_http_response, 0, sizeof(local_http_response));

    ret = recv(sock, local_http_response, sizeof(local_http_response) - 1, 0);

    if (ret > 0)
    {
        local_http_response[ret] = '\0';
        LOG_D("server response: %s", local_http_response);

        if (strncmp(local_http_response, "HTTP/1.1 2", 10) != 0 &&
            strncmp(local_http_response, "HTTP/1.0 2", 10) != 0)
        {
            LOG_E("server rejected upload");
            closesocket(sock);
            if (local_http_lock != RT_NULL)
            {
                rt_mutex_release(local_http_lock);
            }
            return -1;
        }
    }
    else
    {
        LOG_E("recv response failed, ret=%d", ret);
        closesocket(sock);
        if (local_http_lock != RT_NULL)
        {
            rt_mutex_release(local_http_lock);
        }
        return -1;
    }

    closesocket(sock);

    if (local_http_lock != RT_NULL)
    {
        rt_mutex_release(local_http_lock);
    }

    return 0;
}

static int local_http_post_retry(const char *path,
                                 const char *json,
                                 int retry_count,
                                 int retry_delay_ms)
{
    int i;
    int ret = -1;

    for (i = 0; i < retry_count; i++)
    {
        ret = local_http_post(path, json);
        if (ret == 0)
        {
            return 0;
        }

        if (i + 1 < retry_count)
        {
            LOG_W("http post retry: path=%s attempt=%d/%d",
                  path,
                  i + 2,
                  retry_count);
            rt_thread_mdelay(retry_delay_ms);
        }
    }

    return ret;
}

static int local_http_get(const char *path, char *response, int response_size)
{
    int sock;
    int ret;
    int total = 0;
    int content_length = -1;
    char *body;

    if (response == RT_NULL || response_size <= 0)
    {
        return -1;
    }

    if (local_http_lock != RT_NULL)
    {
        rt_mutex_take(local_http_lock, RT_WAITING_FOREVER);
    }

    sock = local_tcp_connect();

    if (sock < 0)
    {
        if (local_http_lock != RT_NULL)
        {
            rt_mutex_release(local_http_lock);
        }
        return -1;
    }

    rt_snprintf(local_http_request,
                sizeof(local_http_request),
                "GET %s HTTP/1.1\r\n"
                "Host: %s:%s\r\n"
                "Connection: close\r\n"
                "\r\n",
                path,
                LOCAL_SERVER_HOST,
                LOCAL_SERVER_PORT);

    ret = socket_send_all(sock, local_http_request, strlen(local_http_request));

    if (ret < 0)
    {
        LOG_E("send get request failed");
        closesocket(sock);
        if (local_http_lock != RT_NULL)
        {
            rt_mutex_release(local_http_lock);
        }
        return -1;
    }

    memset(response, 0, response_size);

    while (1)
    {
        if (total >= response_size - 1)
        {
            break;
        }

        ret = recv(sock, response + total, response_size - total - 1, 0);

        if (ret > 0)
        {
            total += ret;
            response[total] = '\0';

            if (total >= response_size - 1)
            {
                break;
            }

            body = strstr(response, "\r\n\r\n");
            if (body != RT_NULL)
            {
                if (content_length < 0)
                {
                    content_length = local_http_content_length(response);
                }
                body += 4;
                if (content_length >= 0 &&
                    (int)strlen(body) >= content_length)
                {
                    break;
                }
            }
        }
        else
        {
            break;
        }
    }

    closesocket(sock);

    response[total] = '\0';

    if (local_http_lock != RT_NULL)
    {
        rt_mutex_release(local_http_lock);
    }

    if (total <= 0)
    {
        LOG_E("get response failed");
        return -1;
    }

    return total;
}

int app_local_upload_medicine_taken(const app_medicine_plan_t *plan)
{
    char date_buf[16];
    char time_buf[16];
    char json[256];

    if (plan == RT_NULL || plan->plan_slot < 1 ||
        plan->plan_slot > APP_MEDICINE_PLAN_MAX_COUNT)
    {
        return -1;
    }

    app_time_get_string(date_buf, sizeof(date_buf), time_buf, sizeof(time_buf));
    rt_snprintf(json,
                sizeof(json),
                "{\"event\":\"medicine_taken\","
                "\"status\":\"taken\","
                "\"plan_slot\":%d,"
                "\"slot\":%d,"
                "\"user_name\":\"%s\","
                "\"date\":\"%s\","
                "\"time\":\"%s\","
                "\"medicine_count\":%d}",
                plan->plan_slot,
                plan->plan_slot,
                plan->user_name[0] == '\0' ? "patient" : plan->user_name,
                date_buf,
                time_buf,
                plan->medicine_count);

    return local_http_post(LOCAL_SERVER_TAKEN_PATH, json);
}

static void local_json_escape_text(const char *src, char *dst, int dst_size)
{
    int out = 0;

    if (dst == RT_NULL || dst_size <= 0)
    {
        return;
    }

    if (src == RT_NULL)
    {
        dst[0] = '\0';
        return;
    }

    while (*src != '\0' && out < dst_size - 1)
    {
        if ((*src == '"' || *src == '\\') && out < dst_size - 2)
        {
            dst[out++] = '\\';
            dst[out++] = *src++;
            continue;
        }

        if ((unsigned char)*src < 0x20)
        {
            src++;
            continue;
        }

        dst[out++] = *src++;
    }

    dst[out] = '\0';
}

int app_local_upload_camera_recording_start(const app_medicine_plan_t *plan)
{
    char date_buf[16];
    char time_buf[16];
    char user_name_json[APP_MEDICINE_USER_NAME_LEN * 2];
    char json[256];
    int ret;

    if (plan == RT_NULL)
    {
        return -1;
    }

    app_time_get_string(date_buf, sizeof(date_buf), time_buf, sizeof(time_buf));
    local_json_escape_text(plan->user_name[0] == '\0' ? "patient" : plan->user_name,
                           user_name_json,
                           sizeof(user_name_json));
    rt_snprintf(json,
                sizeof(json),
                "{\"planSlot\":%d,"
                "\"slot\":%d,"
                "\"userName\":\"%s\","
                "\"date\":\"%s\","
                "\"time\":\"%s\","
                "\"title\":\"medicine_auto_record\"}",
                plan->plan_slot,
                plan->plan_slot,
                user_name_json,
                date_buf,
                time_buf);

    ret = local_http_post_retry(LOCAL_SERVER_CAMERA_RECORDING_START_PATH,
                                json,
                                LOCAL_CAMERA_RECORDING_HTTP_RETRY_COUNT,
                                LOCAL_CAMERA_RECORDING_HTTP_RETRY_DELAY_MS);
    if (ret == 0)
    {
        LOG_I("medicine camera recording start uploaded: plan_slot=%d",
              plan->plan_slot);
    }
    else
    {
        LOG_E("medicine camera recording start upload failed: plan_slot=%d",
              plan->plan_slot);
    }

    return ret;
}

int app_local_upload_camera_recording_finish(const app_medicine_plan_t *plan,
                                             const char *status)
{
    char date_buf[16];
    char time_buf[16];
    char status_json[32];
    char json[160];
    int ret;

    app_time_get_string(date_buf, sizeof(date_buf), time_buf, sizeof(time_buf));
    local_json_escape_text(status == RT_NULL ? "completed" : status,
                           status_json,
                           sizeof(status_json));
    rt_snprintf(json,
                sizeof(json),
                "{\"planSlot\":%d,"
                "\"slot\":%d,"
                "\"status\":\"%s\","
                "\"date\":\"%s\","
                "\"time\":\"%s\"}",
                plan == RT_NULL ? 0 : plan->plan_slot,
                plan == RT_NULL ? 0 : plan->plan_slot,
                status_json,
                date_buf,
                time_buf);

    ret = local_http_post_retry(LOCAL_SERVER_CAMERA_RECORDING_FINISH_PATH,
                                json,
                                LOCAL_CAMERA_RECORDING_HTTP_RETRY_COUNT,
                                LOCAL_CAMERA_RECORDING_HTTP_RETRY_DELAY_MS);
    if (ret == 0)
    {
        LOG_I("medicine camera recording finish uploaded: plan_slot=%d status=%s",
              plan == RT_NULL ? 0 : plan->plan_slot,
              status == RT_NULL ? "completed" : status);
    }
    else
    {
        LOG_E("medicine camera recording finish upload failed: plan_slot=%d status=%s",
              plan == RT_NULL ? 0 : plan->plan_slot,
              status == RT_NULL ? "completed" : status);
    }

    return ret;
}

int app_local_upload_get_put_tasks(app_medicine_box_state_t *boxes,
                                   int max_count,
                                   int *count)
{
    int i;
    int http_ret;
    int cached_box_count = 0;
    int out_count = 0;

    if (boxes == RT_NULL || max_count <= 0 || count == RT_NULL)
    {
        return -1;
    }

    http_ret = local_http_get(LOCAL_SERVER_PUT_CONTEXT_PATH,
                              local_plan_response,
                              sizeof(local_plan_response));
    if (http_ret > 0)
    {
        (void)local_parse_box_array_lightweight(local_plan_response);
    }

    if (local_box_lock != RT_NULL)
    {
        rt_mutex_take(local_box_lock, RT_WAITING_FOREVER);
    }

    for (i = 0; i < APP_MEDICINE_PLAN_MAX_COUNT && out_count < max_count; i++)
    {
        app_medicine_box_state_t *box = &local_medicine_boxes[i];

        if (box->box_id < 1 || box->box_id > APP_MEDICINE_PLAN_MAX_COUNT ||
            box->name[0] == '\0')
        {
            continue;
        }

        cached_box_count++;
        if (box->quantity > box->low_threshold)
        {
            continue;
        }

        boxes[out_count++] = *box;
    }

    if (local_box_lock != RT_NULL)
    {
        rt_mutex_release(local_box_lock);
    }

    *count = out_count;
    if (out_count <= 0 && cached_box_count <= 0 && http_ret <= 0)
    {
        return -3;
    }

    return out_count > 0 ? 0 : -2;
}

int app_local_upload_get_box_state(int box_id, app_medicine_box_state_t *box)
{
    if (box == RT_NULL || box_id < 1 || box_id > APP_MEDICINE_PLAN_MAX_COUNT)
    {
        return -1;
    }

    if (local_box_lock != RT_NULL)
    {
        rt_mutex_take(local_box_lock, RT_WAITING_FOREVER);
    }

    *box = local_medicine_boxes[box_id - 1];

    if (local_box_lock != RT_NULL)
    {
        rt_mutex_release(local_box_lock);
    }

    if (box->box_id < 1 || box->box_id > APP_MEDICINE_PLAN_MAX_COUNT)
    {
        return -1;
    }

    return 0;
}

int app_local_upload_medicine_put_done(int box_id,
                                       const char *medicine_name,
                                       int put_count,
                                       int stock_count)
{
    char date_buf[16];
    char time_buf[16];
    char medicine_name_json[APP_MEDICINE_NAME_LEN * 2];
    char json[384];
    app_medicine_box_state_t updated_state;
    rt_bool_t should_notify = RT_FALSE;
    int ret;

    if (box_id < 1 || box_id > APP_MEDICINE_PLAN_MAX_COUNT ||
        put_count <= 0)
    {
        return -1;
    }

    app_time_get_string(date_buf, sizeof(date_buf), time_buf, sizeof(time_buf));
    local_json_escape_text(medicine_name, medicine_name_json,
                           sizeof(medicine_name_json));
    rt_snprintf(json,
                sizeof(json),
                "{\"box_id\":%d,"
                "\"boxId\":%d,"
                "\"medicine_name\":\"%s\","
                "\"medicineName\":\"%s\","
                "\"put_count\":%d,"
                "\"putCount\":%d,"
                "\"stock_count\":%d,"
                "\"stockCount\":%d,"
                "\"date\":\"%s\","
                "\"time\":\"%s\"}",
                box_id,
                box_id,
                medicine_name_json,
                medicine_name_json,
                put_count,
                put_count,
                stock_count,
                stock_count,
                date_buf,
                time_buf);

    if (local_box_lock != RT_NULL)
    {
        rt_mutex_take(local_box_lock, RT_WAITING_FOREVER);
    }
    updated_state = local_medicine_boxes[box_id - 1];
    local_medicine_boxes[box_id - 1].box_id = box_id;
    if (medicine_name != RT_NULL && medicine_name[0] != '\0')
    {
        rt_snprintf(local_medicine_boxes[box_id - 1].name,
                    sizeof(local_medicine_boxes[box_id - 1].name),
                    "%s",
                    medicine_name);
    }
    local_medicine_boxes[box_id - 1].quantity = stock_count;
    should_notify =
        local_medicine_box_equal(&updated_state,
                                 &local_medicine_boxes[box_id - 1]) == RT_FALSE ?
        RT_TRUE : RT_FALSE;
    updated_state = local_medicine_boxes[box_id - 1];
    if (local_box_lock != RT_NULL)
    {
        rt_mutex_release(local_box_lock);
    }

    if (should_notify == RT_TRUE)
    {
        local_notify_k230_medicine_box(&updated_state);
    }

    ret = local_http_post(LOCAL_SERVER_PUT_DONE_PATH, json);

    return ret;
}

static const char *local_json_string(cJSON *object,
                                     const char *name1,
                                     const char *name2,
                                     const char *name3,
                                     const char *name4)
{
    const char *names[4];
    int i;

    names[0] = name1;
    names[1] = name2;
    names[2] = name3;
    names[3] = name4;

    for (i = 0; i < 4; i++)
    {
        cJSON *item;

        if (names[i] == RT_NULL)
        {
            continue;
        }

        item = cJSON_GetObjectItem(object, names[i]);
        if (item != RT_NULL && cJSON_IsString(item) &&
            item->valuestring != RT_NULL)
        {
            return item->valuestring;
        }
    }

    return RT_NULL;
}

static cJSON *local_json_object(cJSON *object,
                                const char *name1,
                                const char *name2,
                                const char *name3,
                                const char *name4)
{
    const char *names[4];
    int i;

    if (object == RT_NULL || !cJSON_IsObject(object))
    {
        return RT_NULL;
    }

    names[0] = name1;
    names[1] = name2;
    names[2] = name3;
    names[3] = name4;

    for (i = 0; i < 4; i++)
    {
        cJSON *item;

        if (names[i] == RT_NULL)
        {
            continue;
        }

        item = cJSON_GetObjectItem(object, names[i]);
        if (item != RT_NULL && cJSON_IsObject(item))
        {
            return item;
        }
    }

    return RT_NULL;
}

static int local_json_int(cJSON *object,
                          const char *name1,
                          const char *name2,
                          const char *name3,
                          int fallback)
{
    const char *names[3];
    int i;

    names[0] = name1;
    names[1] = name2;
    names[2] = name3;

    for (i = 0; i < 3; i++)
    {
        cJSON *item;

        if (names[i] == RT_NULL)
        {
            continue;
        }

        item = cJSON_GetObjectItem(object, names[i]);

        if (item != RT_NULL && cJSON_IsNumber(item))
        {
            return item->valueint;
        }
    }

    return fallback;
}

static int local_json_bool(cJSON *object,
                           const char *name1,
                           const char *name2,
                           const char *name3,
                           int fallback)
{
    const char *names[3];
    int i;

    if (object == RT_NULL || !cJSON_IsObject(object))
    {
        return fallback;
    }

    names[0] = name1;
    names[1] = name2;
    names[2] = name3;

    for (i = 0; i < 3; i++)
    {
        cJSON *item;

        if (names[i] == RT_NULL)
        {
            continue;
        }

        item = cJSON_GetObjectItem(object, names[i]);

        if (item != RT_NULL && cJSON_IsBool(item))
        {
            return cJSON_IsTrue(item) ? 1 : 0;
        }
        if (item != RT_NULL && cJSON_IsNumber(item))
        {
            return item->valueint != 0 ? 1 : 0;
        }
        if (item != RT_NULL && cJSON_IsString(item) &&
            item->valuestring != RT_NULL)
        {
            if (strcmp(item->valuestring, "true") == 0 ||
                strcmp(item->valuestring, "1") == 0 ||
                strcmp(item->valuestring, "on") == 0)
            {
                return 1;
            }
            if (strcmp(item->valuestring, "false") == 0 ||
                strcmp(item->valuestring, "0") == 0 ||
                strcmp(item->valuestring, "off") == 0)
            {
                return 0;
            }
        }
    }

    return fallback;
}

static void local_set_family_contact(const char *name, const char *phone)
{
    if (phone == RT_NULL || phone[0] == '\0')
    {
        return;
    }

    if (local_box_lock != RT_NULL)
    {
        rt_mutex_take(local_box_lock, RT_WAITING_FOREVER);
    }

    rt_snprintf(local_family_contact.name,
                sizeof(local_family_contact.name),
                "%s",
                name == RT_NULL ? "" : name);
    rt_snprintf(local_family_contact.phone,
                sizeof(local_family_contact.phone),
                "%s",
                phone);

    if (local_box_lock != RT_NULL)
    {
        rt_mutex_release(local_box_lock);
    }

    LOG_I("family contact updated: name=%s phone=%s",
          local_family_contact.name,
          local_family_contact.phone);
}

int app_local_upload_get_family_contact(app_family_contact_t *contact)
{
    int ret = -1;

    if (contact == RT_NULL)
    {
        return -1;
    }

    memset(contact, 0, sizeof(*contact));

    if (local_box_lock != RT_NULL)
    {
        rt_mutex_take(local_box_lock, RT_WAITING_FOREVER);
    }

    if (local_family_contact.phone[0] != '\0')
    {
        *contact = local_family_contact;
        ret = 0;
    }

    if (local_box_lock != RT_NULL)
    {
        rt_mutex_release(local_box_lock);
    }

    return ret;
}

static void local_apply_family_contact_fields(cJSON *object,
                                              rt_bool_t allow_plain_phone)
{
    const char *name;
    const char *phone;

    if (object == RT_NULL || !cJSON_IsObject(object))
    {
        return;
    }

    name = local_json_string(object, "familyName", "family_name",
                             "contactName", "contact_name");
    if (name == RT_NULL)
    {
        name = local_json_string(object, "guardianName", "guardian_name",
                                 "emergencyName", "emergency_name");
    }
    if (name == RT_NULL)
    {
        name = local_json_string(object, "name", "userName",
                                 "user_name", RT_NULL);
    }

    phone = local_json_string(object, "familyPhone", "family_phone",
                              "contactPhone", "contact_phone");
    if (phone == RT_NULL)
    {
        phone = local_json_string(object, "guardianPhone", "guardian_phone",
                                  "emergencyPhone", "emergency_phone");
    }
    if (phone == RT_NULL && allow_plain_phone == RT_TRUE)
    {
        phone = local_json_string(object, "phone", "mobile",
                                  "tel", "telephone");
    }

    local_set_family_contact(name, phone);
}

static void local_apply_family_contact_object(cJSON *object)
{
    cJSON *contact;

    if (object == RT_NULL || !cJSON_IsObject(object))
    {
        return;
    }

    contact = local_json_object(object, "familyContact", "family_contact",
                                "family", "guardian");
    if (contact == RT_NULL)
    {
        contact = local_json_object(object, "emergencyContact",
                                    "emergency_contact", "contact",
                                    "relative");
    }
    if (contact != RT_NULL)
    {
        local_apply_family_contact_fields(contact, RT_TRUE);
    }

    local_apply_family_contact_fields(object, RT_FALSE);
}

static int local_box_threshold(cJSON *box, int fallback)
{
    int value;

    value = local_json_int(box, "lowThreshold", "minThreshold",
                           "threshold", -1);
    if (value < 0)
    {
        value = local_json_int(box, "low_threshold", "min_threshold",
                               "targetCount", fallback);
    }

    return value;
}

static const char *local_find_key_range(const char *start,
                                        const char *end,
                                        const char *key)
{
    char pattern[40];
    const char *p;

    if (start == RT_NULL || end == RT_NULL || key == RT_NULL)
    {
        return RT_NULL;
    }

    rt_snprintf(pattern, sizeof(pattern), "\"%s\"", key);
    p = start;
    while (p < end)
    {
        p = strstr(p, pattern);
        if (p == RT_NULL || p >= end)
        {
            return RT_NULL;
        }
        return p;
    }

    return RT_NULL;
}

static const char *local_match_json_pair(const char *open,
                                         char open_ch,
                                         char close_ch)
{
    const char *p;
    rt_bool_t in_string = RT_FALSE;
    rt_bool_t escape = RT_FALSE;
    int depth = 0;

    if (open == RT_NULL || *open != open_ch)
    {
        return RT_NULL;
    }

    for (p = open; *p != '\0'; p++)
    {
        if (in_string == RT_TRUE)
        {
            if (escape == RT_TRUE)
            {
                escape = RT_FALSE;
            }
            else if (*p == '\\')
            {
                escape = RT_TRUE;
            }
            else if (*p == '"')
            {
                in_string = RT_FALSE;
            }
            continue;
        }

        if (*p == '"')
        {
            in_string = RT_TRUE;
            continue;
        }
        if (*p == open_ch)
        {
            depth++;
            continue;
        }
        if (*p == close_ch)
        {
            depth--;
            if (depth == 0)
            {
                return p;
            }
        }
    }

    return RT_NULL;
}

static const char *local_find_object_range(const char *start,
                                           const char *end,
                                           const char *key,
                                           const char **object_end)
{
    const char *p;
    const char *open;
    const char *close;

    p = local_find_key_range(start, end, key);
    if (p == RT_NULL)
    {
        return RT_NULL;
    }

    open = strchr(p, '{');
    if (open == RT_NULL || open >= end)
    {
        return RT_NULL;
    }

    close = local_match_json_pair(open, '{', '}');
    if (close == RT_NULL || close >= end)
    {
        return RT_NULL;
    }

    if (object_end != RT_NULL)
    {
        *object_end = close;
    }
    return open;
}

static const char *local_find_array_range(const char *start,
                                          const char *end,
                                          const char *key,
                                          const char **array_end)
{
    const char *p;
    const char *open;
    const char *close;

    p = local_find_key_range(start, end, key);
    if (p == RT_NULL)
    {
        return RT_NULL;
    }

    open = strchr(p, '[');
    if (open == RT_NULL || open >= end)
    {
        return RT_NULL;
    }

    close = local_match_json_pair(open, '[', ']');
    if (close == RT_NULL || close >= end)
    {
        return RT_NULL;
    }

    if (array_end != RT_NULL)
    {
        *array_end = close;
    }
    return open;
}

static int local_text_int_range(const char *start,
                                const char *end,
                                const char *name1,
                                const char *name2,
                                const char *name3,
                                int fallback)
{
    const char *names[3];
    const char *p;
    int i;

    names[0] = name1;
    names[1] = name2;
    names[2] = name3;

    for (i = 0; i < 3; i++)
    {
        if (names[i] == RT_NULL)
        {
            continue;
        }
        p = local_find_key_range(start, end, names[i]);
        if (p == RT_NULL)
        {
            continue;
        }
        p = strchr(p, ':');
        if (p == RT_NULL || p >= end)
        {
            continue;
        }
        p++;
        while (p < end && (*p == ' ' || *p == '\t'))
        {
            p++;
        }
        return atoi(p);
    }

    return fallback;
}

static int local_text_string_range(const char *start,
                                   const char *end,
                                   const char *name1,
                                   const char *name2,
                                   const char *name3,
                                   const char *name4,
                                   char *out,
                                   int out_size)
{
    const char *names[4];
    const char *p;
    int i;
    int pos = 0;
    rt_bool_t escape = RT_FALSE;

    if (out == RT_NULL || out_size <= 0)
    {
        return -1;
    }
    out[0] = '\0';

    names[0] = name1;
    names[1] = name2;
    names[2] = name3;
    names[3] = name4;

    for (i = 0; i < 4; i++)
    {
        if (names[i] == RT_NULL)
        {
            continue;
        }

        p = local_find_key_range(start, end, names[i]);
        if (p == RT_NULL)
        {
            continue;
        }
        p = strchr(p, ':');
        if (p == RT_NULL || p >= end)
        {
            continue;
        }
        p++;
        while (p < end && (*p == ' ' || *p == '\t'))
        {
            p++;
        }
        if (p >= end || *p != '"')
        {
            continue;
        }
        p++;

        while (p < end && *p != '\0')
        {
            if (escape == RT_TRUE)
            {
                if (pos < out_size - 1)
                {
                    out[pos++] = *p;
                }
                escape = RT_FALSE;
            }
            else if (*p == '\\')
            {
                escape = RT_TRUE;
            }
            else if (*p == '"')
            {
                out[pos] = '\0';
                return 0;
            }
            else if (pos < out_size - 1)
            {
                out[pos++] = *p;
            }
            p++;
        }

        out[pos] = '\0';
        return pos > 0 ? 0 : -1;
    }

    return -1;
}

static void local_apply_family_contact_text_object(const char *start,
                                                   const char *end,
                                                   rt_bool_t allow_plain_phone)
{
    char name[APP_MEDICINE_USER_NAME_LEN] = "";
    char phone[16] = "";

    if (start == RT_NULL || end == RT_NULL)
    {
        return;
    }

    if (local_text_string_range(start, end,
                                "familyName", "family_name",
                                "contactName", "contact_name",
                                name, sizeof(name)) != 0)
    {
        if (local_text_string_range(start, end,
                                    "guardianName", "guardian_name",
                                    "emergencyName", "emergency_name",
                                    name, sizeof(name)) != 0)
        {
            (void)local_text_string_range(start, end,
                                          "name", "userName",
                                          "user_name", RT_NULL,
                                          name, sizeof(name));
        }
    }

    if (local_text_string_range(start, end,
                                "familyPhone", "family_phone",
                                "contactPhone", "contact_phone",
                                phone, sizeof(phone)) != 0)
    {
        if (local_text_string_range(start, end,
                                    "guardianPhone", "guardian_phone",
                                    "emergencyPhone", "emergency_phone",
                                    phone, sizeof(phone)) != 0)
        {
            if (allow_plain_phone == RT_TRUE)
            {
                (void)local_text_string_range(start, end,
                                              "phone", "mobile",
                                              "tel", "telephone",
                                              phone, sizeof(phone));
            }
        }
    }

    local_set_family_contact(name, phone);
}

static void local_apply_family_contact_text(const char *start,
                                            const char *end)
{
    const char *object_end = RT_NULL;
    const char *object_start;

    if (start == RT_NULL || end == RT_NULL)
    {
        return;
    }

    object_start = local_find_object_range(start, end,
                                           "familyContact", &object_end);
    if (object_start == RT_NULL)
    {
        object_start = local_find_object_range(start, end,
                                               "family_contact",
                                               &object_end);
    }
    if (object_start == RT_NULL)
    {
        object_start = local_find_object_range(start, end,
                                               "family", &object_end);
    }
    if (object_start == RT_NULL)
    {
        object_start = local_find_object_range(start, end,
                                               "guardian", &object_end);
    }
    if (object_start == RT_NULL)
    {
        object_start = local_find_object_range(start, end,
                                               "emergencyContact",
                                               &object_end);
    }
    if (object_start == RT_NULL)
    {
        object_start = local_find_object_range(start, end,
                                               "emergency_contact",
                                               &object_end);
    }
    if (object_start == RT_NULL)
    {
        object_start = local_find_object_range(start, end,
                                               "contact", &object_end);
    }

    if (object_start != RT_NULL)
    {
        local_apply_family_contact_text_object(object_start, object_end,
                                               RT_TRUE);
    }

    local_apply_family_contact_text_object(start, end, RT_FALSE);
}

static void local_apply_medicine_box(cJSON *box, int fallback_box_id)
{
    app_medicine_box_state_t state;
    rt_bool_t should_notify = RT_FALSE;
    const char *name;
    const char *box_name;
    int box_id;
    int quantity;
    int low_threshold;

    if (box == RT_NULL || !cJSON_IsObject(box))
    {
        return;
    }

    box_id = local_json_int(box, "boxId", "box_id", "id", fallback_box_id);
    if (box_id < 1 || box_id > APP_MEDICINE_PLAN_MAX_COUNT)
    {
        return;
    }

    quantity = local_json_int(box, "quantity", "stock_count",
                              "stockCount", 0);
    low_threshold = local_box_threshold(box, 5);
    name = local_json_string(box, "name", "medicineName",
                             "medicine_name", RT_NULL);
    box_name = local_json_string(box, "boxName", "box_name",
                                 "title", RT_NULL);

    memset(&state, 0, sizeof(state));
    state.box_id = box_id;
    state.quantity = quantity < 0 ? 0 : quantity;
    state.low_threshold = low_threshold < 0 ? 0 : low_threshold;
    rt_snprintf(state.name,
                sizeof(state.name),
                "%s",
                name == RT_NULL ? "" : name);
    rt_snprintf(state.box_name,
                sizeof(state.box_name),
                "%s",
                box_name == RT_NULL ? "" : box_name);

    if (local_box_lock != RT_NULL)
    {
        rt_mutex_take(local_box_lock, RT_WAITING_FOREVER);
    }
    should_notify = local_medicine_box_equal(&local_medicine_boxes[box_id - 1],
                                             &state) == RT_FALSE ?
                    RT_TRUE : RT_FALSE;
    local_medicine_boxes[box_id - 1] = state;
    if (local_box_lock != RT_NULL)
    {
        rt_mutex_release(local_box_lock);
    }

    if (should_notify == RT_TRUE)
    {
        local_notify_k230_medicine_box(&state);
    }
}

static int local_parse_box_array_lightweight(const char *json_text)
{
    const char *boxes_key;
    const char *p;
    const char *object_start = RT_NULL;
    rt_bool_t in_string = RT_FALSE;
    rt_bool_t escape = RT_FALSE;
    int depth = 0;
    int fallback_box_id = 1;
    int count = 0;

    if (json_text == RT_NULL)
    {
        return -1;
    }

    boxes_key = strstr(json_text, "\"boxes\"");
    if (boxes_key == RT_NULL)
    {
        return -1;
    }

    p = strchr(boxes_key, '[');
    if (p == RT_NULL)
    {
        return -1;
    }
    p++;

    for (; *p != '\0'; p++)
    {
        if (in_string == RT_TRUE)
        {
            if (escape == RT_TRUE)
            {
                escape = RT_FALSE;
            }
            else if (*p == '\\')
            {
                escape = RT_TRUE;
            }
            else if (*p == '"')
            {
                in_string = RT_FALSE;
            }
            continue;
        }

        if (*p == '"')
        {
            in_string = RT_TRUE;
            continue;
        }

        if (*p == '{')
        {
            if (depth == 0)
            {
                object_start = p;
            }
            depth++;
            continue;
        }

        if (*p == '}')
        {
            if (depth <= 0)
            {
                return count > 0 ? 0 : -1;
            }

            depth--;
            if (depth == 0 && object_start != RT_NULL)
            {
                int object_len = (int)(p - object_start + 1);
                const char *parse_end = RT_NULL;
                cJSON *box;

                box = cJSON_ParseWithLengthOpts(object_start,
                                                object_len,
                                                &parse_end,
                                                0);
                if (box != RT_NULL)
                {
                    local_apply_medicine_box(box, fallback_box_id);
                    cJSON_Delete(box);
                    count++;
                }

                fallback_box_id++;
                object_start = RT_NULL;
            }
            continue;
        }

        if (*p == ']' && depth == 0)
        {
            break;
        }
    }

    return count > 0 ? 0 : -1;
}

static void local_apply_medicine_box_text(const char *box_start,
                                          const char *box_end,
                                          int fallback_box_id)
{
    app_medicine_box_state_t state;
    rt_bool_t should_notify = RT_FALSE;
    char name[APP_MEDICINE_NAME_LEN] = "";
    char box_name[APP_MEDICINE_BOX_NAME_LEN] = "";
    int box_id;
    int quantity;
    int low_threshold;

    if (box_start == RT_NULL || box_end == RT_NULL)
    {
        return;
    }

    box_id = local_text_int_range(box_start, box_end,
                                  "boxId", "box_id", "id",
                                  fallback_box_id);
    if (box_id < 1 || box_id > APP_MEDICINE_PLAN_MAX_COUNT)
    {
        return;
    }

    quantity = local_text_int_range(box_start, box_end,
                                    "quantity", "stock_count", "stockCount",
                                    0);
    low_threshold = local_text_int_range(box_start, box_end,
                                         "lowThreshold", "minThreshold",
                                         "threshold", 5);
    local_text_string_range(box_start, box_end,
                            "name", "medicineName", "medicine_name", RT_NULL,
                            name, sizeof(name));
    local_text_string_range(box_start, box_end,
                            "boxName", "box_name", "title", RT_NULL,
                            box_name, sizeof(box_name));

    memset(&state, 0, sizeof(state));
    state.box_id = box_id;
    state.quantity = quantity < 0 ? 0 : quantity;
    state.low_threshold = low_threshold < 0 ? 0 : low_threshold;
    rt_snprintf(state.name, sizeof(state.name), "%s", name);
    rt_snprintf(state.box_name, sizeof(state.box_name), "%s", box_name);

    if (local_box_lock != RT_NULL)
    {
        rt_mutex_take(local_box_lock, RT_WAITING_FOREVER);
    }
    should_notify = local_medicine_box_equal(&local_medicine_boxes[box_id - 1],
                                             &state) == RT_FALSE ?
                    RT_TRUE : RT_FALSE;
    local_medicine_boxes[box_id - 1] = state;
    if (local_box_lock != RT_NULL)
    {
        rt_mutex_release(local_box_lock);
    }

    if (should_notify == RT_TRUE)
    {
        local_notify_k230_medicine_box(&state);
    }
}

static int local_parse_box_array_text(const char *json_text)
{
    const char *json_end;
    const char *array_start;
    const char *array_end = RT_NULL;
    const char *p;
    int fallback_box_id = 1;
    int count = 0;

    if (json_text == RT_NULL)
    {
        return -1;
    }

    json_end = json_text + strlen(json_text);
    array_start = local_find_array_range(json_text, json_end,
                                         "boxes", &array_end);
    if (array_start == RT_NULL)
    {
        return -1;
    }

    p = array_start + 1;
    while (p < array_end)
    {
        const char *object_start = strchr(p, '{');
        const char *object_end;

        if (object_start == RT_NULL || object_start >= array_end)
        {
            break;
        }
        object_end = local_match_json_pair(object_start, '{', '}');
        if (object_end == RT_NULL || object_end > array_end)
        {
            break;
        }

        local_apply_medicine_box_text(object_start, object_end,
                                      fallback_box_id);
        fallback_box_id++;
        count++;
        p = object_end + 1;
    }

    return count > 0 ? 0 : -1;
}

static int local_apply_medicine_plan(cJSON *plan,
                                     int fallback_slot,
                                     const char *patient_name,
                                     const char *patient_phone,
                                     rt_bool_t seen[APP_MEDICINE_PLAN_MAX_COUNT])
{
    app_medicine_plan_t medicine_plan;
    cJSON *medicines;
    const char *time_str;
    const char *earliest_time_str;
    const char *latest_time_str;
    int hour;
    int min;
    int earliest_hour;
    int earliest_min;
    int latest_hour;
    int latest_min;
    int slot;
    int med_count = 0;
    int i;

    if (plan == RT_NULL || !cJSON_IsObject(plan))
    {
        return 0;
    }

    time_str = local_json_string(plan, "time", "medicineTime",
                                 "reminderTime", "takeTime");
    if (time_str == RT_NULL || sscanf(time_str, "%d:%d", &hour, &min) != 2 ||
        hour < 0 || hour > 23 || min < 0 || min > 59)
    {
        return 0;
    }

    earliest_time_str = local_json_string(plan, "earliestTime", "earliest_time",
                                          "startTime", "start_time");
    if (earliest_time_str == RT_NULL ||
        sscanf(earliest_time_str, "%d:%d", &earliest_hour, &earliest_min) != 2 ||
        earliest_hour < 0 || earliest_hour > 23 ||
        earliest_min < 0 || earliest_min > 59)
    {
        earliest_hour = hour;
        earliest_min = min;
    }

    latest_time_str = local_json_string(plan, "latestTime", "latest_time",
                                        "endTime", "end_time");
    if (latest_time_str == RT_NULL ||
        sscanf(latest_time_str, "%d:%d", &latest_hour, &latest_min) != 2 ||
        latest_hour < 0 || latest_hour > 23 ||
        latest_min < 0 || latest_min > 59)
    {
        latest_hour = hour;
        latest_min = min;
    }

    slot = local_json_int(plan, "slot", "plan_slot", "planSlot", fallback_slot);
    if (slot < 1 || slot > APP_MEDICINE_PLAN_MAX_COUNT)
    {
        LOG_W("ignore medicine plan with invalid slot: %d", slot);
        return 0;
    }

    memset(&medicine_plan, 0, sizeof(medicine_plan));
    medicine_plan.plan_slot = slot;
    medicine_plan.hour = hour;
    medicine_plan.min = min;
    medicine_plan.earliest_hour = earliest_hour;
    medicine_plan.earliest_min = earliest_min;
    medicine_plan.latest_hour = latest_hour;
    medicine_plan.latest_min = latest_min;
    rt_snprintf(medicine_plan.user_name,
                sizeof(medicine_plan.user_name),
                "%s",
                patient_name == RT_NULL || patient_name[0] == '\0' ?
                "patient" : patient_name);
    rt_snprintf(medicine_plan.user_phone,
                sizeof(medicine_plan.user_phone),
                "%s",
                patient_phone == RT_NULL ? "" : patient_phone);

    medicines = cJSON_GetObjectItem(plan, "medicines");
    if (medicines != RT_NULL && cJSON_IsArray(medicines))
    {
        int size = cJSON_GetArraySize(medicines);

        for (i = 0; i < size && med_count < APP_MEDICINE_PLAN_MAX_MEDICINES; i++)
        {
            cJSON *medicine = cJSON_GetArrayItem(medicines, i);
            const char *medicine_name;
            const char *box_name;
            int box_id;
            int dose_count;

            if (medicine == RT_NULL || !cJSON_IsObject(medicine))
            {
                continue;
            }

            box_id = local_json_int(medicine, "boxId", "box_id", "cabinetId", 0);
            if (box_id < 1 || box_id > APP_MEDICINE_PLAN_MAX_COUNT)
            {
                continue;
            }

            dose_count = local_json_int(medicine, "doseCount", "dose_count", RT_NULL, 0);
            medicine_name = local_json_string(medicine, "name", "medicineName",
                                              RT_NULL, RT_NULL);
            box_name = local_json_string(medicine, "boxName", "box_name",
                                         RT_NULL, RT_NULL);

            medicine_plan.medicines[med_count].box_id = box_id;
            medicine_plan.medicines[med_count].dose_count = dose_count;
            rt_snprintf(medicine_plan.medicines[med_count].name,
                        sizeof(medicine_plan.medicines[med_count].name),
                        "%s",
                        medicine_name == RT_NULL ? "" : medicine_name);
            rt_snprintf(medicine_plan.medicines[med_count].box_name,
                        sizeof(medicine_plan.medicines[med_count].box_name),
                        "%s",
                        box_name == RT_NULL ? "" : box_name);
            med_count++;
        }
    }

    medicine_plan.medicine_count = med_count;
    app_beep_alarm_set_plan(&medicine_plan);
    seen[slot - 1] = RT_TRUE;
    LOG_I("cloud plan applied: plan_slot=%d window=%02d:%02d-%02d:%02d alarm=%02d:%02d user=%s medicines=%d",
          slot,
          earliest_hour,
          earliest_min,
          latest_hour,
          latest_min,
          hour,
          min,
          medicine_plan.user_name,
          med_count);
    return 1;
}

static int local_parse_plan_array_lightweight(const char *json_text)
{
    const char *plans_key;
    const char *p;
    const char *object_start = RT_NULL;
    rt_bool_t seen[APP_MEDICINE_PLAN_MAX_COUNT] = {RT_FALSE};
    rt_bool_t in_string = RT_FALSE;
    rt_bool_t escape = RT_FALSE;
    rt_bool_t valid_payload = RT_FALSE;
    int depth = 0;
    int fallback_slot = 1;
    int count = 0;
    int i;

    if (json_text == RT_NULL)
    {
        return -1;
    }

    plans_key = strstr(json_text, "\"plans\"");
    if (plans_key == RT_NULL)
    {
        return -1;
    }

    p = strchr(plans_key, '[');
    if (p == RT_NULL)
    {
        return -1;
    }
    p++;

    for (; *p != '\0'; p++)
    {
        if (in_string == RT_TRUE)
        {
            if (escape == RT_TRUE)
            {
                escape = RT_FALSE;
            }
            else if (*p == '\\')
            {
                escape = RT_TRUE;
            }
            else if (*p == '"')
            {
                in_string = RT_FALSE;
            }
            continue;
        }

        if (*p == '"')
        {
            in_string = RT_TRUE;
            continue;
        }

        if (*p == '{')
        {
            if (depth == 0)
            {
                object_start = p;
            }
            depth++;
            continue;
        }

        if (*p == '}')
        {
            if (depth <= 0)
            {
                return -1;
            }

            depth--;
            if (depth == 0 && object_start != RT_NULL)
            {
                int object_len = (int)(p - object_start + 1);
                const char *parse_end = RT_NULL;
                cJSON *plan;

                valid_payload = RT_TRUE;
                plan = cJSON_ParseWithLengthOpts(object_start,
                                                 object_len,
                                                 &parse_end,
                                                 0);
                if (plan != RT_NULL)
                {
                    count += local_apply_medicine_plan(plan,
                                                       fallback_slot,
                                                       RT_NULL,
                                                       RT_NULL,
                                                       seen);
                    cJSON_Delete(plan);
                }
                else
                {
                    const char *error_ptr = cJSON_GetErrorPtr();
                    LOG_W("ignore one medicine plan json object, len=%d", object_len);
                    if (error_ptr != RT_NULL)
                    {
                        LOG_W("plan object parse error near: %.80s", error_ptr);
                    }
                    else if (parse_end != RT_NULL)
                    {
                        LOG_W("plan object parse stopped near: %.80s", parse_end);
                    }
                }

                fallback_slot++;
                object_start = RT_NULL;
            }
            continue;
        }

        if (*p == ']' && depth == 0)
        {
            break;
        }
    }

    if (valid_payload != RT_TRUE)
    {
        return -1;
    }

    for (i = 0; i < APP_MEDICINE_PLAN_MAX_COUNT; i++)
    {
        if (seen[i] == RT_FALSE)
        {
            app_beep_alarm_disable(i);
        }
    }

    LOG_I("cloud medicine plan update count: %d", count);
    return count > 0 ? 0 : -1;
}

static int local_apply_medicine_plan_text(const char *plan_start,
                                          const char *plan_end,
                                          int fallback_slot,
                                          const char *patient_name,
                                          const char *patient_phone,
                                          rt_bool_t seen[APP_MEDICINE_PLAN_MAX_COUNT])
{
    app_medicine_plan_t medicine_plan;
    char time_str[16];
    char earliest_time_str[16];
    char latest_time_str[16];
    const char *medicines_start;
    const char *medicines_end = RT_NULL;
    const char *p;
    int hour;
    int min;
    int earliest_hour;
    int earliest_min;
    int latest_hour;
    int latest_min;
    int slot;
    int med_count = 0;

    if (plan_start == RT_NULL || plan_end == RT_NULL)
    {
        return 0;
    }

    if (local_text_string_range(plan_start, plan_end,
                                "time", "medicineTime",
                                "reminderTime", "takeTime",
                                time_str, sizeof(time_str)) != 0 ||
        sscanf(time_str, "%d:%d", &hour, &min) != 2 ||
        hour < 0 || hour > 23 || min < 0 || min > 59)
    {
        return 0;
    }

    if (local_text_string_range(plan_start, plan_end,
                                "earliestTime", "earliest_time",
                                "startTime", "start_time",
                                earliest_time_str,
                                sizeof(earliest_time_str)) != 0 ||
        sscanf(earliest_time_str, "%d:%d",
               &earliest_hour, &earliest_min) != 2 ||
        earliest_hour < 0 || earliest_hour > 23 ||
        earliest_min < 0 || earliest_min > 59)
    {
        earliest_hour = hour;
        earliest_min = min;
    }

    if (local_text_string_range(plan_start, plan_end,
                                "latestTime", "latest_time",
                                "endTime", "end_time",
                                latest_time_str,
                                sizeof(latest_time_str)) != 0 ||
        sscanf(latest_time_str, "%d:%d",
               &latest_hour, &latest_min) != 2 ||
        latest_hour < 0 || latest_hour > 23 ||
        latest_min < 0 || latest_min > 59)
    {
        latest_hour = hour;
        latest_min = min;
    }

    slot = local_text_int_range(plan_start, plan_end,
                                "slot", "plan_slot", "planSlot",
                                fallback_slot);
    if (slot < 1 || slot > APP_MEDICINE_PLAN_MAX_COUNT)
    {
        LOG_W("ignore medicine plan with invalid slot: %d", slot);
        return 0;
    }

    memset(&medicine_plan, 0, sizeof(medicine_plan));
    medicine_plan.plan_slot = slot;
    medicine_plan.hour = hour;
    medicine_plan.min = min;
    medicine_plan.earliest_hour = earliest_hour;
    medicine_plan.earliest_min = earliest_min;
    medicine_plan.latest_hour = latest_hour;
    medicine_plan.latest_min = latest_min;
    rt_snprintf(medicine_plan.user_name,
                sizeof(medicine_plan.user_name),
                "%s",
                patient_name == RT_NULL || patient_name[0] == '\0' ?
                "patient" : patient_name);
    rt_snprintf(medicine_plan.user_phone,
                sizeof(medicine_plan.user_phone),
                "%s",
                patient_phone == RT_NULL ? "" : patient_phone);

    medicines_start = local_find_array_range(plan_start, plan_end,
                                             "medicines", &medicines_end);
    if (medicines_start != RT_NULL)
    {
        p = medicines_start + 1;
        while (p < medicines_end &&
               med_count < APP_MEDICINE_PLAN_MAX_MEDICINES)
        {
            const char *medicine_start = strchr(p, '{');
            const char *medicine_end;
            app_medicine_item_t *item;

            if (medicine_start == RT_NULL || medicine_start >= medicines_end)
            {
                break;
            }
            medicine_end = local_match_json_pair(medicine_start, '{', '}');
            if (medicine_end == RT_NULL || medicine_end > medicines_end)
            {
                break;
            }

            item = &medicine_plan.medicines[med_count];
            item->box_id = local_text_int_range(medicine_start,
                                                medicine_end,
                                                "boxId", "box_id",
                                                "cabinetId", 0);
            if (item->box_id >= 1 &&
                item->box_id <= APP_MEDICINE_PLAN_MAX_COUNT)
            {
                item->dose_count = local_text_int_range(medicine_start,
                                                        medicine_end,
                                                        "doseCount",
                                                        "dose_count",
                                                        RT_NULL,
                                                        0);
                local_text_string_range(medicine_start,
                                        medicine_end,
                                        "name", "medicineName",
                                        RT_NULL, RT_NULL,
                                        item->name,
                                        sizeof(item->name));
                local_text_string_range(medicine_start,
                                        medicine_end,
                                        "boxName", "box_name",
                                        RT_NULL, RT_NULL,
                                        item->box_name,
                                        sizeof(item->box_name));
                med_count++;
            }
            p = medicine_end + 1;
        }
    }

    medicine_plan.medicine_count = med_count;
    app_beep_alarm_set_plan(&medicine_plan);
    seen[slot - 1] = RT_TRUE;
    LOG_I("cloud plan applied: plan_slot=%d window=%02d:%02d-%02d:%02d alarm=%02d:%02d user=%s medicines=%d",
          slot,
          earliest_hour,
          earliest_min,
          latest_hour,
          latest_min,
          hour,
          min,
          medicine_plan.user_name,
          med_count);
    return 1;
}

static int local_parse_plan_array_text(const char *json_text)
{
    const char *json_end;
    const char *patient_start;
    const char *patient_end = RT_NULL;
    const char *plans_start;
    const char *plans_end = RT_NULL;
    const char *p;
    char patient_name[APP_MEDICINE_USER_NAME_LEN] = "";
    char patient_phone[16] = "";
    rt_bool_t seen[APP_MEDICINE_PLAN_MAX_COUNT] = {RT_FALSE};
    int fallback_slot = 1;
    int count = 0;
    int i;

    if (json_text == RT_NULL)
    {
        return -1;
    }

    json_end = json_text + strlen(json_text);
    local_apply_family_contact_text(json_text, json_end);

    patient_start = local_find_object_range(json_text, json_end,
                                            "patient", &patient_end);
    if (patient_start != RT_NULL)
    {
        local_text_string_range(patient_start, patient_end,
                                "name", "user_name", "userName", RT_NULL,
                                patient_name, sizeof(patient_name));
        local_text_string_range(patient_start, patient_end,
                                "phone", "mobile", RT_NULL, RT_NULL,
                                patient_phone, sizeof(patient_phone));
    }

    (void)local_parse_box_array_text(json_text);

    plans_start = local_find_array_range(json_text, json_end,
                                         "plans", &plans_end);
    if (plans_start == RT_NULL)
    {
        return -1;
    }

    p = plans_start + 1;
    while (p < plans_end && fallback_slot <= APP_MEDICINE_PLAN_MAX_COUNT)
    {
        const char *plan_start = strchr(p, '{');
        const char *plan_end;

        if (plan_start == RT_NULL || plan_start >= plans_end)
        {
            break;
        }
        plan_end = local_match_json_pair(plan_start, '{', '}');
        if (plan_end == RT_NULL || plan_end > plans_end)
        {
            break;
        }

        count += local_apply_medicine_plan_text(plan_start,
                                                plan_end,
                                                fallback_slot,
                                                patient_name,
                                                patient_phone,
                                                seen);
        fallback_slot++;
        p = plan_end + 1;
    }

    if (count <= 0)
    {
        return -1;
    }

    for (i = 0; i < APP_MEDICINE_PLAN_MAX_COUNT; i++)
    {
        if (seen[i] == RT_FALSE)
        {
            app_beep_alarm_disable(i);
        }
    }

    LOG_I("cloud medicine plan update count: %d", count);
    return 0;
}

static int local_parse_medicine_plan(const char *response)
{
    const char *json_text;
    const char *body_start;
    const char *parse_end = RT_NULL;
    int content_length = -1;
    int json_len;
    cJSON *root;
    cJSON *config;
    cJSON *patient;
    cJSON *plans;
    const char *patient_name = RT_NULL;
    const char *patient_phone = RT_NULL;
    rt_bool_t seen[APP_MEDICINE_PLAN_MAX_COUNT] = {RT_FALSE};
    rt_bool_t valid_payload = RT_FALSE;
    int count = 0;
    int i;

    if (response == RT_NULL)
    {
        return -1;
    }

    json_text = strstr(response, "\r\n\r\n");
    body_start = json_text == RT_NULL ? response : json_text + 4;
    json_text = body_start;
    while (*json_text != '\0' && *json_text != '{' && *json_text != '[')
    {
        json_text++;
    }

    content_length = local_http_content_length(response);
    if (content_length > 0 && json_text >= body_start &&
        content_length > (int)(json_text - body_start))
    {
        json_len = content_length - (int)(json_text - body_start);
        if (json_len > (int)strlen(json_text))
        {
            json_len = (int)strlen(json_text);
        }
    }
    else
    {
        json_len = (int)strlen(json_text);
    }

    if (local_parse_plan_array_text(json_text) == 0)
    {
        return 0;
    }

    root = cJSON_ParseWithLengthOpts(json_text,
                                     json_len,
                                     &parse_end,
                                     0);
    if (root == RT_NULL)
    {
        const char *error_ptr = cJSON_GetErrorPtr();

        LOG_W("invalid medicine plan json");
        LOG_W("medicine plan json len=%d, content_length=%d",
              json_len,
              content_length);
        if (error_ptr != RT_NULL)
        {
            LOG_W("medicine plan parse error near: %.80s", error_ptr);
        }
        else if (parse_end != RT_NULL)
        {
            LOG_W("medicine plan parse stopped near: %.80s", parse_end);
        }
        LOG_W("medicine plan response head: %.160s", response);
        LOG_W("medicine plan body head: %.160s", json_text);
        if (local_parse_plan_array_lightweight(json_text) == 0)
        {
            LOG_W("medicine plan parsed by lightweight fallback");
            return 0;
        }
        return -1;
    }

    config = root;
    if (cJSON_IsObject(root))
    {
        cJSON *data = cJSON_GetObjectItem(root, "data");
        local_apply_family_contact_object(root);

        if (data != RT_NULL && cJSON_IsObject(data))
        {
            config = data;
        }

        local_apply_family_contact_object(config);

        patient = cJSON_GetObjectItem(config, "patient");
        if (patient != RT_NULL && cJSON_IsObject(patient))
        {
            patient_name = local_json_string(patient, "name", "user_name",
                                             "userName", RT_NULL);
            patient_phone = local_json_string(patient, "phone", "mobile",
                                              RT_NULL, RT_NULL);
        }

        {
            cJSON *boxes = cJSON_GetObjectItem(config, "boxes");
            if (boxes != RT_NULL && cJSON_IsArray(boxes))
            {
                int size = cJSON_GetArraySize(boxes);
                for (i = 0; i < size; i++)
                {
                    local_apply_medicine_box(cJSON_GetArrayItem(boxes, i),
                                             i + 1);
                }
            }
        }
    }

    plans = config;
    if (config != RT_NULL && cJSON_IsObject(config))
    {
        cJSON *nested = cJSON_GetObjectItem(config, "plans");
        if (nested == RT_NULL)
        {
            nested = cJSON_GetObjectItem(config, "list");
        }
        if (nested != RT_NULL)
        {
            plans = nested;
        }
    }

    if (plans != RT_NULL && cJSON_IsArray(plans))
    {
        int size = cJSON_GetArraySize(plans);
        valid_payload = RT_TRUE;
        for (i = 0; i < size && i < APP_MEDICINE_PLAN_MAX_COUNT; i++)
        {
            count += local_apply_medicine_plan(cJSON_GetArrayItem(plans, i),
                                               i + 1,
                                               patient_name,
                                               patient_phone,
                                               seen);
        }
    }
    else if (plans != RT_NULL && cJSON_IsObject(plans))
    {
        valid_payload = RT_TRUE;
        count += local_apply_medicine_plan(plans, 1,
                                           patient_name,
                                           patient_phone,
                                           seen);
    }

    if (valid_payload == RT_TRUE)
    {
        for (i = 0; i < APP_MEDICINE_PLAN_MAX_COUNT; i++)
        {
            if (seen[i] == RT_FALSE)
            {
                app_beep_alarm_disable(i);
            }
        }
        LOG_I("cloud medicine plan update count: %d", count);
    }

    cJSON_Delete(root);
    return valid_payload == RT_TRUE ? 0 : -1;
}

static void local_get_medicine_plan(void)
{
    if (local_http_get(LOCAL_SERVER_PLAN_PATH,
                       local_plan_response,
                       sizeof(local_plan_response)) > 0)
    {
        LOG_D("medicine plan response: %s", local_plan_response);
        if (local_parse_medicine_plan(local_plan_response) == 0)
        {
            return;
        }
    }

    LOG_W("primary medicine plan api failed, try fallback");
    if (local_http_get(LOCAL_SERVER_PLAN_FALLBACK_PATH,
                       local_plan_response,
                       sizeof(local_plan_response)) > 0)
    {
        LOG_D("medicine plan fallback response: %s", local_plan_response);
        (void)local_parse_medicine_plan(local_plan_response);
    }
}

static void local_get_medicine_taken_status(void)
{
    char *json_text;
    char *json_end;
    cJSON *root;
    cJSON *data;
    cJSON *taken_slots;
    int i;

    if (local_http_get(LOCAL_SERVER_TAKEN_STATUS_PATH,
                       local_http_response,
                       sizeof(local_http_response)) <= 0)
    {
        return;
    }

    json_text = strstr(local_http_response, "\r\n\r\n");
    json_text = json_text != RT_NULL ? json_text + 4 : local_http_response;
    if (json_text == RT_NULL || json_text[0] == '\0')
    {
        return;
    }

    json_end = json_text + strlen(json_text);
    while (json_end > json_text &&
           (json_end[-1] == '\r' || json_end[-1] == '\n' ||
            json_end[-1] == '\0'))
    {
        json_end--;
    }

    root = cJSON_ParseWithLengthOpts(json_text,
                                     (int)(json_end - json_text),
                                     RT_NULL,
                                     0);
    if (root == RT_NULL)
    {
        return;
    }

    data = local_json_object(root, "data", RT_NULL, RT_NULL, RT_NULL);
    if (data == RT_NULL)
    {
        data = root;
    }

    taken_slots = cJSON_GetObjectItem(data, "takenSlots");
    if (taken_slots != RT_NULL && cJSON_IsArray(taken_slots))
    {
        cJSON *item;
        cJSON_ArrayForEach(item, taken_slots)
        {
            if (cJSON_IsNumber(item))
            {
                app_beep_alarm_mark_taken(item->valueint);
            }
        }
    }

    {
        cJSON *slot_status_root = cJSON_GetObjectItem(data, "slotStatus");

        for (i = 1; i <= APP_MEDICINE_PLAN_MAX_COUNT; i++)
        {
            char key[4];
            cJSON *slot_status;

            rt_snprintf(key, sizeof(key), "%d", i);
            slot_status = slot_status_root != RT_NULL ?
                          cJSON_GetObjectItem(slot_status_root, key) : RT_NULL;
            if (slot_status != RT_NULL &&
                ((cJSON_IsString(slot_status) &&
                  slot_status->valuestring != RT_NULL &&
                  strcmp(slot_status->valuestring, "taken") == 0) ||
                 (cJSON_IsBool(slot_status) && cJSON_IsTrue(slot_status))))
            {
                app_beep_alarm_mark_taken(i);
            }
        }
    }

    cJSON_Delete(root);
}

static void local_get_camera_control(void)
{
    char *json_text;
    char *json_end;
    cJSON *root;
    cJSON *data;
    int enabled;

    if (local_http_get(LOCAL_SERVER_CAMERA_CONTROL_PATH,
                       local_camera_control_response,
                       sizeof(local_camera_control_response)) <= 0)
    {
        return;
    }

    json_text = strstr(local_camera_control_response, "\r\n\r\n");
    json_text = json_text != RT_NULL ? json_text + 4 :
                local_camera_control_response;
    if (json_text == RT_NULL || json_text[0] == '\0')
    {
        return;
    }

    json_end = json_text + strlen(json_text);
    while (json_end > json_text &&
           (json_end[-1] == '\r' || json_end[-1] == '\n' ||
            json_end[-1] == '\0'))
    {
        json_end--;
    }

    root = cJSON_ParseWithLengthOpts(json_text,
                                     (int)(json_end - json_text),
                                     RT_NULL,
                                     0);
    if (root == RT_NULL)
    {
        return;
    }

    data = local_json_object(root, "data", RT_NULL, RT_NULL, RT_NULL);
    enabled = local_json_bool(data != RT_NULL ? data : root,
                              "enabled",
                              "controlEnabled",
                              "desiredEnabled",
                              -1);
    if (enabled >= 0)
    {
        app_esp32cam_ctrl_set_manual(enabled ? RT_TRUE : RT_FALSE);
    }

    cJSON_Delete(root);
}

static void local_camera_control_entry(void *parameter)
{
    while (1)
    {
        local_get_camera_control();
        rt_thread_mdelay(LOCAL_CAMERA_CONTROL_INTERVAL_MS);
    }
}

static void local_upload_entry(void *parameter)
{
    int temperature = 0;
    int humidity = 0;

    rt_int32_t body_temp = BODY_TEMP_INVALID_X100;
    int body_int = 0;
    int body_dec = 0;
    rt_bool_t has_body_temp = RT_FALSE;
    rt_int32_t pending_body_temp = BODY_TEMP_INVALID_X100;
    rt_bool_t pending_body_temp_valid = RT_FALSE;

    int heart_rate = 0;
    int spo2 = 0;
    rt_bool_t has_max30102 = RT_FALSE;
    int pending_heart_rate = 0;
    int pending_spo2 = 0;
    rt_bool_t pending_max30102 = RT_FALSE;

    char date_buf[16];
    char time_buf[16];
    char *json = local_upload_json;

    int plan_count = LOCAL_PLAN_REFRESH_UPLOAD_CYCLES;
    int post_ret;

    while (1)
    {
        if (app_sensor_get(&temperature, &humidity) != 0)
        {
            LOG_W("sensor data not ready");
            temperature = 0;
            humidity = 0;
        }

        has_body_temp = RT_FALSE;

        if (app_body_temp_take(&body_temp) == 0)
        {
            pending_body_temp = body_temp;
            pending_body_temp_valid = RT_TRUE;
        }

        has_body_temp = pending_body_temp_valid;
        body_temp = pending_body_temp;
        body_int = body_temp / 100;
        body_dec = body_temp % 100;

        if (body_dec < 0)
        {
            body_dec = -body_dec;
        }

        if (has_body_temp == RT_TRUE)
        {
            LOG_I("body temp pending upload: %d.%02d C", body_int, body_dec);
        }

        heart_rate = 0;
        spo2 = 0;

        if (app_max30102_get(&heart_rate, &spo2) == 0)
        {
            pending_heart_rate = heart_rate;
            pending_spo2 = spo2;
            pending_max30102 = RT_TRUE;
            LOG_I("max30102 data ready: heartRate=%d, spo2=%d", heart_rate, spo2);
        }

        has_max30102 = pending_max30102;
        heart_rate = pending_heart_rate;
        spo2 = pending_spo2;

        app_time_get_string(date_buf, sizeof(date_buf), time_buf, sizeof(time_buf));

        if (has_body_temp == RT_TRUE)
        {
            if (has_max30102 == RT_TRUE)
            {
                rt_snprintf(json,
                            LOCAL_UPLOAD_JSON_SIZE,
                            "{\"temperature\":%d,"
                            "\"humidity\":%d,"
                            "\"bodyTemperature\":%d.%02d,"
                            "\"heartRate\":%d,"
                            "\"spo2\":%d,"
                            "\"date\":\"%s\","
                            "\"time\":\"%s\"}",
                            temperature,
                            humidity,
                            body_int,
                            body_dec,
                            heart_rate,
                            spo2,
                            date_buf,
                            time_buf);
            }
            else
            {
                rt_snprintf(json,
                            LOCAL_UPLOAD_JSON_SIZE,
                            "{\"temperature\":%d,"
                            "\"humidity\":%d,"
                            "\"bodyTemperature\":%d.%02d,"
                            "\"heartRate\":null,"
                            "\"spo2\":null,"
                            "\"date\":\"%s\","
                            "\"time\":\"%s\"}",
                            temperature,
                            humidity,
                            body_int,
                            body_dec,
                            date_buf,
                            time_buf);
            }
        }
        else
        {
            if (has_max30102 == RT_TRUE)
            {
                rt_snprintf(json,
                            LOCAL_UPLOAD_JSON_SIZE,
                            "{\"temperature\":%d,"
                            "\"humidity\":%d,"
                            "\"bodyTemperature\":null,"
                            "\"heartRate\":%d,"
                            "\"spo2\":%d,"
                            "\"date\":\"%s\","
                            "\"time\":\"%s\"}",
                            temperature,
                            humidity,
                            heart_rate,
                            spo2,
                            date_buf,
                            time_buf);
            }
            else
            {
                rt_snprintf(json,
                            LOCAL_UPLOAD_JSON_SIZE,
                            "{\"temperature\":%d,"
                            "\"humidity\":%d,"
                            "\"bodyTemperature\":null,"
                            "\"heartRate\":null,"
                            "\"spo2\":null,"
                            "\"date\":\"%s\","
                            "\"time\":\"%s\"}",
                            temperature,
                            humidity,
                            date_buf,
                            time_buf);
            }
        }

        post_ret = local_http_post(LOCAL_SERVER_UPLOAD_PATH, json);

        if (post_ret == 0 && has_max30102 == RT_TRUE)
        {
            pending_max30102 = RT_FALSE;
            pending_heart_rate = 0;
            pending_spo2 = 0;
        }

        if (post_ret == 0 && has_body_temp == RT_TRUE)
        {
            pending_body_temp_valid = RT_FALSE;
            pending_body_temp = BODY_TEMP_INVALID_X100;
        }

        plan_count++;

        if (plan_count >= LOCAL_PLAN_REFRESH_UPLOAD_CYCLES)
        {
            plan_count = 0;
            local_get_medicine_plan();
            local_get_medicine_taken_status();
        }

        rt_thread_mdelay(LOCAL_UPLOAD_INTERVAL_MS);
    }
}

int app_local_upload_start(void)
{
    rt_err_t ret;

    if (upload_started == RT_TRUE)
    {
        return 0;
    }

    if (local_http_lock == RT_NULL)
    {
        local_http_lock = rt_mutex_create("local_http", RT_IPC_FLAG_FIFO);
        if (local_http_lock == RT_NULL)
        {
            LOG_E("create local http mutex failed");
            return -1;
        }
    }

    if (local_box_lock == RT_NULL)
    {
        local_box_lock = rt_mutex_create("med_box", RT_IPC_FLAG_FIFO);
        if (local_box_lock == RT_NULL)
        {
            LOG_E("create medicine box mutex failed");
            return -1;
        }
    }

    ret = rt_thread_init(&local_upload_thread,
                         "local_up",
                         local_upload_entry,
                         RT_NULL,
                         local_upload_stack,
                         sizeof(local_upload_stack),
                         22,
                         10);

    if (ret == RT_EOK)
    {
        upload_started = RT_TRUE;
        rt_thread_startup(&local_upload_thread);
        LOG_I("local upload thread started");

        ret = rt_thread_init(&local_camera_control_thread,
                             "cam_ctl",
                             local_camera_control_entry,
                             RT_NULL,
                             local_camera_control_stack,
                             sizeof(local_camera_control_stack),
                             21,
                             10);
        if (ret == RT_EOK)
        {
            rt_thread_startup(&local_camera_control_thread);
            LOG_I("camera control polling thread started");
        }
        else
        {
            LOG_E("camera control thread init failed, ret=%d", ret);
        }

        return 0;
    }

    LOG_E("local upload thread init failed, ret=%d", ret);

    return -1;
}

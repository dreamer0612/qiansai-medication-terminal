#ifndef __APP_K230_AUTH_H__
#define __APP_K230_AUTH_H__

#include <rtthread.h>

typedef struct
{
    char trigger_type[32];
    char user_name[32];
    char permission[16];
    char current_mode[16];
    rt_tick_t update_tick;
    rt_bool_t valid;
} app_k230_auth_status_t;

int app_k230_auth_start(void);
int app_k230_cloud_bridge_start(void);
int app_k230_send_cmd(const char *cmd);
int app_k230_send_medicine_stock(int box_id, const char *medicine_name, int quantity);
int app_k230_get_status(app_k230_auth_status_t *status);
int app_k230_authenticate(app_k230_auth_status_t *status, rt_int32_t timeout_ms);

#endif

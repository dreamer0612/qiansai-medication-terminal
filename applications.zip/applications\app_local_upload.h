#ifndef __APP_LOCAL_UPLOAD_H__
#define __APP_LOCAL_UPLOAD_H__

#include "app_beep_alarm.h"

typedef struct
{
    int box_id;
    int quantity;
    int low_threshold;
    char name[APP_MEDICINE_NAME_LEN];
    char box_name[APP_MEDICINE_BOX_NAME_LEN];
} app_medicine_box_state_t;

typedef struct
{
    char name[APP_MEDICINE_USER_NAME_LEN];
    char phone[16];
} app_family_contact_t;

int app_local_upload_start(void);
int app_local_upload_medicine_taken(const app_medicine_plan_t *plan);
int app_local_upload_camera_recording_start(const app_medicine_plan_t *plan);
int app_local_upload_camera_recording_finish(const app_medicine_plan_t *plan,
                                            const char *status);
int app_local_upload_get_put_tasks(app_medicine_box_state_t *boxes,
                                   int max_count,
                                   int *count);
int app_local_upload_get_box_state(int box_id, app_medicine_box_state_t *box);
int app_local_upload_get_family_contact(app_family_contact_t *contact);
int app_local_upload_medicine_put_done(int box_id,
                                       const char *medicine_name,
                                       int put_count,
                                       int stock_count);

#endif

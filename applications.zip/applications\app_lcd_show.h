#ifndef __APP_LCD_SHOW_H__
#define __APP_LCD_SHOW_H__

int app_lcd_show_start(void);
void app_lcd_show_set_k230_status(const char *user_name,
                                  const char *permission,
                                  const char *current_mode);

#endif

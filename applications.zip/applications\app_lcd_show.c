#include <rtthread.h>
#include <rtdevice.h>
#include <board.h>
#include <drv_lcd.h>
#include <string.h>

#include "app_time.h"
#include "app_sensor.h"
#include "app_lcd_show.h"

#define DBG_TAG "app.lcd"
#define DBG_LVL DBG_INFO
#include <rtdbg.h>

static rt_bool_t lcd_show_started = RT_FALSE;
static char k230_user[32] = "--";
static char k230_permission[16] = "--";
static char k230_mode[16] = "--";
static rt_bool_t k230_status_valid = RT_FALSE;

void app_lcd_show_set_k230_status(const char *user_name,
                                  const char *permission,
                                  const char *current_mode)
{
    rt_base_t level;
    char user_tmp[sizeof(k230_user)];
    char permission_tmp[sizeof(k230_permission)];
    char mode_tmp[sizeof(k230_mode)];

    rt_snprintf(user_tmp, sizeof(user_tmp), "%s", user_name == RT_NULL ? "--" : user_name);
    rt_snprintf(permission_tmp, sizeof(permission_tmp), "%s", permission == RT_NULL ? "--" : permission);
    rt_snprintf(mode_tmp, sizeof(mode_tmp), "%s", current_mode == RT_NULL ? "--" : current_mode);

    level = rt_hw_interrupt_disable();
    memcpy(k230_user, user_tmp, sizeof(k230_user));
    memcpy(k230_permission, permission_tmp, sizeof(k230_permission));
    memcpy(k230_mode, mode_tmp, sizeof(k230_mode));
    k230_status_valid = RT_TRUE;
    rt_hw_interrupt_enable(level);
}

static void lcd_show_entry(void *parameter)
{
    rt_base_t level;
    int temp;
    int humi;
    int ret;

    char date_buf[16];
    char time_buf[16];
    char date_line[32];
    char time_line[32];
    char temp_buf[32];
    char humi_buf[32];
    char k230_line1[32];
    char k230_line2[32];
    char local_user[32];
    char local_permission[16];
    char local_mode[16];
    rt_bool_t local_k230_valid;

    rt_thread_mdelay(1000);

    LOG_I("lcd show thread start");

    lcd_clear(WHITE);
    lcd_set_color(WHITE, BLACK);

    while (1)
    {
        ret = app_sensor_get(&temp, &humi);

        app_time_get_string(date_buf, sizeof(date_buf), time_buf, sizeof(time_buf));

        rt_snprintf(date_line, sizeof(date_line), "Date: %s", date_buf);
        rt_snprintf(time_line, sizeof(time_line), "Time: %s", time_buf);

        if (ret == 0)
        {
            rt_snprintf(temp_buf, sizeof(temp_buf), "Temp: %d C", temp);
            rt_snprintf(humi_buf, sizeof(humi_buf), "Humi: %d %%", humi);
        }
        else
        {
            rt_snprintf(temp_buf, sizeof(temp_buf), "Temp: -- C");
            rt_snprintf(humi_buf, sizeof(humi_buf), "Humi: -- %%");
        }

        level = rt_hw_interrupt_disable();
        memcpy(local_user, k230_user, sizeof(local_user));
        memcpy(local_permission, k230_permission, sizeof(local_permission));
        memcpy(local_mode, k230_mode, sizeof(local_mode));
        local_k230_valid = k230_status_valid;
        rt_hw_interrupt_enable(level);

        if (local_k230_valid == RT_TRUE)
        {
            rt_snprintf(k230_line1, sizeof(k230_line1), "K230: %s", local_permission);
            rt_snprintf(k230_line2, sizeof(k230_line2), "%s %s", local_user, local_mode);
        }
        else
        {
            rt_snprintf(k230_line1, sizeof(k230_line1), "K230: waiting");
            rt_snprintf(k230_line2, sizeof(k230_line2), "User: --");
        }

        lcd_fill(0, 0, 239, 239, WHITE);

        lcd_show_string(20, 25, 24, date_line);
        lcd_show_string(20, 60, 24, time_line);
        lcd_show_string(20, 95, 24, temp_buf);
        lcd_show_string(20, 130, 24, humi_buf);
        lcd_show_string(20, 170, 16, k230_line1);
        lcd_show_string(20, 195, 16, k230_line2);

        LOG_D("lcd show: %s %s %s %s %s %s",
              date_buf,
              time_buf,
              temp_buf,
              humi_buf,
              k230_line1,
              k230_line2);

        rt_thread_mdelay(1000);
    }
}

int app_lcd_show_start(void)
{
    rt_thread_t tid;

    if (lcd_show_started == RT_TRUE)
    {
        return 0;
    }

    tid = rt_thread_create("lcd_show",
                           lcd_show_entry,
                           RT_NULL,
                           2048,
                           20,
                           10);

    if (tid != RT_NULL)
    {
        lcd_show_started = RT_TRUE;
        rt_thread_startup(tid);
        return 0;
    }

    LOG_E("create lcd thread failed");

    return -1;
}

 #ifndef __APP_TIME_H__
#define __APP_TIME_H__

#include <rtthread.h>
#include <time.h>

int app_time_sync(void);
int app_time_auto_sync_start(void);
time_t app_time_get(void);
void app_time_get_string(char *date_buf, int date_len, char *time_buf, int time_len);

#endif

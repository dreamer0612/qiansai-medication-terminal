#include <rtthread.h>
#include <rtdevice.h>
#include <board.h>
#include <string.h>
#include <stdio.h>
#include <cJSON.h>

#include "app_esp32_slave.h"
#include "app_ram.h"
#include "app_sensor.h"
#include "app_time.h"
#include "app_beep_alarm.h"
#include "app_medicine_servo.h"
#include "app_max30102.h"
#include "app_body_temp.h"
#include "app_k230_auth.h"
#include "app_local_upload.h"
#include "app_esp32cam_ctrl.h"
#include "app_v100c.h"

#define DBG_TAG "app.esp32"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>

#define ESP32_UART_NAME        "uart2"
#define ESP32_LINE_BUF_SIZE    512
#define ESP32_UART_RX_BUF_SIZE 128
#define ESP32_SLOT_COUNT       6
#define ESP32_TIMER_LEN        6
#define ESP32_REPORT_BUF_SIZE  768
#define ESP32_VOICE_BUF_SIZE   1024
#define ESP32_PUT_CONTEXT_BUF_SIZE 2048
#define ESP32_PUT_TARGET_COUNT 14
#define ESP32_BATTERY_DEFAULT  85
#define ESP32_MEASURE_TIMEOUT_MS 70000
#define ESP32_AUTH_PROMPT_TIMEOUT_MS 120000
#define ESP32_FACE_AUTH_TIMEOUT_MS 30000
#define ESP32_FACE_PROMPT_TIMEOUT_MS 120000
#define ESP32_BROADCAST_TIMEOUT_MS 60000
#define ESP32_TAKEN_DONE_TIMEOUT_MS 300000
#define ESP32_REPLY_DELAY_MS 120
#define ESP32_AUTH_ACK_RETRY_INTERVAL_MS 3000
#define ESP32_AUTH_ACK_RETRY_COUNT 1
#define ESP32_SLAVE_STACK_SIZE 6144
#define ESP32_MEASURE_STACK_SIZE 2048
#define ESP32_MEDICINE_STACK_SIZE 4096
#define ESP32_MEASURE_MQ_POOL_SIZE 128
#define ESP32_MEDICINE_MQ_POOL_SIZE 1536

typedef enum
{
    ESP32_MEASURE_HEART_SPO2 = 1,
    ESP32_MEASURE_BODY_TEMP = 2
} esp32_measure_type_t;

typedef enum
{
    ESP32_MEDICINE_OPERATION_TAKE = 0,
    ESP32_MEDICINE_OPERATION_PUT = 1
} esp32_medicine_operation_t;

typedef struct
{
    app_medicine_plan_t plan;
    int box_id;
    rt_uint32_t request_id;
    esp32_medicine_operation_t operation;
} esp32_medicine_job_t;

typedef enum
{
    ESP32_MEDICINE_IDLE = 0,
    ESP32_MEDICINE_WAIT_AUTH_PROMPT,
    ESP32_MEDICINE_AUTHENTICATING,
    ESP32_MEDICINE_WAIT_FACE_PROMPT,
    ESP32_MEDICINE_WAIT_BROADCAST,
    ESP32_MEDICINE_WAIT_TAKEN_DONE
} esp32_medicine_phase_t;

typedef struct
{
    int lid_status[ESP32_SLOT_COUNT];
    int stock[ESP32_SLOT_COUNT];
    char timers[ESP32_SLOT_COUNT][ESP32_TIMER_LEN];
    char last_action[32];
    char last_error[64];
} esp32_slave_state_t;

static rt_device_t esp32_uart = RT_NULL;
static struct rt_semaphore esp32_rx_sem;
static rt_mutex_t esp32_tx_lock = RT_NULL;
static rt_mutex_t esp32_state_lock = RT_NULL;
static rt_bool_t esp32_started = RT_FALSE;
static esp32_slave_state_t esp32_state;
static struct rt_messagequeue esp32_measure_mq;
ALIGN(RT_ALIGN_SIZE)
static rt_uint8_t esp32_measure_mq_pool[ESP32_MEASURE_MQ_POOL_SIZE];
static struct rt_messagequeue esp32_medicine_mq;
ALIGN(RT_ALIGN_SIZE)
static rt_uint8_t esp32_medicine_mq_pool[ESP32_MEDICINE_MQ_POOL_SIZE];
static rt_bool_t esp32_medicine_busy = RT_FALSE;
static esp32_medicine_phase_t esp32_medicine_phase = ESP32_MEDICINE_IDLE;
static int esp32_pending_plan_slot = 0;
static int esp32_pending_auth_box_id = 0;
static rt_uint32_t esp32_pending_auth_request_id = 0;
static rt_uint32_t esp32_auth_request_seq = 0;
static rt_uint32_t esp32_pending_box_mask = 0;
static int esp32_requested_box_id = 0;
static int esp32_open_box_id = 0;
static int esp32_taken_done_box_id = 0;
static int esp32_put_done_count = 0;
static esp32_medicine_operation_t esp32_active_operation = ESP32_MEDICINE_OPERATION_TAKE;
static rt_bool_t esp32_auth_prompt_done = RT_FALSE;
static rt_bool_t esp32_face_prompt_done = RT_FALSE;
static struct rt_semaphore esp32_broadcast_done_sem;
static struct rt_semaphore esp32_taken_done_sem;
static struct rt_semaphore esp32_auth_prompt_done_sem;
static struct rt_semaphore esp32_face_prompt_done_sem;
static app_medicine_plan_t esp32_default_plan_buf;
static app_medicine_plan_t esp32_candidate_plan_buf;
static esp32_medicine_job_t esp32_queue_job_buf;
static struct rt_thread esp32_slave_thread;
static struct rt_thread esp32_measure_thread;
static struct rt_thread esp32_medicine_thread;
ALIGN(RT_ALIGN_SIZE)
static rt_uint8_t esp32_slave_stack[ESP32_SLAVE_STACK_SIZE] APP_CCMRAM;
ALIGN(RT_ALIGN_SIZE)
static rt_uint8_t esp32_measure_stack[ESP32_MEASURE_STACK_SIZE] APP_CCMRAM;
ALIGN(RT_ALIGN_SIZE)
static rt_uint8_t esp32_medicine_stack[ESP32_MEDICINE_STACK_SIZE] APP_CCMRAM;
static char esp32_line_buf[ESP32_LINE_BUF_SIZE];
static char esp32_reminder_message[ESP32_VOICE_BUF_SIZE];
static char esp32_put_context_message[ESP32_PUT_CONTEXT_BUF_SIZE];
static app_medicine_box_state_t esp32_put_task_boxes[ESP32_SLOT_COUNT];

static rt_err_t esp32_uart_rx_ind(rt_device_t dev, rt_size_t size)
{
    rt_sem_release(&esp32_rx_sem);
    return RT_EOK;
}

static void esp32_state_init(void)
{
    int i;

    memset(&esp32_state, 0, sizeof(esp32_state));

    for (i = 0; i < ESP32_SLOT_COUNT; i++)
    {
        esp32_state.stock[i] = 10;
        rt_snprintf(esp32_state.timers[i], sizeof(esp32_state.timers[i]), "--:--");
    }

    rt_snprintf(esp32_state.last_action, sizeof(esp32_state.last_action), "boot");
}

static int esp32_json_int(cJSON *root, const char *name, int *value)
{
    cJSON *item;

    if (root == RT_NULL || name == RT_NULL || value == RT_NULL)
    {
        return -1;
    }

    item = cJSON_GetObjectItem(root, name);
    if (item == RT_NULL || !cJSON_IsNumber(item))
    {
        return -1;
    }

    *value = item->valueint;
    return 0;
}

static const char *esp32_json_string(cJSON *root, const char *name)
{
    cJSON *item;

    if (root == RT_NULL || name == RT_NULL)
    {
        return RT_NULL;
    }

    item = cJSON_GetObjectItem(root, name);
    if (item == RT_NULL || !cJSON_IsString(item) || item->valuestring == RT_NULL)
    {
        return RT_NULL;
    }

    return item->valuestring;
}

static void esp32_set_action_locked(const char *action)
{
    rt_snprintf(esp32_state.last_action,
                sizeof(esp32_state.last_action),
                "%s",
                action == RT_NULL ? "" : action);
    esp32_state.last_error[0] = '\0';
}

static void esp32_set_error_locked(const char *error)
{
    rt_snprintf(esp32_state.last_error,
                sizeof(esp32_state.last_error),
                "%s",
                error == RT_NULL ? "unknown_error" : error);
}

static int esp32_parse_hhmm(const char *time_str, int *hour, int *min)
{
    int h = 0;
    int m = 0;
    char tail = '\0';

    if (time_str == RT_NULL || hour == RT_NULL || min == RT_NULL)
    {
        return -1;
    }

    if (sscanf(time_str, "%d:%d%c", &h, &m, &tail) != 2)
    {
        return -1;
    }

    if (h < 0 || h > 23 || m < 0 || m > 59)
    {
        return -1;
    }

    *hour = h;
    *min = m;
    return 0;
}

static int esp32_send_raw(const char *data, rt_size_t len)
{
    rt_size_t written;
    int ret = 0;

    if (esp32_uart == RT_NULL || data == RT_NULL)
    {
        return -1;
    }

    if (esp32_tx_lock != RT_NULL)
    {
        rt_mutex_take(esp32_tx_lock, RT_WAITING_FOREVER);
    }

    rt_thread_mdelay(ESP32_REPLY_DELAY_MS);

    written = rt_device_write(esp32_uart, 0, data, len);
    if (written != len)
    {
        LOG_E("esp32 uart tx failed, expected=%d, written=%d",
              (int)len, (int)written);
        ret = -1;
    }

    rt_kprintf("[ESP32 TX RAW]\n%.*s", (int)len, data);

    if (esp32_tx_lock != RT_NULL)
    {
        rt_mutex_release(esp32_tx_lock);
    }

    return ret;
}

static const char *esp32_json_start(const char *line)
{
    if (line == RT_NULL)
    {
        return RT_NULL;
    }

    while (*line != '\0' && *line != '{')
    {
        line++;
    }

    return *line == '{' ? line : RT_NULL;
}

static void esp32_send_measure_status(const char *type,
                                      const char *status,
                                      const char *reason,
                                      int heart_rate,
                                      int spo2,
                                      rt_int32_t body_temp_x100)
{
    char message[ESP32_VOICE_BUF_SIZE];
    int len;
    int repeat_count = 2;
    int i;

    if (strcmp(type, "heart_spo2") == 0 && strcmp(status, "success") == 0)
    {
        len = rt_snprintf(message, sizeof(message),
                          "{\"tool\":\"measurement_result\",\"type\":\"heart_spo2\"," 
                          "\"status\":\"success\",\"heartRate\":%d,\"spo2\":%d}\n",
                          heart_rate,
                          spo2);
    }
    else if (strcmp(type, "body_temperature") == 0 && strcmp(status, "success") == 0)
    {
        int integer = body_temp_x100 / 100;
        int decimal = body_temp_x100 % 100;
        if (decimal < 0) decimal = -decimal;
        len = rt_snprintf(message, sizeof(message),
                          "{\"tool\":\"measurement_result\",\"type\":\"body_temperature\"," 
                          "\"status\":\"success\",\"bodyTemperature\":%d.%02d}\n",
                          integer,
                          decimal);
    }
    else
    {
        len = rt_snprintf(message, sizeof(message),
                          "{\"tool\":\"measurement_result\",\"type\":\"%s\"," 
                          "\"status\":\"%s\",\"reason\":\"%s\"}\n",
                          type,
                          status,
                          reason == RT_NULL ? "unknown" : reason);
    }

    if (len > 0 && len < (int)sizeof(message))
    {
        for (i = 0; i < repeat_count; i++)
        {
            if (i > 0)
            {
                rt_thread_mdelay(250);
            }

            if (esp32_send_raw(message, len) != 0)
            {
                LOG_E("send measurement result failed: type=%s, status=%s, try=%d",
                      type, status, i + 1);
            }
        }
    }
    else
    {
        LOG_E("build measurement result failed, len=%d", len);
    }
}

static const char *esp32_max30102_reason(int ret)
{
    switch (ret)
    {
    case APP_MAX30102_ERR_NOT_READY:
        return "max30102_not_ready";
    case APP_MAX30102_ERR_BUSY:
        return "max30102_busy";
    case APP_MAX30102_ERR_NO_FINGER:
        return "no_finger";
    case APP_MAX30102_ERR_FINGER_LOST:
        return "finger_lost";
    case APP_MAX30102_ERR_UNSTABLE:
        return "unstable";
    case APP_MAX30102_ERR_TIMEOUT:
        return "timeout";
    default:
        return "unknown";
    }
}

static void esp32_measure_entry(void *parameter)
{
    esp32_measure_type_t type;

    while (1)
    {
        if (rt_mq_recv(&esp32_measure_mq, &type, sizeof(type),
                       RT_WAITING_FOREVER) != RT_EOK)
        {
            continue;
        }

        if (type == ESP32_MEASURE_HEART_SPO2)
        {
            int heart_rate = 0;
            int spo2 = 0;
            int ret = app_max30102_measure(&heart_rate, &spo2,
                                           ESP32_MEASURE_TIMEOUT_MS);
            esp32_send_measure_status("heart_spo2",
                                      ret == 0 ? "success" : "failed",
                                      ret == 0 ? RT_NULL : esp32_max30102_reason(ret),
                                      heart_rate, spo2, BODY_TEMP_INVALID_X100);
        }
        else if (type == ESP32_MEASURE_BODY_TEMP)
        {
            rt_int32_t body_temp = BODY_TEMP_INVALID_X100;
            int ret = app_body_temp_measure(&body_temp,
                                            ESP32_MEASURE_TIMEOUT_MS);
            esp32_send_measure_status("body_temperature",
                                      ret == 0 ? "success" : "failed",
                                      ret == 0 ? RT_NULL : "body_temperature_failed",
                                      0, 0, body_temp);
        }
    }
}

static int esp32_queue_measurement(esp32_measure_type_t type)
{
    const char *type_name = type == ESP32_MEASURE_HEART_SPO2 ?
                            "heart_spo2" : "body_temperature";

    if (rt_mq_send(&esp32_measure_mq, &type, sizeof(type)) != RT_EOK)
    {
        LOG_W("measurement queue busy: %s", type_name);
        esp32_send_measure_status(type_name, "busy", "queue_busy", 0, 0,
                                  BODY_TEMP_INVALID_X100);
        return -1;
    }

    LOG_I("measurement accepted: %s, wait final result", type_name);
    return 0;
}

static rt_bool_t esp32_plan_has_box(const app_medicine_plan_t *plan, int box_id)
{
    int i;

    if (plan == RT_NULL || box_id < 1 || box_id > ESP32_SLOT_COUNT)
    {
        return RT_FALSE;
    }

    if (plan->medicine_count <= 0)
    {
        return box_id == plan->plan_slot ? RT_TRUE : RT_FALSE;
    }

    for (i = 0; i < plan->medicine_count; i++)
    {
        if (plan->medicines[i].box_id == box_id)
        {
            return RT_TRUE;
        }
    }

    return RT_FALSE;
}

static rt_uint32_t esp32_plan_box_mask(const app_medicine_plan_t *plan)
{
    rt_uint32_t mask = 0;
    int i;

    if (plan == RT_NULL)
    {
        return 0;
    }

    for (i = 0; i < plan->medicine_count; i++)
    {
        int box_id = plan->medicines[i].box_id;
        if (box_id >= 1 && box_id <= ESP32_SLOT_COUNT)
        {
            mask |= (1UL << (box_id - 1));
        }
    }

    return mask;
}

static int esp32_box_mask_count(rt_uint32_t mask)
{
    int count = 0;
    int i;

    for (i = 0; i < ESP32_SLOT_COUNT; i++)
    {
        if ((mask & (1UL << i)) != 0)
        {
            count++;
        }
    }

    return count;
}

static int esp32_plan_box_dose(const app_medicine_plan_t *plan, int box_id)
{
    int dose = 0;
    int i;

    if (plan == RT_NULL)
    {
        return 0;
    }

    for (i = 0; i < plan->medicine_count; i++)
    {
        if (plan->medicines[i].box_id == box_id)
        {
            dose += plan->medicines[i].dose_count > 0 ?
                    plan->medicines[i].dose_count : 1;
        }
    }

    return dose;
}

static rt_uint32_t esp32_job_box_mask(const esp32_medicine_job_t *job)
{
    if (job == RT_NULL)
    {
        return 0;
    }

    if (job->box_id >= 1 && job->box_id <= ESP32_SLOT_COUNT)
    {
        return 1UL << (job->box_id - 1);
    }

    return esp32_plan_box_mask(&job->plan);
}

static const char *esp32_plan_box_name(const app_medicine_plan_t *plan,
                                       int box_id)
{
    int i;

    if (plan == RT_NULL)
    {
        return "";
    }

    for (i = 0; i < plan->medicine_count; i++)
    {
        if (plan->medicines[i].box_id == box_id)
        {
            return plan->medicines[i].name;
        }
    }

    return "";
}

static int esp32_put_recommended_count(int stock_count)
{
    int put_count = ESP32_PUT_TARGET_COUNT - stock_count;

    return put_count > 0 ? put_count : 0;
}

static const app_medicine_box_state_t *esp32_find_put_task_box(
    const app_medicine_box_state_t *boxes,
    int count,
    int box_id)
{
    int i;

    if (boxes == RT_NULL)
    {
        return RT_NULL;
    }

    for (i = 0; i < count; i++)
    {
        if (boxes[i].box_id == box_id)
        {
            return &boxes[i];
        }
    }

    return RT_NULL;
}

static int esp32_put_task_recommended_count(const app_medicine_box_state_t *box)
{
    int put_count;

    if (box == RT_NULL)
    {
        return 0;
    }

    put_count = box->low_threshold - box->quantity;
    return put_count > 0 ? put_count : 1;
}

static rt_uint32_t esp32_put_task_mask(const app_medicine_box_state_t *boxes,
                                       int count)
{
    rt_uint32_t mask = 0;
    int i;

    if (boxes == RT_NULL)
    {
        return 0;
    }

    for (i = 0; i < count; i++)
    {
        int box_id = boxes[i].box_id;
        if (box_id >= 1 && box_id <= ESP32_SLOT_COUNT)
        {
            mask |= 1UL << (box_id - 1);
        }
    }

    return mask;
}

static void esp32_put_mode_from_stock(rt_uint32_t mask,
                                      char *mode,
                                      rt_size_t mode_size)
{
    int i;
    rt_bool_t has_stock = RT_FALSE;

    if (mode == RT_NULL || mode_size == 0)
    {
        return;
    }

    rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
    for (i = 0; i < ESP32_SLOT_COUNT; i++)
    {
        if ((mask & (1UL << i)) != 0 && esp32_state.stock[i] > 0)
        {
            has_stock = RT_TRUE;
            break;
        }
    }
    rt_mutex_release(esp32_state_lock);

    rt_snprintf(mode,
                mode_size,
                "%s",
                has_stock == RT_TRUE ? "refill" : "initial_fill");
}

static void esp32_send_face_auth_result(const esp32_medicine_job_t *job,
                                        const char *status,
                                        const char *recognized_name)
{
    char message[256];
    const char *name = recognized_name == RT_NULL || recognized_name[0] == '\0' ?
                       "unknown" : recognized_name;
    const char *expected = job->plan.user_name[0] == '\0' ?
                           "patient" : job->plan.user_name;
    const char *voice_code = strcmp(status, "success") == 0 ?
                             "FACE_AUTH_SUCCESS" : "FACE_AUTH_FAILED";
    int len;

    len = rt_snprintf(message, sizeof(message),
                      "{\"tool\":\"face_auth_result\","
                      "\"plan_slot\":%d,\"slot\":%d,\"box_id\":%d,"
                      "\"status\":\"%s\",\"user_name\":\"%s\","
                      "\"expected_user_name\":\"%s\","
                      "\"voice_code\":\"%s\"}\n",
                      job->plan.plan_slot,
                      job->plan.plan_slot,
                      job->box_id,
                      status,
                      name,
                      expected,
                      voice_code);
    if (len > 0 && len < (int)sizeof(message))
    {
        esp32_send_raw(message, len);
    }
}

static void esp32_send_face_auth_busy(void)
{
    char message[224];
    int plan_slot = 0;
    int box_id = 0;
    int len;

    rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
    plan_slot = esp32_pending_plan_slot;
    box_id = esp32_open_box_id > 0 ? esp32_open_box_id : esp32_requested_box_id;
    rt_mutex_release(esp32_state_lock);

    len = rt_snprintf(message,
                      sizeof(message),
                      "{\"tool\":\"face_auth_result\","
                      "\"plan_slot\":%d,\"slot\":%d,\"box_id\":%d,"
                      "\"status\":\"busy\",\"user_name\":\"unknown\","
                      "\"expected_user_name\":\"patient\","
                      "\"voice_code\":\"FACE_AUTH_FAILED\"}\n",
                      plan_slot,
                      plan_slot,
                      box_id);
    if (len > 0 && len < (int)sizeof(message))
    {
        esp32_send_raw(message, len);
    }
}

static void esp32_send_medicine_auth_ack(int plan_slot,
                                         int box_id,
                                         rt_uint32_t request_id,
                                         int retry)
{
    char ack[160];
    int len;

    len = rt_snprintf(ack, sizeof(ack),
                      "{\"tool\":\"medicine_auth_ack\","
                      "\"plan_slot\":%d,\"slot\":%d,\"box_id\":%d,"
                      "\"status\":\"accepted\","
                      "\"request_id\":%u,\"retry\":%d}\n",
                      plan_slot,
                      plan_slot,
                      box_id,
                      (unsigned int)request_id,
                      retry);
    if (len > 0 && len < (int)sizeof(ack))
    {
        esp32_send_raw(ack, len);
    }
}

static int esp32_resend_auth_ack_if_waiting(void)
{
    rt_bool_t resend = RT_FALSE;
    int plan_slot = 0;
    int box_id = 0;
    rt_uint32_t request_id = 0;

    rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
    if (esp32_medicine_busy == RT_TRUE &&
        esp32_medicine_phase == ESP32_MEDICINE_WAIT_AUTH_PROMPT &&
        esp32_pending_plan_slot > 0)
    {
        resend = RT_TRUE;
        plan_slot = esp32_pending_plan_slot;
        box_id = esp32_pending_auth_box_id;
        request_id = esp32_pending_auth_request_id;
        esp32_set_action_locked("resend_auth_ack");
    }
    else if (esp32_medicine_busy == RT_TRUE)
    {
        rt_mutex_release(esp32_state_lock);
        esp32_send_face_auth_busy();
        return -2;
    }
    rt_mutex_release(esp32_state_lock);

    if (resend == RT_TRUE)
    {
        esp32_send_medicine_auth_ack(plan_slot, box_id, request_id, 0);
        return 1;
    }

    return 0;
}

static rt_err_t esp32_wait_auth_prompt_done_with_ack_retry(int plan_slot,
                                                           int box_id)
{
    rt_tick_t start_tick = rt_tick_get();
    rt_tick_t timeout_tick =
        rt_tick_from_millisecond(ESP32_AUTH_PROMPT_TIMEOUT_MS);
    rt_tick_t retry_tick =
        rt_tick_from_millisecond(ESP32_AUTH_ACK_RETRY_INTERVAL_MS);
    int retry_count = 0;

    while ((rt_tick_t)(rt_tick_get() - start_tick) < timeout_tick)
    {
        rt_tick_t elapsed = (rt_tick_t)(rt_tick_get() - start_tick);
        rt_tick_t remain = timeout_tick - elapsed;
        rt_tick_t wait_tick = remain < retry_tick ? remain : retry_tick;
        rt_err_t ret;

        ret = rt_sem_take(&esp32_auth_prompt_done_sem, wait_tick);
        if (ret == RT_EOK)
        {
            return RT_EOK;
        }

        if (ret != -RT_ETIMEOUT)
        {
            return ret;
        }

        if (retry_count < ESP32_AUTH_ACK_RETRY_COUNT)
        {
            rt_bool_t should_retry = RT_FALSE;

            rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
            if (esp32_medicine_busy == RT_TRUE &&
                esp32_medicine_phase == ESP32_MEDICINE_WAIT_AUTH_PROMPT &&
                esp32_pending_plan_slot == plan_slot &&
                esp32_auth_prompt_done == RT_FALSE)
            {
                esp32_set_action_locked("retry_auth_ack");
                should_retry = RT_TRUE;
            }
            rt_mutex_release(esp32_state_lock);

            if (should_retry == RT_TRUE)
            {
                retry_count++;
                LOG_W("medicine auth ack retry %d/%d: plan_slot=%d box_id=%d",
                      retry_count,
                      ESP32_AUTH_ACK_RETRY_COUNT,
                      plan_slot,
                      box_id);
                rt_uint32_t request_id = 0;

                rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
                request_id = esp32_pending_auth_request_id;
                rt_mutex_release(esp32_state_lock);

                esp32_send_medicine_auth_ack(plan_slot,
                                             box_id,
                                             request_id,
                                             retry_count);
            }
        }
    }

    return -RT_ETIMEOUT;
}

static void esp32_send_medicine_box_result(const esp32_medicine_job_t *job,
                                           const char *status,
                                           int remaining_boxes)
{
    char message[256];
    int len;

    len = rt_snprintf(message, sizeof(message),
                      "{\"tool\":\"medicine_box_result\","
                      "\"plan_slot\":%d,\"slot\":%d,\"box_id\":%d,"
                      "\"status\":\"%s\",\"remaining_boxes\":%d}\n",
                      job->plan.plan_slot,
                      job->plan.plan_slot,
                      job->box_id,
                      status,
                      remaining_boxes);
    if (len > 0 && len < (int)sizeof(message))
    {
        esp32_send_raw(message, len);
    }
}

static void esp32_send_medicine_taken_ack(const esp32_medicine_job_t *job,
                                          int remaining_boxes)
{
    char message[256];
    int len;

    len = rt_snprintf(message, sizeof(message),
                      "{\"tool\":\"medicine_taken_ack\","
                      "\"plan_slot\":%d,\"slot\":%d,\"box_id\":%d,"
                      "\"status\":\"closed\",\"remaining_boxes\":%d}\n",
                      job->plan.plan_slot,
                      job->plan.plan_slot,
                      job->box_id,
                      remaining_boxes);
    if (len > 0 && len < (int)sizeof(message))
    {
        esp32_send_raw(message, len);
    }
}

static void esp32_send_medicine_session_result(const esp32_medicine_job_t *job,
                                               const char *status)
{
    char message[256];
    int len;

    len = rt_snprintf(message, sizeof(message),
                      "{\"tool\":\"medicine_session_result\","
                      "\"plan_slot\":%d,\"slot\":%d,"
                      "\"status\":\"%s\",\"taken\":%s}\n",
                      job->plan.plan_slot,
                      job->plan.plan_slot,
                      status,
                      strcmp(status, "completed") == 0 ? "true" : "false");
    if (len > 0 && len < (int)sizeof(message))
    {
        esp32_send_raw(message, len);
    }
}

static void esp32_send_medicine_already_taken(int plan_slot, int box_id)
{
    char message[256];
    int len;

    len = rt_snprintf(message, sizeof(message),
                      "{\"tool\":\"medicine_already_taken\","
                      "\"event\":\"medicine_already_taken\","
                      "\"plan_slot\":%d,\"slot\":%d,\"box_id\":%d,"
                      "\"status\":\"already_taken\",\"taken\":true,"
                      "\"voice_code\":\"MEDICINE_ALREADY_TAKEN\"}\n",
                      plan_slot,
                      plan_slot,
                      box_id);
    if (len > 0 && len < (int)sizeof(message))
    {
        esp32_send_raw(message, len);
    }
}

static void esp32_send_put_box_result(const esp32_medicine_job_t *job,
                                      const char *status,
                                      int remaining_boxes)
{
    char message[256];
    int len;

    len = rt_snprintf(message, sizeof(message),
                      "{\"tool\":\"put_box_result\","
                      "\"plan_slot\":%d,\"slot\":%d,\"box_id\":%d,"
                      "\"status\":\"%s\",\"remaining_boxes\":%d}\n",
                      job->plan.plan_slot,
                      job->plan.plan_slot,
                      job->box_id,
                      status,
                      remaining_boxes);
    if (len > 0 && len < (int)sizeof(message))
    {
        esp32_send_raw(message, len);
    }
}

static void esp32_send_put_medicine_ack(const esp32_medicine_job_t *job,
                                        int remaining_boxes,
                                        int stock_count)
{
    char message[384];
    const app_medicine_box_state_t *box;
    const char *medicine_name;
    int len;

    box = esp32_find_put_task_box(esp32_put_task_boxes,
                                  ESP32_SLOT_COUNT,
                                  job->box_id);
    medicine_name = box != RT_NULL && box->name[0] != '\0' ?
                    box->name : esp32_plan_box_name(&job->plan, job->box_id);

    len = rt_snprintf(message, sizeof(message),
                      "{\"tool\":\"put_medicine_ack\","
                      "\"plan_slot\":%d,\"slot\":%d,\"box_id\":%d,"
                      "\"status\":\"recorded\",\"medicine_name\":\"%s\","
                      "\"stock_count\":%d,\"remaining_boxes\":%d}\n",
                      job->plan.plan_slot,
                      job->plan.plan_slot,
                      job->box_id,
                      medicine_name,
                      stock_count,
                      remaining_boxes);
    if (len > 0 && len < (int)sizeof(message))
    {
        esp32_send_raw(message, len);
    }
}

static void esp32_send_put_session_result(const esp32_medicine_job_t *job,
                                          const char *status,
                                          const char *mode)
{
    char message[256];
    int len;

    len = rt_snprintf(message, sizeof(message),
                      "{\"tool\":\"put_session_result\","
                      "\"plan_slot\":%d,\"slot\":%d,"
                      "\"status\":\"%s\",\"mode\":\"%s\"}\n",
                      job->plan.plan_slot,
                      job->plan.plan_slot,
                      status,
                      mode == RT_NULL || mode[0] == '\0' ?
                      "refill" : mode);
    if (len > 0 && len < (int)sizeof(message))
    {
        esp32_send_raw(message, len);
    }
}

static int esp32_send_authenticated_medicine_plan(const app_medicine_plan_t *plan)
{
    char time_buf[16];
    char message[ESP32_VOICE_BUF_SIZE];
    int len;
    int i;

    if (plan == RT_NULL || plan->medicine_count <= 0)
    {
        return -1;
    }

    app_time_get_string(RT_NULL, 0, time_buf, sizeof(time_buf));
    len = rt_snprintf(message,
                      ESP32_VOICE_BUF_SIZE,
                      "{\"tool\":\"medicine_plan\"," 
                      "\"event\":\"authenticated_medicine_plan\"," 
                      "\"plan_slot\":%d,\"slot\":%d,"
                      "\"user_name\":\"%s\"," 
                      "\"voice_code\":\"MEDICINE_PLAN\"," 
                      "\"medicines\":[",
                      plan->plan_slot,
                      plan->plan_slot,
                      plan->user_name[0] == '\0' ? "patient" : plan->user_name);
    if (len < 0 || len >= ESP32_VOICE_BUF_SIZE)
    {
        return -1;
    }

    for (i = 0; i < plan->medicine_count &&
                i < APP_MEDICINE_PLAN_MAX_MEDICINES; i++)
    {
        int n = rt_snprintf(message + len,
                            ESP32_VOICE_BUF_SIZE - len,
                            "%s{\"box_id\":%d,\"boxId\":%d,"
                            "\"name\":\"%s\",\"dose_count\":%d}",
                            i == 0 ? "" : ",",
                            plan->medicines[i].box_id,
                            plan->medicines[i].box_id,
                            plan->medicines[i].name,
                            plan->medicines[i].dose_count);
        if (n < 0 || n >= ESP32_VOICE_BUF_SIZE - len)
        {
            return -1;
        }
        len += n;
    }

    {
        int n = rt_snprintf(message + len,
                            ESP32_VOICE_BUF_SIZE - len,
                            "],\"timestamp\":\"%s\"}\n",
                            time_buf);
        if (n < 0 || n >= ESP32_VOICE_BUF_SIZE - len)
        {
            return -1;
        }
        len += n;
    }

    return esp32_send_raw(message, len);
}

static int esp32_send_put_medicine_context(const esp32_medicine_job_t *job,
                                           rt_uint32_t mask,
                                           const char *mode)
{
    char *message = esp32_put_context_message;
    const char *resolved_mode = mode == RT_NULL || mode[0] == '\0' ?
                                "refill" : mode;
    rt_bool_t initial_fill;
    int stocks[ESP32_SLOT_COUNT];
    int len;
    int i;
    rt_bool_t first = RT_TRUE;

    if (job == RT_NULL || job->plan.medicine_count <= 0 || mask == 0)
    {
        return -1;
    }

    initial_fill = strcmp(resolved_mode, "initial_fill") == 0 ?
                   RT_TRUE : RT_FALSE;

    rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
    for (i = 0; i < ESP32_SLOT_COUNT; i++)
    {
        stocks[i] = esp32_state.stock[i];
    }
    rt_mutex_release(esp32_state_lock);

    len = rt_snprintf(message,
                      ESP32_PUT_CONTEXT_BUF_SIZE,
                      "{\"tool\":\"put_medicine_context\","
                      "\"mode\":\"%s\",\"status\":\"ready\","
                      "\"boxes\":[",
                      resolved_mode);
    if (len < 0 || len >= ESP32_PUT_CONTEXT_BUF_SIZE)
    {
        return -1;
    }

    for (i = 0; i < ESP32_SLOT_COUNT; i++)
    {
        int box_id = i + 1;
        int stock_count;
        int n;

        if ((mask & (1UL << i)) == 0)
        {
            continue;
        }

        stock_count = stocks[i] < 0 ? 0 : stocks[i];
        n = rt_snprintf(message + len,
                        ESP32_PUT_CONTEXT_BUF_SIZE - len,
                        "%s{\"box_id\":%d,\"bound\":%s,"
                        "\"medicine_name\":\"%s\","
                        "\"stock_count\":%d,\"stock_source\":\"local\","
                        "\"status\":\"%s\"}",
                        first == RT_TRUE ? "" : ",",
                        box_id,
                        initial_fill == RT_TRUE ? "false" : "true",
                        esp32_plan_box_name(&job->plan, box_id),
                        stock_count,
                        stock_count <= 0 ? "empty" :
                        (stock_count < ESP32_PUT_TARGET_COUNT ?
                         "low" : "normal"));
        if (n < 0 || n >= ESP32_PUT_CONTEXT_BUF_SIZE - len)
        {
            return -1;
        }
        len += n;
        first = RT_FALSE;
    }

    {
        int n = rt_snprintf(message + len,
                            ESP32_PUT_CONTEXT_BUF_SIZE - len,
                            "],\"tasks\":[");
        if (n < 0 || n >= ESP32_PUT_CONTEXT_BUF_SIZE - len)
        {
            return -1;
        }
        len += n;
    }

    first = RT_TRUE;
    for (i = 0; i < ESP32_SLOT_COUNT; i++)
    {
        int box_id = i + 1;
        int stock_count;
        int put_count;
        int n;

        if ((mask & (1UL << i)) == 0)
        {
            continue;
        }

        stock_count = stocks[i] < 0 ? 0 : stocks[i];
        put_count = esp32_put_recommended_count(stock_count);
        n = rt_snprintf(message + len,
                        ESP32_PUT_CONTEXT_BUF_SIZE - len,
                        "%s{\"box_id\":%d,\"medicine_name\":\"%s\","
                        "\"action\":\"%s\",\"bound\":%s,"
                        "\"stock_count\":%d,\"target_count\":%d,"
                        "\"put_count\":%d,\"stock_source\":\"local\","
                        "\"confirm_binding\":%s}",
                        first == RT_TRUE ? "" : ",",
                        box_id,
                        esp32_plan_box_name(&job->plan, box_id),
                        initial_fill == RT_TRUE ? "bind_and_fill" : "refill",
                        initial_fill == RT_TRUE ? "false" : "true",
                        stock_count,
                        ESP32_PUT_TARGET_COUNT,
                        put_count,
                        initial_fill == RT_TRUE ? "true" : "false");
        if (n < 0 || n >= ESP32_PUT_CONTEXT_BUF_SIZE - len)
        {
            return -1;
        }
        len += n;
        first = RT_FALSE;
    }

    {
        int n = rt_snprintf(message + len,
                            ESP32_PUT_CONTEXT_BUF_SIZE - len,
                            "]}\n");
        if (n < 0 || n >= ESP32_PUT_CONTEXT_BUF_SIZE - len)
        {
            return -1;
        }
        len += n;
    }

    return esp32_send_raw(message, len);
}

static int esp32_send_put_medicine_context_from_boxes(
    const esp32_medicine_job_t *job,
    const app_medicine_box_state_t *boxes,
    int count)
{
    char *message = esp32_put_context_message;
    int len;
    int i;

    if (job == RT_NULL || boxes == RT_NULL || count <= 0)
    {
        return -1;
    }

    len = rt_snprintf(message,
                      ESP32_PUT_CONTEXT_BUF_SIZE,
                      "{\"tool\":\"put_medicine_context\","
                      "\"mode\":\"refill\",\"status\":\"ready\","
                      "\"boxes\":[");
    if (len < 0 || len >= ESP32_PUT_CONTEXT_BUF_SIZE)
    {
        return -1;
    }

    for (i = 0; i < count; i++)
    {
        const app_medicine_box_state_t *box = &boxes[i];
        int put_count = esp32_put_task_recommended_count(box);
        int n;

        n = rt_snprintf(message + len,
                        ESP32_PUT_CONTEXT_BUF_SIZE - len,
                        "%s{\"box_id\":%d,\"bound\":true,"
                        "\"medicine_name\":\"%s\","
                        "\"stock_count\":%d,"
                        "\"lowThreshold\":%d,"
                        "\"target_count\":%d,"
                        "\"put_count\":%d,"
                        "\"stock_source\":\"cloud\","
                        "\"status\":\"low\"}",
                        i == 0 ? "" : ",",
                        box->box_id,
                        box->name,
                        box->quantity,
                        box->low_threshold,
                        box->quantity + put_count,
                        put_count);
        if (n < 0 || n >= ESP32_PUT_CONTEXT_BUF_SIZE - len)
        {
            return -1;
        }
        len += n;
    }

    {
        int n = rt_snprintf(message + len,
                            ESP32_PUT_CONTEXT_BUF_SIZE - len,
                            "],\"tasks\":[");
        if (n < 0 || n >= ESP32_PUT_CONTEXT_BUF_SIZE - len)
        {
            return -1;
        }
        len += n;
    }

    for (i = 0; i < count; i++)
    {
        const app_medicine_box_state_t *box = &boxes[i];
        int put_count = esp32_put_task_recommended_count(box);
        int n;

        n = rt_snprintf(message + len,
                        ESP32_PUT_CONTEXT_BUF_SIZE - len,
                        "%s{\"box_id\":%d,\"medicine_name\":\"%s\","
                        "\"action\":\"refill\",\"bound\":true,"
                        "\"stock_count\":%d,"
                        "\"lowThreshold\":%d,"
                        "\"target_count\":%d,"
                        "\"put_count\":%d,"
                        "\"stock_source\":\"cloud\","
                        "\"confirm_binding\":false}",
                        i == 0 ? "" : ",",
                        box->box_id,
                        box->name,
                        box->quantity,
                        box->low_threshold,
                        box->quantity + put_count,
                        put_count);
        if (n < 0 || n >= ESP32_PUT_CONTEXT_BUF_SIZE - len)
        {
            return -1;
        }
        len += n;
    }

    {
        int n = rt_snprintf(message + len,
                            ESP32_PUT_CONTEXT_BUF_SIZE - len,
                            "]}\n");
        if (n < 0 || n >= ESP32_PUT_CONTEXT_BUF_SIZE - len)
        {
            return -1;
        }
        len += n;
    }

    return esp32_send_raw(message, len);
}

static int esp32_send_put_medicine_blocked(const esp32_medicine_job_t *job,
                                           const char *status,
                                           const char *speech)
{
    char message[256];
    int len;

    if (job == RT_NULL)
    {
        return -1;
    }

    len = rt_snprintf(message,
                      sizeof(message),
                      "{\"tool\":\"put_medicine_context\","
                      "\"mode\":\"refill\","
                      "\"status\":\"%s\","
                      "\"speech\":\"%s\","
                      "\"boxes\":[],\"tasks\":[]}\n",
                      status == RT_NULL ? "stock_unknown" : status,
                      speech == RT_NULL ?
                      "\\u5e93\\u5b58\\u4fe1\\u606f\\u83b7\\u53d6"
                      "\\u5931\\u8d25\\uff0c\\u8bf7\\u7a0d\\u540e"
                      "\\u91cd\\u8bd5" : speech);
    if (len > 0 && len < (int)sizeof(message))
    {
        return esp32_send_raw(message, len);
    }

    return -1;
}

static int esp32_send_put_medicine_no_low_stock(const esp32_medicine_job_t *job)
{
    return esp32_send_put_medicine_blocked(
        job,
        "no_low_stock",
        "\\u5f53\\u524d\\u6ca1\\u6709\\u4f4e\\u4e8e"
        "\\u9608\\u503c\\u7684\\u836f\\u4ed3\\uff0c"
        "\\u65e0\\u9700\\u8865\\u836f");
}

static int esp32_send_put_medicine_stock_unknown(const esp32_medicine_job_t *job)
{
    return esp32_send_put_medicine_blocked(
        job,
        "stock_unknown",
        "\\u5e93\\u5b58\\u4fe1\\u606f\\u83b7\\u53d6"
        "\\u5931\\u8d25\\uff0c\\u8bf7\\u7a0d\\u540e"
        "\\u91cd\\u8bd5");
}

static void esp32_medicine_entry(void *parameter)
{
    esp32_medicine_job_t job;

    while (1)
    {
        app_k230_auth_status_t auth_status;
        int auth_ret;
        rt_bool_t auth_allowed;
        rt_bool_t user_match;
        rt_err_t auth_prompt_wait_ret;

        if (rt_mq_recv(&esp32_medicine_mq, &job, sizeof(job),
                       RT_WAITING_FOREVER) != RT_EOK)
        {
            continue;
        }

        memset(&auth_status, 0, sizeof(auth_status));
        if (job.operation == ESP32_MEDICINE_OPERATION_TAKE)
        {
            app_esp32cam_ctrl_set_medicine(RT_TRUE);
            (void)app_local_upload_camera_recording_start(&job.plan);
        }

        rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
        esp32_medicine_phase = ESP32_MEDICINE_WAIT_AUTH_PROMPT;
        esp32_pending_plan_slot = job.plan.plan_slot;
        esp32_active_operation = job.operation;
        esp32_auth_prompt_done = RT_FALSE;
        esp32_set_action_locked(job.operation == ESP32_MEDICINE_OPERATION_PUT ?
                                "wait_put_auth_prompt" : "wait_auth_prompt");
        rt_mutex_release(esp32_state_lock);

        auth_prompt_wait_ret =
            esp32_wait_auth_prompt_done_with_ack_retry(job.plan.plan_slot,
                                                       job.box_id);
        if (auth_prompt_wait_ret != RT_EOK)
        {
            rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
            esp32_set_error_locked("auth_prompt_timeout");
            esp32_medicine_busy = RT_FALSE;
            esp32_medicine_phase = ESP32_MEDICINE_IDLE;
            esp32_pending_plan_slot = 0;
            esp32_pending_auth_box_id = 0;
            esp32_pending_auth_request_id = 0;
            esp32_pending_box_mask = 0;
            esp32_requested_box_id = 0;
            esp32_open_box_id = 0;
            esp32_taken_done_box_id = 0;
            esp32_put_done_count = 0;
            esp32_active_operation = ESP32_MEDICINE_OPERATION_TAKE;
            esp32_auth_prompt_done = RT_FALSE;
            esp32_face_prompt_done = RT_FALSE;
            rt_mutex_release(esp32_state_lock);
            if (job.operation == ESP32_MEDICINE_OPERATION_PUT)
            {
                esp32_send_put_session_result(&job,
                                              "auth_prompt_timeout",
                                              "refill");
            }
            else
            {
                esp32_send_medicine_session_result(&job,
                                                   "auth_prompt_timeout");
                (void)app_local_upload_camera_recording_finish(
                    &job.plan,
                    "auth_prompt_timeout");
                app_esp32cam_ctrl_set_medicine(RT_FALSE);
            }
            continue;
        }

        rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
        esp32_medicine_phase = ESP32_MEDICINE_AUTHENTICATING;
        esp32_set_action_locked("face_auth_started");
        rt_mutex_release(esp32_state_lock);

        auth_ret = app_k230_authenticate(&auth_status,
                                         ESP32_FACE_AUTH_TIMEOUT_MS);

        auth_allowed = auth_ret == 0 && strcmp(auth_status.permission, "allowed") == 0 ?
                       RT_TRUE : RT_FALSE;
        user_match = job.plan.user_name[0] == '\0' ||
                     strcmp(job.plan.user_name, "patient") == 0 ||
                     strcmp(job.plan.user_name, auth_status.user_name) == 0 ?
                     RT_TRUE : RT_FALSE;
        LOG_I("medicine face auth: ret=%d trigger=%s permission=%s user=%s expected=%s allowed=%d match=%d",
              auth_ret,
              auth_status.trigger_type,
              auth_status.permission,
              auth_status.user_name,
              job.plan.user_name,
              auth_allowed == RT_TRUE ? 1 : 0,
              user_match == RT_TRUE ? 1 : 0);

        if (auth_allowed == RT_TRUE && user_match == RT_TRUE)
        {
            rt_uint32_t pending_mask;
            rt_err_t face_prompt_wait_ret;
            char put_mode[16];

            put_mode[0] = '\0';

            esp32_send_face_auth_result(&job, "success", auth_status.user_name);

            rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
            esp32_medicine_phase = ESP32_MEDICINE_WAIT_FACE_PROMPT;
            esp32_pending_plan_slot = job.plan.plan_slot;
            esp32_pending_box_mask = 0;
            esp32_requested_box_id = 0;
            esp32_face_prompt_done = RT_FALSE;
            esp32_set_action_locked(job.operation == ESP32_MEDICINE_OPERATION_PUT ?
                                    "wait_prepare_put_medicine" :
                                    "wait_face_success_prompt");
            rt_mutex_release(esp32_state_lock);

            face_prompt_wait_ret = rt_sem_take(&esp32_face_prompt_done_sem,
                                               rt_tick_from_millisecond(
                                                   ESP32_FACE_PROMPT_TIMEOUT_MS));
            if (face_prompt_wait_ret != RT_EOK)
            {
                rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
                esp32_set_error_locked("face_success_prompt_timeout");
                esp32_medicine_busy = RT_FALSE;
                esp32_medicine_phase = ESP32_MEDICINE_IDLE;
                esp32_pending_plan_slot = 0;
                esp32_pending_auth_box_id = 0;
                esp32_pending_auth_request_id = 0;
                esp32_pending_box_mask = 0;
                esp32_requested_box_id = 0;
                esp32_open_box_id = 0;
                esp32_taken_done_box_id = 0;
                esp32_put_done_count = 0;
                esp32_active_operation = ESP32_MEDICINE_OPERATION_TAKE;
                esp32_face_prompt_done = RT_FALSE;
                rt_mutex_release(esp32_state_lock);
                if (job.operation == ESP32_MEDICINE_OPERATION_PUT)
                {
                    esp32_send_put_session_result(&job,
                                                  "face_prompt_timeout",
                                                  "refill");
                }
                else
                {
                    esp32_send_medicine_session_result(&job,
                                                       "face_prompt_timeout");
                    (void)app_local_upload_camera_recording_finish(
                        &job.plan,
                        "face_prompt_timeout");
                    app_esp32cam_ctrl_set_medicine(RT_FALSE);
                }
                continue;
            }

            if (job.operation == ESP32_MEDICINE_OPERATION_PUT)
            {
                int put_task_count = 0;
                int put_task_ret;

                memset(esp32_put_task_boxes, 0, sizeof(esp32_put_task_boxes));
                put_task_ret = app_local_upload_get_put_tasks(
                    esp32_put_task_boxes,
                    ESP32_SLOT_COUNT,
                    &put_task_count);
                if (put_task_ret != 0)
                {
                    pending_mask = 0;
                    if (put_task_ret == -3)
                    {
                        esp32_send_put_medicine_stock_unknown(&job);
                    }
                    else
                    {
                        esp32_send_put_medicine_no_low_stock(&job);
                    }
                }
                else
                {
                    pending_mask = esp32_put_task_mask(esp32_put_task_boxes,
                                                       put_task_count);
                    rt_snprintf(put_mode, sizeof(put_mode), "refill");
                }
            }
            else
            {
                pending_mask = esp32_job_box_mask(&job);
            }

            rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
            esp32_medicine_phase = ESP32_MEDICINE_WAIT_BROADCAST;
            esp32_pending_box_mask = pending_mask;
            esp32_requested_box_id = 0;
            esp32_set_action_locked(job.operation == ESP32_MEDICINE_OPERATION_PUT ?
                                    "wait_put_open_request" :
                                    "wait_medicine_broadcast");
            rt_mutex_release(esp32_state_lock);

            if (job.operation == ESP32_MEDICINE_OPERATION_PUT)
            {
                if (pending_mask != 0 &&
                    esp32_send_put_medicine_context_from_boxes(
                        &job,
                        esp32_put_task_boxes,
                        esp32_box_mask_count(pending_mask)) != 0)
                {
                    rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
                    esp32_set_error_locked("put_context_send_failed");
                    esp32_pending_box_mask = 0;
                    rt_mutex_release(esp32_state_lock);
                    pending_mask = 0;
                }
            }
            else if (esp32_send_authenticated_medicine_plan(&job.plan) != 0)
            {
                rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
                esp32_set_error_locked("medicine_plan_send_failed");
                esp32_pending_box_mask = 0;
                rt_mutex_release(esp32_state_lock);
                pending_mask = 0;
            }

            while (pending_mask != 0)
            {
                rt_err_t wait_ret;
                int box_id;
                int open_ret;
                int taken_box_id;
                int put_count;
                int remaining_boxes;
                int i;
                rt_bool_t k230_stock_notify = RT_FALSE;
                int k230_stock_count = 0;

                rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
                esp32_medicine_phase = ESP32_MEDICINE_WAIT_BROADCAST;
                esp32_open_box_id = 0;
                esp32_taken_done_box_id = 0;
                esp32_put_done_count = 0;
                rt_mutex_release(esp32_state_lock);

                wait_ret = rt_sem_take(&esp32_broadcast_done_sem,
                                       rt_tick_from_millisecond(
                                           ESP32_BROADCAST_TIMEOUT_MS));
                if (wait_ret != RT_EOK)
                {
                    rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
                    esp32_set_error_locked("medicine_broadcast_timeout");
                    rt_mutex_release(esp32_state_lock);
                    break;
                }

                rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
                box_id = esp32_requested_box_id;
                esp32_requested_box_id = 0;
                rt_mutex_release(esp32_state_lock);

                if (box_id < 1 || box_id > ESP32_SLOT_COUNT ||
                    (pending_mask & (1UL << (box_id - 1))) == 0)
                {
                    continue;
                }

                job.box_id = box_id;
                open_ret = app_medicine_servo_open(box_id);
                rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
                if (open_ret == 0)
                {
                    int dose = esp32_plan_box_dose(&job.plan, box_id);
                    memset(esp32_state.lid_status, 0,
                           sizeof(esp32_state.lid_status));
                    esp32_state.lid_status[box_id - 1] = 1;
                    if (job.operation == ESP32_MEDICINE_OPERATION_TAKE)
                    {
                        app_medicine_box_state_t box_state;
                        if (app_local_upload_get_box_state(box_id, &box_state) == 0)
                        {
                            esp32_state.stock[box_id - 1] = box_state.quantity;
                        }
                        esp32_state.stock[box_id - 1] -= dose;
                        if (esp32_state.stock[box_id - 1] < 0)
                        {
                            esp32_state.stock[box_id - 1] = 0;
                        }
                        k230_stock_count = esp32_state.stock[box_id - 1];
                        k230_stock_notify = RT_TRUE;
                    }
                    pending_mask &= ~(1UL << (box_id - 1));
                    esp32_pending_box_mask = pending_mask;
                    esp32_open_box_id = box_id;
                    esp32_taken_done_box_id = 0;
                    esp32_put_done_count = 0;
                    esp32_medicine_phase = ESP32_MEDICINE_WAIT_TAKEN_DONE;
                    esp32_set_action_locked(job.operation == ESP32_MEDICINE_OPERATION_PUT ?
                                            "put_box_opened" :
                                            "medicine_box_opened");
                }
                else
                {
                    esp32_set_error_locked("servo_open_failed");
                }
                rt_mutex_release(esp32_state_lock);

                if (k230_stock_notify == RT_TRUE)
                {
                    app_medicine_box_state_t box_state;
                    const char *medicine_name;

                    medicine_name = esp32_plan_box_name(&job.plan, box_id);
                    if ((medicine_name == RT_NULL || medicine_name[0] == '\0') &&
                        app_local_upload_get_box_state(box_id, &box_state) == 0)
                    {
                        medicine_name = box_state.name[0] != '\0' ?
                                        box_state.name : box_state.box_name;
                    }
                    (void)app_k230_send_medicine_stock(box_id,
                                                       medicine_name,
                                                       k230_stock_count);
                }

                remaining_boxes = esp32_box_mask_count(pending_mask);
                if (job.operation == ESP32_MEDICINE_OPERATION_PUT)
                {
                    esp32_send_put_box_result(&job,
                                              open_ret == 0 ?
                                              "opened" : "servo_failed",
                                              remaining_boxes);
                }
                else
                {
                    esp32_send_medicine_box_result(&job,
                                                   open_ret == 0 ?
                                                   "opened" : "servo_failed",
                                                   remaining_boxes);
                }

                if (open_ret != 0)
                {
                    continue;
                }

                wait_ret = rt_sem_take(&esp32_taken_done_sem,
                                       rt_tick_from_millisecond(
                                           ESP32_TAKEN_DONE_TIMEOUT_MS));
                if (wait_ret != RT_EOK)
                {
                    (void)app_medicine_servo_close();
                    rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
                    memset(esp32_state.lid_status, 0,
                           sizeof(esp32_state.lid_status));
                    esp32_open_box_id = 0;
                    esp32_taken_done_box_id = 0;
                    esp32_put_done_count = 0;
                    esp32_set_error_locked("medicine_taken_timeout");
                    rt_mutex_release(esp32_state_lock);
                    if (job.operation == ESP32_MEDICINE_OPERATION_PUT)
                    {
                        esp32_send_put_session_result(&job,
                                                      "timeout",
                                                      put_mode);
                    }
                    else
                    {
                        esp32_send_medicine_session_result(&job, "timeout");
                    }
                    break;
                }

                rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
                taken_box_id = esp32_taken_done_box_id;
                put_count = esp32_put_done_count;
                esp32_taken_done_box_id = 0;
                esp32_put_done_count = 0;
                rt_mutex_release(esp32_state_lock);

                if (taken_box_id != box_id)
                {
                    continue;
                }

                if (app_medicine_servo_close() != 0)
                {
                    rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
                    esp32_set_error_locked("servo_close_failed");
                    rt_mutex_release(esp32_state_lock);
                }

                rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
                for (i = 0; i < ESP32_SLOT_COUNT; i++)
                {
                    esp32_state.lid_status[i] = 0;
                }
                if (job.operation == ESP32_MEDICINE_OPERATION_PUT)
                {
                    const app_medicine_box_state_t *put_box =
                        esp32_find_put_task_box(esp32_put_task_boxes,
                                                ESP32_SLOT_COUNT,
                                                box_id);
                    int base_stock = put_box != RT_NULL ?
                                     put_box->quantity :
                                     esp32_state.stock[box_id - 1];

                    if (put_count <= 0)
                    {
                        put_count = esp32_put_task_recommended_count(put_box);
                    }
                    if (put_count <= 0)
                    {
                        put_count = 1;
                    }
                    esp32_state.stock[box_id - 1] = base_stock + put_count;
                }
                esp32_open_box_id = 0;
                if (job.operation == ESP32_MEDICINE_OPERATION_PUT)
                {
                    esp32_set_action_locked(remaining_boxes == 0 ?
                                            "medicine_put_completed" :
                                            "medicine_put_done");
                }
                else
                {
                    esp32_set_action_locked(remaining_boxes == 0 ?
                                            "medicine_completed" :
                                            "medicine_box_taken");
                }
                if (remaining_boxes > 0)
                {
                    esp32_medicine_phase = ESP32_MEDICINE_WAIT_BROADCAST;
                    esp32_requested_box_id = 0;
                    esp32_taken_done_box_id = 0;
                    esp32_put_done_count = 0;
                    esp32_set_action_locked(
                        job.operation == ESP32_MEDICINE_OPERATION_PUT ?
                        "wait_put_open_request" :
                        "wait_medicine_broadcast");
                }
                rt_mutex_release(esp32_state_lock);

                if (job.operation == ESP32_MEDICINE_OPERATION_PUT)
                {
                    int stock_count;
                    const app_medicine_box_state_t *put_box;
                    const char *medicine_name;

                    rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
                    stock_count = esp32_state.stock[box_id - 1];
                    rt_mutex_release(esp32_state_lock);

                    put_box = esp32_find_put_task_box(esp32_put_task_boxes,
                                                      ESP32_SLOT_COUNT,
                                                      box_id);
                    medicine_name = put_box != RT_NULL &&
                                    put_box->name[0] != '\0' ?
                                    put_box->name :
                                    esp32_plan_box_name(&job.plan, box_id);

                    if (app_local_upload_medicine_put_done(box_id,
                                                           medicine_name,
                                                           put_count,
                                                           stock_count) != 0)
                    {
                        rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
                        esp32_set_error_locked("medicine_put_upload_failed");
                        rt_mutex_release(esp32_state_lock);
                    }

                    esp32_send_put_medicine_ack(&job,
                                                remaining_boxes,
                                                stock_count);
                }
                else
                {
                    int stock_count;

                    rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
                    stock_count = esp32_state.stock[box_id - 1];
                    rt_mutex_release(esp32_state_lock);

                    esp32_send_medicine_taken_ack(&job, remaining_boxes);
                    app_v100c_notify_low_stock(&job.plan,
                                               box_id,
                                               stock_count);
                }

                if (remaining_boxes == 0)
                {
                    if (job.operation == ESP32_MEDICINE_OPERATION_TAKE)
                    {
                        app_beep_alarm_mark_taken(job.plan.plan_slot);
                        if (app_local_upload_medicine_taken(&job.plan) != 0)
                        {
                            rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
                            esp32_set_error_locked("medicine_taken_upload_failed");
                            rt_mutex_release(esp32_state_lock);
                        }
                    }
                    if (job.operation == ESP32_MEDICINE_OPERATION_PUT)
                    {
                        esp32_send_put_session_result(&job,
                                                      "completed",
                                                      put_mode);
                    }
                    else
                    {
                        esp32_send_medicine_session_result(&job, "completed");
                    }
                }
            }
        }
        else
        {
            esp32_send_face_auth_result(&job, "failed", auth_status.user_name);
            rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
            esp32_set_action_locked(user_match == RT_TRUE ?
                                    "face_auth_failed" : "face_user_mismatch");
            rt_mutex_release(esp32_state_lock);
        }

        rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
        esp32_medicine_busy = RT_FALSE;
        esp32_medicine_phase = ESP32_MEDICINE_IDLE;
        esp32_pending_plan_slot = 0;
        esp32_pending_auth_box_id = 0;
        esp32_pending_auth_request_id = 0;
        esp32_pending_box_mask = 0;
        esp32_requested_box_id = 0;
        esp32_open_box_id = 0;
        esp32_taken_done_box_id = 0;
        esp32_put_done_count = 0;
        esp32_active_operation = ESP32_MEDICINE_OPERATION_TAKE;
        esp32_auth_prompt_done = RT_FALSE;
        esp32_face_prompt_done = RT_FALSE;
        rt_mutex_release(esp32_state_lock);
        if (job.operation == ESP32_MEDICINE_OPERATION_TAKE)
        {
            (void)app_local_upload_camera_recording_finish(&job.plan,
                                                           "completed");
            app_esp32cam_ctrl_set_medicine(RT_FALSE);
        }
    }
}

static int esp32_queue_medicine(int plan_slot,
                                int box_id,
                                esp32_medicine_operation_t operation)
{
    esp32_medicine_job_t *job = &esp32_queue_job_buf;

    memset(job, 0, sizeof(*job));
    if (app_beep_alarm_get_plan(plan_slot, &job->plan) != 0)
    {
        if (operation != ESP32_MEDICINE_OPERATION_PUT)
        {
            return -1;
        }

        memset(&job->plan, 0, sizeof(job->plan));
        job->plan.plan_slot = plan_slot;
        rt_snprintf(job->plan.user_name,
                    sizeof(job->plan.user_name),
                    "patient");
    }

    if (operation != ESP32_MEDICINE_OPERATION_PUT &&
        (job->plan.medicine_count <= 0 ||
         esp32_plan_box_mask(&job->plan) == 0))
    {
        return -1;
    }

    if (operation != ESP32_MEDICINE_OPERATION_PUT &&
        box_id > 0 && esp32_plan_has_box(&job->plan, box_id) != RT_TRUE)
    {
        return -3;
    }
    job->box_id = box_id;
    job->operation = operation;

    rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
    if (esp32_medicine_busy == RT_TRUE)
    {
        rt_mutex_release(esp32_state_lock);
        esp32_send_face_auth_busy();
        return -2;
    }
    esp32_medicine_busy = RT_TRUE;
    esp32_medicine_phase = ESP32_MEDICINE_WAIT_AUTH_PROMPT;
    esp32_pending_plan_slot = job->plan.plan_slot;
    esp32_pending_auth_box_id = job->box_id;
    esp32_auth_request_seq++;
    if (esp32_auth_request_seq == 0)
    {
        esp32_auth_request_seq = 1;
    }
    job->request_id = esp32_auth_request_seq;
    esp32_pending_auth_request_id = job->request_id;
    esp32_open_box_id = 0;
    esp32_taken_done_box_id = 0;
    esp32_put_done_count = 0;
    esp32_active_operation = operation;
    esp32_auth_prompt_done = RT_FALSE;
    esp32_face_prompt_done = RT_FALSE;
    esp32_set_action_locked(operation == ESP32_MEDICINE_OPERATION_PUT ?
                            "wait_put_auth_prompt" : "wait_auth_prompt");
    rt_mutex_release(esp32_state_lock);

    while (rt_sem_trytake(&esp32_broadcast_done_sem) == RT_EOK)
    {
    }
    while (rt_sem_trytake(&esp32_taken_done_sem) == RT_EOK)
    {
    }
    while (rt_sem_trytake(&esp32_face_prompt_done_sem) == RT_EOK)
    {
    }
    while (rt_sem_trytake(&esp32_auth_prompt_done_sem) == RT_EOK)
    {
    }

    if (rt_mq_send(&esp32_medicine_mq, job, sizeof(*job)) != RT_EOK)
    {
        rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
        esp32_medicine_busy = RT_FALSE;
        esp32_medicine_phase = ESP32_MEDICINE_IDLE;
        esp32_pending_plan_slot = 0;
        esp32_pending_auth_box_id = 0;
        esp32_pending_auth_request_id = 0;
        esp32_active_operation = ESP32_MEDICINE_OPERATION_TAKE;
        rt_mutex_release(esp32_state_lock);
        return -2;
    }

    esp32_send_medicine_auth_ack(job->plan.plan_slot,
                                 job->box_id,
                                 job->request_id,
                                 0);
    return 0;
}

static int esp32_send_report_with_error(const char *error)
{
    esp32_slave_state_t state;
    int temperature = 0;
    int humidity = 0;
    rt_bool_t has_sensor;
    char time_buf[16];
    char temp_text[16];
    char humi_text[16];
    char report[ESP32_REPORT_BUF_SIZE];
    int len;

    if (esp32_state_lock != RT_NULL)
    {
        rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
    }

    state = esp32_state;

    if (esp32_state_lock != RT_NULL)
    {
        rt_mutex_release(esp32_state_lock);
    }

    (void)error;
    has_sensor = app_sensor_get(&temperature, &humidity) == 0 ? RT_TRUE : RT_FALSE;
    app_time_get_string(RT_NULL, 0, time_buf, sizeof(time_buf));

    if (has_sensor == RT_TRUE)
    {
        rt_snprintf(temp_text, sizeof(temp_text), "%d", temperature);
        rt_snprintf(humi_text, sizeof(humi_text), "%d", humidity);
    }
    else
    {
        rt_snprintf(temp_text, sizeof(temp_text), "null");
        rt_snprintf(humi_text, sizeof(humi_text), "null");
    }

    len = rt_snprintf(report,
                      sizeof(report),
                      "[State Report]{"
                      "\"lid_status\":[%d,%d,%d,%d,%d,%d],"
                      "\"temperature\":%s,"
                      "\"humidity\":%s,"
                      "\"battery\":%d,"
                      "\"last_action\":\"%s\","
                      "\"timestamp\":\"%s\"",
                      state.lid_status[0],
                      state.lid_status[1],
                      state.lid_status[2],
                      state.lid_status[3],
                      state.lid_status[4],
                      state.lid_status[5],
                      temp_text,
                      humi_text,
                      ESP32_BATTERY_DEFAULT,
                      state.last_action,
                      time_buf);

    if (len < 0 || len >= (int)sizeof(report))
    {
        LOG_E("state report buffer too small");
        return -1;
    }

    {
        int n;

        n = rt_snprintf(report + len, sizeof(report) - len, "}\n");
        if (n < 0 || n >= (int)(sizeof(report) - len))
        {
            LOG_E("state report buffer too small");
            return -1;
        }

        len += n;
    }

    if (len < 0 || len >= (int)sizeof(report))
    {
        LOG_E("state report buffer too small");
        return -1;
    }

    if (esp32_send_raw(report, strlen(report)) != 0)
    {
        LOG_E("send state report failed");
        return -1;
    }

    LOG_I("state report sent");
    return 0;
}

int app_esp32_slave_report(void)
{
    return esp32_send_report_with_error(RT_NULL);
}

int app_esp32_slave_send_medicine_reminder(const app_medicine_plan_t *plan)
{
    char *message = esp32_reminder_message;
    int len;

    if (plan == RT_NULL || plan->plan_slot < 1 ||
        plan->plan_slot > APP_MEDICINE_PLAN_MAX_COUNT)
    {
        return -1;
    }

    len = rt_snprintf(message,
                      ESP32_VOICE_BUF_SIZE,
                      "{\"tool\":\"voice_alarm\","
                      "\"event\":\"medicine_reminder\","
                      "\"plan_slot\":%d,\"slot\":%d,"
                      "\"voice_code\":\"TAKE_MEDICINE\"}\n",
                      plan->plan_slot,
                      plan->plan_slot);
    if (len <= 0 || len >= ESP32_VOICE_BUF_SIZE)
    {
        LOG_E("medicine reminder buffer too small");
        return -1;
    }

    if (esp32_send_raw(message, len) != 0)
    {
        LOG_E("send voice alarm failed");
        return -1;
    }

    rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
    esp32_set_action_locked("voice_alarm");
    rt_mutex_release(esp32_state_lock);

    LOG_I("medicine voice alarm sent: plan_slot=%d, user=%s, medicines=%d",
          plan->plan_slot,
          plan->user_name[0] == '\0' ? "patient" : plan->user_name,
          plan->medicine_count);
    return 0;
}

int app_esp32_slave_send_medicine_reminder_stop(const app_medicine_plan_t *plan,
                                                const char *reason)
{
    char message[256];
    const char *stop_reason = reason == RT_NULL || reason[0] == '\0' ?
                              "recognized_face" : reason;
    int plan_slot;
    int len;

    if (plan == RT_NULL || plan->plan_slot < 1 ||
        plan->plan_slot > APP_MEDICINE_PLAN_MAX_COUNT)
    {
        return -1;
    }

    plan_slot = plan->plan_slot;
    len = rt_snprintf(message,
                      sizeof(message),
                      "{\"tool\":\"voice_alarm_stop\","
                      "\"event\":\"medicine_reminder_stop\","
                      "\"plan_slot\":%d,\"slot\":%d,"
                      "\"status\":\"stopped\","
                      "\"voice_code\":\"STOP_MEDICINE_REMINDER\"}\n",
                      plan_slot,
                      plan_slot);
    if (len <= 0 || len >= (int)sizeof(message))
    {
        LOG_E("medicine reminder stop buffer too small");
        return -1;
    }

    if (esp32_send_raw(message, len) != 0)
    {
        LOG_E("send voice alarm stop failed");
        return -1;
    }

    rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
    esp32_set_action_locked("voice_alarm_stop");
    rt_mutex_release(esp32_state_lock);

    LOG_I("medicine voice alarm stop sent: plan_slot=%d reason=%s",
          plan_slot,
          stop_reason);
    return 0;
}

static int esp32_handle_open_lid(cJSON *args)
{
    int box_id;

    if (esp32_json_int(args, "box_id", &box_id) != 0 || box_id < 1 || box_id > ESP32_SLOT_COUNT)
    {
        return -1;
    }

    if (app_medicine_servo_open(box_id) != 0)
    {
        return -2;
    }

    rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
    memset(esp32_state.lid_status, 0, sizeof(esp32_state.lid_status));
    esp32_state.lid_status[box_id - 1] = 1;
    esp32_set_action_locked("open_lid");
    rt_mutex_release(esp32_state_lock);

    return 0;
}

static int esp32_handle_close_lid(cJSON *args)
{
    int box_id;
    int i;

    if (esp32_json_int(args, "box_id", &box_id) != 0 || box_id < 0 || box_id > ESP32_SLOT_COUNT)
    {
        return -1;
    }

    if (app_medicine_servo_close() != 0)
    {
        return -2;
    }

    rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);

    for (i = 0; i < ESP32_SLOT_COUNT; i++)
    {
        esp32_state.lid_status[i] = 0;
    }

    esp32_set_action_locked("close_lid");
    rt_mutex_release(esp32_state_lock);

    return 0;
}

static int esp32_find_default_medicine_plan(app_medicine_plan_t *plan)
{
    char time_buf[16];
    int hour = 0;
    int min = 0;
    int sec = 0;
    int now_min;
    int best_slot = 0;
    int best_delta = 24 * 60 + 1;
    int fallback_slot = 0;
    int i;

    if (plan == RT_NULL)
    {
        return -1;
    }

    if (app_beep_alarm_get_current_plan(plan) == 0)
    {
        return 0;
    }

    app_time_get_string(RT_NULL, 0, time_buf, sizeof(time_buf));
    if (sscanf(time_buf, "%d:%d:%d", &hour, &min, &sec) != 3)
    {
        hour = 0;
        min = 0;
    }
    now_min = hour * 60 + min;

    for (i = 1; i <= APP_MEDICINE_PLAN_MAX_COUNT; i++)
    {
        int candidate_min;
        int delta;

        if (app_beep_alarm_get_plan(i, &esp32_candidate_plan_buf) != 0 ||
            esp32_candidate_plan_buf.medicine_count <= 0 ||
            esp32_plan_box_mask(&esp32_candidate_plan_buf) == 0)
        {
            continue;
        }

        if (fallback_slot == 0)
        {
            fallback_slot = i;
        }

        candidate_min = esp32_candidate_plan_buf.hour * 60 +
                        esp32_candidate_plan_buf.min;
        delta = candidate_min - now_min;
        if (delta < 0)
        {
            delta += 24 * 60;
        }

        if (delta < best_delta)
        {
            best_delta = delta;
            best_slot = i;
        }
    }

    if (best_slot > 0)
    {
        return app_beep_alarm_get_plan(best_slot, plan);
    }

    if (fallback_slot > 0)
    {
        return app_beep_alarm_get_plan(fallback_slot, plan);
    }

    return -1;
}

static int esp32_handle_take_medicine(cJSON *args)
{
    int plan_slot = 0;
    int box_id = 0;
    int busy_ret;

    busy_ret = esp32_resend_auth_ack_if_waiting();
    if (busy_ret != 0)
    {
        return busy_ret > 0 ? 0 : busy_ret;
    }

    if (esp32_json_int(args, "plan_slot", &plan_slot) != 0)
    {
        if (esp32_json_int(args, "slot", &plan_slot) != 0)
        {
            if (esp32_find_default_medicine_plan(&esp32_default_plan_buf) != 0)
            {
                return -4;
            }
            plan_slot = esp32_default_plan_buf.plan_slot;
        }
    }

    if (plan_slot < 1 || plan_slot > APP_MEDICINE_PLAN_MAX_COUNT)
    {
        return -1;
    }

    if (esp32_json_int(args, "box_id", &box_id) != 0)
    {
        (void)esp32_json_int(args, "boxId", &box_id);
    }

    app_beep_alarm_mark_response(plan_slot);

    if (app_beep_alarm_is_taken(plan_slot) == RT_TRUE)
    {
        LOG_I("ignore duplicate take medicine request: plan_slot=%d box_id=%d",
              plan_slot,
              box_id);
        esp32_send_medicine_already_taken(plan_slot, box_id);
        return 0;
    }

    return esp32_queue_medicine(plan_slot,
                                box_id,
                                ESP32_MEDICINE_OPERATION_TAKE);
}

static int esp32_handle_put_medicine(cJSON *args)
{
    int plan_slot = 0;
    int box_id = 0;
    int busy_ret;

    busy_ret = esp32_resend_auth_ack_if_waiting();
    if (busy_ret != 0)
    {
        return busy_ret > 0 ? 0 : busy_ret;
    }

    if (esp32_json_int(args, "plan_slot", &plan_slot) != 0)
    {
        if (esp32_json_int(args, "slot", &plan_slot) != 0)
        {
            if (esp32_find_default_medicine_plan(&esp32_default_plan_buf) != 0)
            {
                plan_slot = 1;
            }
            else
            {
                plan_slot = esp32_default_plan_buf.plan_slot;
            }
        }
    }

    if (plan_slot < 1 || plan_slot > APP_MEDICINE_PLAN_MAX_COUNT)
    {
        return -1;
    }

    if (esp32_json_int(args, "box_id", &box_id) != 0)
    {
        (void)esp32_json_int(args, "boxId", &box_id);
    }

    return esp32_queue_medicine(plan_slot,
                                box_id,
                                ESP32_MEDICINE_OPERATION_PUT);
}

static int esp32_handle_medicine_broadcast_done(cJSON *args)
{
    int plan_slot;
    int box_id = 0;
    int i;
    int pending_count = 0;
    int only_pending_box = 0;

    if (esp32_json_int(args, "plan_slot", &plan_slot) != 0 &&
        esp32_json_int(args, "slot", &plan_slot) != 0)
    {
        return -1;
    }

    if (esp32_json_int(args, "box_id", &box_id) != 0)
    {
        (void)esp32_json_int(args, "boxId", &box_id);
    }

    rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
    if (esp32_medicine_phase != ESP32_MEDICINE_WAIT_BROADCAST ||
        plan_slot != esp32_pending_plan_slot)
    {
        rt_mutex_release(esp32_state_lock);
        return -1;
    }

    if (box_id <= 0)
    {
        for (i = 0; i < ESP32_SLOT_COUNT; i++)
        {
            if ((esp32_pending_box_mask & (1UL << i)) != 0)
            {
                pending_count++;
                only_pending_box = i + 1;
            }
        }

        if (pending_count != 1)
        {
            rt_mutex_release(esp32_state_lock);
            return -4;
        }
        box_id = only_pending_box;
    }

    if (box_id < 1 || box_id > ESP32_SLOT_COUNT ||
        (esp32_pending_box_mask & (1UL << (box_id - 1))) == 0)
    {
        rt_mutex_release(esp32_state_lock);
        return -3;
    }

    if (esp32_requested_box_id != 0)
    {
        rt_mutex_release(esp32_state_lock);
        return -2;
    }

    esp32_requested_box_id = box_id;
    esp32_set_action_locked(esp32_active_operation == ESP32_MEDICINE_OPERATION_PUT ?
                            "put_open_request" :
                            "medicine_broadcast_done");
    rt_mutex_release(esp32_state_lock);
    rt_sem_release(&esp32_broadcast_done_sem);
    return 0;
}

static int esp32_handle_auth_prompt_done(cJSON *args)
{
    int plan_slot = 0;

    if (esp32_json_int(args, "plan_slot", &plan_slot) != 0)
    {
        (void)esp32_json_int(args, "slot", &plan_slot);
    }

    rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
    if (esp32_medicine_phase != ESP32_MEDICINE_WAIT_AUTH_PROMPT ||
        esp32_pending_plan_slot <= 0)
    {
        rt_mutex_release(esp32_state_lock);
        return -1;
    }

    if (plan_slot > 0 && plan_slot != esp32_pending_plan_slot)
    {
        rt_mutex_release(esp32_state_lock);
        return -3;
    }

    if (esp32_auth_prompt_done == RT_TRUE)
    {
        rt_mutex_release(esp32_state_lock);
        return -2;
    }

    esp32_auth_prompt_done = RT_TRUE;
    esp32_set_action_locked("auth_prompt_done");
    rt_mutex_release(esp32_state_lock);
    rt_sem_release(&esp32_auth_prompt_done_sem);
    return 0;
}

static int esp32_handle_face_auth_broadcast_done(cJSON *args)
{
    int plan_slot = 0;

    if (esp32_json_int(args, "plan_slot", &plan_slot) != 0)
    {
        (void)esp32_json_int(args, "slot", &plan_slot);
    }

    rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
    if (esp32_medicine_phase != ESP32_MEDICINE_WAIT_FACE_PROMPT ||
        esp32_pending_plan_slot <= 0)
    {
        rt_mutex_release(esp32_state_lock);
        return -1;
    }

    if (plan_slot > 0 && plan_slot != esp32_pending_plan_slot)
    {
        rt_mutex_release(esp32_state_lock);
        return -3;
    }

    if (esp32_face_prompt_done == RT_TRUE)
    {
        rt_mutex_release(esp32_state_lock);
        return -2;
    }

    esp32_face_prompt_done = RT_TRUE;
    esp32_set_action_locked("face_success_prompt_done");
    rt_mutex_release(esp32_state_lock);
    rt_sem_release(&esp32_face_prompt_done_sem);
    return 0;
}

static int esp32_handle_medicine_taken_done(cJSON *args)
{
    int plan_slot;
    int box_id = 0;

    if (esp32_json_int(args, "plan_slot", &plan_slot) != 0 &&
        esp32_json_int(args, "slot", &plan_slot) != 0)
    {
        return -1;
    }

    if (esp32_json_int(args, "box_id", &box_id) != 0)
    {
        (void)esp32_json_int(args, "boxId", &box_id);
    }

    rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
    if (esp32_medicine_phase != ESP32_MEDICINE_WAIT_TAKEN_DONE ||
        plan_slot != esp32_pending_plan_slot ||
        esp32_open_box_id <= 0)
    {
        rt_mutex_release(esp32_state_lock);
        return -1;
    }

    if (box_id <= 0)
    {
        box_id = esp32_open_box_id;
    }

    if (box_id != esp32_open_box_id)
    {
        rt_mutex_release(esp32_state_lock);
        return -3;
    }

    if (esp32_taken_done_box_id != 0)
    {
        rt_mutex_release(esp32_state_lock);
        return -2;
    }

    esp32_taken_done_box_id = box_id;
    esp32_set_action_locked("medicine_taken_done");
    rt_mutex_release(esp32_state_lock);
    rt_sem_release(&esp32_taken_done_sem);
    return 0;
}

static int esp32_handle_medicine_put_done(cJSON *args)
{
    int plan_slot;
    int box_id = 0;
    int put_count = 0;

    if (esp32_json_int(args, "plan_slot", &plan_slot) != 0 &&
        esp32_json_int(args, "slot", &plan_slot) != 0)
    {
        return -1;
    }

    if (esp32_json_int(args, "box_id", &box_id) != 0)
    {
        (void)esp32_json_int(args, "boxId", &box_id);
    }

    if (esp32_json_int(args, "count", &put_count) != 0 &&
        esp32_json_int(args, "amount", &put_count) != 0 &&
        esp32_json_int(args, "num", &put_count) != 0 &&
        esp32_json_int(args, "dose_count", &put_count) != 0)
    {
        (void)esp32_json_int(args, "put_count", &put_count);
    }

    rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
    if (esp32_medicine_phase != ESP32_MEDICINE_WAIT_TAKEN_DONE ||
        plan_slot != esp32_pending_plan_slot ||
        esp32_open_box_id <= 0)
    {
        rt_mutex_release(esp32_state_lock);
        return -1;
    }

    if (box_id <= 0)
    {
        box_id = esp32_open_box_id;
    }

    if (box_id != esp32_open_box_id)
    {
        rt_mutex_release(esp32_state_lock);
        return -3;
    }

    if (esp32_taken_done_box_id != 0)
    {
        rt_mutex_release(esp32_state_lock);
        return -2;
    }

    esp32_taken_done_box_id = box_id;
    esp32_put_done_count = put_count;
    esp32_set_action_locked("medicine_put_done");
    rt_mutex_release(esp32_state_lock);
    rt_sem_release(&esp32_taken_done_sem);
    return 0;
}

static int esp32_handle_make_phone_call(cJSON *args)
{
    app_family_contact_t contact;
    int ret;

    RT_UNUSED(args);

    if (app_local_upload_get_family_contact(&contact) != 0)
    {
        LOG_W("make phone call requested but family phone is empty");
        return -1;
    }

    ret = app_v100c_call(contact.phone);
    if (ret != 0)
    {
        LOG_W("make phone call failed: phone=%s ret=%d",
              contact.phone,
              ret);
        return -2;
    }

    rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
    esp32_set_action_locked("make_phone_call");
    rt_mutex_release(esp32_state_lock);

    LOG_I("make phone call sent to family contact: name=%s phone=%s",
          contact.name,
          contact.phone);
    return 0;
}

static int esp32_handle_send_sms(cJSON *args)
{
    app_family_contact_t contact;
    const char *content;
    int ret;

    content = esp32_json_string(args, "content");
    if (content == RT_NULL)
    {
        content = esp32_json_string(args, "message");
    }
    if (content == RT_NULL)
    {
        content = esp32_json_string(args, "text");
    }
    if (content == RT_NULL || content[0] == '\0')
    {
        return -1;
    }

    if (app_local_upload_get_family_contact(&contact) != 0)
    {
        LOG_W("send sms requested but family phone is empty");
        return -2;
    }

    ret = app_v100c_send_sms(contact.phone, content);
    if (ret != 0)
    {
        LOG_W("send sms failed: phone=%s ret=%d",
              contact.phone,
              ret);
        return -3;
    }

    rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
    esp32_set_action_locked("send_sms");
    rt_mutex_release(esp32_state_lock);

    LOG_I("sms sent to family contact: name=%s phone=%s",
          contact.name,
          contact.phone);
    return 0;
}

static int esp32_handle_set_timer(cJSON *args)
{
    int slot;
    int hour;
    int min;
    const char *time_str;

    if (esp32_json_int(args, "slot", &slot) != 0 || slot < 1 || slot > ESP32_SLOT_COUNT)
    {
        return -1;
    }

    time_str = esp32_json_string(args, "time");
    if (esp32_parse_hhmm(time_str, &hour, &min) != 0)
    {
        return -1;
    }

    rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
    rt_snprintf(esp32_state.timers[slot - 1], ESP32_TIMER_LEN, "%02d:%02d", hour, min);
    esp32_set_action_locked("set_timer");
    rt_mutex_release(esp32_state_lock);

    if (slot <= ESP32_SLOT_COUNT)
    {
        const char *user_name;

        app_beep_alarm_set_time(slot - 1, hour, min);

        user_name = esp32_json_string(args, "user_name");
        if (user_name == RT_NULL)
        {
            user_name = esp32_json_string(args, "user");
        }
        if (user_name == RT_NULL)
        {
            user_name = esp32_json_string(args, "name");
        }
        app_beep_alarm_set_user(slot - 1, user_name);
    }

    return 0;
}

static void esp32_handle_json_line(const char *line)
{
    const char *json_line;
    cJSON *root;
    cJSON *args;
    const char *tool;
    const char *error = RT_NULL;
    int ret = 0;
    rt_bool_t send_state_report = RT_TRUE;

    if (line == RT_NULL || line[0] == '\0')
    {
        return;
    }

    rt_kprintf("[ESP32 RX RAW]\n");
    rt_kprintf("%s\n", line);

    json_line = esp32_json_start(line);
    if (json_line == RT_NULL)
    {
        LOG_W("invalid esp32 json: %s", line);
        esp32_send_report_with_error("invalid_json");
        return;
    }

    if (json_line != line)
    {
        LOG_W("drop esp32 rx prefix before json: %s", line);
    }

    root = cJSON_Parse(json_line);
    if (root == RT_NULL)
    {
        LOG_W("invalid esp32 json: %s", json_line);
        esp32_send_report_with_error("invalid_json");
        return;
    }

    tool = esp32_json_string(root, "tool");
    args = cJSON_GetObjectItem(root, "args");

    if (tool == RT_NULL)
    {
        error = "invalid_command";
        ret = -1;
    }
    else if (strcmp(tool, "measure_heart_spo2") == 0 ||
             strcmp(tool, "measure_vitals") == 0 ||
             strcmp(tool, "measure_heart_rate") == 0)
    {
        ret = esp32_queue_measurement(ESP32_MEASURE_HEART_SPO2);
        error = ret == 0 ? RT_NULL : "measurement_busy";
        send_state_report = RT_FALSE;
    }
    else if (strcmp(tool, "measure_body_temperature") == 0 ||
             strcmp(tool, "measure_body_temp") == 0 ||
             strcmp(tool, "measure_temperature") == 0)
    {
        ret = esp32_queue_measurement(ESP32_MEASURE_BODY_TEMP);
        error = ret == 0 ? RT_NULL : "measurement_busy";
        send_state_report = RT_FALSE;
    }
    else if (args == RT_NULL || !cJSON_IsObject(args))
    {
        error = "invalid_command";
        ret = -1;
    }
    else if (strcmp(tool, "open_lid") == 0)
    {
        ret = esp32_handle_open_lid(args);
        error = ret == 0 ? RT_NULL :
                (ret == -2 ? "servo_open_failed" : "invalid_open_lid_args");
    }
    else if (strcmp(tool, "close_lid") == 0)
    {
        ret = esp32_handle_close_lid(args);
        error = ret == 0 ? RT_NULL :
                (ret == -2 ? "servo_close_failed" : "invalid_close_lid_args");
    }
    else if (strcmp(tool, "query_state") == 0)
    {
        rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
        esp32_set_action_locked("query_state");
        rt_mutex_release(esp32_state_lock);
    }
    else if (strcmp(tool, "make_phone_call") == 0 ||
             strcmp(tool, "phone_call") == 0 ||
             strcmp(tool, "call_family") == 0)
    {
        ret = esp32_handle_make_phone_call(args);
        error = ret == 0 ? RT_NULL :
                (ret == -2 ? "phone_call_failed" :
                             "family_phone_not_synced");
    }
    else if (strcmp(tool, "send_sms") == 0 ||
             strcmp(tool, "send_family_sms") == 0 ||
             strcmp(tool, "notify_family") == 0)
    {
        ret = esp32_handle_send_sms(args);
        error = ret == 0 ? RT_NULL :
                (ret == -1 ? "invalid_sms_content" :
                (ret == -2 ? "family_phone_not_synced" :
                             "send_sms_failed"));
    }
    else if (strcmp(tool, "start_face_auth") == 0 ||
             strcmp(tool, "medicine_face_auth") == 0 ||
             strcmp(tool, "take_medicine") == 0)
    {
        ret = esp32_handle_take_medicine(args);
        error = ret == 0 ? RT_NULL :
                (ret == -2 ? "face_auth_busy" :
                (ret == -3 ? "box_not_in_plan" :
                (ret == -4 ? "medicine_plan_not_synced" :
                             "invalid_take_medicine_args")));
        send_state_report = RT_FALSE;
    }
    else if (strcmp(tool, "put_medicine") == 0 ||
             strcmp(tool, "refill_medicine") == 0 ||
             strcmp(tool, "add_medicine") == 0)
    {
        ret = esp32_handle_put_medicine(args);
        error = ret == 0 ? RT_NULL :
                (ret == -2 ? "face_auth_busy" :
                (ret == -3 ? "box_not_in_plan" :
                (ret == -4 ? "medicine_plan_not_synced" :
                             "invalid_put_medicine_args")));
        send_state_report = RT_FALSE;
    }
    else if (strcmp(tool, "medicine_broadcast_done") == 0 ||
             strcmp(tool, "medicine_open_request") == 0 ||
             strcmp(tool, "put_open_request") == 0 ||
             strcmp(tool, "medicine_plan_announced") == 0)
    {
        ret = esp32_handle_medicine_broadcast_done(args);
        error = ret == 0 ? RT_NULL :
                (ret == -2 ? "medicine_box_request_busy" :
                (ret == -3 ? "box_not_pending" :
                (ret == -4 ? "box_id_required" :
                             "invalid_broadcast_done_args")));
        send_state_report = RT_FALSE;
    }
    else if (strcmp(tool, "medicine_auth_prompt_done") == 0 ||
             strcmp(tool, "start_put_face_auth") == 0 ||
             strcmp(tool, "face_auth_prompt_done") == 0 ||
             strcmp(tool, "auth_prompt_done") == 0)
    {
        ret = esp32_handle_auth_prompt_done(args);
        error = ret == 0 ? RT_NULL :
                (ret == -2 ? "auth_prompt_done_busy" :
                (ret == -3 ? "plan_slot_mismatch" :
                             "invalid_auth_prompt_done_args"));
        send_state_report = RT_FALSE;
    }
    else if (strcmp(tool, "face_auth_broadcast_done") == 0 ||
             strcmp(tool, "prepare_medicine") == 0 ||
             strcmp(tool, "prepare_put_medicine") == 0 ||
             strcmp(tool, "face_auth_result_announced") == 0 ||
             strcmp(tool, "face_auth_success_announced") == 0 ||
             strcmp(tool, "face_success_prompt_done") == 0)
    {
        ret = esp32_handle_face_auth_broadcast_done(args);
        error = ret == 0 ? RT_NULL :
                (ret == -2 ? "face_prompt_done_busy" :
                (ret == -3 ? "plan_slot_mismatch" :
                             "invalid_face_prompt_done_args"));
        send_state_report = RT_FALSE;
    }
    else if (strcmp(tool, "medicine_put_done") == 0 ||
             strcmp(tool, "put_medicine_done") == 0)
    {
        ret = esp32_handle_medicine_put_done(args);
        error = ret == 0 ? RT_NULL :
                (ret == -2 ? "medicine_put_busy" :
                (ret == -3 ? "box_not_open" :
                             "invalid_put_done_args"));
        send_state_report = RT_FALSE;
    }
    else if (strcmp(tool, "medicine_taken_done") == 0 ||
             strcmp(tool, "medicine_box_taken") == 0 ||
             strcmp(tool, "next_medicine") == 0)
    {
        ret = esp32_handle_medicine_taken_done(args);
        error = ret == 0 ? RT_NULL :
                (ret == -2 ? "medicine_taken_busy" :
                (ret == -3 ? "box_not_open" :
                             "invalid_taken_done_args"));
        send_state_report = RT_FALSE;
    }
    else if (strcmp(tool, "set_timer") == 0)
    {
        ret = esp32_handle_set_timer(args);
        error = ret == 0 ? RT_NULL : "invalid_set_timer_args";
    }
    else if (strcmp(tool, "get_stock") == 0)
    {
        rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
        esp32_set_action_locked("get_stock");
        rt_mutex_release(esp32_state_lock);
    }
    else
    {
        error = "unknown_tool";
        ret = -1;
    }

    if (ret != 0 && error != RT_NULL)
    {
        rt_mutex_take(esp32_state_lock, RT_WAITING_FOREVER);
        esp32_set_error_locked(error);
        rt_mutex_release(esp32_state_lock);
        LOG_W("esp32 command failed: %s", error);
    }
    else
    {
        LOG_I("esp32 command handled: %s", tool == RT_NULL ? "" : tool);
    }

    if (send_state_report == RT_TRUE)
    {
        esp32_send_report_with_error(error);
    }
    cJSON_Delete(root);
}

static void esp32_process_char(char ch, char *line_buf, int *line_pos)
{
    if (ch == '\n')
    {
        int len = *line_pos;

        while (len > 0 && line_buf[len - 1] == '\r')
        {
            len--;
        }

        line_buf[len] = '\0';
        *line_pos = 0;
        esp32_handle_json_line(line_buf);
        return;
    }

    if (*line_pos >= ESP32_LINE_BUF_SIZE - 1)
    {
        *line_pos = 0;
        LOG_W("esp32 rx line too long, drop");
        esp32_send_report_with_error("line_too_long");
        return;
    }

    line_buf[*line_pos] = ch;
    (*line_pos)++;
}

static void esp32_slave_entry(void *parameter)
{
    int line_pos = 0;

    LOG_I("esp32 slave thread start");

    while (1)
    {
        char ch;

        while (rt_device_read(esp32_uart, -1, &ch, 1) == 1)
        {
            esp32_process_char(ch, esp32_line_buf, &line_pos);
        }

        rt_sem_take(&esp32_rx_sem, RT_WAITING_FOREVER);
    }
}

int app_esp32_slave_start(void)
{
    struct serial_configure config = RT_SERIAL_CONFIG_DEFAULT;
    rt_err_t ret;

    if (esp32_started == RT_TRUE)
    {
        return 0;
    }

    esp32_uart = rt_device_find(ESP32_UART_NAME);
    if (esp32_uart == RT_NULL)
    {
        LOG_E("find %s failed", ESP32_UART_NAME);
        return -1;
    }

    esp32_state_lock = rt_mutex_create("esp32_st", RT_IPC_FLAG_FIFO);
    if (esp32_state_lock == RT_NULL)
    {
        LOG_E("create esp32 state mutex failed");
        return -1;
    }

    esp32_tx_lock = rt_mutex_create("esp32_tx", RT_IPC_FLAG_FIFO);
    if (esp32_tx_lock == RT_NULL)
    {
        LOG_E("create esp32 tx mutex failed");
        rt_mutex_delete(esp32_state_lock);
        esp32_state_lock = RT_NULL;
        return -1;
    }

    rt_sem_init(&esp32_rx_sem, "esp32_rx", 0, RT_IPC_FLAG_FIFO);
    rt_sem_init(&esp32_broadcast_done_sem, "esp32_brd", 0,
                RT_IPC_FLAG_FIFO);
    rt_sem_init(&esp32_taken_done_sem, "esp32_tkn", 0,
                RT_IPC_FLAG_FIFO);
    rt_sem_init(&esp32_auth_prompt_done_sem, "esp32_apd", 0,
                RT_IPC_FLAG_FIFO);
    rt_sem_init(&esp32_face_prompt_done_sem, "esp32_fpd", 0,
                RT_IPC_FLAG_FIFO);
    rt_mq_init(&esp32_measure_mq,
               "esp32_meas",
               esp32_measure_mq_pool,
               sizeof(esp32_measure_type_t),
               sizeof(esp32_measure_mq_pool),
               RT_IPC_FLAG_FIFO);
    rt_mq_init(&esp32_medicine_mq,
               "esp32_med",
               esp32_medicine_mq_pool,
               sizeof(esp32_medicine_job_t),
               sizeof(esp32_medicine_mq_pool),
               RT_IPC_FLAG_FIFO);
    esp32_state_init();

    config.baud_rate = BAUD_RATE_115200;
    config.data_bits = DATA_BITS_8;
    config.stop_bits = STOP_BITS_1;
    config.parity = PARITY_NONE;
    config.bufsz = ESP32_UART_RX_BUF_SIZE;

    rt_device_control(esp32_uart, RT_DEVICE_CTRL_CONFIG, &config);
    rt_device_set_rx_indicate(esp32_uart, esp32_uart_rx_ind);

    if (rt_device_open(esp32_uart, RT_DEVICE_FLAG_INT_RX) != RT_EOK)
    {
        LOG_E("open %s failed", ESP32_UART_NAME);
        rt_mutex_delete(esp32_tx_lock);
        rt_mutex_delete(esp32_state_lock);
        esp32_tx_lock = RT_NULL;
        esp32_state_lock = RT_NULL;
        esp32_uart = RT_NULL;
        return -1;
    }

    ret = rt_thread_init(&esp32_slave_thread,
                         "esp32_slv",
                         esp32_slave_entry,
                         RT_NULL,
                         esp32_slave_stack,
                         sizeof(esp32_slave_stack),
                         19,
                         10);
    if (ret != RT_EOK)
    {
        LOG_E("create esp32 slave thread failed, ret=%d", ret);
        rt_device_close(esp32_uart);
        rt_mutex_delete(esp32_tx_lock);
        rt_mutex_delete(esp32_state_lock);
        esp32_tx_lock = RT_NULL;
        esp32_state_lock = RT_NULL;
        esp32_uart = RT_NULL;
        return -1;
    }

    ret = rt_thread_init(&esp32_measure_thread,
                         "esp32_meas",
                         esp32_measure_entry,
                         RT_NULL,
                         esp32_measure_stack,
                         sizeof(esp32_measure_stack),
                         20,
                         10);
    if (ret != RT_EOK)
    {
        LOG_E("create esp32 measurement thread failed, ret=%d", ret);
        rt_thread_detach(&esp32_slave_thread);
        rt_device_close(esp32_uart);
        rt_mutex_delete(esp32_tx_lock);
        rt_mutex_delete(esp32_state_lock);
        esp32_tx_lock = RT_NULL;
        esp32_state_lock = RT_NULL;
        esp32_uart = RT_NULL;
        return -1;
    }

    ret = rt_thread_init(&esp32_medicine_thread,
                         "esp32_med",
                         esp32_medicine_entry,
                         RT_NULL,
                         esp32_medicine_stack,
                         sizeof(esp32_medicine_stack),
                         20,
                         10);
    if (ret != RT_EOK)
    {
        LOG_E("create esp32 medicine thread failed, ret=%d", ret);
        rt_thread_detach(&esp32_measure_thread);
        rt_thread_detach(&esp32_slave_thread);
        rt_device_close(esp32_uart);
        rt_mutex_delete(esp32_tx_lock);
        rt_mutex_delete(esp32_state_lock);
        esp32_tx_lock = RT_NULL;
        esp32_state_lock = RT_NULL;
        esp32_uart = RT_NULL;
        return -1;
    }

    esp32_started = RT_TRUE;
    rt_thread_startup(&esp32_slave_thread);
    rt_thread_startup(&esp32_measure_thread);
    rt_thread_startup(&esp32_medicine_thread);
    LOG_I("esp32 slave started on %s, 115200 8N1", ESP32_UART_NAME);

    return 0;
}

static int esp32_report_cmd(void)
{
    return app_esp32_slave_report();
}
MSH_CMD_EXPORT(esp32_report_cmd, send esp32 state report);

#include <rtthread.h>
#include <rtdevice.h>
#include "app_body_temp.h"
#include "app_ram.h"

#define DBG_TAG "body.temp"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>

#define GY906_I2C_BUS_NAME              "i2c1"

#define MLX90614_I2C_ADDR               0x5A
#define MLX90614_RAM_TA                 0x06
#define MLX90614_RAM_TOBJ1              0x07

#define BODY_DETECT_MIN_TEMP_X100       3300
#define BODY_LEAVE_TEMP_X100            3200

#define BODY_STABLE_RANGE_X100          40
#define BODY_DISCARD_COUNT              5
#define BODY_SAMPLE_COUNT               10
#define BODY_SAMPLE_DELAY_MS            150

#define BODY_RESULT_COUNT               3
#define BODY_COMPENSATION_X100          50
#define BODY_COMMAND_DETECT_TIMEOUT_MS  20000

static struct rt_i2c_bus_device *mlx90614_bus = RT_NULL;

static rt_bool_t body_temp_started = RT_FALSE;
static struct rt_mutex body_temp_mutex_obj;
static rt_mutex_t body_temp_mutex = RT_NULL;
static rt_int32_t latest_body_temp = BODY_TEMP_INVALID_X100;
static struct rt_mutex body_temp_request_lock_obj;
static rt_mutex_t body_temp_request_lock = RT_NULL;
static struct rt_semaphore body_temp_request_sem;
static struct rt_semaphore body_temp_done_sem;
static struct rt_thread body_temp_thread;
static rt_uint8_t body_temp_thread_stack[2048] APP_CCMRAM;
static rt_int32_t body_temp_request_result = BODY_TEMP_INVALID_X100;
static int body_temp_request_status = -1;

static void print_temp_x100(const char *name, rt_int32_t temp)
{
    rt_int32_t integer;
    rt_int32_t decimal;

    integer = temp / 100;
    decimal = temp % 100;

    if (decimal < 0)
    {
        decimal = -decimal;
    }

    if (name && name[0] != '\0')
    {
        rt_kprintf("%s: %d.%02d C\r\n", name, integer, decimal);
    }
    else
    {
        rt_kprintf("%d.%02d C\r\n", integer, decimal);
    }
}

static rt_uint8_t mlx90614_crc8(rt_uint8_t *data, rt_uint8_t len)
{
    rt_uint8_t crc = 0;
    rt_uint8_t i;
    rt_uint8_t j;

    for (i = 0; i < len; i++)
    {
        crc ^= data[i];

        for (j = 0; j < 8; j++)
        {
            if (crc & 0x80)
            {
                crc = (crc << 1) ^ 0x07;
            }
            else
            {
                crc <<= 1;
            }
        }
    }

    return crc;
}

static int mlx90614_init(const char *i2c_bus_name)
{
    mlx90614_bus = (struct rt_i2c_bus_device *)rt_device_find(i2c_bus_name);

    if (mlx90614_bus == RT_NULL)
    {
        LOG_E("can't find %s", i2c_bus_name);
        return -RT_ERROR;
    }

    rt_thread_mdelay(300);

    LOG_I("mlx90614 init success, bus=%s, addr=0x%02x",
          i2c_bus_name, MLX90614_I2C_ADDR);

    return RT_EOK;
}

static int mlx90614_read_word(rt_uint8_t reg, rt_uint16_t *data)
{
    struct rt_i2c_msg msgs[2];
    rt_uint8_t cmd = reg;
    rt_uint8_t buf[3];
    rt_uint8_t crc_buf[5];
    rt_uint8_t pec;

    if (mlx90614_bus == RT_NULL)
    {
        LOG_E("i2c bus not init");
        return -RT_ERROR;
    }

    msgs[0].addr  = MLX90614_I2C_ADDR;
    msgs[0].flags = RT_I2C_WR;
    msgs[0].buf   = &cmd;
    msgs[0].len   = 1;

    msgs[1].addr  = MLX90614_I2C_ADDR;
    msgs[1].flags = RT_I2C_RD;
    msgs[1].buf   = buf;
    msgs[1].len   = 3;

    if (rt_i2c_transfer(mlx90614_bus, msgs, 2) != 2)
    {
        LOG_E("read reg 0x%02x failed", reg);
        return -RT_ERROR;
    }

    crc_buf[0] = (MLX90614_I2C_ADDR << 1) | 0;
    crc_buf[1] = reg;
    crc_buf[2] = (MLX90614_I2C_ADDR << 1) | 1;
    crc_buf[3] = buf[0];
    crc_buf[4] = buf[1];

    pec = mlx90614_crc8(crc_buf, 5);

    if (pec != buf[2])
    {
        LOG_W("pec error, calc=0x%02x, recv=0x%02x", pec, buf[2]);
    }

    *data = ((rt_uint16_t)buf[1] << 8) | buf[0];

    return RT_EOK;
}

static int mlx90614_read_temp_x100(rt_uint8_t reg, rt_int32_t *temp)
{
    rt_uint16_t raw;
    int ret;

    ret = mlx90614_read_word(reg, &raw);
    if (ret != RT_EOK)
    {
        return ret;
    }

    if (raw & 0x8000)
    {
        LOG_E("temperature error, raw=0x%04x", raw);
        return -RT_ERROR;
    }

    *temp = (rt_int32_t)raw * 2 - 27315;

    return RT_EOK;
}

static int mlx90614_read_object_x100(rt_int32_t *temp)
{
    return mlx90614_read_temp_x100(MLX90614_RAM_TOBJ1, temp);
}

static int mlx90614_read_ambient_x100(rt_int32_t *temp)
{
    return mlx90614_read_temp_x100(MLX90614_RAM_TA, temp);
}

static void body_temp_save(rt_int32_t temp)
{
    if (body_temp_mutex == RT_NULL)
    {
        return;
    }

    rt_mutex_take(body_temp_mutex, RT_WAITING_FOREVER);
    latest_body_temp = temp;
    rt_mutex_release(body_temp_mutex);
}

int app_body_temp_get(rt_int32_t *body_temp_x100)
{
    if (body_temp_x100 == RT_NULL)
    {
        return -1;
    }

    if (body_temp_mutex == RT_NULL)
    {
        return -1;
    }

    rt_mutex_take(body_temp_mutex, RT_WAITING_FOREVER);
    *body_temp_x100 = latest_body_temp;
    rt_mutex_release(body_temp_mutex);

    if (*body_temp_x100 == BODY_TEMP_INVALID_X100)
    {
        return -1;
    }

    return 0;
}

int app_body_temp_take(rt_int32_t *body_temp_x100)
{
    if (body_temp_x100 == RT_NULL)
    {
        return -1;
    }

    if (body_temp_mutex == RT_NULL)
    {
        return -1;
    }

    rt_mutex_take(body_temp_mutex, RT_WAITING_FOREVER);

    if (latest_body_temp == BODY_TEMP_INVALID_X100)
    {
        rt_mutex_release(body_temp_mutex);
        return -1;
    }

    *body_temp_x100 = latest_body_temp;
    latest_body_temp = BODY_TEMP_INVALID_X100;

    rt_mutex_release(body_temp_mutex);

    return 0;
}

static int discard_unstable_samples(void)
{
    rt_int32_t temp;
    int i;

    for (i = 0; i < BODY_DISCARD_COUNT; i++)
    {
        if (mlx90614_read_object_x100(&temp) != RT_EOK)
        {
            return -RT_ERROR;
        }

        if (temp < BODY_DETECT_MIN_TEMP_X100)
        {
            return -RT_ERROR;
        }

        rt_thread_mdelay(BODY_SAMPLE_DELAY_MS);
    }

    return RT_EOK;
}

static int read_one_stable_body_temp(rt_int32_t *body_temp)
{
    rt_int32_t samples[BODY_SAMPLE_COUNT];
    rt_int32_t sum = 0;
    rt_int32_t max;
    rt_int32_t min;
    rt_int32_t avg;
    int i;

    for (i = 0; i < BODY_SAMPLE_COUNT; i++)
    {
        if (mlx90614_read_object_x100(&samples[i]) != RT_EOK)
        {
            return -RT_ERROR;
        }

        if (samples[i] < BODY_DETECT_MIN_TEMP_X100)
        {
            return -RT_ERROR;
        }

        rt_thread_mdelay(BODY_SAMPLE_DELAY_MS);
    }

    max = samples[0];
    min = samples[0];

    for (i = 0; i < BODY_SAMPLE_COUNT; i++)
    {
        if (samples[i] > max)
        {
            max = samples[i];
        }

        if (samples[i] < min)
        {
            min = samples[i];
        }

        sum += samples[i];
    }

    if ((max - min) > BODY_STABLE_RANGE_X100)
    {
        LOG_W("temperature not stable, range=%d.%02d C",
              (max - min) / 100,
              (max - min) % 100);
        return -RT_ERROR;
    }

    sum = sum - max - min;
    avg = sum / (BODY_SAMPLE_COUNT - 2);

    avg = avg + BODY_COMPENSATION_X100;

    *body_temp = avg;

    return RT_EOK;
}

static int read_three_success_results(rt_int32_t results[BODY_RESULT_COUNT])
{
    int i;
    int success_count = 0;

    for (i = 0; i < BODY_RESULT_COUNT; i++)
    {
        if (read_one_stable_body_temp(&results[i]) != RT_EOK)
        {
            LOG_W("stable result %d failed, continue with valid results",
                  i + 1);
            results[i] = BODY_TEMP_INVALID_X100;
            continue;
        }

        success_count++;
        rt_kprintf("Stable result %d: ", i + 1);
        print_temp_x100("", results[i]);

        rt_thread_mdelay(200);
    }

    return success_count;
}

static rt_int32_t body_temp_abs_diff(rt_int32_t a, rt_int32_t b)
{
    return a > b ? a - b : b - a;
}

static int body_temp_average_closest_pair(const rt_int32_t results[BODY_RESULT_COUNT],
                                          rt_int32_t *avg)
{
    int best_i = -1;
    int best_j = -1;
    rt_int32_t best_diff = 0;
    int i;
    int j;

    if (avg == RT_NULL)
    {
        return -RT_ERROR;
    }

    for (i = 0; i < BODY_RESULT_COUNT; i++)
    {
        if (results[i] == BODY_TEMP_INVALID_X100)
        {
            continue;
        }

        for (j = i + 1; j < BODY_RESULT_COUNT; j++)
        {
            rt_int32_t diff;

            if (results[j] == BODY_TEMP_INVALID_X100)
            {
                continue;
            }

            diff = body_temp_abs_diff(results[i], results[j]);
            if (best_i < 0 || diff < best_diff)
            {
                best_i = i;
                best_j = j;
                best_diff = diff;
            }
        }
    }

    if (best_i < 0 || best_j < 0)
    {
        return -RT_ERROR;
    }

    *avg = (results[best_i] + results[best_j]) / 2;
    LOG_W("body temperature fallback: use closest result %d and %d, diff=%d.%02d C",
          best_i + 1,
          best_j + 1,
          best_diff / 100,
          best_diff % 100);
    return RT_EOK;
}

static int read_final_body_temp(rt_int32_t *final_body_temp)
{
    rt_int32_t results[BODY_RESULT_COUNT];
    rt_int32_t sum = 0;
    rt_int32_t avg;
    rt_int32_t max = BODY_TEMP_INVALID_X100;
    rt_int32_t min = BODY_TEMP_INVALID_X100;
    int success_count;
    int i;

    success_count = read_three_success_results(results);
    if (success_count <= 0)
    {
        return -RT_ERROR;
    }

    for (i = 0; i < BODY_RESULT_COUNT; i++)
    {
        if (results[i] == BODY_TEMP_INVALID_X100)
        {
            continue;
        }

        if (max == BODY_TEMP_INVALID_X100 || results[i] > max)
        {
            max = results[i];
        }

        if (min == BODY_TEMP_INVALID_X100 || results[i] < min)
        {
            min = results[i];
        }

        sum += results[i];
    }

    if (success_count >= 2 &&
        (max - min) > BODY_STABLE_RANGE_X100)
    {
        if (body_temp_average_closest_pair(results, &avg) != RT_EOK)
        {
            return -RT_ERROR;
        }
    }
    else
    {
        avg = sum / success_count;
        if (success_count < BODY_RESULT_COUNT)
        {
            LOG_W("body temperature fallback: use %d valid result(s)",
                  success_count);
        }
    }

    *final_body_temp = avg;

    return RT_EOK;
}

static void body_temp_entry(void *parameter)
{
    rt_int32_t object_temp = 0;
    rt_int32_t ambient_temp = 0;
    rt_int32_t body_temp = 0;

    if (mlx90614_init(GY906_I2C_BUS_NAME) != RT_EOK)
    {
        LOG_E("gy906 init failed");
        return;
    }

    while (1)
    {
        rt_tick_t wait_started;
        rt_bool_t forehead_found = RT_FALSE;

        rt_sem_take(&body_temp_request_sem, RT_WAITING_FOREVER);
        body_temp_request_status = -1;
        body_temp_request_result = BODY_TEMP_INVALID_X100;
        LOG_I("body temperature command received, place forehead");
        wait_started = rt_tick_get();

        while ((rt_tick_t)(rt_tick_get() - wait_started) <
               rt_tick_from_millisecond(BODY_COMMAND_DETECT_TIMEOUT_MS))
        {
            if (mlx90614_read_object_x100(&object_temp) == RT_EOK &&
                object_temp >= BODY_DETECT_MIN_TEMP_X100)
            {
                forehead_found = RT_TRUE;
                break;
            }
            rt_thread_mdelay(200);
        }

        if (forehead_found == RT_FALSE)
        {
            LOG_W("body temperature wait forehead timeout");
        }
        else
        {
            LOG_I("forehead detected, measuring...");

            if (discard_unstable_samples() == RT_EOK &&
                read_final_body_temp(&body_temp) == RT_EOK)
            {
                body_temp_save(body_temp);
                body_temp_request_result = body_temp;
                body_temp_request_status = 0;
                rt_kprintf("Final Body Temp: ");
                print_temp_x100("", body_temp);

                if (mlx90614_read_ambient_x100(&ambient_temp) == RT_EOK)
                {
                    rt_kprintf("Ambient Temp: ");
                    print_temp_x100("", ambient_temp);
                }
            }
            else
            {
                LOG_W("body temperature measurement failed");
            }
        }

        rt_sem_release(&body_temp_done_sem);
    }
}

int app_body_temp_measure(rt_int32_t *body_temp_x100, rt_int32_t timeout_ms)
{
    rt_err_t ret;

    if (body_temp_x100 == RT_NULL || body_temp_started == RT_FALSE)
    {
        return -1;
    }

    if (rt_mutex_take(body_temp_request_lock, 0) != RT_EOK)
    {
        return -2;
    }

    while (rt_sem_trytake(&body_temp_done_sem) == RT_EOK)
    {
    }
    rt_sem_release(&body_temp_request_sem);
    ret = rt_sem_take(&body_temp_done_sem,
                      timeout_ms < 0 ? RT_WAITING_FOREVER :
                      rt_tick_from_millisecond(timeout_ms));

    if (ret == RT_EOK && body_temp_request_status == 0)
    {
        *body_temp_x100 = body_temp_request_result;
        ret = RT_EOK;
    }
    else
    {
        *body_temp_x100 = BODY_TEMP_INVALID_X100;
        ret = -RT_ERROR;
    }

    rt_mutex_release(body_temp_request_lock);
    return ret == RT_EOK ? 0 : -1;
}

int app_body_temp_start(void)
{
    rt_err_t ret;

    if (body_temp_started == RT_TRUE)
    {
        return 0;
    }

    ret = rt_mutex_init(&body_temp_mutex_obj, "body_tmp", RT_IPC_FLAG_FIFO);
    if (ret != RT_EOK)
    {
        LOG_E("body temp mutex init failed, ret=%d", ret);
        return -1;
    }
    body_temp_mutex = &body_temp_mutex_obj;

    ret = rt_mutex_init(&body_temp_request_lock_obj, "body_req", RT_IPC_FLAG_FIFO);
    if (ret != RT_EOK)
    {
        rt_mutex_detach(body_temp_mutex);
        body_temp_mutex = RT_NULL;
        LOG_E("body temp request mutex init failed, ret=%d", ret);
        return -1;
    }
    body_temp_request_lock = &body_temp_request_lock_obj;
    rt_sem_init(&body_temp_request_sem, "body_go", 0, RT_IPC_FLAG_FIFO);
    rt_sem_init(&body_temp_done_sem, "body_done", 0, RT_IPC_FLAG_FIFO);

    ret = rt_thread_init(&body_temp_thread,
                         "body_tmp",
                         body_temp_entry,
                         RT_NULL,
                         body_temp_thread_stack,
                         sizeof(body_temp_thread_stack),
                         21,
                         10);

    if (ret == RT_EOK)
    {
        body_temp_started = RT_TRUE;
        rt_thread_startup(&body_temp_thread);
        LOG_I("body temp thread started");
        return 0;
    }

    LOG_E("body temp thread init failed, ret=%d", ret);
    rt_sem_detach(&body_temp_done_sem);
    rt_sem_detach(&body_temp_request_sem);
    rt_mutex_detach(body_temp_request_lock);
    rt_mutex_detach(body_temp_mutex);
    body_temp_request_lock = RT_NULL;
    body_temp_mutex = RT_NULL;

    return -1;
}

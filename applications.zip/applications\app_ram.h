#ifndef APP_RAM_H
#define APP_RAM_H

#if defined(__GNUC__)
#define APP_CCMRAM __attribute__((section(".ccmram"), aligned(8)))
#else
#define APP_CCMRAM
#endif

#endif

#include <rtthread.h>
#include <rtdevice.h>
#include <rthw.h>
#include <board.h>
#include <stdlib.h>

#include "app_medicine_servo.h"

#define DBG_TAG "app.servo"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>

#define SERVO_GPIO_PIN              GET_PIN(A, 5)
#define SERVO_PERIOD_US             20000U
#define SERVO_MIN_PULSE_US          470U
#define SERVO_MAX_PULSE_US          2500U
#define SERVO_MAX_ANGLE             225

#define SERVO_CLOSE_ANGLE           218
#define SERVO_MOVE_STEP_DEGREE      3
#define SERVO_MOVE_STEP_DELAY_MS    10

#define MEDICINE_BOX_COUNT          6
#define SERVO_THREAD_STACK_SIZE     1024
#define SERVO_THREAD_PRIORITY       8

static const rt_uint8_t medicine_box_angle[MEDICINE_BOX_COUNT] =
{
    170, 130, 95, 60, 25, 0
};

static rt_mutex_t servo_lock = RT_NULL;
static rt_bool_t servo_started = RT_FALSE;
static int servo_current_angle = SERVO_CLOSE_ANGLE;
static volatile rt_uint32_t servo_pulse_us = SERVO_MIN_PULSE_US;

static rt_uint32_t servo_angle_to_pulse_us(int angle)
{
    rt_uint32_t pulse_range = SERVO_MAX_PULSE_US - SERVO_MIN_PULSE_US;

    return SERVO_MIN_PULSE_US +
           (rt_uint32_t)((((rt_uint64_t)pulse_range * angle) +
                          (SERVO_MAX_ANGLE / 2U)) / SERVO_MAX_ANGLE);
}

static int servo_write_angle(int angle)
{
    rt_base_t level;

    if (angle < 0 || angle > SERVO_MAX_ANGLE)
    {
        return -1;
    }

    level = rt_hw_interrupt_disable();
    servo_pulse_us = servo_angle_to_pulse_us(angle);
    rt_hw_interrupt_enable(level);

    return 0;
}

static rt_uint32_t servo_get_pulse_us(void)
{
    rt_uint32_t pulse;
    rt_base_t level;

    level = rt_hw_interrupt_disable();
    pulse = servo_pulse_us;
    rt_hw_interrupt_enable(level);

    return pulse;
}

static void servo_pwm_entry(void *parameter)
{
    while (1)
    {
        rt_uint32_t pulse = servo_get_pulse_us();

        rt_pin_write(SERVO_GPIO_PIN, PIN_HIGH);
        rt_hw_us_delay(pulse);
        rt_pin_write(SERVO_GPIO_PIN, PIN_LOW);
        rt_thread_mdelay((SERVO_PERIOD_US - pulse) / 1000U);
    }
}

static int servo_move_to(int target_angle)
{
    int direction;
    int angle;

    if (servo_started != RT_TRUE)
    {
        LOG_E("servo is not started");
        return -1;
    }

    if (target_angle < 0 || target_angle > SERVO_MAX_ANGLE)
    {
        return -1;
    }

    rt_mutex_take(servo_lock, RT_WAITING_FOREVER);

    direction = target_angle >= servo_current_angle ?
                SERVO_MOVE_STEP_DEGREE : -SERVO_MOVE_STEP_DEGREE;
    angle = servo_current_angle;

    while (angle != target_angle)
    {
        angle += direction;

        if ((direction > 0 && angle > target_angle) ||
            (direction < 0 && angle < target_angle))
        {
            angle = target_angle;
        }

        if (servo_write_angle(angle) != 0)
        {
            rt_mutex_release(servo_lock);
            return -1;
        }

        servo_current_angle = angle;
        rt_thread_mdelay(SERVO_MOVE_STEP_DELAY_MS);
    }

    rt_mutex_release(servo_lock);
    LOG_I("servo moved to %d degree", target_angle);
    return 0;
}

int app_medicine_servo_start(void)
{
    rt_thread_t tid;

    if (servo_started == RT_TRUE)
    {
        return 0;
    }

    servo_lock = rt_mutex_create("med_servo", RT_IPC_FLAG_FIFO);
    if (servo_lock == RT_NULL)
    {
        LOG_E("create servo mutex failed");
        return -1;
    }

    rt_pin_mode(SERVO_GPIO_PIN, PIN_MODE_OUTPUT);
    rt_pin_write(SERVO_GPIO_PIN, PIN_LOW);

    if (servo_write_angle(SERVO_CLOSE_ANGLE) != 0)
    {
        LOG_E("init servo angle failed");
        rt_mutex_delete(servo_lock);
        servo_lock = RT_NULL;
        return -1;
    }

    tid = rt_thread_create("servo_pwm",
                           servo_pwm_entry,
                           RT_NULL,
                           SERVO_THREAD_STACK_SIZE,
                           SERVO_THREAD_PRIORITY,
                           10);
    if (tid == RT_NULL)
    {
        LOG_E("create servo pwm thread failed");
        rt_mutex_delete(servo_lock);
        servo_lock = RT_NULL;
        return -1;
    }

    servo_current_angle = SERVO_CLOSE_ANGLE;
    servo_started = RT_TRUE;
    rt_thread_startup(tid);
    rt_thread_mdelay(500);
    LOG_I("medicine servo started on GPIO PA5");
    return 0;
}

int app_medicine_servo_open(int box_id)
{
    if (box_id < 1 || box_id > MEDICINE_BOX_COUNT)
    {
        return -1;
    }

    LOG_I("open medicine box %d, target angle %d",
          box_id,
          medicine_box_angle[box_id - 1]);
    return servo_move_to(medicine_box_angle[box_id - 1]);
}

int app_medicine_servo_close(void)
{
    LOG_I("close medicine box, target angle %d", SERVO_CLOSE_ANGLE);
    return servo_move_to(SERVO_CLOSE_ANGLE);
}

static int medicine_servo_cmd(int argc, char **argv)
{
    int value;

    if (argc == 2 && rt_strcmp(argv[1], "close") == 0)
    {
        return app_medicine_servo_close();
    }

    if (argc != 3)
    {
        rt_kprintf("Usage: medicine_servo open <1-6>\n");
        rt_kprintf("       medicine_servo close\n");
        rt_kprintf("       medicine_servo angle <0-225>\n");
        return -1;
    }

    value = atoi(argv[2]);

    if (rt_strcmp(argv[1], "open") == 0)
    {
        return app_medicine_servo_open(value);
    }

    if (rt_strcmp(argv[1], "angle") == 0)
    {
        return servo_move_to(value);
    }

    rt_kprintf("Unknown operation: %s\n", argv[1]);
    return -1;
}
MSH_CMD_EXPORT(medicine_servo_cmd, control medicine box servo);

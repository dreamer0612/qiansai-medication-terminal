#ifndef __APP_BODY_TEMP_H__
#define __APP_BODY_TEMP_H__

#include <rtthread.h>

#define BODY_TEMP_INVALID_X100      (-10000)

int app_body_temp_start(void);
int app_body_temp_get(rt_int32_t *body_temp_x100);
int app_body_temp_take(rt_int32_t *body_temp_x100);
int app_body_temp_measure(rt_int32_t *body_temp_x100, rt_int32_t timeout_ms);

#endif

#include <rtthread.h>
#include <rtdevice.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <ntp.h>

#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>

#include "app_time.h"
#include "app_ram.h"

#define DBG_TAG "app.time"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>

extern int setenv(const char *name, const char *value, int overwrite);

static time_t ntp_time_base = 0;
static rt_tick_t ntp_tick_base = 0;
static rt_bool_t time_synced = RT_FALSE;
static rt_bool_t time_auto_started = RT_FALSE;
static struct rt_thread time_sync_thread;
static rt_uint8_t time_sync_stack[2048] APP_CCMRAM;
static char time_http_request[160];
static char time_http_response[512];

static const char *ntp_servers[] =
{
    "ntp.aliyun.com",
    "ntp.tencent.com",
    "cn.ntp.org.cn",
};

#define TIME_HTTP_HOST "YOUR_SERVER_HOST"
#define TIME_HTTP_PORT "3000"

static int is_leap_year(int year)
{
    return ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0);
}

static int month_to_number(const char *month)
{
    static const char *months[] =
    {
        "Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    };
    int i;

    for (i = 0; i < 12; i++)
    {
        if (strncmp(month, months[i], 3) == 0)
        {
            return i + 1;
        }
    }

    return 0;
}

static time_t make_utc_time(int year, int month, int day, int hour, int min, int sec)
{
    static const int month_days[] =
    {
        31, 28, 31, 30, 31, 30,
        31, 31, 30, 31, 30, 31
    };
    time_t days = 0;
    int y;
    int m;

    if (year < 2023 || month < 1 || month > 12 || day < 1 || day > 31 ||
        hour < 0 || hour > 23 || min < 0 || min > 59 || sec < 0 || sec > 59)
    {
        return 0;
    }

    for (y = 1970; y < year; y++)
    {
        days += is_leap_year(y) ? 366 : 365;
    }

    for (m = 1; m < month; m++)
    {
        days += month_days[m - 1];
        if (m == 2 && is_leap_year(year))
        {
            days += 1;
        }
    }

    days += day - 1;
    return days * 86400 + hour * 3600 + min * 60 + sec;
}

static time_t parse_http_date(const char *response)
{
    const char *p;
    char week[4];
    char month_name[4];
    int day;
    int year;
    int hour;
    int min;
    int sec;
    int month;

    p = strstr(response, "\r\nDate: ");
    if (p == RT_NULL)
    {
        p = strstr(response, "\nDate: ");
    }
    if (p == RT_NULL)
    {
        return 0;
    }

    p = strstr(p, "Date: ");
    if (p == RT_NULL)
    {
        return 0;
    }
    p += strlen("Date: ");

    if (sscanf(p, "%3s, %d %3s %d %d:%d:%d GMT",
               week, &day, month_name, &year, &hour, &min, &sec) != 7)
    {
        return 0;
    }

    month = month_to_number(month_name);
    if (month == 0)
    {
        return 0;
    }

    return make_utc_time(year, month, day, hour, min, sec);
}

static int socket_send_all(int sock, const char *buf, int len)
{
    int sent = 0;

    while (sent < len)
    {
        int ret = send(sock, buf + sent, len - sent, 0);
        if (ret <= 0)
        {
            return -1;
        }
        sent += ret;
    }

    return 0;
}

static time_t app_time_http_sync(void)
{
    struct addrinfo hints;
    struct addrinfo *res = RT_NULL;
    int sock;
    int ret;
    time_t http_time;

    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;

    if (getaddrinfo(TIME_HTTP_HOST, TIME_HTTP_PORT, &hints, &res) != 0 || res == RT_NULL)
    {
        return 0;
    }

    sock = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
    if (sock < 0)
    {
        freeaddrinfo(res);
        return 0;
    }

    if (connect(sock, res->ai_addr, res->ai_addrlen) != 0)
    {
        freeaddrinfo(res);
        closesocket(sock);
        return 0;
    }
    freeaddrinfo(res);

    rt_snprintf(time_http_request,
                sizeof(time_http_request),
                "GET / HTTP/1.1\r\n"
                "Host: %s:%s\r\n"
                "Connection: close\r\n"
                "\r\n",
                TIME_HTTP_HOST,
                TIME_HTTP_PORT);

    if (socket_send_all(sock, time_http_request, strlen(time_http_request)) != 0)
    {
        closesocket(sock);
        return 0;
    }

    memset(time_http_response, 0, sizeof(time_http_response));
    ret = recv(sock, time_http_response, sizeof(time_http_response) - 1, 0);
    closesocket(sock);

    if (ret <= 0)
    {
        return 0;
    }

    time_http_response[ret] = '\0';
    http_time = parse_http_date(time_http_response);
    if (http_time >= 1700000000)
    {
        LOG_I("http time sync success");
        return http_time;
    }

    return 0;
}

int app_time_sync(void)
{
    time_t ntp_time;
    int i;

    setenv("TZ", "CST-8", 1);
    tzset();

    LOG_I("start ntp sync");

    ntp_time = ntp_get_time(RT_NULL);

    for (i = 0;
         ntp_time < 1700000000 &&
         i < (int)(sizeof(ntp_servers) / sizeof(ntp_servers[0]));
         i++)
    {
        LOG_I("try ntp server: %s", ntp_servers[i]);
        ntp_time = ntp_get_time(ntp_servers[i]);

        if (ntp_time >= 1700000000)
        {
            break;
        }
    }

    if (ntp_time < 1700000000)
    {
        LOG_W("ntp get time failed or invalid: %ld", ntp_time);
        ntp_time = app_time_http_sync();
        if (ntp_time < 1700000000)
        {
            LOG_E("http time sync also failed");
            return -1;
        }
    }

    ntp_time_base = ntp_time;
    ntp_tick_base = rt_tick_get();
    time_synced = RT_TRUE;

    LOG_I("ntp sync success");

    return 0;
}

static void app_time_auto_sync_entry(void *parameter)
{
    while (1)
    {
        if (app_time_sync() == 0)
        {
            rt_thread_mdelay(60 * 60 * 1000);
        }
        else
        {
            rt_thread_mdelay(10 * 1000);
        }
    }
}

int app_time_auto_sync_start(void)
{
    rt_err_t ret;

    if (time_auto_started == RT_TRUE)
    {
        return 0;
    }

    ret = rt_thread_init(&time_sync_thread,
                         "time_sync",
                         app_time_auto_sync_entry,
                         RT_NULL,
                         time_sync_stack,
                         sizeof(time_sync_stack),
                         23,
                         10);

    if (ret == RT_EOK)
    {
        time_auto_started = RT_TRUE;
        rt_thread_startup(&time_sync_thread);
        return 0;
    }

    LOG_E("init time sync thread failed, ret=%d", ret);

    return -1;
}

time_t app_time_get(void)
{
    rt_tick_t now_tick;
    rt_tick_t diff_tick;
    time_t diff_sec;

    if (time_synced != RT_TRUE)
    {
        return 0;
    }

    now_tick = rt_tick_get();
    diff_tick = now_tick - ntp_tick_base;
    diff_sec = diff_tick / RT_TICK_PER_SECOND;

    return ntp_time_base + diff_sec;
}

void app_time_get_string(char *date_buf, int date_len, char *time_buf, int time_len)
{
    time_t now;
    struct tm *tm_now;

    now = app_time_get();

    if (now == 0)
    {
        if (date_buf != RT_NULL && date_len > 0)
            rt_snprintf(date_buf, date_len, "1970-01-01");

        if (time_buf != RT_NULL && time_len > 0)
            rt_snprintf(time_buf, time_len, "00:00:00");

        return;
    }

    tm_now = localtime(&now);

    if (tm_now == RT_NULL)
    {
        if (date_buf != RT_NULL && date_len > 0)
            rt_snprintf(date_buf, date_len, "1970-01-01");

        if (time_buf != RT_NULL && time_len > 0)
            rt_snprintf(time_buf, time_len, "00:00:00");

        return;
    }

    if (date_buf != RT_NULL && date_len > 0)
    {
        rt_snprintf(date_buf, date_len,
                    "%04d-%02d-%02d",
                    tm_now->tm_year + 1900,
                    tm_now->tm_mon + 1,
                    tm_now->tm_mday);
    }

    if (time_buf != RT_NULL && time_len > 0)
    {
        rt_snprintf(time_buf, time_len,
                    "%02d:%02d:%02d",
                    tm_now->tm_hour,
                    tm_now->tm_min,
                    tm_now->tm_sec);
    }
}

int app_time_sync_cmd(void)
{
    return app_time_sync();
}
MSH_CMD_EXPORT(app_time_sync_cmd, sync time from ntp without rtc);

int app_time_print_cmd(void)
{
    char date_buf[16];
    char time_buf[16];

    app_time_get_string(date_buf, sizeof(date_buf), time_buf, sizeof(time_buf));

    LOG_I("current date: %s", date_buf);
    LOG_I("current time: %s", time_buf);

    return 0;
}
MSH_CMD_EXPORT(app_time_print_cmd, print current time);

#ifndef __APP_V100C_H__
#define __APP_V100C_H__

#include <rtthread.h>
#include "app_beep_alarm.h"

#ifndef APP_V100C_LOW_STOCK_THRESHOLD
#define APP_V100C_LOW_STOCK_THRESHOLD 3
#endif

int app_v100c_start(void);
int app_v100c_send_sms(const char *phone, const char *content_utf8);
int app_v100c_call(const char *phone);
int app_v100c_hangup(void);
int app_v100c_notify_low_stock(const app_medicine_plan_t *plan,
                               int box_id,
                               int stock_count);

#endif

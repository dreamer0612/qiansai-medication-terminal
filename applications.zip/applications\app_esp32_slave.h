#ifndef __APP_ESP32_SLAVE_H__
#define __APP_ESP32_SLAVE_H__

#include "app_beep_alarm.h"

int app_esp32_slave_start(void);
int app_esp32_slave_report(void);
int app_esp32_slave_send_medicine_reminder(const app_medicine_plan_t *plan);
int app_esp32_slave_send_medicine_reminder_stop(const app_medicine_plan_t *plan,
                                                const char *reason);

#endif

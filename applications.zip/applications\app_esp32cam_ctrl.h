#ifndef __APP_ESP32CAM_CTRL_H__
#define __APP_ESP32CAM_CTRL_H__

#include <rtthread.h>

int app_esp32cam_ctrl_start(void);
void app_esp32cam_ctrl_set(rt_bool_t enabled);
void app_esp32cam_ctrl_set_manual(rt_bool_t enabled);
void app_esp32cam_ctrl_set_medicine(rt_bool_t enabled);
rt_bool_t app_esp32cam_ctrl_get(void);

#endif

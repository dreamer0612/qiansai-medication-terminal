#ifndef __APP_MAX30102_H__
#define __APP_MAX30102_H__

#include <rtthread.h>

#define APP_MAX30102_ERR_NOT_READY     (-1)
#define APP_MAX30102_ERR_BUSY          (-2)
#define APP_MAX30102_ERR_NO_FINGER     (-3)
#define APP_MAX30102_ERR_FINGER_LOST   (-4)
#define APP_MAX30102_ERR_UNSTABLE      (-5)
#define APP_MAX30102_ERR_TIMEOUT       (-6)

int app_max30102_start(void);
int app_max30102_get(int *heart_rate, int *spo2);
int app_max30102_measure(int *heart_rate, int *spo2, rt_int32_t timeout_ms);

#endif

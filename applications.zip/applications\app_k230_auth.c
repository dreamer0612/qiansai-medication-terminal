﻿#include <rtthread.h>
#include <rtdevice.h>
#include <board.h>
#include <string.h>
#include <cJSON.h>

#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>

#include "app_k230_auth.h"
#include "app_ram.h"
#include "app_lcd_show.h"
#include "app_local_upload.h"
#include "app_medicine_servo.h"
#include "app_v100c.h"

#define DBG_TAG "app.k230"
#define DBG_LVL DBG_INFO
#include <rtdbg.h>

#define K230_UART_NAME        "uart3"
#define K230_LINE_BUF_SIZE    512
#define K230_UART_RX_BUF_SIZE 256
#define K230_THREAD_STACK_SIZE 8192
#define K230_CLOUD_THREAD_STACK_SIZE 8192
#define K230_CLOUD_HTTP_REQUEST_SIZE 1536
#define K230_CLOUD_HTTP_RESPONSE_SIZE 1024
#define K230_CLOUD_POST_JSON_SIZE 1280
#define K230_CLOUD_LINE_QUEUE_COUNT 3
#define K230_CLOUD_POLL_INTERVAL_MS 3000
#define K230_CLOUD_FAIL_BACKOFF_MAX_MS 15000

#define K230_CLOUD_SERVER_HOST "YOUR_SERVER_HOST"
#define K230_CLOUD_SERVER_PORT "3000"
#define K230_CLOUD_COMMAND_PATH "/api/device/k230/command"
#define K230_CLOUD_RESULT_PATH  "/api/device/k230/result"
#define K230_MEDICINE_STOCK_CMD_SIZE 128
#define K230_MEDICINE_NAME_SAFE_SIZE 64
#define K230_AUTH_WAKE_DELAY_MS 1000
#define K230_AUTH_QUERY_RETRY_INTERVAL_MS 2000
#define K230_AUTH_QUERY_RETRY_COUNT 2

typedef struct
{
    char line[K230_LINE_BUF_SIZE];
} k230_cloud_line_msg_t;

static rt_device_t k230_uart = RT_NULL;
static struct rt_semaphore k230_rx_sem;
static rt_mutex_t k230_tx_lock = RT_NULL;
static rt_mutex_t k230_auth_lock = RT_NULL;
static rt_bool_t k230_started = RT_FALSE;
static app_k230_auth_status_t k230_status;
static struct rt_semaphore k230_auth_done_sem;
static rt_bool_t k230_auth_waiting = RT_FALSE;
static rt_tick_t k230_auth_start_tick = 0;
static struct rt_thread k230_thread;
ALIGN(RT_ALIGN_SIZE)
static rt_uint8_t k230_thread_stack[K230_THREAD_STACK_SIZE] APP_CCMRAM;
static char k230_uart_line_buf[K230_LINE_BUF_SIZE];
static rt_bool_t k230_cloud_started = RT_FALSE;
static rt_mutex_t k230_cloud_http_lock = RT_NULL;
static struct rt_messagequeue k230_cloud_line_mq;
ALIGN(RT_ALIGN_SIZE)
static rt_uint8_t k230_cloud_line_mq_pool[sizeof(k230_cloud_line_msg_t) *
                                          K230_CLOUD_LINE_QUEUE_COUNT];
static struct rt_thread k230_cloud_thread;
ALIGN(RT_ALIGN_SIZE)
static rt_uint8_t k230_cloud_thread_stack[K230_CLOUD_THREAD_STACK_SIZE] APP_CCMRAM;
static char k230_cloud_http_request[K230_CLOUD_HTTP_REQUEST_SIZE];
static char k230_cloud_http_response[K230_CLOUD_HTTP_RESPONSE_SIZE];
static char k230_cloud_post_json[K230_CLOUD_POST_JSON_SIZE];
static char k230_cloud_escaped_line[K230_LINE_BUF_SIZE * 2];
static k230_cloud_line_msg_t k230_cloud_pending_msg;

static void k230_copy_string(char *dst, rt_size_t dst_size, const char *src)
{
    if (dst == RT_NULL || dst_size == 0)
    {
        return;
    }

    rt_snprintf(dst, dst_size, "%s", src == RT_NULL ? "" : src);
}

static void k230_sanitize_field(char *dst, rt_size_t dst_size, const char *src)
{
    rt_size_t pos = 0;

    if (dst == RT_NULL || dst_size == 0)
    {
        return;
    }

    if (src == RT_NULL || src[0] == '\0')
    {
        rt_snprintf(dst, dst_size, "unknown");
        return;
    }

    while (*src != '\0' && pos < dst_size - 1)
    {
        char ch = *src++;

        if (ch == '|' || ch == '\r' || ch == '\n' || ch == '\t')
        {
            ch = ' ';
        }

        dst[pos++] = ch;
    }

    dst[pos] = '\0';
    if (pos == 0)
    {
        rt_snprintf(dst, dst_size, "unknown");
    }
}

static rt_err_t k230_uart_rx_ind(rt_device_t dev, rt_size_t size)
{
    rt_sem_release(&k230_rx_sem);
    return RT_EOK;
}

static int k230_uart_open_with_bufsz(rt_size_t rx_bufsz)
{
    struct serial_configure config = RT_SERIAL_CONFIG_DEFAULT;

    config.baud_rate = BAUD_RATE_115200;
    config.data_bits = DATA_BITS_8;
    config.stop_bits = STOP_BITS_1;
    config.parity = PARITY_NONE;
    config.bufsz = rx_bufsz;

    rt_device_control(k230_uart, RT_DEVICE_CTRL_CONFIG, &config);
    if (rt_device_open(k230_uart, RT_DEVICE_FLAG_INT_RX) == RT_EOK)
    {
        LOG_I("k230 uart rx fifo size=%d", (int)rx_bufsz);
        return 0;
    }

    return -1;
}

static const char *k230_json_string(cJSON *root, const char *name)
{
    cJSON *item;

    item = cJSON_GetObjectItem(root, name);
    if (item == RT_NULL || !cJSON_IsString(item) || item->valuestring == RT_NULL)
    {
        return RT_NULL;
    }

    return item->valuestring;
}

static int k230_json_int(cJSON *root, const char *name, int *value)
{
    cJSON *item;

    if (root == RT_NULL || name == RT_NULL || value == RT_NULL)
    {
        return -1;
    }

    item = cJSON_GetObjectItem(root, name);
    if (item == RT_NULL || !cJSON_IsNumber(item))
    {
        return -1;
    }

    *value = item->valueint;
    return 0;
}

static int k230_socket_send_all(int sock, const char *buf, int len)
{
    int sent = 0;

    while (sent < len)
    {
        int ret = send(sock, buf + sent, len - sent, 0);

        if (ret <= 0)
        {
            return -1;
        }

        sent += ret;
    }

    return 0;
}

static int k230_cloud_tcp_connect(void)
{
    struct addrinfo hints;
    struct addrinfo *res = RT_NULL;
    struct addrinfo *p;
    int sock = -1;
    int ret;

    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;

    ret = getaddrinfo(K230_CLOUD_SERVER_HOST, K230_CLOUD_SERVER_PORT,
                      &hints, &res);
    if (ret != 0 || res == RT_NULL)
    {
        LOG_D("k230 cloud getaddrinfo failed");
        return -1;
    }

    for (p = res; p != RT_NULL; p = p->ai_next)
    {
        sock = socket(p->ai_family, p->ai_socktype, p->ai_protocol);
        if (sock < 0)
        {
            continue;
        }

        if (connect(sock, p->ai_addr, p->ai_addrlen) == 0)
        {
            break;
        }

        closesocket(sock);
        sock = -1;
    }

    freeaddrinfo(res);

    if (sock < 0)
    {
        LOG_D("k230 cloud tcp connect failed");
        return -1;
    }

    return sock;
}

static int k230_cloud_http_request_do(const char *method,
                                      const char *path,
                                      const char *json,
                                      char *response,
                                      int response_size)
{
    int sock;
    int ret;
    int total = 0;
    int request_len;
    int json_len = json == RT_NULL ? 0 : strlen(json);

    if (method == RT_NULL || path == RT_NULL ||
        response == RT_NULL || response_size <= 0)
    {
        return -1;
    }

    if (k230_cloud_http_lock != RT_NULL)
    {
        rt_mutex_take(k230_cloud_http_lock, RT_WAITING_FOREVER);
    }

    sock = k230_cloud_tcp_connect();
    if (sock < 0)
    {
        if (k230_cloud_http_lock != RT_NULL)
        {
            rt_mutex_release(k230_cloud_http_lock);
        }
        return -1;
    }

    if (strcmp(method, "POST") == 0)
    {
        request_len = rt_snprintf(k230_cloud_http_request,
                                  sizeof(k230_cloud_http_request),
                                  "POST %s HTTP/1.1\r\n"
                                  "Host: %s:%s\r\n"
                                  "Content-Type: application/json\r\n"
                                  "Content-Length: %d\r\n"
                                  "Connection: close\r\n"
                                  "\r\n"
                                  "%s",
                                  path,
                                  K230_CLOUD_SERVER_HOST,
                                  K230_CLOUD_SERVER_PORT,
                                  json_len,
                                  json == RT_NULL ? "" : json);
    }
    else
    {
        request_len = rt_snprintf(k230_cloud_http_request,
                                  sizeof(k230_cloud_http_request),
                                  "GET %s HTTP/1.1\r\n"
                                  "Host: %s:%s\r\n"
                                  "Connection: close\r\n"
                                  "\r\n",
                                  path,
                                  K230_CLOUD_SERVER_HOST,
                                  K230_CLOUD_SERVER_PORT);
    }

    if (request_len <= 0 || request_len >= (int)sizeof(k230_cloud_http_request))
    {
        LOG_E("k230 cloud http request too long");
        closesocket(sock);
        if (k230_cloud_http_lock != RT_NULL)
        {
            rt_mutex_release(k230_cloud_http_lock);
        }
        return -1;
    }

    ret = k230_socket_send_all(sock, k230_cloud_http_request, request_len);
    if (ret < 0)
    {
        LOG_D("k230 cloud send request failed");
        closesocket(sock);
        if (k230_cloud_http_lock != RT_NULL)
        {
            rt_mutex_release(k230_cloud_http_lock);
        }
        return -1;
    }

    memset(response, 0, response_size);
    while (1)
    {
        ret = recv(sock, response + total, response_size - total - 1, 0);
        if (ret > 0)
        {
            total += ret;
            if (total >= response_size - 1)
            {
                break;
            }
        }
        else
        {
            break;
        }
    }

    closesocket(sock);
    response[total] = '\0';

    if (k230_cloud_http_lock != RT_NULL)
    {
        rt_mutex_release(k230_cloud_http_lock);
    }

    if (total <= 0)
    {
        LOG_D("k230 cloud recv response failed");
        return -1;
    }

    if (strncmp(response, "HTTP/1.1 2", 10) != 0 &&
        strncmp(response, "HTTP/1.0 2", 10) != 0)
    {
        LOG_E("k230 cloud server rejected: %s", response);
        return -1;
    }

    return total;
}

static const char *k230_cloud_http_body(const char *response)
{
    const char *body;

    if (response == RT_NULL)
    {
        return RT_NULL;
    }

    body = strstr(response, "\r\n\r\n");
    body = body == RT_NULL ? response : body + 4;
    while (*body != '\0' && *body != '{' && *body != '[')
    {
        body++;
    }

    return body;
}

static int k230_cloud_json_escape(const char *src, char *dst, int dst_size)
{
    int used = 0;

    if (src == RT_NULL || dst == RT_NULL || dst_size <= 0)
    {
        return -1;
    }

    while (*src != '\0')
    {
        unsigned char ch = (unsigned char)*src++;

        if (ch == '"' || ch == '\\')
        {
            if (used + 2 >= dst_size)
            {
                return -1;
            }
            dst[used++] = '\\';
            dst[used++] = (char)ch;
        }
        else if (ch == '\t')
        {
            if (used + 2 >= dst_size)
            {
                return -1;
            }
            dst[used++] = '\\';
            dst[used++] = 't';
        }
        else if (ch < 0x20)
        {
            if (used + 6 >= dst_size)
            {
                return -1;
            }
            rt_snprintf(dst + used, dst_size - used, "\\u%04x", ch);
            used += 6;
        }
        else
        {
            if (used + 1 >= dst_size)
            {
                return -1;
            }
            dst[used++] = (char)ch;
        }
    }

    dst[used] = '\0';
    return used;
}

static int k230_cloud_post_line(const char *line)
{
    int escaped_len;
    int json_len;

    if (line == RT_NULL || line[0] == '\0')
    {
        return -1;
    }

    escaped_len = k230_cloud_json_escape(line,
                                         k230_cloud_escaped_line,
                                         sizeof(k230_cloud_escaped_line));
    if (escaped_len < 0)
    {
        LOG_E("k230 cloud escape line failed");
        return -1;
    }

    json_len = rt_snprintf(k230_cloud_post_json,
                           sizeof(k230_cloud_post_json),
                           "{\"line\":\"%s\"}",
                           k230_cloud_escaped_line);
    if (json_len <= 0 || json_len >= (int)sizeof(k230_cloud_post_json))
    {
        LOG_E("k230 cloud result json too long");
        return -1;
    }

    return k230_cloud_http_request_do("POST",
                                      K230_CLOUD_RESULT_PATH,
                                      k230_cloud_post_json,
                                      k230_cloud_http_response,
                                      sizeof(k230_cloud_http_response));
}

static int k230_cloud_fetch_command(char *cmd, int cmd_size)
{
    const char *body;
    const char *command = RT_NULL;
    cJSON *root;
    cJSON *data;
    int ret;

    if (cmd == RT_NULL || cmd_size <= 0)
    {
        return -1;
    }
    cmd[0] = '\0';

    ret = k230_cloud_http_request_do("GET",
                                     K230_CLOUD_COMMAND_PATH,
                                     RT_NULL,
                                     k230_cloud_http_response,
                                     sizeof(k230_cloud_http_response));
    if (ret < 0)
    {
        return -1;
    }

    body = k230_cloud_http_body(k230_cloud_http_response);
    root = cJSON_Parse(body);
    if (root == RT_NULL)
    {
        LOG_W("k230 cloud invalid command json");
        return -1;
    }

    data = cJSON_GetObjectItem(root, "data");
    if (data != RT_NULL)
    {
        if (cJSON_IsString(data) && data->valuestring != RT_NULL)
        {
            command = data->valuestring;
        }
        else if (cJSON_IsObject(data))
        {
            cJSON *item = cJSON_GetObjectItem(data, "command");
            if (item != RT_NULL && cJSON_IsString(item) &&
                item->valuestring != RT_NULL)
            {
                command = item->valuestring;
            }
        }
    }

    if (command != RT_NULL && command[0] != '\0')
    {
        rt_snprintf(cmd, cmd_size, "%s", command);
        cJSON_Delete(root);
        return 1;
    }

    cJSON_Delete(root);
    return 0;
}

static void k230_cloud_submit_line(const char *line)
{
    k230_cloud_line_msg_t msg;

    if (k230_cloud_started == RT_FALSE || line == RT_NULL || line[0] == '\0')
    {
        return;
    }

    if (strncmp(line, "[DEBUG]", 7) == 0 ||
        strstr(line, "HEX:") != RT_NULL ||
        strstr(line, "Parsed CMD:") != RT_NULL)
    {
        return;
    }

    /* The web face-management flow only needs K230 text protocol replies.
     * recognized_face JSON events are frequent local status updates; posting
     * every one competes with the normal upload thread and can exhaust the
     * small RT-Thread/SAL networking resources.
     */
    if (strncmp(line, "EDIT:", 5) != 0 &&
        strncmp(line, "USER:", 5) != 0)
    {
        return;
    }

    rt_snprintf(msg.line, sizeof(msg.line), "%s", line);
    if (rt_mq_send(&k230_cloud_line_mq, &msg, sizeof(msg)) != RT_EOK)
    {
        LOG_W("k230 cloud line queue full, drop: %s", line);
    }
}

static int k230_cloud_send_command(const char *command)
{
    return app_k230_send_cmd(command);
}

static void k230_cloud_entry(void *parameter)
{
    char command[160];
    int delay_ms = K230_CLOUD_POLL_INTERVAL_MS;
    int fetch_ret;

    LOG_I("k230 cloud bridge thread start");

    while (1)
    {
        while (rt_mq_recv(&k230_cloud_line_mq,
                          &k230_cloud_pending_msg,
                          sizeof(k230_cloud_pending_msg),
                          0) == RT_EOK)
        {
            if (k230_cloud_post_line(k230_cloud_pending_msg.line) > 0)
            {
                LOG_I("k230 cloud result posted: %s", k230_cloud_pending_msg.line);
            }
            else
            {
                LOG_W("k230 cloud result post failed: %s", k230_cloud_pending_msg.line);
            }
        }

        fetch_ret = k230_cloud_fetch_command(command, sizeof(command));
        if (fetch_ret > 0)
        {
            LOG_I("k230 cloud command: %s", command);
            k230_cloud_send_command(command);
            delay_ms = K230_CLOUD_POLL_INTERVAL_MS;
        }
        else if (fetch_ret == 0)
        {
            delay_ms = K230_CLOUD_POLL_INTERVAL_MS;
        }
        else
        {
            delay_ms += K230_CLOUD_POLL_INTERVAL_MS;
            if (delay_ms > K230_CLOUD_FAIL_BACKOFF_MAX_MS)
            {
                delay_ms = K230_CLOUD_FAIL_BACKOFF_MAX_MS;
            }
        }

        rt_thread_mdelay(delay_ms);
    }
}

static void k230_update_status(const char *trigger_type,
                               const char *user_name,
                               const char *permission,
                               const char *current_mode,
                               rt_bool_t auth_response)
{
    rt_base_t level;
    rt_bool_t notify_auth = RT_FALSE;
    rt_bool_t face_auth_event;
    rt_bool_t query_auth_done;
    app_k230_auth_status_t status_tmp;

    k230_copy_string(status_tmp.trigger_type, sizeof(status_tmp.trigger_type), trigger_type);
    k230_copy_string(status_tmp.user_name, sizeof(status_tmp.user_name), user_name);
    k230_copy_string(status_tmp.permission, sizeof(status_tmp.permission), permission);
    k230_copy_string(status_tmp.current_mode, sizeof(status_tmp.current_mode), current_mode);
    status_tmp.update_tick = rt_tick_get();
    status_tmp.valid = RT_TRUE;
    face_auth_event = strcmp(status_tmp.trigger_type, "recognized_face") == 0 &&
                      strcmp(status_tmp.permission, "allowed") == 0 &&
                      status_tmp.user_name[0] != '\0' &&
                      strcmp(status_tmp.user_name, "unknown") != 0 ? RT_TRUE : RT_FALSE;
    query_auth_done = auth_response == RT_TRUE &&
                      (strcmp(status_tmp.permission, "allowed") == 0 ||
                       (status_tmp.user_name[0] != '\0' &&
                        strcmp(status_tmp.user_name, "unknown") != 0)) ?
                      RT_TRUE : RT_FALSE;

    level = rt_hw_interrupt_disable();
    k230_status = status_tmp;
    if (k230_auth_waiting == RT_TRUE &&
        (query_auth_done == RT_TRUE || face_auth_event == RT_TRUE))
    {
        k230_auth_waiting = RT_FALSE;
        notify_auth = RT_TRUE;
    }
    rt_hw_interrupt_enable(level);

    if (notify_auth == RT_TRUE)
    {
        if (query_auth_done != RT_TRUE && face_auth_event == RT_TRUE)
        {
            LOG_I("k230 active auth completed by recognized face, user=%s, start_tick=%u, update_tick=%u",
                  status_tmp.user_name,
                  (unsigned int)k230_auth_start_tick,
                  (unsigned int)status_tmp.update_tick);
        }
        rt_sem_release(&k230_auth_done_sem);
    }

    app_lcd_show_set_k230_status(user_name, permission, current_mode);
}

static cJSON *k230_tool_args(cJSON *root)
{
    cJSON *args;

    args = cJSON_GetObjectItem(root, "args");
    if (args != RT_NULL && cJSON_IsObject(args))
    {
        return args;
    }

    return root;
}

static int k230_handle_open_lid(cJSON *root)
{
    cJSON *args;
    int box_id = 0;
    int ret;

    args = k230_tool_args(root);
    if (k230_json_int(args, "box_id", &box_id) != 0)
    {
        (void)k230_json_int(args, "boxId", &box_id);
    }

    if (box_id < 1 || box_id > APP_MEDICINE_PLAN_MAX_COUNT)
    {
        LOG_W("k230 open_lid invalid box_id=%d", box_id);
        return -1;
    }

    ret = app_medicine_servo_open(box_id);
    if (ret != 0)
    {
        LOG_W("k230 open_lid failed: box_id=%d ret=%d", box_id, ret);
        return -2;
    }

    LOG_I("k230 open_lid handled: box_id=%d", box_id);
    return 0;
}

static int k230_handle_make_phone_call(cJSON *root)
{
    cJSON *args;
    app_family_contact_t contact;
    const char *phone;
    int ret;

    args = k230_tool_args(root);
    phone = k230_json_string(args, "phone");
    if (phone == RT_NULL || phone[0] == '\0')
    {
        phone = k230_json_string(args, "phone_number");
    }
    if (phone == RT_NULL || phone[0] == '\0')
    {
        phone = k230_json_string(args, "mobile");
    }
    if (phone == RT_NULL || phone[0] == '\0')
    {
        if (app_local_upload_get_family_contact(&contact) != 0)
        {
            LOG_W("k230 make_phone_call ignored, family phone is empty");
            return -1;
        }
        phone = contact.phone;
    }

    ret = app_v100c_call(phone);
    if (ret != 0)
    {
        LOG_W("k230 make_phone_call failed: phone=%s ret=%d", phone, ret);
        return -2;
    }

    LOG_I("k230 make_phone_call handled: phone=%s", phone);
    return 0;
}

static int k230_handle_tool_command(cJSON *root, const char *tool)
{
    if (root == RT_NULL || tool == RT_NULL)
    {
        return -1;
    }

    if (strcmp(tool, "open_lid") == 0)
    {
        return k230_handle_open_lid(root);
    }

    if (strcmp(tool, "make_phone_call") == 0 ||
        strcmp(tool, "phone_call") == 0 ||
        strcmp(tool, "call_family") == 0)
    {
        return k230_handle_make_phone_call(root);
    }

    LOG_W("k230 unknown tool command: %s", tool);
    return -1;
}

static void k230_handle_json_line(const char *line)
{
    cJSON *root;
    const char *json_line;
    const char *tool;
    const char *device;
    const char *trigger_type;
    const char *user_name;
    const char *permission;
    const char *current_mode;

    if (line == RT_NULL || line[0] == '\0')
    {
        return;
    }

    /* K230 also emits protocol text and optional debug lines. They are not
     * JSON events and must not be reported as malformed JSON. */
    if (strncmp(line, "[DEBUG]", 7) == 0 ||
        strstr(line, "HEX:") != RT_NULL ||
        strstr(line, "Parsed CMD:") != RT_NULL)
    {
        LOG_D("k230 debug: %s", line);
        return;
    }

    if (strncmp(line, "EDIT:", 5) == 0 ||
        strncmp(line, "USER:", 5) == 0)
    {
        LOG_I("k230 response: %s", line);
        return;
    }

    json_line = strchr(line, '{');
    if (json_line == RT_NULL)
    {
        LOG_D("k230 text: %s", line);
        return;
    }
    if (json_line != line)
    {
        LOG_W("drop k230 rx prefix before json: %s", line);
    }

    root = cJSON_Parse(json_line);
    if (root == RT_NULL)
    {
        LOG_W("invalid k230 json: %s", json_line);
        return;
    }

    tool = k230_json_string(root, "tool");
    if (tool != RT_NULL)
    {
        int ret = k230_handle_tool_command(root, tool);
        if (ret == 0)
        {
            LOG_I("k230 tool handled: %s", tool);
        }
        else
        {
            LOG_W("k230 tool failed: %s ret=%d", tool, ret);
        }
        cJSON_Delete(root);
        return;
    }

    device = k230_json_string(root, "device");
    trigger_type = k230_json_string(root, "trigger_type");
    user_name = k230_json_string(root, "user_name");
    permission = k230_json_string(root, "permission");
    current_mode = k230_json_string(root, "current_mode");
    if (current_mode == RT_NULL)
    {
        current_mode = "normal_mode";
    }

    if (trigger_type == RT_NULL ||
        user_name == RT_NULL ||
        permission == RT_NULL)
    {
        LOG_W("k230 json missing required field: %s", json_line);
        cJSON_Delete(root);
        return;
    }

    /* The K230 protocol specifies lowercase "k230". Keep uppercase support
     * for compatibility with older firmware. */
    if (device != RT_NULL &&
        strcmp(device, "k230") != 0 && strcmp(device, "K230") != 0)
    {
        LOG_W("ignore json from device: %s", device);
        cJSON_Delete(root);
        return;
    }

    k230_update_status(trigger_type,
                       user_name,
                       permission,
                       current_mode,
                       strcmp(trigger_type, "query_permission") == 0 ?
                       RT_TRUE : RT_FALSE);

    if (strcmp(permission, "allowed") == 0)
    {
        LOG_I("k230 auth allowed, user=%s, trigger=%s, mode=%s",
              user_name,
              trigger_type,
              current_mode);
    }
    else
    {
        LOG_W("k230 auth not allowed, user=%s, permission=%s, trigger=%s, mode=%s",
              user_name,
              permission,
              trigger_type,
              current_mode);
    }

    cJSON_Delete(root);
}

static void k230_complete_line(char *line_buf, int *line_pos)
{
    int len;

    len = *line_pos;
    while (len > 0 && (line_buf[len - 1] == '\r' || line_buf[len - 1] == '\n'))
    {
        len--;
    }

    line_buf[len] = '\0';
    *line_pos = 0;

    if (len == 0)
    {
        return;
    }

    k230_cloud_submit_line(line_buf);
    k230_handle_json_line(line_buf);
}

static void k230_process_char(char ch, char *line_buf, int *line_pos)
{
    if (ch == '\n' || ch == '\r')
    {
        k230_complete_line(line_buf, line_pos);
        return;
    }

    if (*line_pos >= K230_LINE_BUF_SIZE - 1)
    {
        *line_pos = 0;
        LOG_W("k230 rx line too long, drop");
        return;
    }

    line_buf[*line_pos] = ch;
    (*line_pos)++;
}

static void k230_auth_entry(void *parameter)
{
    int line_pos = 0;

    LOG_I("k230 auth thread start");

    while (1)
    {
        char ch;

        while (rt_device_read(k230_uart, -1, &ch, 1) == 1)
        {
            k230_process_char(ch, k230_uart_line_buf, &line_pos);
        }

        rt_sem_take(&k230_rx_sem, RT_WAITING_FOREVER);
    }
}

int app_k230_send_cmd(const char *cmd)
{
    rt_size_t len;

    if (cmd == RT_NULL || cmd[0] == '\0')
    {
        return -1;
    }

    if (k230_uart == RT_NULL)
    {
        LOG_E("k230 uart not ready");
        return -1;
    }

    len = strlen(cmd);

    if (k230_tx_lock != RT_NULL)
    {
        rt_mutex_take(k230_tx_lock, RT_WAITING_FOREVER);
    }

    if (rt_device_write(k230_uart, 0, cmd, len) != len ||
        rt_device_write(k230_uart, 0, "\r\n", 2) != 2)
    {
        if (k230_tx_lock != RT_NULL)
        {
            rt_mutex_release(k230_tx_lock);
        }

        LOG_E("send k230 cmd failed: %s", cmd);
        return -1;
    }

    if (k230_tx_lock != RT_NULL)
    {
        rt_mutex_release(k230_tx_lock);
    }

    LOG_I("send k230 cmd: %s", cmd);
    return 0;
}

int app_k230_send_medicine_stock(int box_id, const char *medicine_name, int quantity)
{
    char safe_name[K230_MEDICINE_NAME_SAFE_SIZE];
    char cmd[K230_MEDICINE_STOCK_CMD_SIZE];
    int len;

    if (box_id < 1)
    {
        box_id = 0;
    }

    if (quantity < 0)
    {
        quantity = 0;
    }

    k230_sanitize_field(safe_name, sizeof(safe_name), medicine_name);
    len = rt_snprintf(cmd,
                      sizeof(cmd),
                      "MED:STOCK|%d|%s|%d",
                      box_id,
                      safe_name,
                      quantity);
    if (len <= 0 || len >= (int)sizeof(cmd))
    {
        LOG_E("build k230 medicine stock cmd failed");
        return -1;
    }

    return app_k230_send_cmd(cmd);
}

int app_k230_get_status(app_k230_auth_status_t *status)
{
    rt_base_t level;

    if (status == RT_NULL)
    {
        return -1;
    }

    level = rt_hw_interrupt_disable();
    *status = k230_status;
    rt_hw_interrupt_enable(level);

    return status->valid == RT_TRUE ? 0 : -1;
}

int app_k230_authenticate(app_k230_auth_status_t *status, rt_int32_t timeout_ms)
{
    rt_base_t level;
    rt_err_t wait_ret;
    rt_tick_t auth_wait_start;
    rt_tick_t timeout_tick;
    rt_tick_t retry_tick;
    int query_count = 0;

    if (status == RT_NULL || k230_started == RT_FALSE || k230_auth_lock == RT_NULL)
    {
        return -1;
    }

    memset(status, 0, sizeof(*status));

    if (rt_mutex_take(k230_auth_lock, 0) != RT_EOK)
    {
        return -2;
    }

    while (rt_sem_trytake(&k230_auth_done_sem) == RT_EOK)
    {
    }

    level = rt_hw_interrupt_disable();
    memset(&k230_status, 0, sizeof(k230_status));
    k230_auth_start_tick = rt_tick_get();
    k230_auth_waiting = RT_TRUE;
    rt_hw_interrupt_enable(level);

    if (app_k230_send_cmd("MODE:NORMAL") != 0)
    {
        level = rt_hw_interrupt_disable();
        k230_auth_waiting = RT_FALSE;
        rt_hw_interrupt_enable(level);
        rt_mutex_release(k230_auth_lock);
        return -1;
    }

    rt_thread_mdelay(K230_AUTH_WAKE_DELAY_MS);

    if (rt_sem_trytake(&k230_auth_done_sem) == RT_EOK)
    {
        level = rt_hw_interrupt_disable();
        k230_auth_waiting = RT_FALSE;
        if (k230_status.valid == RT_TRUE)
        {
            *status = k230_status;
        }
        rt_hw_interrupt_enable(level);

        app_k230_send_cmd("MODE:SAVEPWR");
        rt_mutex_release(k230_auth_lock);
        return status->valid == RT_TRUE ? 0 : -1;
    }

    timeout_tick = timeout_ms < 0 ? RT_WAITING_FOREVER :
                   rt_tick_from_millisecond(timeout_ms);
    retry_tick = rt_tick_from_millisecond(K230_AUTH_QUERY_RETRY_INTERVAL_MS);
    auth_wait_start = rt_tick_get();
    wait_ret = -RT_ETIMEOUT;

    while (timeout_ms < 0 ||
           (rt_tick_t)(rt_tick_get() - auth_wait_start) < timeout_tick)
    {
        rt_tick_t wait_tick = retry_tick;

        if (query_count < K230_AUTH_QUERY_RETRY_COUNT)
        {
            if (app_k230_send_cmd("CMD:QUERY_PERMISSION") != 0)
            {
                level = rt_hw_interrupt_disable();
                k230_auth_waiting = RT_FALSE;
                rt_hw_interrupt_enable(level);
                app_k230_send_cmd("MODE:SAVEPWR");
                rt_mutex_release(k230_auth_lock);
                return -1;
            }
            query_count++;
        }

        if (timeout_ms >= 0)
        {
            rt_tick_t elapsed = (rt_tick_t)(rt_tick_get() - auth_wait_start);
            rt_tick_t remaining = elapsed >= timeout_tick ? 0 : timeout_tick - elapsed;

            if (remaining == 0)
            {
                break;
            }
            if (wait_tick > remaining)
            {
                wait_tick = remaining;
            }
        }

        wait_ret = rt_sem_take(&k230_auth_done_sem, wait_tick);
        if (wait_ret == RT_EOK)
        {
            break;
        }
    }

    level = rt_hw_interrupt_disable();
    k230_auth_waiting = RT_FALSE;
    if (wait_ret == RT_EOK && k230_status.valid == RT_TRUE)
    {
        *status = k230_status;
    }
    rt_hw_interrupt_enable(level);

    app_k230_send_cmd("MODE:SAVEPWR");
    rt_mutex_release(k230_auth_lock);

    return wait_ret == RT_EOK && status->valid == RT_TRUE ? 0 : -1;
}

int app_k230_auth_start(void)
{
    rt_err_t ret;
    int opened = -1;

    if (k230_started == RT_TRUE)
    {
        return 0;
    }

    k230_uart = rt_device_find(K230_UART_NAME);
    if (k230_uart == RT_NULL)
    {
        LOG_E("find %s failed", K230_UART_NAME);
        return -1;
    }

    rt_sem_init(&k230_rx_sem, "k230_rx", 0, RT_IPC_FLAG_FIFO);
    rt_sem_init(&k230_auth_done_sem, "k230_done", 0, RT_IPC_FLAG_FIFO);
    rt_device_set_rx_indicate(k230_uart, k230_uart_rx_ind);

    if (k230_uart_open_with_bufsz(K230_UART_RX_BUF_SIZE) == 0 ||
        k230_uart_open_with_bufsz(128) == 0 ||
        k230_uart_open_with_bufsz(64) == 0)
    {
        opened = 0;
    }

    if (opened != 0)
    {
        LOG_E("open %s failed, no memory for rx fifo", K230_UART_NAME);
        return -1;
    }

    k230_tx_lock = rt_mutex_create("k230_tx", RT_IPC_FLAG_FIFO);
    if (k230_tx_lock == RT_NULL)
    {
        LOG_E("create k230 tx mutex failed");
        rt_device_close(k230_uart);
        k230_uart = RT_NULL;
        return -1;
    }

    k230_auth_lock = rt_mutex_create("k230_req", RT_IPC_FLAG_FIFO);
    if (k230_auth_lock == RT_NULL)
    {
        LOG_E("create k230 auth mutex failed");
        rt_mutex_delete(k230_tx_lock);
        k230_tx_lock = RT_NULL;
        rt_device_close(k230_uart);
        k230_uart = RT_NULL;
        return -1;
    }

    ret = rt_thread_init(&k230_thread,
                         "k230_auth",
                         k230_auth_entry,
                         RT_NULL,
                         k230_thread_stack,
                         sizeof(k230_thread_stack),
                         19,
                         10);

    if (ret != RT_EOK)
    {
        LOG_E("create k230 auth thread failed, ret=%d", ret);
        rt_mutex_delete(k230_auth_lock);
        k230_auth_lock = RT_NULL;
        rt_mutex_delete(k230_tx_lock);
        k230_tx_lock = RT_NULL;
        rt_device_close(k230_uart);
        k230_uart = RT_NULL;
        return -1;
    }

    k230_started = RT_TRUE;
    rt_thread_startup(&k230_thread);
    LOG_I("k230 auth started on %s, 115200 8N1", K230_UART_NAME);

    return 0;
}

int app_k230_cloud_bridge_start(void)
{
    rt_err_t ret;

    if (k230_cloud_started == RT_TRUE)
    {
        return 0;
    }

    if (k230_started == RT_FALSE)
    {
        LOG_E("start k230 cloud bridge after app_k230_auth_start");
        return -1;
    }

    k230_cloud_http_lock = rt_mutex_create("k230_http", RT_IPC_FLAG_FIFO);
    if (k230_cloud_http_lock == RT_NULL)
    {
        LOG_E("create k230 cloud http mutex failed");
        return -1;
    }

    ret = rt_mq_init(&k230_cloud_line_mq,
                     "k230_cld",
                     k230_cloud_line_mq_pool,
                     sizeof(k230_cloud_line_msg_t),
                     sizeof(k230_cloud_line_mq_pool),
                     RT_IPC_FLAG_FIFO);
    if (ret != RT_EOK)
    {
        LOG_E("init k230 cloud line mq failed, ret=%d", ret);
        rt_mutex_delete(k230_cloud_http_lock);
        k230_cloud_http_lock = RT_NULL;
        return -1;
    }

    ret = rt_thread_init(&k230_cloud_thread,
                         "k230_cloud",
                         k230_cloud_entry,
                         RT_NULL,
                         k230_cloud_thread_stack,
                         sizeof(k230_cloud_thread_stack),
                         23,
                         10);
    if (ret != RT_EOK)
    {
        LOG_E("create k230 cloud thread failed, ret=%d", ret);
        rt_mq_detach(&k230_cloud_line_mq);
        rt_mutex_delete(k230_cloud_http_lock);
        k230_cloud_http_lock = RT_NULL;
        return -1;
    }

    k230_cloud_started = RT_TRUE;
    rt_thread_startup(&k230_cloud_thread);
    LOG_I("k230 cloud bridge started: http://%s:%s",
          K230_CLOUD_SERVER_HOST,
          K230_CLOUD_SERVER_PORT);

    return 0;
}

static int k230_mode(int argc, char **argv)
{
    if (argc != 2)
    {
        rt_kprintf("usage: k230_mode normal|savepwr|edit\n");
        return -1;
    }

    if (strcmp(argv[1], "normal") == 0)
    {
        return app_k230_send_cmd("MODE:NORMAL");
    }
    else if (strcmp(argv[1], "savepwr") == 0)
    {
        return app_k230_send_cmd("MODE:SAVEPWR");
    }
    else if (strcmp(argv[1], "edit") == 0)
    {
        return app_k230_send_cmd("MODE:EDIT");
    }

    rt_kprintf("usage: k230_mode normal|savepwr|edit\n");
    return -1;
}
MSH_CMD_EXPORT(k230_mode, set k230 mode);

static int k230_query(void)
{
    return app_k230_send_cmd("CMD:QUERY_PERMISSION");
}
MSH_CMD_EXPORT(k230_query, query k230 current user permission);

static int k230_user_list(void)
{
    return app_k230_send_cmd("USER:LIST");
}
MSH_CMD_EXPORT(k230_user_list, list k230 users);

static int k230_user_del(int argc, char **argv)
{
    char cmd[80];

    if (argc != 2)
    {
        rt_kprintf("usage: k230_user_del <name>\n");
        return -1;
    }

    rt_snprintf(cmd, sizeof(cmd), "USER:DEL|%s", argv[1]);
    return app_k230_send_cmd(cmd);
}
MSH_CMD_EXPORT(k230_user_del, delete k230 authorized user);

static int k230_user_rename(int argc, char **argv)
{
    char cmd[96];

    if (argc != 3)
    {
        rt_kprintf("usage: k230_user_rename <old> <new>\n");
        return -1;
    }

    rt_snprintf(cmd, sizeof(cmd), "USER:RENAME|%s|%s", argv[1], argv[2]);
    return app_k230_send_cmd(cmd);
}
MSH_CMD_EXPORT(k230_user_rename, rename k230 authorized user);

static int k230_send(int argc, char **argv)
{
    char cmd[160];
    int i;

    if (argc < 2)
    {
        rt_kprintf("usage: k230_send <raw>\n");
        return -1;
    }

    cmd[0] = '\0';

    for (i = 1; i < argc; i++)
    {
        if (i > 1)
        {
            rt_snprintf(cmd + strlen(cmd), sizeof(cmd) - strlen(cmd), " ");
        }

        rt_snprintf(cmd + strlen(cmd), sizeof(cmd) - strlen(cmd), "%s", argv[i]);
    }

    return app_k230_send_cmd(cmd);
}
MSH_CMD_EXPORT(k230_send, send raw line to k230);


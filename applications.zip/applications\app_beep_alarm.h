#ifndef __APP_BEEP_ALARM_H__
#define __APP_BEEP_ALARM_H__

#include <rtthread.h>

#define APP_MEDICINE_PLAN_MAX_COUNT       6
#define APP_MEDICINE_PLAN_MAX_MEDICINES   6
#define APP_MEDICINE_USER_NAME_LEN        32
#define APP_MEDICINE_NAME_LEN             48
#define APP_MEDICINE_BOX_NAME_LEN         32

typedef struct
{
    int box_id;
    int dose_count;
    char name[APP_MEDICINE_NAME_LEN];
    char box_name[APP_MEDICINE_BOX_NAME_LEN];
} app_medicine_item_t;

typedef struct
{
    int plan_slot;
    int hour;
    int min;
    char user_name[APP_MEDICINE_USER_NAME_LEN];
    char user_phone[16];
    int medicine_count;
    app_medicine_item_t medicines[APP_MEDICINE_PLAN_MAX_MEDICINES];
    int earliest_hour;
    int earliest_min;
    int latest_hour;
    int latest_min;
} app_medicine_plan_t;

int app_beep_alarm_start(void);
void app_beep_alarm_set_time(int index, int hour, int min);
void app_beep_alarm_set_user(int index, const char *user_name);
void app_beep_alarm_disable(int index);
int app_beep_alarm_set_plan(const app_medicine_plan_t *plan);
int app_beep_alarm_get_plan(int plan_slot, app_medicine_plan_t *plan);
int app_beep_alarm_get_current_plan(app_medicine_plan_t *plan);
void app_beep_alarm_mark_taken(int plan_slot);
void app_beep_alarm_mark_response(int plan_slot);
rt_bool_t app_beep_alarm_is_taken(int plan_slot);

#endif

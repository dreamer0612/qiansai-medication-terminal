#include <rtthread.h>
#include <rtdevice.h>
#include <board.h>
#include <wlan_mgnt.h>

#include "app_time.h"
#include "app_sensor.h"
#include "app_lcd_show.h"
#include "app_beep_alarm.h"
#include "app_local_upload.h"
#include "app_body_temp.h"
#include "app_max30102.h"
#include "app_k230_auth.h"
#include "app_esp32_slave.h"
#include "app_esp32cam_ctrl.h"
#include "app_medicine_servo.h"
#include "app_v100c.h"

#define DBG_TAG "main"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>

#define APP_AUTO_THREAD_STACK_SIZE 1024

static void app_auto_entry(void *parameter)
{
    LOG_I("Smart medicine box demo start");

    app_esp32cam_ctrl_start();

    app_medicine_servo_start();

    rt_thread_mdelay(3000);

    app_sensor_start();

    rt_thread_mdelay(1000);

    app_lcd_show_start();

    app_k230_auth_start();

    rt_thread_mdelay(500);

    app_body_temp_start();

    rt_thread_mdelay(500);

    if (app_max30102_start() != 0)
    {
        LOG_E("MAX30102 start failed");
    }

    rt_thread_mdelay(500);

    app_esp32_slave_start();

    rt_thread_mdelay(1000);

    app_v100c_start();

    rt_thread_mdelay(500);

    LOG_I("wifi connecting...");
    rt_wlan_connect("YOUR_WIFI_SSID", "YOUR_WIFI_PASSWORD");

    while (rt_wlan_is_connected() != RT_TRUE)
    {
        rt_thread_mdelay(500);
    }

    LOG_I("wifi connected");

    rt_thread_mdelay(2000);

    app_time_auto_sync_start();

    rt_thread_mdelay(500);

    app_beep_alarm_start();

    rt_thread_mdelay(1000);

    app_local_upload_start();

    rt_thread_mdelay(500);

    app_k230_cloud_bridge_start();
}

int main(void)
{
    rt_thread_t tid;

    tid = rt_thread_create("app_auto",
                           app_auto_entry,
                           RT_NULL,
                           APP_AUTO_THREAD_STACK_SIZE,
                           20,
                           10);

    if (tid != RT_NULL)
    {
        rt_thread_startup(tid);
    }
    else
    {
        LOG_E("app_auto thread create failed");
    }

    return 0;
}

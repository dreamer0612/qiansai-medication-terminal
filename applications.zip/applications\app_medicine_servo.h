#ifndef APP_MEDICINE_SERVO_H
#define APP_MEDICINE_SERVO_H

int app_medicine_servo_start(void);
int app_medicine_servo_open(int box_id);
int app_medicine_servo_close(void);

#endif

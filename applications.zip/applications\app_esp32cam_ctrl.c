#include <rtthread.h>
#include <rtdevice.h>
#include <board.h>

#include "app_esp32cam_ctrl.h"

#define DBG_TAG "esp32cam.ctrl"
#define DBG_LVL DBG_INFO
#include <rtdbg.h>

#define ESP32CAM_CTRL_PIN GET_PIN(A, 8)

static rt_bool_t esp32cam_ctrl_started = RT_FALSE;
static rt_bool_t esp32cam_manual_enabled = RT_FALSE;
static rt_bool_t esp32cam_medicine_enabled = RT_FALSE;
static rt_bool_t esp32cam_output_enabled = RT_FALSE;
static rt_mutex_t esp32cam_ctrl_lock = RT_NULL;

static void esp32cam_ctrl_apply_locked(void)
{
    rt_bool_t enabled = (esp32cam_manual_enabled == RT_TRUE ||
                         esp32cam_medicine_enabled == RT_TRUE) ?
                        RT_TRUE : RT_FALSE;

    if (esp32cam_ctrl_started == RT_TRUE)
    {
        rt_pin_write(ESP32CAM_CTRL_PIN, enabled == RT_TRUE ? PIN_HIGH : PIN_LOW);
    }

    if (enabled != esp32cam_output_enabled)
    {
        esp32cam_output_enabled = enabled;
        LOG_I("ESP32-CAM PA8 output %s (manual=%d medicine=%d)",
              enabled == RT_TRUE ? "HIGH" : "LOW",
              esp32cam_manual_enabled,
              esp32cam_medicine_enabled);
    }
}

int app_esp32cam_ctrl_start(void)
{
    if (esp32cam_ctrl_lock == RT_NULL)
    {
        esp32cam_ctrl_lock = rt_mutex_create("cam_ctrl", RT_IPC_FLAG_FIFO);
        if (esp32cam_ctrl_lock == RT_NULL)
        {
            LOG_E("create cam ctrl mutex failed");
            return -1;
        }
    }

    rt_mutex_take(esp32cam_ctrl_lock, RT_WAITING_FOREVER);
    rt_pin_mode(ESP32CAM_CTRL_PIN, PIN_MODE_OUTPUT);
    esp32cam_ctrl_started = RT_TRUE;
    esp32cam_ctrl_apply_locked();
    rt_mutex_release(esp32cam_ctrl_lock);

    LOG_I("ESP32-CAM control pin ready: PA8, high=enable low=disable");
    return 0;
}

void app_esp32cam_ctrl_set_manual(rt_bool_t enabled)
{
    if (esp32cam_ctrl_lock != RT_NULL)
    {
        rt_mutex_take(esp32cam_ctrl_lock, RT_WAITING_FOREVER);
    }

    esp32cam_manual_enabled = enabled == RT_TRUE ? RT_TRUE : RT_FALSE;
    esp32cam_ctrl_apply_locked();

    if (esp32cam_ctrl_lock != RT_NULL)
    {
        rt_mutex_release(esp32cam_ctrl_lock);
    }
}

void app_esp32cam_ctrl_set_medicine(rt_bool_t enabled)
{
    if (esp32cam_ctrl_lock != RT_NULL)
    {
        rt_mutex_take(esp32cam_ctrl_lock, RT_WAITING_FOREVER);
    }

    esp32cam_medicine_enabled = enabled == RT_TRUE ? RT_TRUE : RT_FALSE;
    esp32cam_ctrl_apply_locked();

    if (esp32cam_ctrl_lock != RT_NULL)
    {
        rt_mutex_release(esp32cam_ctrl_lock);
    }
}

void app_esp32cam_ctrl_set(rt_bool_t enabled)
{
    app_esp32cam_ctrl_set_manual(enabled);
}

rt_bool_t app_esp32cam_ctrl_get(void)
{
    rt_bool_t enabled;

    if (esp32cam_ctrl_lock != RT_NULL)
    {
        rt_mutex_take(esp32cam_ctrl_lock, RT_WAITING_FOREVER);
    }

    enabled = esp32cam_output_enabled;

    if (esp32cam_ctrl_lock != RT_NULL)
    {
        rt_mutex_release(esp32cam_ctrl_lock);
    }

    return enabled;
}

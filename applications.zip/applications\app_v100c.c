#include <rtthread.h>
#include <rtdevice.h>
#include <string.h>
#include <stdio.h>

#include "app_v100c.h"
#include "app_ram.h"
#include "app_local_upload.h"

#define DBG_TAG "app.v100c"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>

#define V100C_UART_NAME          "uart4"
#define V100C_RX_THREAD_STACK    1024
#define V100C_RX_THREAD_PRIORITY 22
#define V100C_UART_RX_BUF_SIZE   1024
#define V100C_RX_LINE_SIZE       1024
#define V100C_SMS_TEXT_SIZE      192
#define V100C_SMS_HEX_SIZE       (V100C_SMS_TEXT_SIZE * 2 + 1)
#define V100C_CMD_SIZE           512

static rt_device_t v100c_uart = RT_NULL;
static struct rt_semaphore v100c_rx_sem;
static struct rt_mutex v100c_tx_lock;
static rt_bool_t v100c_started = RT_FALSE;
static struct rt_thread v100c_rx_thread;
ALIGN(RT_ALIGN_SIZE)
static rt_uint8_t v100c_rx_stack[V100C_RX_THREAD_STACK] APP_CCMRAM;
static char v100c_rx_line[V100C_RX_LINE_SIZE];

static rt_err_t v100c_rx_ind(rt_device_t dev, rt_size_t size)
{
    RT_UNUSED(dev);
    RT_UNUSED(size);
    rt_sem_release(&v100c_rx_sem);
    return RT_EOK;
}

static void v100c_rx_entry(void *parameter)
{
    char ch;
    char *line = v100c_rx_line;
    int pos = 0;
    rt_bool_t line_overflow = RT_FALSE;

    RT_UNUSED(parameter);

    while (1)
    {
        while (rt_device_read(v100c_uart, 0, &ch, 1) == 1)
        {
            if (ch == '\r')
            {
                continue;
            }
            if (ch == '\n')
            {
                if (line_overflow == RT_TRUE)
                {
                    LOG_W("rx line overflow, dropped");
                    line_overflow = RT_FALSE;
                    pos = 0;
                }
                else if (pos > 0)
                {
                    line[pos] = '\0';
                    LOG_I("rx: %s", line);
                    pos = 0;
                }
                continue;
            }
            if (line_overflow == RT_TRUE)
            {
                continue;
            }
            if (pos < V100C_RX_LINE_SIZE - 1)
            {
                line[pos++] = ch;
            }
            else
            {
                line[pos] = '\0';
                LOG_W("rx line too long, drop prefix: %s", line);
                pos = 0;
                line_overflow = RT_TRUE;
            }
        }

        rt_sem_take(&v100c_rx_sem, RT_WAITING_FOREVER);
    }
}

static void v100c_bytes_to_hex(const char *src, char *hex, rt_size_t hex_size)
{
    static const char table[] = "0123456789ABCDEF";
    const unsigned char *p = (const unsigned char *)src;
    rt_size_t out = 0;

    if (hex_size == 0)
    {
        return;
    }

    while (*p != '\0' && out + 2 < hex_size)
    {
        hex[out++] = table[(*p >> 4) & 0x0F];
        hex[out++] = table[*p & 0x0F];
        p++;
    }
    hex[out] = '\0';
}

static void v100c_append_literal_hex(char *hex,
                                     rt_size_t hex_size,
                                     const char *literal)
{
    rt_size_t len;
    rt_size_t add_len;

    if (hex == RT_NULL || literal == RT_NULL || hex_size == 0)
    {
        return;
    }

    len = strlen(hex);
    add_len = strlen(literal);
    if (len + add_len >= hex_size)
    {
        return;
    }

    memcpy(hex + len, literal, add_len + 1);
}

static void v100c_append_text_hex(char *hex,
                                  rt_size_t hex_size,
                                  const char *text)
{
    static const char table[] = "0123456789ABCDEF";
    const unsigned char *p = (const unsigned char *)text;
    rt_size_t out;

    if (hex == RT_NULL || text == RT_NULL || hex_size == 0)
    {
        return;
    }

    out = strlen(hex);
    while (*p != '\0' && out + 2 < hex_size)
    {
        hex[out++] = table[(*p >> 4) & 0x0F];
        hex[out++] = table[*p & 0x0F];
        p++;
    }
    hex[out] = '\0';
}

static int v100c_write_cmd(const char *cmd)
{
    rt_size_t len;
    rt_size_t written;

    if (cmd == RT_NULL)
    {
        return -RT_EINVAL;
    }
    if (v100c_started != RT_TRUE && app_v100c_start() != 0)
    {
        return -RT_ERROR;
    }

    len = strlen(cmd);
    rt_mutex_take(&v100c_tx_lock, RT_WAITING_FOREVER);
    written = rt_device_write(v100c_uart, 0, cmd, len);
    rt_mutex_release(&v100c_tx_lock);

    if (written != len)
    {
        LOG_E("write failed %d/%d", (int)written, (int)len);
        return -RT_ERROR;
    }

    LOG_I("tx: %s", cmd);
    return 0;
}

static int app_v100c_send_sms_hex(const char *phone, const char *content_hex)
{
    char cmd[V100C_CMD_SIZE];

    if (phone == RT_NULL || phone[0] == '\0' ||
        content_hex == RT_NULL || content_hex[0] == '\0')
    {
        return -RT_EINVAL;
    }

    rt_snprintf(cmd,
                sizeof(cmd),
                "{\"cmd\":\"sms\",\"phone\":\"%s\",\"content_hex\":\"%s\"}\r\n",
                phone,
                content_hex);
    return v100c_write_cmd(cmd);
}

int app_v100c_start(void)
{
    struct serial_configure config = RT_SERIAL_CONFIG_DEFAULT;

    if (v100c_started == RT_TRUE)
    {
        return 0;
    }

    v100c_uart = rt_device_find(V100C_UART_NAME);
    if (v100c_uart == RT_NULL)
    {
        LOG_E("%s not found", V100C_UART_NAME);
        return -RT_ERROR;
    }

    config.baud_rate = BAUD_RATE_115200;
    config.data_bits = DATA_BITS_8;
    config.stop_bits = STOP_BITS_1;
    config.parity = PARITY_NONE;
    config.bufsz = V100C_UART_RX_BUF_SIZE;
    rt_device_control(v100c_uart, RT_DEVICE_CTRL_CONFIG, &config);
    rt_sem_init(&v100c_rx_sem, "v100c_rx", 0, RT_IPC_FLAG_FIFO);
    rt_mutex_init(&v100c_tx_lock, "v100c_tx", RT_IPC_FLAG_FIFO);
    rt_device_set_rx_indicate(v100c_uart, v100c_rx_ind);

    if (rt_device_open(v100c_uart, RT_DEVICE_FLAG_INT_RX) != RT_EOK)
    {
        LOG_E("%s open failed", V100C_UART_NAME);
        return -RT_ERROR;
    }

    if (rt_thread_init(&v100c_rx_thread,
                       "v100c_rx",
                       v100c_rx_entry,
                       RT_NULL,
                       v100c_rx_stack,
                       sizeof(v100c_rx_stack),
                       V100C_RX_THREAD_PRIORITY,
                       10) != RT_EOK)
    {
        LOG_E("rx thread init failed");
        return -RT_ERROR;
    }
    rt_thread_startup(&v100c_rx_thread);

    v100c_started = RT_TRUE;
    LOG_I("started on %s, 115200 8N1", V100C_UART_NAME);
    return 0;
}

int app_v100c_send_sms(const char *phone, const char *content_utf8)
{
    char hex[V100C_SMS_HEX_SIZE];

    if (phone == RT_NULL || phone[0] == '\0' ||
        content_utf8 == RT_NULL || content_utf8[0] == '\0')
    {
        return -RT_EINVAL;
    }

    v100c_bytes_to_hex(content_utf8, hex, sizeof(hex));
    return app_v100c_send_sms_hex(phone, hex);
}

int app_v100c_call(const char *phone)
{
    char cmd[96];

    if (phone == RT_NULL || phone[0] == '\0')
    {
        return -RT_EINVAL;
    }

    rt_snprintf(cmd,
                sizeof(cmd),
                "{\"cmd\":\"call\",\"phone\":\"%s\"}\r\n",
                phone);
    return v100c_write_cmd(cmd);
}

int app_v100c_hangup(void)
{
    return v100c_write_cmd("{\"cmd\":\"hangup\"}\r\n");
}

int app_v100c_notify_low_stock(const app_medicine_plan_t *plan,
                               int box_id,
                               int stock_count)
{
    app_medicine_box_state_t box_state;
    const char *medicine_name = RT_NULL;
    char content_hex[V100C_SMS_HEX_SIZE];
    char num_buf[12];
    int low_threshold = APP_V100C_LOW_STOCK_THRESHOLD;
    int i;

    if (plan == RT_NULL || box_id <= 0)
    {
        return -RT_EINVAL;
    }

    if (app_local_upload_get_box_state(box_id, &box_state) == 0)
    {
        if (box_state.low_threshold > 0)
        {
            low_threshold = box_state.low_threshold;
        }
        if (box_state.name[0] != '\0')
        {
            medicine_name = box_state.name;
        }
    }

    if (stock_count > low_threshold)
    {
        LOG_I("stock ok box=%d stock=%d threshold=%d",
              box_id,
              stock_count,
              low_threshold);
        return 0;
    }
    if (plan->user_phone[0] == '\0')
    {
        LOG_W("low stock but user phone is empty");
        return -RT_EINVAL;
    }

    for (i = 0; i < plan->medicine_count; i++)
    {
        if (medicine_name == RT_NULL &&
            plan->medicines[i].box_id == box_id &&
            plan->medicines[i].name[0] != '\0')
        {
            medicine_name = plan->medicines[i].name;
            break;
        }
    }
    if (medicine_name == RT_NULL)
    {
        medicine_name = "unknown";
    }

    content_hex[0] = '\0';
    v100c_append_literal_hex(content_hex, sizeof(content_hex), "E7ACAC");
    rt_snprintf(num_buf, sizeof(num_buf), "%d", box_id);
    v100c_append_text_hex(content_hex, sizeof(content_hex), num_buf);
    v100c_append_literal_hex(content_hex,
                             sizeof(content_hex),
                             "E4B8AAE88DAFE4BB93E79A84");
    v100c_append_text_hex(content_hex, sizeof(content_hex), medicine_name);
    v100c_append_literal_hex(content_hex, sizeof(content_hex), "E8BF98E589A9");
    rt_snprintf(num_buf, sizeof(num_buf), "%d", stock_count);
    v100c_append_text_hex(content_hex, sizeof(content_hex), num_buf);
    v100c_append_literal_hex(content_hex,
                             sizeof(content_hex),
                             "E9A297EFBC8CE8AFB7E8BF9BE8A18CE8A1A5E88DAF");

    LOG_I("low stock notify phone=%s box=%d stock=%d threshold=%d",
          plan->user_phone,
          box_id,
          stock_count,
          low_threshold);
    return app_v100c_send_sms_hex(plan->user_phone, content_hex);
}

#ifdef FINSH_USING_MSH
static void v100c_sms(int argc, char **argv)
{
    if (argc < 3)
    {
        rt_kprintf("usage: v100c_sms <phone> <content>\n");
        return;
    }
    rt_kprintf("v100c_sms ret=%d\n", app_v100c_send_sms(argv[1], argv[2]));
}
MSH_CMD_EXPORT(v100c_sms, send sms by V100C);

static void v100c_call(int argc, char **argv)
{
    if (argc < 2)
    {
        rt_kprintf("usage: v100c_call <phone>\n");
        return;
    }
    rt_kprintf("v100c_call ret=%d\n", app_v100c_call(argv[1]));
}
MSH_CMD_EXPORT(v100c_call, dial by V100C);

static void v100c_hangup(void)
{
    rt_kprintf("v100c_hangup ret=%d\n", app_v100c_hangup());
}
MSH_CMD_EXPORT(v100c_hangup, hangup V100C call);
#endif

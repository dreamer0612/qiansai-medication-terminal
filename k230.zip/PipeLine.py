import os
import ujson
from media.sensor import *
from media.display import *
from media.media import *
from libs.Utils import ScopedTiming
import nncase_runtime as nn
import ulab.numpy as np
import image
import gc
import sys
import time

# PipeLine类
class PipeLine:
    def __init__(self,rgb888p_size=[224,224],display_mode="hdmi",display_size=None,osd_layer_num=1,debug_mode=0):
        # sensor给AI的图像分辨率
        self.rgb888p_size=[ALIGN_UP(rgb888p_size[0],16),rgb888p_size[1]]
        # 视频输出VO图像分辨率
        if display_size is None:
            self.display_size=None
        else:
            self.display_size=[display_size[0],display_size[1]]
        # 视频显示模式
        self.display_mode=display_mode
        # sensor对象
        self.sensor=None
        # osd显示Image对象
        self.osd_img=None
        # 【新增】纯黑色背景图对象，用于覆盖视频层和OSD层
        self.black_img = None
        self.cur_frame=None
        self.debug_mode=debug_mode
        self.osd_layer_num = osd_layer_num
        # 显示状态标记
        self.is_display_enabled = False
        # 保存Sensor与显示层的绑定信息
        self.sensor_bind_info = None

    # PipeLine初始化函数
    def create(self,sensor=None,hmirror=None,vflip=None,fps=60):
        with ScopedTiming("init PipeLine",self.debug_mode > 0):
            nn.shrink_memory_pool()
            # 初始化并配置sensor
            brd=os.uname()[-1]
            if brd=="k230d_canmv_bpi_zero":
                self.sensor = Sensor(fps=30) if sensor is None else sensor
            elif brd=="k230_canmv_lckfb":
                self.sensor = Sensor(fps=30) if sensor is None else sensor
            elif brd=="k230d_canmv_atk_dnk230d":
                self.sensor = Sensor(fps=30) if sensor is None else sensor
            else:
                self.sensor = Sensor(fps=fps) if sensor is None else sensor
            self.sensor.reset()
            if hmirror is not None and (hmirror==True or hmirror==False):
                self.sensor.set_hmirror(hmirror)
            if vflip is not None and (vflip==True or vflip==False):
                self.sensor.set_vflip(vflip)
                
            # 初始化显示（仅在create时执行一次）
            if self.display_mode=="hdmi":
                if self.display_size==None:
                    Display.init(Display.LT9611,osd_num=self.osd_layer_num, to_ide = True)
                else:
                    Display.init(Display.LT9611, width=self.display_size[0], height=self.display_size[1],osd_num=self.osd_layer_num, to_ide = True)
            elif self.display_mode=="lcd":
                if self.display_size==None:
                    Display.init(Display.ST7701, osd_num=self.osd_layer_num, to_ide=True)
                else:
                    Display.init(Display.ST7701, width=self.display_size[0], height=self.display_size[1], osd_num=self.osd_layer_num, to_ide=True)
            elif self.display_mode=="lt9611":
                if self.display_size==None:
                    Display.init(Display.LT9611,osd_num=self.osd_layer_num, to_ide = True)
                else:
                    Display.init(Display.LT9611, width=self.display_size[0], height=self.display_size[1],osd_num=self.osd_layer_num, to_ide = True)
            elif self.display_mode=="st7701":
                if self.display_size==None:
                    Display.init(Display.ST7701, osd_num=self.osd_layer_num, to_ide=True)
                else:
                    Display.init(Display.ST7701, width=self.display_size[0], height=self.display_size[1], osd_num=self.osd_layer_num, to_ide=True)
            elif self.display_mode=="hx8399":
                if self.display_size==None:
                    Display.init(Display.HX8399, osd_num=self.osd_layer_num, to_ide=True)
                else:
                    Display.init(Display.HX8399, width=self.display_size[0], height=self.display_size[1], osd_num=self.osd_layer_num, to_ide=True)
            else:
                Display.init(Display.LT9611,osd_num=self.osd_layer_num, to_ide = True)
            self.display_size=[Display.width(),Display.height()]
                
            # 配置Sensor通道（通道0给显示，通道2给AI，全程保持）
            self.sensor.set_framesize(w = self.display_size[0], h = self.display_size[1])
            self.sensor.set_pixformat(PIXEL_FORMAT_YUV_SEMIPLANAR_420)
            self.sensor.set_framesize(w = self.rgb888p_size[0], h = self.rgb888p_size[1], chn=CAM_CHN_ID_2)
            self.sensor.set_pixformat(PIXEL_FORMAT_RGB_888_PLANAR, chn=CAM_CHN_ID_2)

            # OSD图像初始化
            self.osd_img = image.Image(self.display_size[0], self.display_size[1], image.ARGB8888)
            
            # 【新增】预创建纯黑色背景图（ARGB8888格式，不透明黑色）
            self.black_img = image.Image(self.display_size[0], self.display_size[1], image.ARGB8888)
            self.black_img.draw_rectangle(0, 0, self.display_size[0], self.display_size[1], color=(0, 0, 0), fill=True)

            # 保存绑定信息
            self.sensor_bind_info = self.sensor.bind_info(x = 0, y = 0, chn = CAM_CHN_ID_0)
            Display.bind_layer(**self.sensor_bind_info, layer = Display.LAYER_VIDEO1)

            # Media初始化
            MediaManager.init()
            # 启动Sensor
            self.sensor.run()
            # 初始标记显示为启用
            self.is_display_enabled = True

    # 获取一帧AI图像数据
    def get_frame(self):
        with ScopedTiming("get a frame",self.debug_mode > 0):
            self.cur_frame = self.sensor.snapshot(chn=CAM_CHN_ID_2)
            input_np=self.cur_frame.to_numpy_ref()
            return input_np

    # 在屏幕上显示osd_img
    def show_image(self):
        if not self.is_display_enabled:
            return
        with ScopedTiming("show result",self.debug_mode > 0):    
            Display.show_image(self.osd_img, 0, 0, Display.LAYER_OSD3)

    def enable_display(self):
        """
        启用显示输出
        """
        with ScopedTiming("enable display", self.debug_mode > 0):
            if self.is_display_enabled:
                return
            
            if self.sensor is None or self.sensor_bind_info is None:
                raise RuntimeError("PipeLine未初始化，请先调用create()")
            
            # 重新绑定Sensor通道0到视频层
            Display.bind_layer(**self.sensor_bind_info, layer = Display.LAYER_VIDEO1)
            
            # 更新状态
            self.is_display_enabled = True

    def disable_display(self):
        """
        禁用显示输出（解绑视频层 + 黑色覆盖视频层 + 黑色覆盖OSD层）
        """
        with ScopedTiming("disable display", self.debug_mode > 0):
            if not self.is_display_enabled:
                return
            
            # 1. 先解绑视频层，切断Sensor数据流
            Display.unbind_layer(layer=Display.LAYER_VIDEO1)
            
            # 2. 【新增】用黑色背景图覆盖视频图层（LAYER_VIDEO1）
            Display.show_image(self.black_img, 0, 0, Display.LAYER_VIDEO1)
            
            # 3. 用黑色背景图覆盖OSD图层（LAYER_OSD3）
            Display.show_image(self.black_img, 0, 0, Display.LAYER_OSD3)
            
            # 4. 更新状态
            self.is_display_enabled = False

    def get_display_size(self):
        return self.display_size

    # PipeLine销毁函数
    def destroy(self):
        with ScopedTiming("deinit PipeLine",self.debug_mode > 0):
            os.exitpoint(os.EXITPOINT_ENABLE_SLEEP)
            self.sensor.reset()
            self.sensor.stop()
            Display.deinit()
            time.sleep_ms(50)
            MediaManager.deinit()
            self.is_display_enabled = False

#注意！draw_string_advanced参数是（A，R，G，B）
from libs.PipeLine import PipeLine
from libs.AIBase import AIBase
from libs.AI2D import Ai2d
from libs.Utils import *
import os, gc, math, time
from media.media import *
import nncase_runtime as nn
import ulab.numpy as np
import aidemo

try:
    from machine import FPIOA, Pin, UART
except Exception:
    FPIOA = None
    Pin = None
    UART = None


# ---------------------------------------------------------------------------
# 全局模式状态机：串口协议指令（常量，便于与上位机约定后统一修改）
# ---------------------------------------------------------------------------
UART2_TX_PIN = 11
UART2_RX_PIN = 12
UART2_BAUDRATE = 115200
UART1_TX_PIN = 3
UART1_RX_PIN = 4
UART1_BAUDRATE = 115200

# 指令行结束符：仅用于在接收缓冲中切分完整帧；参与比较的指令内容不含此序列
CMD_PROTOCOL_LINE_END = b"\r\n"
HMI_CMD_END = b"\xff\xff\xff"
HMI_TEXT_ENCODING = "utf-8"
HMI_NORMAL_COLOR = 2016
HMI_LOW_COLOR = 64512
HMI_WARN_COLOR = 63488
HMI_PAGE_REFRESH_DELAY_MS = 120
HMI_BOOT_REFRESH_DELAY_MS = 500
HMI_BOOT_REFRESH_INTERVAL_MS = 1000
HMI_BOOT_REFRESH_COUNT = 3
BOX_DATA_DIR = "/sdcard/box_data"
BOX_DATA_FILE = BOX_DATA_DIR + "/box_data.txt"
BOX_DEFAULT_CAPACITY = 20

# 指令载荷（不含结束符）；上位机发送 = 载荷 + CMD_PROTOCOL_LINE_END
CMD_SET_NORMAL_MODE = b"MODE:NORMAL"
CMD_SET_SAVE_POWER_MODE = b"MODE:SAVEPWR"
CMD_SET_EDIT_MODE = b"MODE:EDIT"
CMD_MED_STOCK_PREFIX = b"MED:STOCK|"
CMD_HMI_OPEN_LID_PREFIX = b"REQ,OPEN_LID,"

STATE_NORMAL_MODE = "normal_mode"
STATE_SAVE_POWER_MODE = "save_power_mode"
STATE_EDIT_MODE = "edit_mode"

# # 板子回传测试（串口测试用，取消注释后需同步取消 __main__ 内串口测试段）
#UART_TX_BOOT_OK = b"SM:READY" + CMD_PROTOCOL_LINE_END
# UART_TX_STATE_NORMAL = b"STATE:NORMAL_MODE" + CMD_PROTOCOL_LINE_END
# UART_TX_STATE_SAVEPOWER = b"STATE:SAVE_POWER_MODE" + CMD_PROTOCOL_LINE_END
# UART_TX_STATE_EDIT = b"STATE:EDIT_MODE" + CMD_PROTOCOL_LINE_END

_UART2_RX_BUFFER_MAX = 256

# 密码持久化（与 uart2.py 一致）：进入编辑模式前串口校验用
PASSWORD_FILE = "/sdcard/password/uart_password.txt"
DEFAULT_PASSWORD = "CHANGE_ME"


def load_password():
    try:
        with open(PASSWORD_FILE, "r") as f:
            p = f.read().strip()
            if p:
                return p
    except OSError:
        pass
    return DEFAULT_PASSWORD


def uart2_init_for_state_machine():
    """按 UART2 测试脚本方式初始化 UART2；失败时返回 None（不抛异常）。"""
    if UART is None or FPIOA is None:
        return None
    try:
        fpioa = FPIOA()
        fpioa.set_function(UART2_TX_PIN, fpioa.UART2_TXD)
        fpioa.set_function(UART2_RX_PIN, fpioa.UART2_RXD)
        u = UART(
            UART.UART2,
            baudrate=UART2_BAUDRATE,
            bits=UART.EIGHTBITS,
            parity=UART.PARITY_NONE,
            stop=UART.STOPBITS_ONE,
        )
        return u
    except Exception:
        return None


def uart1_init_for_hmi():
    """初始化 UART1 连接淘晶驰 USART HMI 屏；失败时返回 None。"""
    if UART is None or FPIOA is None:
        return None
    try:
        fpioa = FPIOA()
        fpioa.set_function(UART1_TX_PIN, fpioa.UART1_TXD)
        fpioa.set_function(UART1_RX_PIN, fpioa.UART1_RXD)
        u = UART(
            UART.UART1,
            baudrate=UART1_BAUDRATE,
            bits=UART.EIGHTBITS,
            parity=UART.PARITY_NONE,
            stop=UART.STOPBITS_ONE,
        )
        return u
    except Exception:
        return None


CMD_EDIT_CANCEL = b"EDIT:CANCEL" #此命令未启用
CMD_USER_LIST = b"USER:LIST"
CMD_USER_REGISTER_PREFIX = b"USER:REGISTER|"
CMD_USER_DEL_PREFIX = b"USER:DEL|"
CMD_USER_RENAME_PREFIX = b"USER:RENAME|"
CMD_QUERY_PERMISSION = b"CMD:QUERY_PERMISSION"


class MedicineBoxHMI:
    """UART1 串口屏适配：读取药仓文件，并按 HMI 协议刷新 main/box1~box6。"""

    def __init__(self):
        self.uart = uart1_init_for_hmi()
        self._rx_buf = bytearray()
        self.current_page = "main"
        self.current_box = 0
        self._pending_refresh = None
        self._boot_refresh_remaining = HMI_BOOT_REFRESH_COUNT
        self._next_boot_refresh_ms = self._ticks_ms() + HMI_BOOT_REFRESH_DELAY_MS
        self._pending_emergency = []
        self._ensure_data_file()

    def pop_emergency_command(self):
        if not self._pending_emergency:
            return None
        item = self._pending_emergency[0]
        self._pending_emergency = self._pending_emergency[1:]
        return item

    def _ensure_data_file(self):
        try:
            os.listdir(BOX_DATA_DIR)
        except Exception:
            try:
                os.mkdir(BOX_DATA_DIR)
            except Exception:
                pass
        need_header = False
        try:
            with open(BOX_DATA_FILE, "r") as f:
                need_header = not bool(f.read(1))
        except Exception:
            need_header = True
        if need_header:
            try:
                with open(BOX_DATA_FILE, "w") as f:
                    f.write("# box_id|name|qty|updated_at\n")
            except Exception as e:
                print("[HMI] create box data failed:", e)

    def _now_text(self):
        try:
            t = time.localtime()
            return "{:04d}-{:02d}-{:02d} {:02d}:{:02d}:{:02d}".format(t[0], t[1], t[2], t[3], t[4], t[5])
        except Exception:
            try:
                return str(time.ticks_ms())
            except Exception:
                return "unknown"

    def _decode_line_text(self, data):
        if isinstance(data, str):
            return data
        for enc in ("utf-8", "gb2312", "gbk"):
            try:
                return data.decode(enc)
            except Exception:
                pass
        return ""

    def _hmi_encode(self, text):
        if not isinstance(text, str):
            text = str(text)
        try:
            return text.encode(HMI_TEXT_ENCODING)
        except Exception:
            return text.encode("utf-8", "replace")

    def _escape_hmi_text(self, text):
        if not isinstance(text, str):
            text = str(text)
        return text.replace('"', "'").replace("\r", " ").replace("\n", " ")

    def _sanitize_file_text(self, text):
        text = self._escape_hmi_text(text)
        return text.replace("|", " ").replace("\t", " ")

    def _send_cmd(self, cmd):
        if self.uart is None:
            return
        try:
            self.uart.write(self._hmi_encode(cmd) + HMI_CMD_END)
        except Exception as e:
            print("[HMI] send failed:", e)

    def _ticks_ms(self):
        try:
            return time.ticks_ms()
        except Exception:
            return int(time.time() * 1000)

    def _ticks_due(self, due_ms):
        now = self._ticks_ms()
        try:
            return time.ticks_diff(now, due_ms) >= 0
        except Exception:
            return now >= due_ms

    def _schedule_refresh(self, page, box_id=0):
        self.current_page = page
        self.current_box = box_id
        due_ms = self._ticks_ms() + HMI_PAGE_REFRESH_DELAY_MS
        self._pending_refresh = (page, box_id, due_ms)

    def _process_pending_refresh(self):
        if self._pending_refresh is None:
            return
        page, box_id, due_ms = self._pending_refresh
        if not self._ticks_due(due_ms):
            return
        self._pending_refresh = None
        if page == "box" and 1 <= box_id <= 6:
            self.refresh_box(box_id)
        else:
            self.refresh_main()

    def _process_boot_refresh(self):
        if self._boot_refresh_remaining <= 0:
            return
        if not self._ticks_due(self._next_boot_refresh_ms):
            return
        self._boot_refresh_remaining -= 1
        self._send_cmd("page main")
        self._schedule_refresh("main", 0)
        self._next_boot_refresh_ms = self._ticks_ms() + HMI_BOOT_REFRESH_INTERVAL_MS

    def _set_text(self, target, text):
        self._send_cmd(target + '.txt="' + self._escape_hmi_text(text) + '"')

    def _ref(self, target):
        self._send_cmd("ref " + target)

    def _set_val(self, target, value):
        try:
            value = int(value)
        except Exception:
            value = 0
        self._send_cmd(target + ".val=" + str(value))
        self._ref(target)

    def _set_pco(self, target, color):
        try:
            color = int(color)
        except Exception:
            color = 0
        self._send_cmd(target + ".pco=" + str(color))

    def _status_for_qty(self, qty):
        if qty > 10:
            return "正常", HMI_NORMAL_COLOR
        if qty < 5:
            return "不足", HMI_WARN_COLOR
        return "偏低", HMI_LOW_COLOR

    def _progress_for_qty(self, qty, capacity):
        try:
            qty = int(qty)
        except Exception:
            qty = 0
        try:
            capacity = int(capacity)
        except Exception:
            capacity = BOX_DEFAULT_CAPACITY
        if capacity <= 0:
            capacity = BOX_DEFAULT_CAPACITY
        if qty < 0:
            qty = 0
        if qty > capacity:
            qty = capacity
        percent = qty * 100 // capacity
        if percent < 0:
            return 0
        if percent > 100:
            return 100
        return percent

    def _default_item(self, box_id):
        return {
            "id": box_id,
            "name": "--",
            "qty": 0,
            "updated_at": "未更新",
        }

    def read_box_data(self):
        self._ensure_data_file()
        data = {}
        try:
            with open(BOX_DATA_FILE, "r") as f:
                for raw_line in f:
                    line = raw_line.strip()
                    if not line or line.startswith("#"):
                        continue
                    parts = line.split("|")
                    if len(parts) < 4:
                        continue
                    try:
                        box_id = int(parts[0])
                    except Exception:
                        continue
                    if box_id < 1 or box_id > 6:
                        continue
                    try:
                        qty = int(parts[2])
                    except Exception:
                        qty = 0
                    updated_at = parts[6] if len(parts) > 6 else parts[3]
                    data[box_id] = {
                        "id": box_id,
                        "name": parts[1],
                        "qty": qty,
                        "updated_at": updated_at,
                    }
        except Exception as e:
            print("[HMI] read box data failed:", e)
        return data

    def write_box_data(self, data):
        self._ensure_data_file()
        try:
            with open(BOX_DATA_FILE, "w") as f:
                f.write("# box_id|name|qty|updated_at\n")
                for box_id in range(1, 7):
                    item = data.get(box_id, None)
                    if item is None:
                        continue
                    name = self._sanitize_file_text(item.get("name", "--"))
                    try:
                        qty = int(item.get("qty", 0))
                    except Exception:
                        qty = 0
                    updated_at = self._sanitize_file_text(item.get("updated_at", ""))
                    f.write("{}|{}|{}|{}\n".format(box_id, name, qty, updated_at))
        except Exception as e:
            print("[HMI] write box data failed:", e)

    def update_stock_from_main(self, line):
        parts = line[len(CMD_MED_STOCK_PREFIX):].split(b"|")
        if len(parts) != 3:
            print("[HMI] bad MED:STOCK:", line)
            return False
        try:
            box_id = int(self._decode_line_text(parts[0]).strip())
        except Exception:
            print("[HMI] bad stock box id")
            return False
        if box_id < 1 or box_id > 6:
            print("[HMI] stock box id out of range:", box_id)
            return False
        name = self._decode_line_text(parts[1]).strip()
        if not name:
            name = "--"
        try:
            qty = int(self._decode_line_text(parts[2]).strip())
        except Exception:
            print("[HMI] bad stock qty")
            return False
        if qty < 0:
            qty = 0

        data = self.read_box_data()
        data[box_id] = {
            "id": box_id,
            "name": name,
            "qty": qty,
            "updated_at": self._now_text(),
        }
        self.write_box_data(data)
        print("[HMI] stock saved:", box_id, name, qty)
        return True

    def refresh_main(self):
        self.current_page = "main"
        self.current_box = 0
        data = self.read_box_data()
        latest = "未更新"
        for box_id in range(1, 7):
            item = data.get(box_id, self._default_item(box_id))
            name_idx = (box_id - 1) * 2
            qty_idx = name_idx + 1
            status, color = self._status_for_qty(item["qty"])
            qty_text = "剩余 " + str(item["qty"])
            self._set_text("t{}".format(name_idx), item["name"])
            self._set_text("t{}".format(qty_idx), qty_text)
            self._set_pco("t{}".format(qty_idx), color)
            if item.get("updated_at"):
                latest = item["updated_at"]
        self._set_text("t12", "更新时间")
        self._set_text("g0", latest)

    def refresh_box(self, box_id):
        if box_id < 1 or box_id > 6:
            return
        self.current_page = "box"
        self.current_box = box_id
        data = self.read_box_data()
        item = data.get(box_id, self._default_item(box_id))
        status, color = self._status_for_qty(item["qty"])
        progress = self._progress_for_qty(item["qty"], BOX_DEFAULT_CAPACITY)
        self._set_text("t0", item["name"])
        self._set_text("t2", str(item["qty"]))
        self._set_text("t1", status)
        self._set_pco("t1", color)
        self._set_val("j0", progress)

    def refresh_current_page(self):
        if self.current_page == "box" and 1 <= self.current_box <= 6:
            self.refresh_box(self.current_box)
        elif self.current_page == "main":
            self.refresh_main()

    def handle_emergency_call(self, line):
        print("[HMI] emergency call:", line)
        prev_page = self.current_page
        prev_box = self.current_box
        if self.current_page == "main":
            self._set_text("g0", "紧急呼叫中")
        self.current_page = "open"
        self.current_box = 0
        self._pending_refresh = None
        self._pending_emergency.append(("phone_call", 0))
        parts = line.split(b",")
        if len(parts) >= 3 and parts[1] == b"BIN":
            try:
                box_id = int(parts[2].decode("ascii"))
            except Exception:
                box_id = 0
            if 1 <= box_id <= 6:
                if prev_page == "box" and prev_box == box_id:
                    self._set_text("t1", "呼叫中")
                    self._set_pco("t1", HMI_LOW_COLOR)

    def handle_open_lid_request(self, payload):
        try:
            box_id = int(payload[len(CMD_HMI_OPEN_LID_PREFIX):].decode("ascii"))
        except Exception:
            print("[HMI] bad REQ,OPEN_LID:", payload)
            return
        if box_id < 1 or box_id > 6:
            print("[HMI] open lid box id out of range:", box_id)
            return
        self.current_page = "open"
        self.current_box = box_id
        self._pending_refresh = None
        self._pending_emergency.append(("open_lid", box_id))

    def _normalize_hmi_payload(self, payload):
        idx = payload.rfind(HMI_CMD_END)
        if idx >= 0:
            payload = payload[idx + len(HMI_CMD_END):]
        for prefix in (b"REQ,MAIN", b"REQ,BIN,", CMD_HMI_OPEN_LID_PREFIX, b"EMG_CALL", b"SET,BIN,"):
            idx = payload.find(prefix)
            if idx >= 0:
                return payload[idx:]
        return payload

    def handle_line(self, payload):
        payload = self._normalize_hmi_payload(payload)
        self._boot_refresh_remaining = 0
        if payload == b"REQ,MAIN":
            self._schedule_refresh("main", 0)
            return
        if payload.startswith(b"REQ,BIN,"):
            try:
                box_id = int(payload[len(b"REQ,BIN,"):].decode("ascii"))
            except Exception:
                print("[HMI] bad REQ,BIN:", payload)
                return
            if box_id < 1 or box_id > 6:
                print("[HMI] REQ,BIN out of range:", box_id)
                return
            self._schedule_refresh("box", box_id)
            return
        if payload.startswith(CMD_HMI_OPEN_LID_PREFIX):
            self.handle_open_lid_request(payload)
            return
        if payload.startswith(b"EMG_CALL"):
            self.handle_emergency_call(payload)
            return
        if payload.startswith(b"SET,BIN,"):
            print("[HMI] ignore SET command:", payload)
            return
        print("[HMI] unknown command:", payload)

    def poll(self):
        self._process_boot_refresh()
        self._process_pending_refresh()
        if self.uart is None:
            return
        if not self.uart.any():
            return
        chunk = self.uart.read()
        if not chunk:
            return
        self._rx_buf.extend(chunk)
        if len(self._rx_buf) > _UART2_RX_BUFFER_MAX:
            self._rx_buf = bytearray(self._rx_buf[-(_UART2_RX_BUFFER_MAX // 2):])
        end = CMD_PROTOCOL_LINE_END
        end_len = len(end)
        while True:
            idx = self._rx_buf.find(end)
            if idx < 0:
                break
            payload = bytes(self._rx_buf[:idx]).strip(b"\x00 \t\r\n")
            self._rx_buf = bytearray(self._rx_buf[idx + end_len:])
            self.handle_line(payload)


class GlobalModeStateMachine:
    """全局状态：模式切换、编辑模式密码校验、编辑模式下 USER 串口指令。"""

    def __init__(self, face_app=None, hmi_app=None):
        self.state = STATE_SAVE_POWER_MODE
        self.uart = uart2_init_for_state_machine()
        self._rx_buf = bytearray()
        self._edit_auth_pending = False
        self.face_app = face_app
        self.hmi_app = hmi_app
        self.last_recognized_name = "unknown"
        self.last_recognized_time = 0

    def set_face_app(self, face_app):
        self.face_app = face_app

    def set_hmi_app(self, hmi_app):
        self.hmi_app = hmi_app

    def _uart_tx(self, data):
        if self.uart is None:
            return False
        try:
            if isinstance(data, str):
                data = data.encode("utf-8")
            self.uart.write(data)
            return True
        except Exception:
            return False

    def _send_open_lid_command(self, box_id):
        try:
            box_id = int(box_id)
        except Exception:
            return
        if box_id < 1 or box_id > 6:
            return
        cmd = b'{"tool":"open_lid","args":{"box_id":' + str(box_id).encode("ascii") + b'}}\n'
        if self._uart_tx(cmd):
            print("[MAIN] open lid command sent:", box_id)
        else:
            print("[MAIN] open lid command send failed:", box_id)

    def _send_phone_call_command(self):
        if self._uart_tx(b'{"tool":"make_phone_call","args":{}}\n'):
            print("[MAIN] phone call command sent")
        else:
            print("[MAIN] phone call command send failed")

    def handle_hmi_emergency_command(self, action, box_id):
        if action == "phone_call":
            self._send_phone_call_command()
            return
        if action == "open_lid":
            self._send_open_lid_command(box_id)
            return
        print("[MAIN] unknown HMI emergency action:", action)

    def _send_face_event(self, trigger_type, user_name, permission):
        import json
        event = {
            "device": "k230",
            "trigger_type": trigger_type,
            "user_name": user_name,
            "permission": permission,
            "current_mode": self.state
        }
        json_str = json.dumps(event) + "\r\n"
        self._uart_tx(json_str)

    def _send_medication_event(self, user_name, status, distance):
        import json
        permission = "allowed" if user_name != "unknown" else "denied"
        event = {
            "device": "k230",
            "trigger_type": "medication_detected",
            "user_name": user_name,
            "permission": permission,
            "medication_status": status,
            "hand_face_distance": distance,
            "current_mode": self.state
        }
        json_str = json.dumps(event) + "\r\n"
        self._uart_tx(json_str)

    def is_edit_mode(self):
        return self.state == STATE_EDIT_MODE

    def is_register_allowed(self):
        """仅编辑模式允许录入人脸（普通/省电不允许）。"""
        return self.state == STATE_EDIT_MODE

    def get_status_hint(self):
        if self._edit_auth_pending:
            return "串口: 等待编辑密码"
        if self.state == STATE_EDIT_MODE:
            return "编辑模式: 按键注册 | 串口 USER:LIST/DEL/RENAME"
        if self.state == STATE_SAVE_POWER_MODE:
            return "省电模式: 仅识别"
        return "普通模式: 仅识别"

    def poll_serial_and_transition(self):
        if self.uart is None:
            return
        if not self.uart.any():
            return
        chunk = self.uart.read()
        if not chunk:
            return
        # 【调试1】打印原始数据 + 十六进制
        hex_str = " ".join(["{:02X}".format(b) for b in chunk])
        print("[REPL] Raw RX HEX:", hex_str)

        self._rx_buf.extend(chunk)
        if len(self._rx_buf) > _UART2_RX_BUFFER_MAX:
            self._rx_buf = bytearray(self._rx_buf[-(_UART2_RX_BUFFER_MAX // 2) :])
        end = CMD_PROTOCOL_LINE_END
        end_len = len(end)
        while True:
            idx = self._rx_buf.find(end)
            if idx < 0:
                break
            payload = bytes(self._rx_buf[:idx]).strip(b"\x00 \t\r\n")
            # CanMV/MicroPython 部分版本 bytearray 不支持 del buf[:n]，用切片重建
            self._rx_buf = bytearray(self._rx_buf[idx + end_len :])
            if payload.startswith(CMD_MED_STOCK_PREFIX):
                self._handle_med_stock(payload)
            elif self._edit_auth_pending:
                self._handle_edit_auth_line(payload)
            elif payload.startswith(b"USER:"):
                self._handle_user_serial(payload)
            else:
                self._apply_line_command(payload)

    def _handle_med_stock(self, line):
        if self.hmi_app is None:
            print("[MAIN] no HMI app for MED:STOCK")
            return
        if self.hmi_app.update_stock_from_main(line):
            self.hmi_app.refresh_current_page()

    def _handle_edit_auth_line(self, line):
        """收到 MODE:EDIT 后，下一行内容为密码（逻辑参考 uart2.py 登录校验）。"""
        if line == CMD_SET_NORMAL_MODE or line == CMD_EDIT_CANCEL:
            self._edit_auth_pending = False
            self.state = STATE_NORMAL_MODE
            self._uart_tx(b"EDIT:AUTH_CANCEL\r\n")
            return
        if line == CMD_SET_SAVE_POWER_MODE:
            self._edit_auth_pending = False
            self.state = STATE_SAVE_POWER_MODE
            self._uart_tx(b"EDIT:AUTH_CANCEL\r\n")
            return
        if line == CMD_SET_EDIT_MODE:
            self._uart_tx(b"EDIT:INPUT_PASSWORD\r\n")
            return
        try:
            text = line.decode("utf-8").strip()
        except Exception:
            self._uart_tx(b"EDIT:PASSWORD_FAIL\r\n")
            return
        pwd = load_password()
        if text == pwd:
            self._edit_auth_pending = False
            self.state = STATE_EDIT_MODE
            self._uart_tx(b"EDIT:AUTH_OK\r\n")
        else:
            self._uart_tx(b"EDIT:PASSWORD_FAIL\r\n")

    def _handle_user_serial(self, line):
        """编辑模式下：列出用户、网页注册、删除、改名（基于 user_dict / 文件）。"""
        app = self.face_app
        if app is None:
            self._uart_tx(b"USER:ERR:no_app\r\n")
            return
        if line == CMD_USER_LIST:
            names = app.list_user_names()
            try:
                joined = ",".join(names)
            except Exception:
                joined = ""
            self._uart_tx(b"USER:LIST:OK:" + joined.encode("utf-8") + b"\r\n")
            return
        if line.startswith(CMD_USER_REGISTER_PREFIX):
            rest = line[len(CMD_USER_REGISTER_PREFIX) :]
            try:
                name = rest.decode("utf-8").strip()
            except Exception:
                self._uart_tx(b"USER:REGISTER:ERR:decode\r\n")
                return
            ok, msg = app.request_serial_register(name)
            if ok:
                if msg == "already":
                    self._uart_tx(("USER:REGISTER:OK:" + name + "\r\n").encode("utf-8"))
                else:
                    self._uart_tx(("USER:REGISTER:WAIT:" + name + "\r\n").encode("utf-8"))
            else:
                self._uart_tx(("USER:REGISTER:ERR:" + msg + "\r\n").encode("utf-8"))
            return
        if line.startswith(CMD_USER_DEL_PREFIX):
            rest = line[len(CMD_USER_DEL_PREFIX) :]
            try:
                name = rest.decode("utf-8").strip()
            except Exception:
                self._uart_tx(b"USER:DEL:ERR:decode\r\n")
                return
            ok, msg = app.delete_user(name)
            if ok:
                self._uart_tx(("USER:DEL:OK:" + msg + "\r\n").encode("utf-8"))
            else:
                self._uart_tx(("USER:DEL:ERR:" + msg + "\r\n").encode("utf-8"))
            return
        if line.startswith(CMD_USER_RENAME_PREFIX):
            rest = line[len(CMD_USER_RENAME_PREFIX) :]
            try:
                parts = rest.split(b"|", 1)
                if len(parts) != 2:
                    self._uart_tx(b"USER:RENAME:ERR:format\r\n")
                    return
                old_name = parts[0].decode("utf-8").strip()
                new_name = parts[1].decode("utf-8").strip()
            except Exception:
                self._uart_tx(b"USER:RENAME:ERR:decode\r\n")
                return
            ok, msg = app.rename_user(old_name, new_name)
            if ok:
                self._uart_tx(("USER:RENAME:OK:" + msg + "\r\n").encode("utf-8"))
            else:
                self._uart_tx(("USER:RENAME:ERR:" + msg + "\r\n").encode("utf-8"))
            return
        self._uart_tx(b"USER:ERR:unknown_cmd\r\n")

    def _apply_line_command(self, line):
        # 【调试2】添加：打印切分后的指令内容
        print("[REPL] Parsed CMD:", line)

        if line == CMD_QUERY_PERMISSION:
            # 使用主循环中最新的识别结果
            permission = "allowed" if self.last_recognized_name != "unknown" else "denied"
            self._send_face_event("query_permission", self.last_recognized_name, permission)
            return

        if line == CMD_SET_NORMAL_MODE:
            self._edit_auth_pending = False
            if self.face_app is not None:
                self.face_app.clear_pending_serial_register()
            self.state = STATE_NORMAL_MODE
        elif line == CMD_SET_SAVE_POWER_MODE:
            self._edit_auth_pending = False
            if self.face_app is not None:
                self.face_app.clear_pending_serial_register()
            self.state = STATE_SAVE_POWER_MODE
        elif line == CMD_SET_EDIT_MODE:
            if self.state == STATE_EDIT_MODE:
                self._uart_tx(b"EDIT:ALREADY\r\n")
                return
            self._edit_auth_pending = True
            self._uart_tx(b"EDIT:INPUT_PASSWORD\r\n")


class FaceDetApp(AIBase):
    def __init__(self, kmodel_path, model_input_size, anchors, confidence_threshold=0.25, nms_threshold=0.3, rgb888p_size=[1920, 1080], display_size=[1920, 1080], debug_mode=0):
        super().__init__(kmodel_path, model_input_size, rgb888p_size, debug_mode)
        self.kmodel_path = kmodel_path
        self.model_input_size = model_input_size
        self.confidence_threshold = confidence_threshold
        self.nms_threshold = nms_threshold
        self.anchors = anchors
        self.rgb888p_size = [ALIGN_UP(rgb888p_size[0], 16), rgb888p_size[1]]
        self.display_size = [ALIGN_UP(display_size[0], 16), display_size[1]]
        self.debug_mode = debug_mode
        self.ai2d = Ai2d(debug_mode)
        self.ai2d.set_ai2d_dtype(nn.ai2d_format.NCHW_FMT, nn.ai2d_format.NCHW_FMT, np.uint8, np.uint8)

    def config_preprocess(self, input_image_size=None):
        with ScopedTiming("set preprocess config", self.debug_mode > 0):
            ai2d_input_size = input_image_size if input_image_size else self.rgb888p_size
            top, bottom, left, right, _ = letterbox_pad_param(self.rgb888p_size, self.model_input_size)
            self.ai2d.pad([0, 0, 0, 0, top, bottom, left, right], 0, [104, 117, 123])
            self.ai2d.resize(nn.interp_method.tf_bilinear, nn.interp_mode.half_pixel)
            self.ai2d.build([1, 3, ai2d_input_size[1], ai2d_input_size[0]], [1, 3, self.model_input_size[1], self.model_input_size[0]])

    def postprocess(self, results):
        with ScopedTiming("postprocess", self.debug_mode > 0):
            res = aidemo.face_det_post_process(self.confidence_threshold, self.nms_threshold, self.model_input_size[0], self.anchors, self.rgb888p_size, results)
            if len(res) == 0:
                return res, res
            return res[0], res[1]


class FaceRegistrationApp(AIBase):
    def __init__(self, kmodel_path, model_input_size, rgb888p_size=[1920, 1080], display_size=[1920, 1080], debug_mode=0):
        super().__init__(kmodel_path, model_input_size, rgb888p_size, debug_mode)
        self.kmodel_path = kmodel_path
        self.model_input_size = model_input_size
        self.rgb888p_size = [ALIGN_UP(rgb888p_size[0], 16), rgb888p_size[1]]
        self.display_size = [ALIGN_UP(display_size[0], 16), display_size[1]]
        self.debug_mode = debug_mode
        self.umeyama_args_112 = [
            38.2946, 51.6963,
            73.5318, 51.5014,
            56.0252, 71.7366,
            41.5493, 92.3655,
            70.7299, 92.2041
        ]
        self.ai2d = Ai2d(debug_mode)
        self.ai2d.set_ai2d_dtype(nn.ai2d_format.NCHW_FMT, nn.ai2d_format.NCHW_FMT, np.uint8, np.uint8)

    def config_preprocess(self, landm, input_image_size=None):
        with ScopedTiming("set preprocess config", self.debug_mode > 0):
            ai2d_input_size = input_image_size if input_image_size else self.rgb888p_size
            affine_matrix = self.get_affine_matrix(landm)
            self.ai2d.affine(nn.interp_method.cv2_bilinear, 0, 0, 127, 1, affine_matrix)
            self.ai2d.build([1, 3, ai2d_input_size[1], ai2d_input_size[0]], [1, 3, self.model_input_size[1], self.model_input_size[0]])

    def postprocess(self, results):
        with ScopedTiming("postprocess", self.debug_mode > 0):
            return results[0][0]

    def svd22(self, a):
        s = [0.0, 0.0]
        u = [0.0, 0.0, 0.0, 0.0]
        v = [0.0, 0.0, 0.0, 0.0]
        s[0] = (math.sqrt((a[0] - a[3]) ** 2 + (a[1] + a[2]) ** 2) + math.sqrt((a[0] + a[3]) ** 2 + (a[1] - a[2]) ** 2)) / 2
        s[1] = abs(s[0] - math.sqrt((a[0] - a[3]) ** 2 + (a[1] + a[2]) ** 2))
        v[2] = math.sin((math.atan2(2 * (a[0] * a[1] + a[2] * a[3]), a[0] ** 2 - a[1] ** 2 + a[2] ** 2 - a[3] ** 2)) / 2) if s[0] > s[1] else 0
        v[0] = math.sqrt(1 - v[2] ** 2)
        v[1] = -v[2]
        v[3] = v[0]
        u[0] = -(a[0] * v[0] + a[1] * v[2]) / s[0] if s[0] != 0 else 1
        u[2] = -(a[2] * v[0] + a[3] * v[2]) / s[0] if s[0] != 0 else 0
        u[1] = (a[0] * v[1] + a[1] * v[3]) / s[1] if s[1] != 0 else -u[2]
        u[3] = (a[2] * v[1] + a[3] * v[3]) / s[1] if s[1] != 0 else u[0]
        v[0] = -v[0]
        v[2] = -v[2]
        return u, s, v

    def image_umeyama_112(self, src):
        src_num = 5
        src_dim = 2
        src_mean = [0.0, 0.0]
        dst_mean = [0.0, 0.0]
        for i in range(0, src_num * 2, 2):
            src_mean[0] += src[i]
            src_mean[1] += src[i + 1]
            dst_mean[0] += self.umeyama_args_112[i]
            dst_mean[1] += self.umeyama_args_112[i + 1]
        src_mean[0] /= src_num
        src_mean[1] /= src_num
        dst_mean[0] /= src_num
        dst_mean[1] /= src_num

        src_demean = [[0.0, 0.0] for _ in range(src_num)]
        dst_demean = [[0.0, 0.0] for _ in range(src_num)]
        for i in range(src_num):
            src_demean[i][0] = src[2 * i] - src_mean[0]
            src_demean[i][1] = src[2 * i + 1] - src_mean[1]
            dst_demean[i][0] = self.umeyama_args_112[2 * i] - dst_mean[0]
            dst_demean[i][1] = self.umeyama_args_112[2 * i + 1] - dst_mean[1]

        a = [[0.0, 0.0], [0.0, 0.0]]
        for i in range(src_dim):
            for k in range(src_dim):
                for j in range(src_num):
                    a[i][k] += dst_demean[j][i] * src_demean[j][k]
                a[i][k] /= src_num

        t = [[1, 0, 0], [0, 1, 0], [0, 0, 1]]
        u, s, v = self.svd22([a[0][0], a[0][1], a[1][0], a[1][1]])
        t[0][0] = u[0] * v[0] + u[1] * v[2]
        t[0][1] = u[0] * v[1] + u[1] * v[3]
        t[1][0] = u[2] * v[0] + u[3] * v[2]
        t[1][1] = u[2] * v[1] + u[3] * v[3]

        src_demean_mean = [0.0, 0.0]
        src_demean_var = [0.0, 0.0]
        for i in range(src_num):
            src_demean_mean[0] += src_demean[i][0]
            src_demean_mean[1] += src_demean[i][1]
        src_demean_mean[0] /= src_num
        src_demean_mean[1] /= src_num
        for i in range(src_num):
            src_demean_var[0] += (src_demean_mean[0] - src_demean[i][0]) * (src_demean_mean[0] - src_demean[i][0])
            src_demean_var[1] += (src_demean_mean[1] - src_demean[i][1]) * (src_demean_mean[1] - src_demean[i][1])
        src_demean_var[0] /= src_num
        src_demean_var[1] /= src_num

        scale = 1.0 / (src_demean_var[0] + src_demean_var[1]) * (s[0] + s[1])
        t[0][2] = dst_mean[0] - scale * (t[0][0] * src_mean[0] + t[0][1] * src_mean[1])
        t[1][2] = dst_mean[1] - scale * (t[1][0] * src_mean[0] + t[1][1] * src_mean[1])
        t[0][0] *= scale
        t[0][1] *= scale
        t[1][0] *= scale
        t[1][1] *= scale
        return t

    def get_affine_matrix(self, sparse_points):
        with ScopedTiming("get_affine_matrix", self.debug_mode > 1):
            matrix_dst = self.image_umeyama_112(sparse_points)
            return [matrix_dst[0][0], matrix_dst[0][1], matrix_dst[0][2], matrix_dst[1][0], matrix_dst[1][1], matrix_dst[1][2]]


class PersonKeyPointApp(AIBase):
    def __init__(self, kmodel_path, model_input_size, confidence_threshold=0.2, nms_threshold=0.5, rgb888p_size=[1280, 720], display_size=[1920, 1080], debug_mode=0):
        super().__init__(kmodel_path, model_input_size, rgb888p_size, debug_mode)
        self.kmodel_path = kmodel_path
        self.model_input_size = model_input_size
        self.confidence_threshold = confidence_threshold
        self.nms_threshold = nms_threshold
        self.rgb888p_size = [ALIGN_UP(rgb888p_size[0], 16), rgb888p_size[1]]
        self.display_size = [ALIGN_UP(display_size[0], 16), display_size[1]]
        self.debug_mode = debug_mode
        self.ai2d = Ai2d(debug_mode)
        self.ai2d.set_ai2d_dtype(nn.ai2d_format.NCHW_FMT, nn.ai2d_format.NCHW_FMT, np.uint8, np.uint8)

    def config_preprocess(self, input_image_size=None):
        with ScopedTiming("set preprocess config", self.debug_mode > 0):
            ai2d_input_size = input_image_size if input_image_size else self.rgb888p_size
            top, bottom, left, right, _ = center_pad_param(self.rgb888p_size, self.model_input_size)
            self.ai2d.pad([0, 0, 0, 0, top, bottom, left, right], 0, [0, 0, 0])
            self.ai2d.resize(nn.interp_method.tf_bilinear, nn.interp_mode.half_pixel)
            self.ai2d.build([1, 3, ai2d_input_size[1], ai2d_input_size[0]], [1, 3, self.model_input_size[1], self.model_input_size[0]])

    def preprocess(self, input_np):
        with ScopedTiming("preprocess", self.debug_mode > 0):
            return [nn.from_numpy(input_np)]

    def postprocess(self, results):
        with ScopedTiming("postprocess", self.debug_mode > 0):
            return aidemo.person_kp_postprocess(results[0], [self.rgb888p_size[1], self.rgb888p_size[0]], self.model_input_size, self.confidence_threshold, self.nms_threshold)


class FaceRegisterRecognizeRealtime:
    def __init__(self, face_det_kmodel, face_reg_kmodel, det_input_size, reg_input_size, database_dir, anchors, confidence_threshold=0.5, nms_threshold=0.2, face_recognition_threshold=0.75, rgb888p_size=[1280, 720], display_size=[1920, 1080], debug_mode=0, person_kp_kmodel=None, person_kp_input_size=[320, 320], medication_distance_ratio=0.75, medication_consecutive_frames=2):
        self.database_dir = database_dir
        self.face_recognition_threshold = face_recognition_threshold
        self.rgb888p_size = [ALIGN_UP(rgb888p_size[0], 16), rgb888p_size[1]]
        self.display_size = [ALIGN_UP(display_size[0], 16), display_size[1]]
        self.debug_mode = debug_mode
        self.feature_num = 128
        self.max_register_face = 100
        # 用户名 -> 人脸特征向量，便于后续扩展元数据等字段
        self.user_dict = {}
        self.last_prompt = "Ready"
        self._osd_mode_hint = "普通模式: 仅识别"
        self.medication_status = "idle"
        self.medication_min_distance = -1
        self.medication_near_frames = 0
        self.medication_distance_ratio = medication_distance_ratio
        self.medication_consecutive_frames = medication_consecutive_frames
        self.last_medication_event = None
        self.pending_serial_register_name = None
        self.pending_serial_register_start_ms = 0
        self.serial_register_timeout_ms = 15000
        # 统一颜色格式为 ARGB: (A, R, G, B)
        self.prompt_color = (255, 255, 255, 255)

        self.face_det = FaceDetApp(face_det_kmodel, det_input_size, anchors, confidence_threshold, nms_threshold, self.rgb888p_size, self.display_size, debug_mode=0)
        self.face_reg = FaceRegistrationApp(face_reg_kmodel, reg_input_size, self.rgb888p_size, self.display_size, debug_mode=0)
        self.person_kp = None
        if person_kp_kmodel:
            self.person_kp = PersonKeyPointApp(person_kp_kmodel, person_kp_input_size, rgb888p_size=self.rgb888p_size, display_size=self.display_size, debug_mode=0)
            self.person_kp.config_preprocess()
        self.face_det.config_preprocess()

        self._ensure_db_dir()
        self.database_init()

    def _ensure_db_dir(self):
        try:
            os.listdir(self.database_dir)
        except Exception:
            os.mkdir(self.database_dir)

    @staticmethod
    def _stem_filename(filename):
        """去掉最后一个扩展名；CanMV 等 MicroPython 的 os 无 path 子模块，不能用 splitext。"""
        i = filename.rfind(".")
        return filename[0:i] if i > 0 else filename

    def _next_register_name(self):
        return "user_{:03d}".format(len(self.user_dict) + 1)

    def _check_register_quality(self, det_boxes):
        if not det_boxes:
            return False, "注册失败: 未检测到人脸"
        if det_boxes.shape[0] != 1:
            return False, "注册失败: 仅允许单人"

        x1, y1, w, h = det_boxes[0][:4]
        face_area = w * h
        frame_area = self.rgb888p_size[0] * self.rgb888p_size[1]
        ratio = face_area / frame_area
        if ratio < 0.03:
            return False, "注册失败: 人脸太小请靠近"
        return True, "可以注册"

    def database_init(self):
        self.user_dict = {}
        db_file_list = os.listdir(self.database_dir)
        for db_file in db_file_list:
            if not db_file.endswith(".bin"):
                continue
            if len(self.user_dict) >= self.max_register_face:
                break
            full_db_file = self.database_dir + db_file
            with open(full_db_file, "rb") as f:
                data = f.read()
            feature = np.frombuffer(data, dtype=np.float)
            name = self._stem_filename(db_file)
            self.user_dict[name] = feature

    def _append_db(self, name, feature):
        self.user_dict[name] = feature

    def database_search(self, feature):
        best_name = None
        v_score_max = 0.0
        feature /= np.linalg.norm(feature)
        for name, db_feature in self.user_dict.items():
            db_feature /= np.linalg.norm(db_feature)
            v_score = np.dot(feature, db_feature) / 2 + 0.5
            if v_score > v_score_max:
                v_score_max = v_score
                best_name = name
        if best_name is None or v_score_max < self.face_recognition_threshold:
            return "unknown", v_score_max
        return best_name, v_score_max

    def list_user_names(self):
        """数据库中的用户名列表（排序后便于串口与显示）。"""
        try:
            return sorted(self.user_dict.keys())
        except Exception:
            return list(self.user_dict.keys())

    def delete_user(self, name):
        """从 user_dict 与磁盘删除指定用户。"""
        if name not in self.user_dict:
            return False, "not_found"
        path = self.database_dir + name + ".bin"
        try:
            os.remove(path)
        except OSError:
            pass
        try:
            del self.user_dict[name]
        except KeyError:
            return False, "not_found"
        return True, name

    def rename_user(self, old_name, new_name):
        """重命名用户：更新 bin 文件名与 user_dict。"""
        if not new_name:
            return False, "empty_new"
        if old_name not in self.user_dict:
            return False, "not_found"
        if new_name in self.user_dict:
            return False, "new_exists"
        old_path = self.database_dir + old_name + ".bin"
        new_path = self.database_dir + new_name + ".bin"
        try:
            os.rename(old_path, new_path)
        except OSError as e:
            return False, "rename_{}".format(e)
        self.user_dict[new_name] = self.user_dict[old_name]
        del self.user_dict[old_name]
        return True, "{}->{}".format(old_name, new_name)

    def _validate_register_name(self, name):
        if not name:
            return False, "empty_name"
        if len(name) > 48:
            return False, "name_too_long"
        for ch in '/\\:*?"<>|\r\n':
            if ch in name:
                return False, "bad_name"
        return True, "ok"

    def request_serial_register(self, name):
        """网站下发 USER:REGISTER|name 后，记录姓名并等待主循环采集当前人脸。"""
        ok, msg = self._validate_register_name(name)
        if not ok:
            return False, msg
        if name in self.user_dict:
            self.last_prompt = "已存在用户: {}".format(name)
            self.prompt_color = (255, 80, 255, 80)
            return True, "already"
        if len(self.user_dict) >= self.max_register_face:
            return False, "database_full"

        self.pending_serial_register_name = name
        self.pending_serial_register_start_ms = time.ticks_ms()
        self.last_prompt = "网页注册: 请正对摄像头 {}".format(name)
        self.prompt_color = (255, 80, 180, 255)
        return True, "wait"

    def clear_pending_serial_register(self):
        self.pending_serial_register_name = None
        self.pending_serial_register_start_ms = 0

    def has_pending_serial_register(self):
        return self.pending_serial_register_name is not None

    def process_pending_serial_register(self, input_np, det_boxes, landms):
        """在主循环中用当前帧执行网页注册；返回需要通过 UART 回传的网站协议行。"""
        name = self.pending_serial_register_name
        if name is None:
            return None

        now = time.ticks_ms()
        if time.ticks_diff(now, self.pending_serial_register_start_ms) > self.serial_register_timeout_ms:
            self.clear_pending_serial_register()
            self.last_prompt = "网页注册超时: 未采集到合格人脸"
            self.prompt_color = (255, 255, 80, 80)
            return b"USER:REGISTER:ERR:timeout\r\n"

        ok, msg = self._check_register_quality(det_boxes)
        if not ok:
            self.last_prompt = "网页注册等待: 请保持单人脸入镜"
            self.prompt_color = (255, 255, 220, 0)
            return None

        ok, msg = self.register_current_face(input_np, det_boxes, landms, register_name=name, return_message=True)
        self.clear_pending_serial_register()
        if ok:
            return ("USER:REGISTER:OK:" + msg + "\r\n").encode("utf-8")
        return ("USER:REGISTER:ERR:" + msg + "\r\n").encode("utf-8")

    def run(self, input_np):
        det_boxes, landms = self.face_det.run(input_np)
        recg_res = []
        for landm in landms:
            self.face_reg.config_preprocess(landm)
            feature = self.face_reg.run(input_np)
            name, score = self.database_search(feature)
            recg_res.append((name, score))
        return det_boxes, landms, recg_res

    def run_person_keypoint(self, input_np):
        if self.person_kp is None:
            return None
        return self.person_kp.run(input_np)

    def _get_keypoint(self, kps, index):
        try:
            kp = kps[index]
            if kp[2] <= 0:
                return None
            return kp[0], kp[1]
        except Exception:
            return None

    def update_medication_detection(self, det_boxes, pose_res):
        self.last_medication_event = None
        if pose_res is None or len(det_boxes) == 0:
            self.medication_status = "idle"
            self.medication_min_distance = -1
            self.medication_near_frames = 0
            return False
        try:
            if len(pose_res[0]) == 0:
                self.medication_status = "idle"
                self.medication_min_distance = -1
                self.medication_near_frames = 0
                return False
            kpses = pose_res[1]
        except Exception:
            return False

        min_distance = None
        near = False
        for det in det_boxes:
            x1, y1, w, h = det[:4]
            face_cx = x1 + w / 2
            face_cy = y1 + h / 2
            face_diag = math.sqrt(w * w + h * h)
            if face_diag <= 0:
                continue
            threshold = face_diag * self.medication_distance_ratio
            for kps in kpses:
                for wrist_index in (9, 10):
                    wrist = self._get_keypoint(kps, wrist_index)
                    if wrist is None:
                        continue
                    dx = wrist[0] - face_cx
                    dy = wrist[1] - face_cy
                    distance = math.sqrt(dx * dx + dy * dy)
                    if min_distance is None or distance < min_distance:
                        min_distance = distance
                    if distance <= threshold:
                        near = True

        if min_distance is None:
            self.medication_status = "idle"
            self.medication_min_distance = -1
            self.medication_near_frames = 0
            return False

        self.medication_min_distance = int(min_distance)
        if near:
            self.medication_near_frames += 1
        else:
            self.medication_near_frames = 0

        detected = self.medication_near_frames >= self.medication_consecutive_frames
        self.medication_status = "detected" if detected else "tracking"
        if detected:
            self.last_medication_event = {
                "status": self.medication_status,
                "distance": self.medication_min_distance
            }
        return detected

    def register_current_face(self, input_np, det_boxes, landms, register_name=None, return_message=False):
        ok, msg = self._check_register_quality(det_boxes)
        if not ok:
            self.last_prompt = msg
            self.prompt_color = (255, 255, 80, 80)
            return (False, msg) if return_message else False

        name = register_name.strip() if register_name else self._next_register_name()
        ok, msg = self._validate_register_name(name)
        if not ok:
            self.last_prompt = "注册失败: {}".format(msg)
            self.prompt_color = (255, 255, 80, 80)
            return (False, msg) if return_message else False
        if name in self.user_dict:
            self.last_prompt = "重复注册: 已存在 {}".format(name)
            self.prompt_color = (255, 255, 220, 0)
            return (False, "exists") if return_message else False

        self.face_reg.config_preprocess(landms[0])
        feature = self.face_reg.run(input_np)

        # 去重逻辑：若数据库中已存在与当前人脸匹配的条目，则提示但不保存 bin。
        # 注意：database_search 会对传入的特征向量做归一化运算，因此这里使用副本用于查重。
        try:
            feature_for_search = feature.copy() #copy是 numpy类的方法
        except Exception:
            feature_for_search = np.array(feature) #若上一行报错，则强行转为numpy类的数组
        existed_name, score = self.database_search(feature_for_search)
        if existed_name != "unknown":
            self.last_prompt = "重复注册: 已存在 {}".format(existed_name)
            self.prompt_color = (255, 255, 220, 0)
            return (False, "duplicate:{}".format(existed_name)) if return_message else False

        # 查重通过后才考虑数据库是否已满
        if len(self.user_dict) >= self.max_register_face:
            self.last_prompt = "注册失败: 数据库已满"
            self.prompt_color = (255, 255, 80, 80)
            return (False, "database_full") if return_message else False

        save_path = self.database_dir + "{}.bin".format(name)
        with open(save_path, "wb") as file:
            file.write(feature.tobytes())
        self._append_db(name, feature)
        self.last_prompt = "注册成功: {}".format(name)
        self.prompt_color = (255, 80, 255, 80)
        return (True, name) if return_message else True

    def draw_result(self, pl, dets, recg_results):
        pl.osd_img.clear()
        if dets:
            for i, det in enumerate(dets):
                x1, y1, w, h = map(lambda x: int(round(x, 0)), det[:4])
                x1 = x1 * self.display_size[0] // self.rgb888p_size[0]
                y1 = y1 * self.display_size[1] // self.rgb888p_size[1]
                w = w * self.display_size[0] // self.rgb888p_size[0]
                h = h * self.display_size[1] // self.rgb888p_size[1]

                name, score = recg_results[i]
                if name == "unknown":
                    color = (255, 255, 0, 0)
                    text = "unknown {:.3f}".format(score)
                else:
                    color = (255, 0, 255, 0)
                    text = "{} {:.3f}".format(name, score)

                pl.osd_img.draw_rectangle(x1, y1, w, h, color=color, thickness=4)
                pl.osd_img.draw_string_advanced(x1, y1, 28, text, color=color)

        pl.osd_img.draw_string_advanced(20, 20, 28, self.last_prompt, color=self.prompt_color)
        pl.osd_img.draw_string_advanced(20, 58, 24, self._osd_mode_hint, color=(255, 255, 255, 255))
        if self.medication_status == "detected":
            med_color = (255, 0, 255, 0)
        elif self.medication_status == "tracking":
            med_color = (255, 255, 220, 0)
        else:
            med_color = (255, 255, 255, 255)
        med_text = "medication:{} dist:{}".format(self.medication_status, self.medication_min_distance)
        pl.osd_img.draw_string_advanced(20, 92, 24, med_text, color=med_color)

    def set_osd_mode_hint(self, hint_text):
        self._osd_mode_hint = hint_text if hint_text else ""


class RegisterButton:
    def __init__(self, gpio_num=53, debounce_ms=50):
        self.last_state = 0
        self.debounce_ms = debounce_ms
        self.last_press_ms = -100000
        self.enabled = False
        self.pin = None
        if FPIOA is None or Pin is None:
            return
        try:
            self.fpioa = FPIOA()
            self.fpioa.set_function(gpio_num, getattr(FPIOA, "GPIO{}".format(gpio_num)))
            self.pin = Pin(gpio_num, Pin.IN, pull=Pin.PULL_DOWN, drive=7)
            self.enabled = True
        except Exception:
            self.enabled = False

    def pressed(self):
        if not self.enabled:
            return False
        state = self.pin.value()
        edge = (self.last_state == 0 and state == 1)
        self.last_state = state
        if not edge:
            return False
        now = time.ticks_ms()
        if time.ticks_diff(now, self.last_press_ms) < self.debounce_ms:
            return False
        self.last_press_ms = now
        return True


if __name__ == "__main__":
    display_mode = "lcd"
    rgb888p_size = [1280, 720]
    face_det_kmodel_path = "/sdcard/examples/kmodel/face_detection_320.kmodel"
    face_reg_kmodel_path = "/sdcard/examples/kmodel/face_recognition.kmodel"
    person_kp_kmodel_path = "/sdcard/examples/kmodel/yolov8n-pose.kmodel"
    anchors_path = "/sdcard/examples/utils/prior_data_320.bin"
    database_dir = "/sdcard/examples/utils/db/"
    face_det_input_size = [320, 320]
    face_reg_input_size = [112, 112]
    person_kp_input_size = [320, 320]
    confidence_threshold = 0.5
    nms_threshold = 0.2
    anchor_len = 4200
    det_dim = 4
    face_recognition_threshold = 0.75

    anchors = np.fromfile(anchors_path, dtype=np.float)
    anchors = anchors.reshape((anchor_len, det_dim))

    pl = PipeLine(rgb888p_size=rgb888p_size, display_mode=display_mode)
    pl.create()
    pl.disable_display()
    display_size = pl.get_display_size()

    app = FaceRegisterRecognizeRealtime(
        face_det_kmodel_path,
        face_reg_kmodel_path,
        det_input_size=face_det_input_size,
        reg_input_size=face_reg_input_size,
        database_dir=database_dir,
        anchors=anchors,
        confidence_threshold=confidence_threshold,
        nms_threshold=nms_threshold,
        face_recognition_threshold=face_recognition_threshold,
        rgb888p_size=rgb888p_size,
        display_size=display_size,
        person_kp_kmodel=person_kp_kmodel_path,
        person_kp_input_size=person_kp_input_size
    )
    register_button = RegisterButton(gpio_num=53)
    if not register_button.enabled:
        app.last_prompt = "未检测到按键GPIO, 仅识别模式"
        app.prompt_color = (255, 255, 255, 255)

    hmi = MedicineBoxHMI()
    mode_fsm = GlobalModeStateMachine(face_app=app, hmi_app=hmi)

    # # 串口测试：上电回传 READY（需 UART_TX_* 常量已启用）
#    uart_test_prev_state = None
#    _u_boot = mode_fsm.uart
#    if _u_boot is not None:
#        _u_boot.write(UART_TX_BOOT_OK)

    # 节能模式参数
    SAVE_POWER_SKIP_FRAMES = 10
    frame_counter = 0
    last_det_boxes = []
    last_landms = []
    last_recg_res = []
    last_pose_res = None
    pose_frame_counter = 0

    # 人脸检测超时参数（10秒）
    NO_FACE_TIMEOUT_MS = 10000
    last_face_detected_ms = time.ticks_ms()

    # 状态切换冷却时间参数（防止误识别导致频繁切换）
    MODE_SWITCH_COOLDOWN_MS = 3000  # 3秒冷却时间
    last_switch_to_save_power_ms = -MODE_SWITCH_COOLDOWN_MS
    # 未知人脸通知开关（设置为False可禁用未知人脸通知，保留代码方便后续修改）
    ENABLE_UNKNOWN_FACE_NOTIFY = False
    # 未知人脸通知冷却时间（避免频繁发送陌生人脸告警）
    UNKNOWN_FACE_NOTIFY_INTERVAL_MS = 5000  # 5秒
    last_unknown_face_notify_ms = -UNKNOWN_FACE_NOTIFY_INTERVAL_MS
    # 授权人脸通知冷却时间（相同人脸重复识别时的间隔）
    KNOWN_FACE_NOTIFY_INTERVAL_MS = 3000  # 3秒
    last_known_face_notify_ms = -KNOWN_FACE_NOTIFY_INTERVAL_MS
    POSE_SKIP_FRAMES = 3
    MEDICATION_NOTIFY_INTERVAL_MS = 5000
    last_medication_notify_ms = -MEDICATION_NOTIFY_INTERVAL_MS
    # 记录上一次发送的人脸名称（用于检测状态变化）
    last_notified_name = "unknown"

    try:
        while True:
            with ScopedTiming("total", 1):
                mode_fsm.poll_serial_and_transition()
                hmi.poll()

                # # 串口测试：模式变化时回传一行（需 UART_TX_* 常量已启用）
                # u = mode_fsm.uart
                # if u is not None:
                #     st = mode_fsm.state
                #     if st != uart_test_prev_state:
                #         if st == STATE_NORMAL_MODE:
                #             u.write(UART_TX_STATE_NORMAL)
                #         elif st == STATE_SAVE_POWER_MODE:
                #             u.write(UART_TX_STATE_SAVEPOWER)
                #         elif st == STATE_EDIT_MODE:
                #             u.write(UART_TX_STATE_EDIT)
                #         uart_test_prev_state = st

                try:
                    img = pl.get_frame()
                except RuntimeError as e:
                    print("[WARN] get_frame failed:", e)
                    time.sleep_ms(20)
                    gc.collect()
                    continue
                except Exception as e:
                    print("[WARN] get_frame exception:", e)
                    time.sleep_ms(20)
                    gc.collect()
                    continue

                if img is None:
                    print("[WARN] get_frame returned None")
                    time.sleep_ms(20)
                    continue

                while True:
                    emergency_cmd = hmi.pop_emergency_command()
                    if emergency_cmd is None:
                        break
                    mode_fsm.handle_hmi_emergency_command(emergency_cmd[0], emergency_cmd[1])

                current_state = mode_fsm.state

                # 节能模式：减少推理次数
                if current_state == STATE_SAVE_POWER_MODE:
                    frame_counter += 1
                    if frame_counter >= SAVE_POWER_SKIP_FRAMES:
                        frame_counter = 0
                        det_boxes, landms, recg_res = app.run(img)
                        last_det_boxes = det_boxes
                        last_landms = landms
                        last_recg_res = recg_res
                    else:
                        det_boxes = last_det_boxes
                        landms = last_landms
                        recg_res = last_recg_res
                else:
                    det_boxes, landms, recg_res = app.run(img)
                    frame_counter = 0

                if current_state == STATE_SAVE_POWER_MODE:
                    last_pose_res = None
                    pose_frame_counter = 0
                else:
                    pose_frame_counter += 1
                    if pose_frame_counter >= POSE_SKIP_FRAMES:
                        pose_frame_counter = 0
                        last_pose_res = app.run_person_keypoint(img)
                medication_detected = app.update_medication_detection(det_boxes, last_pose_res)

                # 状态机自动切换逻辑
                # 节能模式下识别到人脸后进入正常模式（需经过冷却时间）
                if current_state == STATE_SAVE_POWER_MODE and len(det_boxes) > 0:
                    # 检查是否已过冷却时间
                    cooldown_elapsed = time.ticks_diff(time.ticks_ms(), last_switch_to_save_power_ms)
                    if cooldown_elapsed >= MODE_SWITCH_COOLDOWN_MS:
                        mode_fsm.state = STATE_NORMAL_MODE
                        current_state = STATE_NORMAL_MODE
                        last_face_detected_ms = time.ticks_ms()

                # 正常模式下检测人脸并更新时间
                if current_state == STATE_NORMAL_MODE:
                    if len(det_boxes) > 0:
                        last_face_detected_ms = time.ticks_ms()
                    else:
                        # 10秒内没有识别到人脸回到节能模式
                        elapsed_ms = time.ticks_diff(time.ticks_ms(), last_face_detected_ms)
                        if elapsed_ms >= NO_FACE_TIMEOUT_MS:
                            mode_fsm.state = STATE_SAVE_POWER_MODE
                            current_state = STATE_SAVE_POWER_MODE
                            last_switch_to_save_power_ms = time.ticks_ms()  # 记录切换时间

                app.set_osd_mode_hint(mode_fsm.get_status_hint())

                # 更新最后识别的人脸信息并处理人脸通知
                if len(recg_res) > 0:
                    current_name = recg_res[0][0]
                    mode_fsm.last_recognized_name = current_name
                    mode_fsm.last_recognized_time = time.ticks_ms()

                    now = time.ticks_ms()
                    permission = "allowed" if current_name != "unknown" else "denied"
                    trigger_type = "recognized_face" if current_name != "unknown" else "recognized_new_face"

                    # 判断是否需要发送通知
                    should_notify = False

                    # 未知人脸：检查开关是否启用
                    if current_name == "unknown":
                        # 如果禁用了未知人脸通知，则不发送
                        if not ENABLE_UNKNOWN_FACE_NOTIFY:
                            # 但仍更新last_notified_name，防止状态变化时误触发
                            last_notified_name = current_name
                        else:
                            # 情况1：状态变化（从其他人脸变为unknown）
                            if current_name != last_notified_name:
                                should_notify = True
                            else:
                                # 情况2：相同未知人脸重复识别，使用冷却时间
                                if time.ticks_diff(now, last_unknown_face_notify_ms) >= UNKNOWN_FACE_NOTIFY_INTERVAL_MS:
                                    should_notify = True
                    else:
                        # 授权人脸：
                        # 情况1：状态变化（从unknown变为授权人脸，或人脸ID变化）
                        if current_name != last_notified_name:
                            should_notify = True
                        else:
                            # 情况2：相同人脸重复识别，使用较短的冷却时间
                            if time.ticks_diff(now, last_known_face_notify_ms) >= KNOWN_FACE_NOTIFY_INTERVAL_MS:
                                should_notify = True

                    if should_notify:
                        # 更新通知时间戳
                        if current_name == "unknown":
                            last_unknown_face_notify_ms = now
                        else:
                            last_known_face_notify_ms = now
                        # 更新最后通知的人脸名称
                        last_notified_name = current_name
                        # 发送通知
                        mode_fsm._send_face_event(trigger_type, current_name, permission)

                if medication_detected and app.last_medication_event is not None:
                    now = time.ticks_ms()
                    if time.ticks_diff(now, last_medication_notify_ms) >= MEDICATION_NOTIFY_INTERVAL_MS:
                        last_medication_notify_ms = now
                        mode_fsm._send_medication_event(
                            mode_fsm.last_recognized_name,
                            app.last_medication_event["status"],
                            app.last_medication_event["distance"]
                        )

                if mode_fsm.is_register_allowed() and app.has_pending_serial_register():
                    register_response = app.process_pending_serial_register(img, det_boxes, landms)
                    if register_response is not None:
                        mode_fsm._uart_tx(register_response)

                if mode_fsm.is_register_allowed() and register_button.pressed():
                    app.register_current_face(img, det_boxes, landms)
                    time.sleep_ms(150)
                if current_state == STATE_SAVE_POWER_MODE:
                    pl.disable_display()
                else:
                    pl.enable_display()

                app.draw_result(pl, det_boxes, recg_res)
                pl.show_image()

                gc.collect()
    finally:
        app.face_det.deinit()
        app.face_reg.deinit()
        if app.person_kp is not None:
            app.person_kp.deinit()
        pl.destroy()

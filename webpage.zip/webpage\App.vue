<template>
  <div v-if="!authUser" class="auth-page">
    <section class="auth-card">
      <div class="auth-icon">💊</div>
      <h1>智能药盒监管系统</h1>
      <p>请输入账号密码后进入平台</p>

      <div class="auth-tabs">
        <button
          type="button"
          :class="{ active: authMode === 'login' }"
          @click="setAuthMode('login')"
        >
          登录
        </button>
        <button
          type="button"
          :class="{ active: authMode === 'register' }"
          @click="setAuthMode('register')"
        >
          注册
        </button>
      </div>

      <form class="auth-form" @submit.prevent="submitAuth">
        <label>
          <span>账号</span>
          <input
            v-model.trim="authAccount"
            type="text"
            inputmode="numeric"
            maxlength="11"
            autocomplete="username"
            placeholder="请输入 11 位数字账号"
          />
        </label>

        <label>
          <span>密码</span>
          <div class="auth-password-field">
            <input
              v-model="authPassword"
              :type="showAuthPassword ? 'text' : 'password'"
              autocomplete="current-password"
              placeholder="请输入至少 6 位密码"
            />
            <button
              type="button"
              class="auth-eye-btn"
              :aria-label="showAuthPassword ? '隐藏密码' : '查看密码'"
              :title="showAuthPassword ? '隐藏密码' : '查看密码'"
              @click="showAuthPassword = !showAuthPassword"
            >
              {{ showAuthPassword ? "🙈" : "👁" }}
            </button>
          </div>
        </label>

        <div v-if="authError" class="auth-error">{{ authError }}</div>

        <button class="auth-submit" type="submit" :disabled="authLoading">
          {{ authLoading ? "处理中..." : authMode === "login" ? "立即登录" : "立即注册" }}
        </button>
      </form>
    </section>
  </div>

  <div v-else class="page">
    <aside class="side">
      <div class="logo">💊</div>
      <h2>智能药盒</h2>

      <div
        class="menu"
        :class="{ active: currentPage === 'dashboard' }"
        @click="currentPage = 'dashboard'"
      >
        📊 仪表盘
      </div>

      <div
        class="menu"
        :class="{ active: currentPage === 'sensor' }"
        @click="currentPage = 'sensor'"
      >
        ❤️ 健康检测
      </div>

      <div
        class="menu"
        :class="{ active: currentPage === 'medicine' }"
        @click="currentPage = 'medicine'"
      >
        💊 用药管理
      </div>

      <div
        class="menu"
        :class="{ active: currentPage === 'library' }"
        @click="currentPage = 'library'"
      >
        🧠 药品库
      </div>

      <div
        class="menu"
        :class="{ active: currentPage === 'reminder' }"
        @click="currentPage = 'reminder'"
      >
        📅 用药记录
      </div>

      <div
        class="menu"
        :class="{ active: currentPage === 'box' }"
        @click="currentPage = 'box'"
      >
        📦 药仓管理
      </div>

      <div
        class="menu"
        :class="{ active: currentPage === 'identity' }"
        @click="currentPage = 'identity'"
      >
        👤 用户身份
      </div>

      <div
        class="menu"
        :class="{ active: currentPage === 'family' }"
        @click="currentPage = 'family'"
      >
        👨‍👩‍👧 家属监管
      </div>

      <div
        class="menu"
        :class="{ active: currentPage === 'settings' }"
        @click="currentPage = 'settings'"
      >
        ⚙️ 系统设置
      </div>
    </aside>

    <main class="main">
      <div class="top">
        <div>
          <h1>基于状态感知的智能安全用药药盒监管平台</h1>
          <p>面向居家慢病老人用药安全，实现感知、决策、提醒、预警与远程监管闭环</p>
        </div>

        <div class="top-actions">
          <div class="auth-user-badge">{{ authUser.account }}</div>
          <button class="logout-btn" type="button" @click="logout">退出</button>
          <div class="online" :class="{ offline: !device.online }">
            ● {{ device.online ? "药盒在线" : "等待药盒数据" }}
          </div>
        </div>
      </div>

      <div v-if="currentPage === 'dashboard'">
        <div class="cards">
          <div class="card">
            <div class="card-icon">🌡️</div>
            <div>
              <div class="name">环境温度</div>
              <div class="value">{{ device.temperature }} <span>℃</span></div>
            </div>
          </div>

          <div class="card">
            <div class="card-icon">💧</div>
            <div>
              <div class="name">环境湿度</div>
              <div class="value">{{ device.humidity }} <span>%</span></div>
            </div>
          </div>

          <div class="card">
            <div class="card-icon">📅</div>
            <div>
              <div class="name">当前日期</div>
              <div class="value small">{{ liveDeviceDate }}</div>
            </div>
          </div>

          <div class="card">
            <div class="card-icon">⏱️</div>
            <div>
              <div class="name">当前时间</div>
              <div class="value small">{{ liveDeviceTime }}</div>
            </div>
          </div>

          <div class="card" :class="riskClass">
            <div class="card-icon">🛡️</div>
            <div>
              <div class="name">环境风险等级</div>
              <div class="value">{{ device.riskLevel }}</div>
            </div>
          </div>

          <div class="card">
            <div class="card-icon">📡</div>
            <div>
              <div class="name">通信状态</div>
              <div class="value small">{{ device.online ? "WebSocket 在线" : "未接入" }}</div>
            </div>
          </div>

          <div class="card placeholder-card">
            <div class="card-icon">📦</div>
            <div>
              <div class="name">药仓状态</div>
              <div class="value small">{{ configuredBoxCount }}/6 已配置</div>
            </div>
          </div>
        </div>

        <div class="content">
          <section class="panel">
            <h3>💊 用药管理状态</h3>

            <div class="decision">
              <div class="decision-main">当前可在用药管理页面设置用药时间</div>
              <p>
                当前阶段已支持用户在“用药管理”页面添加药品名称、用药时间和用药剂量。
                后续可结合蜂鸣器、语音提醒、药仓控制和家属通知，实现完整用药闭环。
              </p>
            </div>
          </section>

          <section class="panel">
            <h3>🚨 最近异常预警</h3>

            <div v-if="alarms.length === 0" class="empty">
              暂无异常预警
            </div>

            <div class="alarm" v-for="(item, index) in alarms" :key="index">
              <div class="alarm-title">
                {{ item.time }}　{{ item.type }}
              </div>
              <div class="alarm-msg">
                {{ item.message }}
              </div>
            </div>
          </section>
        </div>

        <div class="bottom">
          <section class="panel trend">
            <h3>📈 环境温湿度趋势</h3>
            <div ref="chartRef" class="chart"></div>
          </section>

          <section class="panel">
            <h3>👨‍👩‍👧 家属远程监管与协同</h3>
            <p class="text">
              当前页面已完成药盒环境信息和体温检测数据接入。后续接入用药计划、
              药仓状态和异常记录后，家属可实时查看老人用药情况与健康数据，
              并接收异常提醒。
            </p>
          </section>

          <section class="panel">
            <h3>📦 药量监测与补药管理</h3>
            <p class="text">
              该模块用于显示药品剩余量、有效期、补药提醒和过期锁仓状态。
              当前阶段为功能占位，后续接入重量传感器或药仓计数数据。
            </p>
          </section>
        </div>
      </div>

      <div v-else class="sub-page">
        <h2>{{ pageTitle }}</h2>

        <div
          class="sub-wide"
          :class="{
            'medicine-wide': currentPage === 'medicine',
            'health-wide': currentPage === 'sensor'
          }"
        >
          <h3>
            {{
              currentPage === "sensor"
                ? "数据图表"
                : currentPage === "library"
                  ? "AI 药品知识库"
                : currentPage === "reminder"
                  ? "月度用药记录"
                  : currentPage === "family"
                    ? "用药视频记录"
                  : currentPage === "settings"
                    ? "报警与联系人设置"
                  : pageTitle + "功能规划"
            }}
          </h3>

          <div v-if="currentPage === 'sensor'" class="health-page health-dashboard-page">
            <div class="health-toolbar">
              <div class="health-actions">
                <button type="button" @click="resetHealthZoom">重置缩放</button>
                <button type="button" @click="exportHeartOxygenTable">导出心率血氧</button>
                <button type="button" @click="exportBodyTemperatureTable">导出体温</button>
                <button type="button" @click="exportHealthAlarmTable">导出异常预警</button>
              </div>
              <div class="health-export-tip">可分别导出心率血氧、体温和异常预警 CSV 表格</div>
            </div>

            <div class="health-range-tabs">
              <button
                v-for="item in healthRangeOptions"
                :key="item.value"
                type="button"
                :class="{ active: selectedHealthRange === item.value }"
                @click="selectHealthRange(item.value)"
              >
                {{ item.label }}
              </button>
            </div>

            <div class="health-stat-grid">
              <div class="health-stat-card">
                <span>心率</span>
                <strong>{{ formatHeartRate(device.heartRate) }}</strong>
              </div>
              <div class="health-stat-card">
                <span>血氧</span>
                <strong>{{ formatBloodOxygen(device.bloodOxygen) }}</strong>
              </div>
              <div class="health-stat-card">
                <span>体温</span>
                <strong>{{ formatBodyTemp(device.bodyTemperature) }}</strong>
              </div>
              <div class="health-stat-card">
                <span>异常预警</span>
                <strong>{{ healthAlarms.length }} 条</strong>
              </div>
            </div>

            <div class="health-chart-grid">
              <section class="health-chart-panel health-visual-panel">
                <h3>健康监测数据</h3>
                <div v-if="!hasHealthTrendData" class="mini-empty">
                  暂无心率或血氧检测数据
                </div>
                <div
                  v-show="hasHealthTrendData"
                  ref="heartChartRef"
                  class="health-chart dashboard-health-chart"
                ></div>
              </section>

              <section class="health-chart-panel health-visual-panel">
                <h3>体温历史数据曲线</h3>
                <div v-if="bodyTempList.length === 0" class="mini-empty">
                  暂无体温检测数据
                </div>
                <div
                  v-show="bodyTempList.length > 0"
                  ref="bodyChartRef"
                  class="health-chart dashboard-health-chart"
                ></div>
              </section>
            </div>

            <div class="health-data-grid">
              <section class="health-table-panel">
                <h3>健康检测数据表</h3>
                <div v-if="healthExportRows.length === 0" class="empty">
                  暂无可导出的健康检测数据
                </div>
                <div v-else class="health-table-wrap">
                  <table class="health-table">
                    <thead>
                      <tr>
                        <th>日期</th>
                        <th>时间</th>
                        <th>心率(bpm)</th>
                        <th>血氧(%)</th>
                        <th>体温(°C)</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-for="(row, index) in healthExportRows" :key="index">
                        <td>{{ row.date }}</td>
                        <td>{{ row.time }}</td>
                        <td>{{ row.heartRate }}</td>
                        <td>{{ row.bloodOxygen }}</td>
                        <td>{{ row.bodyTemperature }}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </section>

              <section class="detail-alarm-panel">
                <h3>最近异常预警</h3>
                <div v-if="healthAlarms.length === 0" class="empty">
                  暂无健康异常预警
                </div>
                <div class="alarm" v-for="(item, index) in healthAlarms" :key="index">
                  <div class="alarm-title">
                    {{ item.time }}　{{ item.type }}
                  </div>
                  <div class="alarm-msg">
                    {{ item.message }}
                  </div>
                </div>
              </section>
            </div>
          </div>

          <div v-else-if="false && currentPage === 'sensor'" class="health-page">
  <div v-if="!healthDetail">
    <div class="health-cards">

      <div class="health-card todo" @click="openHealthDetail('heart')">
        <div class="health-icon">❤️</div>
        <h3>心率</h3>
        <div class="health-value">{{ formatHeartRate(device.heartRate) }}</div>
        <p>点击查看心率历史曲线和最近异常预警。</p>

        <div class="mini-chart-title">历史心率曲线</div>
        <div v-if="heartRateList.length === 0" class="mini-empty">
          暂无心率数据
        </div>
        <div
          v-show="heartRateList.length > 0"
          ref="heartChartRef"
          class="health-chart mini-health-chart"
        ></div>
      </div>

      <div class="health-card todo" @click="openHealthDetail('oxygen')">
        <div class="health-icon">🩸</div>
        <h3>血氧</h3>
        <div class="health-value">{{ formatBloodOxygen(device.bloodOxygen) }}</div>
        <p>点击查看血氧历史曲线和最近异常预警。</p>

        <div class="mini-chart-title">历史血氧曲线</div>
        <div v-if="bloodOxygenList.length === 0" class="mini-empty">
          暂无血氧数据
        </div>
        <div
          v-show="bloodOxygenList.length > 0"
          ref="oxygenChartRef"
          class="health-chart mini-health-chart"
        ></div>
      </div>

      <div class="health-card active-health" @click="openHealthDetail('body')">
        <div class="health-icon">🌡️</div>
        <h3>体温</h3>
        <div class="health-value">{{ formatBodyTemp(device.bodyTemperature) }}</div>
        <p>点击查看体温历史曲线和最近异常预警。</p>

        <div class="mini-chart-title">历史体温曲线</div>
        <div v-if="bodyTempList.length === 0" class="mini-empty">
          暂无体温数据
        </div>
        <div
          v-show="bodyTempList.length > 0"
          ref="bodyChartRef"
          class="health-chart mini-health-chart"
        ></div>
      </div>

    </div>
  </div>

  <div v-else class="health-detail-page">
    <button class="back-btn" @click="closeHealthDetail">
      ← 返回健康检测
    </button>

    <div class="health-chart-panel detail-chart-panel">
      <h3>{{ detailTitle }}历史数据曲线</h3>

      <div v-if="healthDetail === 'heart'">
        <div v-if="heartRateList.length === 0" class="empty">
          暂无心率检测数据
        </div>
        <div
          v-show="heartRateList.length > 0"
          ref="heartChartRef"
          class="health-chart detail-health-chart"
        ></div>
      </div>

      <div v-if="healthDetail === 'oxygen'">
        <div v-if="bloodOxygenList.length === 0" class="empty">
          暂无血氧检测数据
        </div>
        <div
          v-show="bloodOxygenList.length > 0"
          ref="oxygenChartRef"
          class="health-chart detail-health-chart"
        ></div>
      </div>

      <div v-if="healthDetail === 'body'">
        <div v-if="bodyTempList.length === 0" class="empty">
          暂无体温检测数据
        </div>
        <div
          v-show="bodyTempList.length > 0"
          ref="bodyChartRef"
          class="health-chart detail-health-chart"
        ></div>
      </div>
    </div>

    <div class="detail-alarm-panel">
      <h3>{{ detailTitle }}最近异常预警</h3>

      <div v-if="detailAlarms.length === 0" class="empty">
        暂无{{ detailTitle }}异常预警
      </div>

      <div class="alarm" v-for="(item, index) in detailAlarms" :key="index">
        <div class="alarm-title">
          {{ item.time }}　{{ item.type }}
        </div>
        <div class="alarm-msg">
          {{ item.message }}
        </div>
      </div>
    </div>
  </div>
</div>

          <div v-else-if="currentPage === 'medicine'" class="medicine-slots">
            <div
              class="medicine-slot-card"
              v-for="(slot, slotIndex) in medicineSlots"
              :key="slotIndex"
            >
              <div class="slot-title">
                <h3>{{ slot.title }}</h3>
              </div>

              <div class="medicine-time-grid">
                <label>
                  最早用药时间
                  <input v-model="slot.earliestTime" type="time" />
                </label>
                <label>
                  提醒用药时间
                  <input v-model="slot.reminderTime" type="time" />
                </label>
                <label>
                  最晚用药时间
                  <input v-model="slot.latestTime" type="time" />
                </label>
              </div>

              <label>
                药品名称
                <select
                  v-model="slot.boxId"
                  :disabled="boxMedicineOptions.length === 0"
                >
                  <option value="">
                    {{ boxMedicineOptions.length === 0 ? "请先在药仓管理添加药品" : "请选择药仓药品" }}
                  </option>
                  <option
                    v-for="item in boxMedicineOptions"
                    :key="item.id"
                    :value="item.id"
                  >
                    {{ item.title }}：{{ item.name }}（剩余 {{ item.quantity || 0 }}）
                  </option>
                </select>
              </label>

              <label>
                用药剂量
                <input
                  v-model.number="slot.doseCount"
                  type="number"
                  min="1"
                  max="99"
                  step="1"
                  placeholder="请输入一次吃几粒，例如：1"
                />
              </label>

              <button @click="addMedicinePlan(slotIndex)">
                添加到该时间
              </button>

              <div v-if="slot.plans.length === 0" class="empty">
                该时间暂无用药计划
              </div>

              <div
                class="medicine-item"
                v-for="(item, planIndex) in slot.plans"
                :key="planIndex"
              >
                <div>
                  <b>{{ slot.reminderTime }}</b>
                  <span>{{ item.boxName || (item.boxId ? `第 ${item.boxId} 药仓` : "未关联药仓") }} · {{ item.name }}　{{ item.dose }}</span>
                </div>

                <button
                  class="delete-btn"
                  @click="deleteMedicinePlan(slotIndex, planIndex)"
                >
                  删除
                </button>
              </div>
            </div>
            <div class="medicine-save-row">
  <button class="save-all-btn" @click="saveMedicineData">
    保存用药计划并同步到药盒
  </button>
</div>
          </div>
          
          

          <div v-else-if="currentPage === 'library'" class="medicine-library-page">
            <div class="library-toolbar">
              <div>
                <span class="record-eyebrow">AI MEDICINE LIBRARY</span>
                <h3>智能药品库</h3>
                <p>用 AI 检索补全药品资料，人工核对后保存为本地药品卡片。</p>
              </div>
              <div class="library-actions">
                <input
                  v-model.trim="medicineLibrarySearch"
                  type="search"
                  placeholder="搜索药品名称、分类或别名"
                />
                <button type="button" class="secondary-action" @click="loadMedicineLibrary">
                  刷新
                </button>
                <button type="button" class="primary-action" @click="openAddMedicineDialog">
                  添加药品
                </button>
              </div>
            </div>

            <div class="library-stat-grid">
              <section class="library-stat-card">
                <span>药品总数</span>
                <strong>{{ medicineLibrary.length }}</strong>
              </section>
              <section class="library-stat-card">
                <span>AI 生成</span>
                <strong>{{ medicineLibraryAiCount }}</strong>
              </section>
              <section class="library-stat-card">
                <span>人工编辑</span>
                <strong>{{ medicineLibraryManualCount }}</strong>
              </section>
            </div>

            <div v-if="medicineLibraryLoading" class="empty">
              正在加载药品库...
            </div>
            <div v-else-if="filteredMedicineLibrary.length === 0" class="library-empty-state">
              <strong>{{ medicineLibrarySearch ? "没有匹配的药品" : "药品库还是空的" }}</strong>
              <p>{{ medicineLibrarySearch ? "换个关键词试试，或添加一个新药品。" : "点击“添加药品”，输入名称后用 AI 检索补全，也可以手动录入。" }}</p>
              <button type="button" class="primary-action" @click="openAddMedicineDialog">
                添加药品
              </button>
            </div>
            <div v-else class="medicine-library-grid">
              <button
                v-for="item in filteredMedicineLibrary"
                :key="item.id"
                type="button"
                class="medicine-library-card"
                @click="openMedicineDetail(item)"
              >
                <div class="library-card-top">
                  <span>{{ item.aiGenerated ? "AI 检索" : "人工录入" }}</span>
                  <i>{{ formatLibraryDate(item.updatedAt) }}</i>
                </div>
                <h3>{{ item.name }}</h3>
                <p class="library-card-category">{{ item.category || "未分类" }}</p>
                <p>{{ item.summary || "点击查看和编辑药品信息。" }}</p>
                <div class="library-card-tags">
                  <span v-for="tag in medicineCardTags(item)" :key="tag">{{ tag }}</span>
                </div>
              </button>
            </div>

            <p class="library-safety-note">
              本药品库内容仅用于药品科普展示，不构成诊断、治疗或用药建议。AI 生成内容请人工核对后使用。
            </p>
          </div>

          <div v-else-if="currentPage === 'reminder'" class="medication-record-page">
            <div class="record-toolbar">
              <div>
                <span class="record-eyebrow">本月用药档案</span>
                <h3>{{ currentMonthLabel }}</h3>
                <p>按早餐、午餐、晚餐记录每日服药情况</p>
              </div>
              <div class="record-actions">
                <button type="button" class="secondary-action" @click="exportMedicationCsv">
                  导出明细
                </button>
                <button type="button" class="primary-action" @click="exportMedicationChart">
                  导出图表
                </button>
              </div>
            </div>

            <div class="record-summary-grid">
              <section class="record-summary-card success-summary">
                <span>服药成功</span>
                <strong>{{ monthlyMedicationStats.done }}</strong>
                <small>截至当前时间的成功次数</small>
              </section>
              <section class="record-summary-card due-summary">
                <span>应服总次数</span>
                <strong>{{ monthlyMedicationStats.total }}</strong>
                <small>仅统计已经到服药时间的计划</small>
              </section>
              <section class="record-summary-card rate-summary">
                <span>本月服药成功率</span>
                <div class="rate-summary-content">
                  <strong>{{ monthlyMedicationStats.percent }}%</strong>
                  <div class="rate-progress" aria-hidden="true">
                    <span :style="{ width: `${monthlyMedicationStats.percent}%` }"></span>
                  </div>
                </div>
                <small>{{ monthlyMedicationStats.done }}/{{ monthlyMedicationStats.total }} 次</small>
              </section>
            </div>

            <div class="record-content-grid">
              <section class="medication-calendar-panel">
                <div class="calendar-heading">
                  <div>
                    <h3>每日三餐用药日历</h3>
                    <p>点击已到时间的餐次，可切换服药状态</p>
                  </div>
                  <div class="calendar-legend">
                    <span><i class="legend-dot taken-dot"></i>已服药</span>
                    <span><i class="legend-dot missed-dot"></i>未服药</span>
                    <span><i class="legend-dot pending-dot"></i>待记录</span>
                  </div>
                </div>

                <div class="calendar-weekdays">
                  <span v-for="weekday in calendarWeekdays" :key="weekday">{{ weekday }}</span>
                </div>

                <div class="medication-calendar">
                  <div
                    v-for="cell in medicationCalendarCells"
                    :key="cell.key"
                    class="calendar-day"
                    :class="{
                      blank: cell.blank,
                      today: cell.isToday,
                      future: cell.isFuture
                    }"
                  >
                    <template v-if="!cell.blank">
                      <div class="calendar-date">
                        <strong>{{ cell.day }}</strong>
                        <span v-if="cell.isToday">今天</span>
                      </div>
                      <div class="meal-status-list">
                        <button
                          v-for="meal in cell.meals"
                          :key="meal.key"
                          type="button"
                          class="meal-status"
                          :class="meal.status"
                          :disabled="!meal.scheduled || meal.status === 'future'"
                          :title="meal.title"
                          @click="cycleMedicationStatus(meal)"
                        >
                          <span class="meal-name">{{ meal.shortLabel }}</span>
                          <span class="meal-state">{{ medicationStatusLabel(meal) }}</span>
                        </button>
                      </div>
                    </template>
                  </div>
                </div>
              </section>

              <aside class="record-side-panel">
                <section class="meal-plan-panel">
                  <div class="side-panel-heading">
                    <h3>三餐用药计划</h3>
                    <span>{{ scheduledMealCount }}/3 已设置</span>
                  </div>
                  <div class="meal-plan-list">
                    <div v-for="meal in mealDefinitions" :key="meal.id" class="meal-plan-row">
                      <div class="meal-plan-icon" :class="meal.id">{{ meal.shortLabel }}</div>
                      <div>
                        <b>{{ meal.label }} · {{ meal.time }}</b>
                        <span>{{ meal.description }}</span>
                      </div>
                    </div>
                  </div>
                </section>

                <section class="monthly-chart-panel">
                  <div class="side-panel-heading">
                    <div>
                      <h3>本月服药趋势</h3>
                      <p>每日成功次数与应服次数</p>
                    </div>
                  </div>
                  <div ref="medicationChartRef" class="medication-chart"></div>
                </section>
              </aside>
            </div>
          </div>

          <div v-else-if="currentPage === 'family'" class="medicine-video-page">
            <div class="video-toolbar">
              <div>
                <span class="record-eyebrow">用药过程留证</span>
                <h3>用药视频记录</h3>
                <p>ESP32-CAM 在开始用药时创建录像会话，仅保留近 7 天记录，过期视频会自动删除。</p>
              </div>
              <button type="button" class="secondary-action" @click="loadMedicineVideoSessions">
                刷新列表
              </button>
            </div>

            <section class="esp32-live-panel">
              <div class="esp32-live-heading">
                <div>
                  <span class="record-eyebrow">实时摄像头</span>
                  <h3>ESP32-CAM 实时画面</h3>
                  <p>{{ esp32camState.controlEnabled ? (esp32camState.online ? "正在接收摄像头画面" : "等待 ESP32-CAM 上传画面") : "监控已关闭，摄像头不会在页面显示" }}</p>
                </div>
                <div class="esp32-live-actions">
                  <button
                    type="button"
                    class="esp32-control-button"
                    :class="{ active: esp32camState.manualControlEnabled }"
                    :disabled="esp32camControlSaving"
                    @click="toggleEsp32camControl"
                  >
                    {{ esp32camControlSaving ? "设置中..." : esp32camState.manualControlEnabled ? "关闭监控" : "开启监控" }}
                  </button>
                  <span class="esp32-live-badge" :class="{ online: esp32camState.online }">
                    {{ esp32camState.online ? "在线" : "离线" }}
                  </span>
                </div>
              </div>

              <div class="esp32-live-grid">
                <div class="esp32-live-viewer">
                  <img
                    v-if="esp32camState.controlEnabled"
                    :key="esp32camStreamKey"
                    :src="esp32camMjpegUrl"
                    alt="ESP32-CAM 实时画面"
                    @error="refreshEsp32camStream"
                  />
                  <div v-else class="esp32-live-placeholder">
                    <b>监控已关闭</b>
                    <span>开启后才会连接 ESP32-CAM 实时画面</span>
                  </div>
                </div>
                <div class="esp32-live-stats">
                  <div>
                    <b>{{ esp32camState.deviceId || "ESP32-CAM 01" }}</b>
                    <span>设备编号</span>
                  </div>
                  <div>
                    <b>{{ esp32camState.frameCount || 0 }}</b>
                    <span>画面帧数</span>
                  </div>
                  <div>
                    <b>{{ formatFps(esp32camState.currentFps) }}</b>
                    <span>实时帧率</span>
                  </div>
                  <div>
                    <b>{{ formatEsp32camUploadMode(esp32camState.uploadMode) }}</b>
                    <span>上传方式</span>
                  </div>
                  <div>
                    <b>{{ formatFileSize(esp32camState.lastFrameSize) }}</b>
                    <span>最近图像大小</span>
                  </div>
                  <div>
                    <b>{{ esp32camState.streamClients || 0 }}</b>
                    <span>观看人数</span>
                  </div>
                  <div class="wide">
                    <b>{{ formatEsp32camTime(esp32camState.lastFrameAt) }}</b>
                    <span>最近上传时间</span>
                  </div>
                  <a class="esp32-open-link" :href="`${SERVER_HTTP}/esp32cam/`" target="_blank" rel="noreferrer">
                    打开独立查看页
                  </a>
                </div>
              </div>
            </section>

            <div class="video-layout">
              <aside class="video-list-panel">
                <div v-if="medicineVideoSessions.length === 0" class="empty">
                  近 7 天暂无用药录像
                </div>
                <div
                  v-for="session in medicineVideoSessions"
                  :key="session.id"
                  class="video-list-item"
                  :class="{ active: selectedVideoSessionId === session.id }"
                >
                  <button
                    type="button"
                    class="video-list-main"
                    @click="selectVideoSession(session.id)"
                  >
                    <img
                      v-if="session.thumbnailUrl"
                      :key="videoSessionAssetKey(session)"
                      :src="videoAssetUrl(session.thumbnailUrl, videoSessionAssetKey(session))"
                      alt=""
                    />
                    <span v-else class="video-thumb-placeholder">视频</span>
                    <span>
                      <strong>{{ session.title || "用药录像" }}</strong>
                      <small>{{ formatVideoSessionMeta(session) }}</small>
                    </span>
                    <i :class="{ recording: session.status === 'recording' }">
                      {{ session.status === "recording" ? "录制中" : "已完成" }}
                    </i>
                  </button>
                  <button
                    type="button"
                    class="video-delete-button"
                    :disabled="session.status === 'recording' || deletingVideoSessionId === session.id"
                    @click="deleteMedicineVideoSession(session)"
                  >
                    {{ deletingVideoSessionId === session.id ? "删除中" : "删除" }}
                  </button>
                </div>
              </aside>

              <section class="video-viewer-panel">
                <div v-if="!selectedVideoSession" class="empty video-empty">
                  请选择一条录像进行查看
                </div>

                <template v-else>
                  <div class="video-viewer-heading">
                    <div>
                      <h3>{{ selectedVideoSession.title || "用药录像" }}</h3>
                      <p>{{ formatVideoSessionDetail(selectedVideoSession) }}</p>
                    </div>
                    <div class="video-viewer-actions">
                      <span>{{ selectedVideoSession.frameCount || 0 }} 帧</span>
                      <button
                        type="button"
                        class="video-delete-button"
                        :disabled="selectedVideoSession.status === 'recording' || deletingVideoSessionId === selectedVideoSession.id"
                        @click="deleteMedicineVideoSession(selectedVideoSession)"
                      >
                        {{ deletingVideoSessionId === selectedVideoSession.id ? "删除中" : "删除录像" }}
                      </button>
                    </div>
                  </div>

                  <div class="video-player">
                    <video
                      v-if="selectedVideoSession.videoUrl"
                      :key="videoSessionAssetKey(selectedVideoSession)"
                      controls
                      :src="videoAssetUrl(selectedVideoSession.videoUrl, videoSessionAssetKey(selectedVideoSession))"
                    ></video>
                    <img
                      v-else-if="currentVideoFrame"
                      :key="currentVideoFrameKey"
                      :src="videoAssetUrl(currentVideoFrame.url, currentVideoFrameKey)"
                      alt="用药过程画面"
                    />
                    <div v-else class="video-frame-empty">
                      等待 ESP32-CAM 上传画面
                    </div>
                  </div>

                  <div
                    v-if="selectedVideoSession.frames && selectedVideoSession.frames.length > 0"
                    class="frame-control"
                  >
                    <button type="button" @click="stepVideoFrame(-1)">上一帧</button>
                    <button type="button" class="primary-action" @click="toggleFramePlayback">
                      {{ isVideoPlaying ? "暂停" : "播放" }}
                    </button>
                    <button type="button" @click="stepVideoFrame(1)">下一帧</button>
                    <input
                      v-model.number="activeVideoFrameIndex"
                      type="range"
                      min="0"
                      :max="selectedVideoSession.frames.length - 1"
                    />
                    <span>
                      {{ activeVideoFrameIndex + 1 }}/{{ selectedVideoSession.frames.length }}
                    </span>
                  </div>
                </template>
              </section>
            </div>
          </div>

          <div v-else-if="currentPage === 'box'" class="feature-page">
            <div class="feature-grid box-grid">
              <section
                class="feature-card box-slot-card"
                v-for="slot in boxSlots"
                :key="slot.id"
              >
                <div class="box-slot-title">
                  <h3>{{ slot.title }}</h3>
                  <span :class="{ emptyBox: !slot.name }">
                    {{ slot.name ? "已加药" : "空仓" }}
                  </span>
                </div>

                <div class="box-form">
                  <label>
                    药品名称
                    <select
                      v-model="slot.medicineId"
                      :disabled="medicineLibrary.length === 0"
                      @change="handleBoxMedicineSelect(slot)"
                    >
                      <option value="">
                        {{ medicineLibrary.length === 0 ? "请先在药品库添加药品" : "请选择药品库中的药品" }}
                      </option>
                      <option
                        v-if="slot.name && !findMedicineLibraryItem(slot.medicineId)"
                        :value="slot.medicineId || `legacy:${slot.name}`"
                      >
                        {{ slot.name }}（原有药品）
                      </option>
                      <option
                        v-for="medicine in medicineLibrary"
                        :key="medicine.id"
                        :value="medicine.id"
                      >
                        {{ medicine.name }}{{ medicine.category ? ` · ${medicine.category}` : "" }}
                      </option>
                    </select>
                    <small v-if="medicineLibrary.length === 0" class="box-library-tip">
                      请先进入“药品库”添加药品，再回到药仓管理选择。
                    </small>
                  </label>

                  <label>
                    剩余药量
                    <input
                      v-model.number="slot.quantity"
                      type="number"
                      min="0"
                      placeholder="例如：20"
                    />
                  </label>

                  <label>
                    低库存阈值
                    <input
                      v-model.number="slot.lowThreshold"
                      type="number"
                      min="0"
                      placeholder="例如：5"
                    />
                  </label>
                </div>

              </section>
            </div>

            <div class="medicine-save-row">
              <button class="save-all-btn" type="button" @click="saveBoxSlots">
                保存药仓信息并同步到药盒
              </button>
            </div>

            <section class="box-record-panel">
              <div class="box-record-heading">
                <div>
                  <h3>加药记录</h3>
                  <p>共 {{ medicinePutRecords.length }} 条</p>
                </div>
                <button type="button" class="secondary-action" @click="exportMedicinePutRecords">
                  导出表格
                </button>
              </div>

              <div v-if="medicinePutRecords.length === 0" class="empty">
                暂无加药记录
              </div>
              <div v-else class="health-table-wrap box-record-table-wrap">
                <table class="health-table box-record-table">
                  <thead>
                    <tr>
                      <th>加药日期时间</th>
                      <th>药仓号</th>
                      <th>药品名称</th>
                      <th>加药数量</th>
                      <th>加药后库存</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="record in medicinePutRecords" :key="record.id || `${record.recordedAt}-${record.boxId}`">
                      <td>{{ formatDateTime(record.recordedAt) }}</td>
                      <td>第 {{ record.boxId }} 药仓</td>
                      <td>{{ record.medicineName || "--" }}</td>
                      <td>{{ record.putCount }}</td>
                      <td>{{ record.after }}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </section>
          </div>

          <div v-else-if="currentPage === 'identity'" class="identity-page">
            <section class="identity-hero">
              <div class="identity-avatar">{{ medicineUser.name ? medicineUser.name.slice(0, 1) : "用" }}</div>
              <div>
                <span class="identity-eyebrow">USER IDENTITY</span>
                <h2>{{ medicineUser.name || "请完善用户信息" }}</h2>
                <p>用户资料与人脸身份会同步到智能药盒，用于安全用药身份核验。</p>
              </div>
              <span class="face-status" :class="{ registered: identityStatus.faceRegistered }">
                {{ identityStatus.faceRegistered ? "已注册" : "未注册" }}
              </span>
            </section>

            <div class="identity-grid">
              <section class="identity-card">
                <div class="identity-card-title">
                  <span>01</span>
                  <div><h3>用户信息</h3><p>保存后同步给星火开发板</p></div>
                </div>
                <label>用户姓名
                  <input v-model.trim="medicineUser.name" maxlength="30" placeholder="请输入用户姓名"
                    @input="identityDirty = true" />
                </label>
                <label>手机号码
                  <input v-model.trim="medicineUser.phone" type="tel" inputmode="numeric" maxlength="11"
                    placeholder="请输入11位手机号码"
                    @input="medicineUser.phone = medicineUser.phone.replace(/\D/g, ''); identityDirty = true" />
                </label>
                <button class="identity-primary-btn" type="button" :disabled="savingIdentity" @click="saveIdentity">
                  {{ savingIdentity ? "保存中..." : "保存用户信息" }}
                </button>
              </section>

              <section class="identity-card face-register-card">
                <div class="identity-card-title">
                  <span>02</span>
                  <div><h3>人脸身份</h3><p>K230 人脸识别授权</p></div>
                </div>
                <div class="face-device-row">
                  <div class="face-device-icon">⌾</div>
                  <div><strong>K230 人脸模块</strong><p>{{ identityStatus.message }}</p></div>
                  <i :class="{ online: identityStatus.deviceOnline }"></i>
                </div>
                <div class="face-state-row">
                  <span>注册状态</span>
                  <strong :class="{ success: identityStatus.faceRegistered }">
                    {{ faceStatusText }}
                  </strong>
                </div>
                <button class="identity-primary-btn face-btn" type="button"
                  :disabled="faceOperationBusy" @click="openFaceRegisterDialog">
                  {{ faceOperationBusy ? "处理中..." : identityStatus.faceRegistered ? "重新注册人脸" : "注册人脸" }}
                </button>
                <p class="face-help">点击后输入 K230 编辑密码，并正对摄像头完成人脸采集。</p>
              </section>
            </div>

            <section class="identity-card face-users-card">
              <div class="identity-card-title">
                <span>03</span>
                <div><h3>已注册人脸</h3><p>来自 K230 人脸数据库</p></div>
                <button class="face-refresh-btn" type="button" :disabled="faceOperationBusy" @click="openFaceRefreshDialog">
                  {{ faceOperationBusy ? "处理中..." : "刷新名单" }}
                </button>
              </div>
              <div v-if="registeredFaceUsers.length" class="face-users-list">
                <div v-for="name in registeredFaceUsers" :key="name" class="face-user-item">
                  <div class="face-user-avatar">{{ name.slice(0, 1) }}</div>
                  <div>
                    <strong>{{ name }}</strong>
                    <p>{{ name === medicineUser.name ? "当前用户" : "K230 已授权人脸" }}</p>
                  </div>
                  <button class="face-delete-btn" type="button" :disabled="faceOperationBusy" @click="openFaceDeleteDialog(name)">
                    删除
                  </button>
                </div>
              </div>
              <div v-else class="face-users-empty">
                <strong>暂无人脸名单</strong>
                <p>点击刷新名单，从 K230 读取已经注册的人脸信息。</p>
              </div>
            </section>
          </div>

          <div v-else-if="currentPage === 'settings'" class="feature-page">
            <section class="settings-page-panel">
              <div class="settings-heading">
                <div>
                  <span class="record-eyebrow">系统参数</span>
                  <h3>报警阈值与家属联系人</h3>
                  <p>设置健康和环境报警阈值，并保存家属联系人信息用于异常提醒。</p>
                </div>
                <button class="settings-save-btn" type="button" @click="saveAppSettingsToServer">
                  保存设置
                </button>
              </div>

              <div class="settings-section">
                <div class="settings-section-title">
                  <span>01</span>
                  <div>
                    <h4>健康报警阈值</h4>
                    <p>体温达到阈值后，页面会展示对应异常状态。</p>
                  </div>
                </div>
                <div class="settings-grid">
                  <label>
                    低热阈值
                    <input v-model.number="appSettings.lowFeverLimit" type="number" step="0.1" />
                    <small>单位：°C</small>
                  </label>
                  <label>
                    发热阈值
                    <input v-model.number="appSettings.feverLimit" type="number" step="0.1" />
                    <small>单位：°C</small>
                  </label>
                </div>
              </div>

              <div class="settings-section">
                <div class="settings-section-title">
                  <span>02</span>
                  <div>
                    <h4>药盒环境报警</h4>
                    <p>用于判断药盒环境是否可能影响药品保存。</p>
                  </div>
                </div>
                <div class="settings-grid">
                  <label>
                    温度报警
                    <input v-model.number="appSettings.envTempLimit" type="number" step="0.1" />
                    <small>单位：°C</small>
                  </label>
                  <label>
                    湿度报警
                    <input v-model.number="appSettings.humidityLimit" type="number" step="1" />
                    <small>单位：%</small>
                  </label>
                </div>
              </div>

              <div class="settings-section">
                <div class="settings-section-title">
                  <span>03</span>
                  <div>
                    <h4>家属联系人</h4>
                    <p>保存后用于页面展示和后续通知扩展。</p>
                  </div>
                </div>
                <div class="settings-grid">
                  <label>
                    家属姓名
                    <input v-model="appSettings.familyName" placeholder="请输入家属姓名" />
                  </label>
                  <label>
                    家属电话
                    <input v-model="appSettings.familyPhone" type="tel" inputmode="numeric" placeholder="请输入联系电话" />
                  </label>
                </div>
              </div>
            </section>
          </div>
        </div>
      </div>
    </main>

    <div
      v-if="showMedicineLibraryDialog"
      class="identity-modal-backdrop"
      @click.self="closeMedicineLibraryDialog"
    >
      <section class="medicine-library-modal">
        <button class="identity-modal-close" type="button" @click="closeMedicineLibraryDialog">×</button>
        <div class="library-modal-heading">
          <div>
            <span class="record-eyebrow">{{ medicineDialogMode === "create" ? "ADD MEDICINE" : "MEDICINE DETAIL" }}</span>
            <h3>{{ medicineDialogMode === "create" ? "添加药品" : "药品详情" }}</h3>
            <p>AI 检索结果会先进入可编辑草稿，确认无误后再保存到药品库。</p>
          </div>
          <span class="library-source-badge">
            {{ medicineForm.aiGenerated ? "AI 生成" : "人工编辑" }}
          </span>
        </div>

        <div class="library-ai-row">
          <input
            v-model.trim="aiSearchName"
            placeholder="输入药品名称，例如：布洛芬"
            @keyup.enter="searchMedicineByAi"
          />
          <button
            type="button"
            class="primary-action"
            :disabled="aiSearching"
            @click="searchMedicineByAi"
          >
            {{ aiSearching ? "检索中..." : "AI 检索补全" }}
          </button>
        </div>
        <p v-if="medicineAiMessage" class="library-ai-message" :class="{ error: medicineAiMessageType === 'error' }">
          {{ medicineAiMessage }}
        </p>

        <div class="library-form-grid">
          <label>
            药品名称
            <input v-model.trim="medicineForm.name" placeholder="请输入药品名称" />
          </label>
          <label>
            通用名
            <input v-model.trim="medicineForm.genericName" placeholder="可选" />
          </label>
          <label>
            分类
            <input v-model.trim="medicineForm.category" placeholder="例如：解热镇痛药" />
          </label>
          <label>
            别名/商品名
            <textarea v-model="medicineForm.aliases" rows="2" placeholder="每行一条"></textarea>
          </label>
          <label class="wide">
            药品简介
            <textarea v-model="medicineForm.summary" rows="4" placeholder="简要说明该药品的公开说明书信息"></textarea>
          </label>
          <label>
            主要用途
            <textarea v-model="medicineForm.uses" rows="4" placeholder="每行一条"></textarea>
          </label>
          <label>
            常见剂型
            <textarea v-model="medicineForm.dosageForms" rows="4" placeholder="每行一条"></textarea>
          </label>
          <label>
            禁忌
            <textarea v-model="medicineForm.contraindications" rows="4" placeholder="每行一条"></textarea>
          </label>
          <label>
            不良反应
            <textarea v-model="medicineForm.adverseReactions" rows="4" placeholder="每行一条"></textarea>
          </label>
          <label class="wide">
            注意事项
            <textarea v-model="medicineForm.warnings" rows="4" placeholder="每行一条"></textarea>
          </label>
          <label class="wide">
            资料来源
            <textarea v-model="medicineForm.sourcesText" rows="3" placeholder="每行一条，可写：标题 | 链接"></textarea>
          </label>
        </div>

        <p class="library-safety-note in-modal">
          本内容仅用于药品科普展示，不构成诊断、治疗或用药建议。具体用药请咨询医生或药师。
        </p>

        <div class="identity-modal-actions library-modal-actions">
          <button type="button" class="modal-cancel" @click="closeMedicineLibraryDialog">取消</button>
          <button
            v-if="medicineDialogMode === 'edit'"
            type="button"
            class="identity-primary-btn danger-btn"
            :disabled="savingMedicine"
            @click="deleteMedicineLibraryItem"
          >
            删除
          </button>
          <button
            type="button"
            class="identity-primary-btn"
            :disabled="savingMedicine"
            @click="saveMedicineLibraryItem"
          >
            {{ savingMedicine ? "保存中..." : "保存到药品库" }}
          </button>
        </div>
      </section>
    </div>

    <div v-if="showFaceDialog" class="identity-modal-backdrop" @click.self="closeFaceRegisterDialog">
      <section class="identity-modal">
        <button class="identity-modal-close" type="button" @click="closeFaceRegisterDialog">×</button>
        <div class="modal-face-icon">⌾</div>
        <h3>注册人脸</h3>
        <p>请输入 K230 编辑密码。提交后请面向摄像头，保持光线充足。</p>
        <label>K230 编辑密码
          <input v-model="facePassword" type="password" maxlength="64" autocomplete="off"
            placeholder="请输入密码" @keyup.enter="submitFaceRegistration" />
        </label>
        <div class="identity-modal-actions">
          <button type="button" class="modal-cancel" @click="closeFaceRegisterDialog">取消</button>
          <button type="button" class="identity-primary-btn" @click="submitFaceRegistration">开始注册</button>
        </div>
      </section>
    </div>

    <div v-if="showRegisterSuccess" class="identity-modal-backdrop">
      <section class="identity-modal success-modal">
        <div class="success-check">✓</div>
        <h3>注册成功</h3>
        <p>{{ medicineUser.name }} 的人脸身份已录入 K230。</p>
        <button class="identity-primary-btn" type="button" @click="showRegisterSuccess = false">我知道了</button>
      </section>
    </div>

    <div v-if="showFaceRefreshDialog" class="identity-modal-backdrop" @click.self="closeFaceRefreshDialog">
      <section class="identity-modal">
        <button class="identity-modal-close" type="button" @click="closeFaceRefreshDialog">×</button>
        <div class="modal-face-icon">⌾</div>
        <h3>刷新人脸名单</h3>
        <p>请输入 K230 编辑密码，确认后从 K230 读取已经注册的人脸信息。</p>
        <label>K230 编辑密码
          <input v-model="refreshFacePassword" type="password" maxlength="64" autocomplete="off"
            placeholder="请输入密码" @keyup.enter="refreshFaceUsers" />
        </label>
        <div class="identity-modal-actions">
          <button type="button" class="modal-cancel" @click="closeFaceRefreshDialog">取消</button>
          <button type="button" class="identity-primary-btn" :disabled="faceOperationBusy" @click="refreshFaceUsers">
            确认刷新
          </button>
        </div>
      </section>
    </div>

    <div v-if="showFaceDeleteDialog" class="identity-modal-backdrop" @click.self="closeFaceDeleteDialog">
      <section class="identity-modal">
        <button class="identity-modal-close" type="button" @click="closeFaceDeleteDialog">×</button>
        <div class="modal-face-icon danger">−</div>
        <h3>删除人脸</h3>
        <p>请输入 K230 编辑密码，确认删除 {{ deleteFaceName }} 的人脸信息。</p>
        <label>K230 编辑密码
          <input v-model="deleteFacePassword" type="password" maxlength="64" autocomplete="off"
            placeholder="请输入密码" @keyup.enter="submitFaceDelete" />
        </label>
        <div class="identity-modal-actions">
          <button type="button" class="modal-cancel" @click="closeFaceDeleteDialog">取消</button>
          <button type="button" class="identity-primary-btn danger-btn" :disabled="faceOperationBusy" @click="submitFaceDelete">
            确认删除
          </button>
        </div>
      </section>
    </div>
  </div>
</template>

<script setup>
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from "vue";
import { io } from "socket.io-client";
import * as echarts from "echarts";

const detailTitle = computed(() => {
  if (healthDetail.value === "heart") {
    return "心率";
  }

  if (healthDetail.value === "oxygen") {
    return "血氧";
  }

  return "体温";
});

const detailAlarms = computed(() => {
  if (healthDetail.value === "heart") {
    return alarms.value.filter((item) => item.type.includes("心率"));
  }

  if (healthDetail.value === "oxygen") {
    return alarms.value.filter((item) => item.type.includes("血氧"));
  }

  return alarms.value.filter(
    (item) => item.type.includes("体温") || item.type.includes("低热")
  );
});

const currentPage = ref("dashboard");
const activeHealthTab = ref("body");
const healthDetail = ref("");

const DEFAULT_REMOTE_SERVER = "http://YOUR_SERVER_HOST";
const LOCAL_SERVER = "http://127.0.0.1:3000";
const SERVER_HTTP =
  import.meta.env.VITE_API_BASE ||
  (["localhost", "127.0.0.1"].includes(window.location.hostname)
    ? LOCAL_SERVER
    : DEFAULT_REMOTE_SERVER);
const SERVER_WS = SERVER_HTTP;

const AUTH_STORAGE_KEY = "medicine_box_auth_token";
const MEDICINE_STORAGE_KEY = "medicine_slots_data";
const MEDICINE_USER_STORAGE_KEY = "medicine_user_data";
const APP_SETTINGS_STORAGE_KEY = "medicine_box_app_settings";
const MEDICINE_TAKEN_STORAGE_KEY = "medicine_taken_records";
const BOX_SLOTS_STORAGE_KEY = "medicine_box_slots";
const calendarWeekdays = ["一", "二", "三", "四", "五", "六", "日"];
const currentNow = ref(new Date());
let currentTimeTimer = null;
let identityStatusTimer = null;
let videoPlaybackTimer = null;
let esp32camStateTimer = null;
let dashboardStarted = false;
let socket = null;

const authMode = ref("login");
const authAccount = ref("");
const authPassword = ref("");
const showAuthPassword = ref(false);
const authLoading = ref(false);
const authError = ref("");
const authUser = ref(null);

function setAuthMode(mode) {
  authMode.value = mode;
  authError.value = "";
}

function getAuthHeaders() {
  const token = localStorage.getItem(AUTH_STORAGE_KEY);
  return token ? { Authorization: `Bearer ${token}` } : {};
}

function validateAuthForm() {
  if (!/^\d{11}$/.test(authAccount.value)) {
    return "账号必须是 11 位数字";
  }

  if (authPassword.value.length < 6) {
    return "密码至少需要 6 位";
  }

  return "";
}

function applyAuthSession(data) {
  const user = data?.user || data;
  if (!user?.account) {
    authUser.value = null;
    return;
  }

  authUser.value = {
    account: String(user.account),
    createdAt: user.createdAt || "",
  };
  startDashboardApp();
}

async function checkAuthSession() {
  const token = localStorage.getItem(AUTH_STORAGE_KEY);
  if (!token) {
    return;
  }

  authLoading.value = true;
  try {
    const res = await fetch(`${SERVER_HTTP}/api/auth/session`, {
      headers: getAuthHeaders(),
    });
    const result = await res.json();

    if (!res.ok || result.code !== 0) {
      localStorage.removeItem(AUTH_STORAGE_KEY);
      return;
    }

    applyAuthSession(result.data);
  } catch (error) {
    console.error("校验登录状态失败：", error);
  } finally {
    authLoading.value = false;
  }
}

async function submitAuth() {
  const validationError = validateAuthForm();
  if (validationError) {
    authError.value = validationError;
    return;
  }

  authLoading.value = true;
  authError.value = "";

  try {
    const endpoint = authMode.value === "register" ? "register" : "login";
    const res = await fetch(`${SERVER_HTTP}/api/auth/${endpoint}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        account: authAccount.value,
        password: authPassword.value,
      }),
    });
    const result = await res.json();

    if (!res.ok || result.code !== 0) {
      throw new Error(result.msg || "操作失败");
    }

    localStorage.setItem(AUTH_STORAGE_KEY, result.data.token);
    applyAuthSession(result.data);
  } catch (error) {
    authError.value = error.message || "操作失败，请稍后重试";
  } finally {
    authLoading.value = false;
  }
}

function logout() {
  localStorage.removeItem(AUTH_STORAGE_KEY);
  authUser.value = null;
}

const appSettings = ref({
  lowFeverLimit: 37.3,
  feverLimit: 38,
  envTempLimit: 30,
  humidityLimit: 75,
  familyName: "",
  familyPhone: "",
});
const medicineLibrary = ref([]);
const medicineLibrarySearch = ref("");
const medicineLibraryLoading = ref(false);
const showMedicineLibraryDialog = ref(false);
const medicineDialogMode = ref("create");
const medicineForm = ref(createEmptyMedicineForm());
const aiSearchName = ref("");
const aiSearching = ref(false);
const savingMedicine = ref(false);
const medicineAiMessage = ref("");
const medicineAiMessageType = ref("info");
const medicineTakenRecords = ref({});
const medicinePutRecords = ref([]);
const medicineVideoSessions = ref([]);
const selectedVideoSessionId = ref("");
const activeVideoFrameIndex = ref(0);
const isVideoPlaying = ref(false);
const deletingVideoSessionId = ref("");
const esp32camState = ref({
  online: false,
  deviceId: "",
  frameCount: 0,
  lastFrameAt: null,
  lastFrameSize: 0,
  streamClients: 0,
  currentFps: 0,
  averageFps: 0,
  uploadMode: "",
  uploadClients: 0,
  controlEnabled: false,
  manualControlEnabled: false,
  desiredEnabled: false,
  medicineRecording: false,
  activeSessionId: "",
  controlUpdatedAt: null,
  controlSource: "",
});
const esp32camControlSaving = ref(false);
const esp32camStreamKey = ref(Date.now());
const medicineUser = ref({
  name: "",
  phone: "",
});
const savingIdentity = ref(false);
const identityDirty = ref(false);
const showFaceDialog = ref(false);
const showRegisterSuccess = ref(false);
const showFaceRefreshDialog = ref(false);
const showFaceDeleteDialog = ref(false);
const facePassword = ref("");
const refreshFacePassword = ref("");
const deleteFaceName = ref("");
const deleteFacePassword = ref("");
const faceRegistrationStarted = ref(false);
const faceDeleteStarted = ref(false);
const identityStatus = ref({
  faceRegistered: false,
  registrationState: "unregistered",
  message: "尚未注册人脸",
  faceUsers: [],
  deviceOnline: false,
});
const faceRegistering = computed(() =>
  ["waiting_device", "authenticating", "checking", "registering"].includes(
    identityStatus.value.registrationState
  )
);
const faceOperationBusy = computed(() =>
  ["waiting_device", "authenticating", "checking", "registering", "loading_faces", "deleting_face"].includes(
    identityStatus.value.registrationState
  )
);
const registeredFaceUsers = computed(() =>
  Array.isArray(identityStatus.value.faceUsers) ? identityStatus.value.faceUsers : []
);
const faceStatusText = computed(() => {
  const statusTextMap = {
    waiting_device: "等待设备",
    authenticating: "校验密码",
    checking: "查询人脸",
    registering: "采集人脸",
    loading_faces: "读取名单",
    deleting_face: "删除人脸",
    failed: "注册失败",
  };
  if (statusTextMap[identityStatus.value.registrationState]) {
    return statusTextMap[identityStatus.value.registrationState];
  }
  return identityStatus.value.faceRegistered ? "已注册" : "未注册";
});

const boxSlots = ref(
  Array.from({ length: 6 }, (_, index) => {
    return {
      id: index + 1,
      title: `第 ${index + 1} 药仓`,
      medicineId: "",
      name: "",
      quantity: "",
      lowThreshold: 5,
    };
  })
);

const medicineSlots = ref([
  {
    title: "第 1 次用药时间",
    earliestTime: "07:30",
    reminderTime: "08:00",
    latestTime: "08:30",
    boxId: "",
    doseCount: "",
    plans: [
      {
        name: "降压药",
        dose: "1粒",
      },
    ],
  },
  {
    title: "第 2 次用药时间",
    earliestTime: "12:30",
    reminderTime: "13:00",
    latestTime: "13:30",
    boxId: "",
    doseCount: "",
    plans: [
      {
        name: "降糖药",
        dose: "1粒",
      },
    ],
  },
  {
    title: "第 3 次用药时间",
    earliestTime: "18:30",
    reminderTime: "19:00",
    latestTime: "19:30",
    boxId: "",
    doseCount: "",
    plans: [],
  },
]);

function loadMedicineData() {
  const savedData = localStorage.getItem(MEDICINE_STORAGE_KEY);
  const savedUser = localStorage.getItem(MEDICINE_USER_STORAGE_KEY);

  if (savedData) {
    medicineSlots.value = JSON.parse(savedData).map(normalizeMedicineSlot);
  }

  if (savedUser) {
    medicineUser.value = JSON.parse(savedUser);
  }
}

function normalizeMedicineSlot(item, index) {
  const reminderTime = item.reminderTime || item.time || "";
  return {
    ...item,
    title: `第 ${index + 1} 次用药时间`,
    earliestTime: item.earliestTime || reminderTime,
    reminderTime,
    latestTime: item.latestTime || reminderTime,
  };
}

function applyMedicineConfig(config) {
  const plans = Array.isArray(config) ? config : config?.plans;

  if (!Array.isArray(plans)) {
    return;
  }

  if (!Array.isArray(config) && config.patient && !identityDirty.value) {
    medicineUser.value = {
      name: config.patient.name || "",
      phone: config.patient.phone || "",
    };
    localStorage.setItem(MEDICINE_USER_STORAGE_KEY, JSON.stringify(medicineUser.value));
  }

  if (!Array.isArray(config) && Array.isArray(config.boxes)) {
    applyBoxConfig(config.boxes);
  }

  if (!Array.isArray(config) && (config.settings || config.familyContact || config.familyPhone)) {
    const settings = config.settings || {};
    const familyContact = config.familyContact || {};
    appSettings.value = {
      ...appSettings.value,
      ...settings,
      familyName: settings.familyName || familyContact.name || config.familyName || appSettings.value.familyName,
      familyPhone: settings.familyPhone || familyContact.phone || config.familyPhone || appSettings.value.familyPhone,
    };
    localStorage.setItem(APP_SETTINGS_STORAGE_KEY, JSON.stringify(appSettings.value));
  }

  medicineSlots.value = plans.map((item, index) => {
    return normalizeMedicineSlot({
      earliestTime: item.earliestTime,
      reminderTime: item.reminderTime || item.time,
      latestTime: item.latestTime,
      boxId: "",
      doseCount: "",
      plans: item.medicines || [],
    }, index);
  });

  localStorage.setItem(MEDICINE_STORAGE_KEY, JSON.stringify(medicineSlots.value));
}

function persistMedicineLocally() {
  localStorage.setItem(MEDICINE_STORAGE_KEY, JSON.stringify(medicineSlots.value));
  localStorage.setItem(MEDICINE_USER_STORAGE_KEY, JSON.stringify(medicineUser.value));
}

async function loadMedicineDataFromServer() {
  try {
    const res = await fetch(`${SERVER_HTTP}/api/medicine/plans`);
    const result = await res.json();

    if (result.code === 0) {
      applyMedicineConfig(result.data);
    }
  } catch (error) {
    loadMedicineData();
  }
}

function listToText(value) {
  return Array.isArray(value) ? value.join("\n") : "";
}

function textToList(value) {
  return String(value || "")
    .split(/\r?\n/)
    .map((item) => item.trim())
    .filter(Boolean);
}

function sourcesToText(value) {
  if (!Array.isArray(value)) {
    return "";
  }

  return value
    .map((item) => {
      const title = item?.title || "";
      const url = item?.url || "";
      return url ? `${title} | ${url}` : title;
    })
    .filter(Boolean)
    .join("\n");
}

function textToSources(value) {
  return String(value || "")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      const separatorIndex = line.indexOf("|");
      if (separatorIndex >= 0) {
        return {
          title: line.slice(0, separatorIndex).trim() || "资料来源",
          url: line.slice(separatorIndex + 1).trim(),
        };
      }

      const urlMatch = line.match(/https?:\/\/\S+/i);
      return {
        title: urlMatch ? line.replace(urlMatch[0], "").trim() || "资料来源" : line,
        url: urlMatch ? urlMatch[0] : "",
      };
    });
}

function createEmptyMedicineForm(item = {}) {
  return {
    id: item.id || "",
    name: item.name || "",
    genericName: item.genericName || "",
    aliases: listToText(item.aliases),
    category: item.category || "",
    summary: item.summary || "",
    uses: listToText(item.uses),
    dosageForms: listToText(item.dosageForms),
    contraindications: listToText(item.contraindications),
    adverseReactions: listToText(item.adverseReactions),
    warnings: listToText(item.warnings),
    sourcesText: sourcesToText(item.sources),
    aiGenerated: Boolean(item.aiGenerated),
    dataSource: item.dataSource || "",
  };
}

function buildMedicinePayload() {
  return {
    id: medicineForm.value.id,
    name: medicineForm.value.name,
    genericName: medicineForm.value.genericName,
    aliases: textToList(medicineForm.value.aliases),
    category: medicineForm.value.category,
    summary: medicineForm.value.summary,
    uses: textToList(medicineForm.value.uses),
    dosageForms: textToList(medicineForm.value.dosageForms),
    contraindications: textToList(medicineForm.value.contraindications),
    adverseReactions: textToList(medicineForm.value.adverseReactions),
    warnings: textToList(medicineForm.value.warnings),
    sources: textToSources(medicineForm.value.sourcesText),
    aiGenerated: medicineForm.value.aiGenerated,
    dataSource: medicineForm.value.aiGenerated ? "AI 检索整理" : "人工录入",
  };
}

function applyMedicineLibrary(items) {
  medicineLibrary.value = Array.isArray(items) ? items : [];
  reconcileBoxMedicinesWithLibrary();
}

async function loadMedicineLibrary() {
  medicineLibraryLoading.value = true;
  try {
    const res = await fetch(`${SERVER_HTTP}/api/medicine/library`);
    const result = await res.json();
    if (!res.ok || result.code !== 0) {
      throw new Error(result.msg || "药品库加载失败");
    }
    applyMedicineLibrary(result.data);
  } catch (error) {
    console.log("药品库加载失败：", error);
    alert("药品库加载失败，请检查后端是否运行");
  } finally {
    medicineLibraryLoading.value = false;
  }
}

function openAddMedicineDialog() {
  medicineDialogMode.value = "create";
  medicineForm.value = createEmptyMedicineForm();
  aiSearchName.value = "";
  medicineAiMessage.value = "";
  medicineAiMessageType.value = "info";
  showMedicineLibraryDialog.value = true;
}

function openMedicineDetail(item) {
  medicineDialogMode.value = "edit";
  medicineForm.value = createEmptyMedicineForm(item);
  aiSearchName.value = item.name || "";
  medicineAiMessage.value = "";
  medicineAiMessageType.value = "info";
  showMedicineLibraryDialog.value = true;
}

function closeMedicineLibraryDialog() {
  if (!aiSearching.value && !savingMedicine.value) {
    showMedicineLibraryDialog.value = false;
  }
}

async function searchMedicineByAi() {
  const name = (aiSearchName.value || medicineForm.value.name || "").trim();
  if (!name) {
    alert("请先输入药品名称");
    return;
  }

  aiSearching.value = true;
  medicineAiMessage.value = "AI 正在检索权威公开资料，请稍等...";
  medicineAiMessageType.value = "info";
  try {
    const res = await fetch(`${SERVER_HTTP}/api/medicine/library/ai-search`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name }),
    });
    const result = await res.json();
    if (!res.ok || result.code !== 0) {
      throw new Error(result.msg || "AI 检索失败");
    }

    medicineForm.value = createEmptyMedicineForm({
      ...result.data,
      id: medicineDialogMode.value === "edit" ? medicineForm.value.id : "",
      aiGenerated: true,
    });
    aiSearchName.value = result.data.name || name;
    medicineAiMessage.value = "AI 已生成药品信息草稿，请核对和修改后保存。";
    medicineAiMessageType.value = "info";
  } catch (error) {
    medicineAiMessage.value = error.message || "AI 检索失败，可以手动填写药品信息。";
    medicineAiMessageType.value = "error";
  } finally {
    aiSearching.value = false;
  }
}

async function saveMedicineLibraryItem() {
  const payload = buildMedicinePayload();
  if (!payload.name.trim()) {
    alert("请输入药品名称");
    return;
  }

  savingMedicine.value = true;
  try {
    const isEdit = medicineDialogMode.value === "edit" && payload.id;
    const res = await fetch(
      isEdit
        ? `${SERVER_HTTP}/api/medicine/library/${encodeURIComponent(payload.id)}`
        : `${SERVER_HTTP}/api/medicine/library`,
      {
        method: isEdit ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      }
    );
    const result = await res.json();
    if (!res.ok || result.code !== 0) {
      throw new Error(result.msg || "保存失败");
    }

    await loadMedicineLibrary();
    showMedicineLibraryDialog.value = false;
    alert(isEdit ? "药品信息已更新" : "药品已保存到药品库");
  } catch (error) {
    alert("保存失败：" + error.message);
  } finally {
    savingMedicine.value = false;
  }
}

async function deleteMedicineLibraryItem() {
  const id = medicineForm.value.id;
  const name = medicineForm.value.name || "该药品";
  if (!id) {
    showMedicineLibraryDialog.value = false;
    return;
  }

  if (!window.confirm(`确定删除“${name}”吗？删除后将无法在药品库中查看该药品信息。`)) {
    return;
  }

  savingMedicine.value = true;
  try {
    const res = await fetch(`${SERVER_HTTP}/api/medicine/library/${encodeURIComponent(id)}`, {
      method: "DELETE",
    });
    const result = await res.json();
    if (!res.ok || result.code !== 0) {
      throw new Error(result.msg || "删除失败");
    }

    applyMedicineLibrary(result.data);
    showMedicineLibraryDialog.value = false;
    alert("药品已删除");
  } catch (error) {
    alert("删除失败：" + error.message);
  } finally {
    savingMedicine.value = false;
  }
}

function medicineCardTags(item) {
  const tags = [];
  if (Array.isArray(item.uses) && item.uses.length > 0) {
    tags.push(...item.uses.slice(0, 2));
  }
  if (Array.isArray(item.dosageForms) && item.dosageForms.length > 0) {
    tags.push(item.dosageForms[0]);
  }
  return tags.length ? tags.slice(0, 3) : ["可编辑"];
}

function formatLibraryDate(value) {
  if (!value) {
    return "未保存";
  }

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return "未保存";
  }

  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function findMedicineLibraryItem(idOrLegacyValue) {
  const id = String(idOrLegacyValue || "");
  if (!id || id.startsWith("legacy:")) {
    return null;
  }
  return medicineLibrary.value.find((item) => String(item.id) === id) || null;
}

function findMedicineLibraryItemByName(name) {
  const normalizedName = String(name || "").trim().toLowerCase();
  if (!normalizedName) {
    return null;
  }
  return (
    medicineLibrary.value.find((item) => String(item.name || "").trim().toLowerCase() === normalizedName) ||
    null
  );
}

function handleBoxMedicineSelect(slot) {
  if (!slot.medicineId) {
    slot.name = "";
    return;
  }

  if (String(slot.medicineId).startsWith("legacy:")) {
    slot.name = String(slot.medicineId).slice("legacy:".length);
    return;
  }

  const medicine = findMedicineLibraryItem(slot.medicineId);
  slot.name = medicine?.name || "";
}

function reconcileBoxMedicinesWithLibrary() {
  if (medicineLibrary.value.length === 0) {
    return;
  }

  boxSlots.value = boxSlots.value.map((slot) => {
    if (slot.medicineId && findMedicineLibraryItem(slot.medicineId)) {
      return {
        ...slot,
        name: findMedicineLibraryItem(slot.medicineId).name,
      };
    }

    const matchedMedicine = findMedicineLibraryItemByName(slot.name);
    if (!matchedMedicine) {
      return slot;
    }

    return {
      ...slot,
      medicineId: matchedMedicine.id,
      name: matchedMedicine.name,
    };
  });
}

function applyIdentityStatus(data) {
  if (!data) return;
  identityStatus.value = { ...identityStatus.value, ...data };
  if (data.user && !identityDirty.value) {
    medicineUser.value = {
      name: data.user.name || "",
      phone: data.user.phone || "",
    };
    localStorage.setItem(MEDICINE_USER_STORAGE_KEY, JSON.stringify(medicineUser.value));
  }
  if (
    faceRegistrationStarted.value &&
    data.faceRegistered &&
    data.registrationState === "registered"
  ) {
    faceRegistrationStarted.value = false;
    showRegisterSuccess.value = true;
  }
  if (faceRegistrationStarted.value && data.registrationState === "failed") {
    faceRegistrationStarted.value = false;
    alert(data.message || "人脸注册失败");
  }
  if (faceDeleteStarted.value && data.registrationState === "failed") {
    faceDeleteStarted.value = false;
    alert(data.message || "删除人脸失败");
  }
  if (
    faceDeleteStarted.value &&
    !faceOperationBusy.value &&
    data.message &&
    data.message.startsWith("已删除")
  ) {
    faceDeleteStarted.value = false;
    alert(data.message);
  }
}

async function loadIdentityStatus() {
  try {
    const res = await fetch(`${SERVER_HTTP}/api/user/profile`);
    const result = await res.json();
    if (result.code === 0) applyIdentityStatus(result.data);
  } catch (error) {
    console.log("用户身份状态获取失败：", error);
  }
}

async function saveIdentity() {
  if (!medicineUser.value.name) {
    alert("请输入用户姓名");
    return;
  }
  if (!/^1[3-9]\d{9}$/.test(medicineUser.value.phone)) {
    alert("请输入正确的11位手机号码");
    return;
  }
  savingIdentity.value = true;
  try {
    const res = await fetch(`${SERVER_HTTP}/api/user/profile`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(medicineUser.value),
    });
    const result = await res.json();
    if (!res.ok || result.code !== 0) throw new Error(result.msg || "保存失败");
    identityDirty.value = false;
    applyIdentityStatus(result.data);
    alert("用户信息已保存并同步到药盒");
  } catch (error) {
    alert("保存失败：" + error.message);
  } finally {
    savingIdentity.value = false;
  }
}

function openFaceRegisterDialog() {
  if (!medicineUser.value.name || !/^1[3-9]\d{9}$/.test(medicineUser.value.phone)) {
    alert("请先填写并保存完整的用户信息");
    return;
  }
  facePassword.value = "";
  showFaceDialog.value = true;
}

function closeFaceRegisterDialog() {
  if (!faceOperationBusy.value) showFaceDialog.value = false;
}

async function submitFaceRegistration() {
  if (!facePassword.value) {
    alert("请输入 K230 编辑密码");
    return;
  }
  try {
    const res = await fetch(`${SERVER_HTTP}/api/face/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password: facePassword.value }),
    });
    const result = await res.json();
    facePassword.value = "";
    if (!res.ok || result.code !== 0) throw new Error(result.msg || "请求失败");
    showFaceDialog.value = false;
    faceRegistrationStarted.value = true;
    applyIdentityStatus(result.data);
  } catch (error) {
    alert("无法开始注册：" + error.message);
  }
}

function openFaceRefreshDialog() {
  refreshFacePassword.value = "";
  showFaceRefreshDialog.value = true;
}

function closeFaceRefreshDialog() {
  if (!faceOperationBusy.value) showFaceRefreshDialog.value = false;
}

async function refreshFaceUsers() {
  if (!refreshFacePassword.value) {
    alert("请输入 K230 编辑密码");
    return;
  }
  try {
    const res = await fetch(`${SERVER_HTTP}/api/face/users/refresh`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password: refreshFacePassword.value }),
    });
    const result = await res.json();
    refreshFacePassword.value = "";
    if (!res.ok || result.code !== 0) throw new Error(result.msg || "刷新失败");
    showFaceRefreshDialog.value = false;
    applyIdentityStatus(result.data);
  } catch (error) {
    alert("无法刷新人脸名单：" + error.message);
  }
}

function openFaceDeleteDialog(name) {
  deleteFaceName.value = name;
  deleteFacePassword.value = "";
  showFaceDeleteDialog.value = true;
}

function closeFaceDeleteDialog() {
  if (!faceOperationBusy.value) showFaceDeleteDialog.value = false;
}

async function submitFaceDelete() {
  if (!deleteFaceName.value) {
    alert("请选择要删除的人脸");
    return;
  }
  if (!deleteFacePassword.value) {
    alert("请输入 K230 编辑密码");
    return;
  }
  try {
    const res = await fetch(`${SERVER_HTTP}/api/face/users/delete`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: deleteFaceName.value,
        password: deleteFacePassword.value,
      }),
    });
    const result = await res.json();
    deleteFacePassword.value = "";
    if (!res.ok || result.code !== 0) throw new Error(result.msg || "删除失败");
    showFaceDeleteDialog.value = false;
    faceDeleteStarted.value = true;
    applyIdentityStatus(result.data);
  } catch (error) {
    alert("无法删除人脸：" + error.message);
  }
}

async function saveMedicineData() {
  const timeError = validateMedicineTimes();
  if (timeError) {
    alert(timeError);
    return;
  }

  persistMedicineLocally();

  try {
    const res = await fetch(`${SERVER_HTTP}/api/medicine/plans`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        plans: medicineSlots.value.map((slot, index) => {
          return {
            slot: index + 1,
            period: ["morning", "noon", "evening"][index] || `slot${index + 1}`,
            earliestTime: slot.earliestTime,
            reminderTime: slot.reminderTime,
            latestTime: slot.latestTime,
            time: slot.reminderTime,
            medicines: slot.plans.map((item) => {
              return {
                boxId: item.boxId,
                boxName: item.boxName,
                medicineId: item.medicineId,
                name: item.name,
                dose: item.dose,
                doseCount: item.doseCount,
              };
            }),
          };
        }),
      }),
    });

    const result = await res.json();

    if (result.code === 0) {
      alert("用药计划已保存，并同步到药盒");
    } else {
      alert("保存失败：" + (result.msg || "后端返回错误"));
    }
  } catch (error) {
    console.log("用药计划上传失败：", error);
    alert("保存失败，请检查后端是否运行");
  }
}

function validateMedicineTimes() {
  for (let index = 0; index < medicineSlots.value.length; index += 1) {
    const slot = medicineSlots.value[index];
    if (!slot.earliestTime || !slot.reminderTime || !slot.latestTime) {
      return `请完整设置第 ${index + 1} 次用药的三个时间`;
    }
    if (slot.earliestTime > slot.reminderTime || slot.reminderTime > slot.latestTime) {
      return `第 ${index + 1} 次用药必须满足：最早时间 ≤ 提醒时间 ≤ 最晚时间`;
    }
    const next = medicineSlots.value[index + 1];
    if (next && slot.latestTime > next.earliestTime) {
      return `第 ${index + 1} 次最晚时间不能超过第 ${index + 2} 次最早时间`;
    }
  }
  return "";
}

async function addMedicinePlan(index) {
  const slot = medicineSlots.value[index];

  if (boxMedicineOptions.value.length === 0) {
    alert("请先在药仓管理中添加药品，再设置用药计划");
    return;
  }

  const selectedMedicine = boxMedicineOptions.value.find(
    (item) => Number(item.id) === Number(slot.boxId)
  );
  const doseCount = Number(slot.doseCount);

  if (!selectedMedicine || !Number.isInteger(doseCount) || doseCount < 1) {
    alert("请选择药品并填写用药剂量");
    return;
  }

  slot.plans.push({
    boxId: selectedMedicine.id,
    boxName: selectedMedicine.title,
    medicineId: selectedMedicine.medicineId,
    name: selectedMedicine.name,
    doseCount,
    dose: `${doseCount}粒`,
  });

  slot.boxId = "";
  slot.doseCount = "";

  persistMedicineLocally();
}

async function deleteMedicinePlan(slotIndex, planIndex) {
  medicineSlots.value[slotIndex].plans.splice(planIndex, 1);
  persistMedicineLocally();
}

function loadAppSettings() {
  const savedSettings = localStorage.getItem(APP_SETTINGS_STORAGE_KEY);
  const savedRecords = localStorage.getItem(MEDICINE_TAKEN_STORAGE_KEY);
  const savedBoxSlots = localStorage.getItem(BOX_SLOTS_STORAGE_KEY);

  if (savedSettings) {
    const { nurseName, nursePhone, ...cleanSettings } = JSON.parse(savedSettings);
    appSettings.value = {
      ...appSettings.value,
      ...cleanSettings,
    };
  }

  if (savedRecords) {
    medicineTakenRecords.value = JSON.parse(savedRecords);
  }

  if (savedBoxSlots) {
    const parsedSlots = JSON.parse(savedBoxSlots);

    if (Array.isArray(parsedSlots)) {
      boxSlots.value = boxSlots.value.map((slot, index) => {
        const { addDate, ...savedSlot } = parsedSlots[index] || {};
        return {
          ...slot,
          ...savedSlot,
          id: index + 1,
          title: `第 ${index + 1} 药仓`,
        };
      });
    }
  }
}

function saveAppSettings() {
  localStorage.setItem(APP_SETTINGS_STORAGE_KEY, JSON.stringify(appSettings.value));
  alert("本地设置已保存");
}

async function saveAppSettingsToServer() {
  const familyPhone = String(appSettings.value.familyPhone || "").trim();

  if (familyPhone && !/^1[3-9]\d{9}$/.test(familyPhone)) {
    alert("家属电话格式不正确，请填写 11 位手机号");
    return;
  }

  appSettings.value = {
    ...appSettings.value,
    familyName: String(appSettings.value.familyName || "").trim(),
    familyPhone,
  };
  localStorage.setItem(APP_SETTINGS_STORAGE_KEY, JSON.stringify(appSettings.value));

  try {
    const res = await fetch(`${SERVER_HTTP}/api/app/settings`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(appSettings.value),
    });
    const result = await res.json();

    if (result.code === 0) {
      applyMedicineConfig(result.data);
      alert("设置已保存，并同步到药盒配置");
    } else {
      alert("保存失败：" + (result.msg || "后端返回错误"));
    }
  } catch (error) {
    console.log("settings upload failed:", error);
    alert("设置已保存在本地，但同步到后端失败，请检查后端是否运行");
  }
}

function saveMedicineTakenRecords() {
  localStorage.setItem(
    MEDICINE_TAKEN_STORAGE_KEY,
    JSON.stringify(medicineTakenRecords.value)
  );
}

function mergeMedicineTakenRecords(records) {
  if (!records || typeof records !== "object" || Array.isArray(records)) {
    return;
  }

  medicineTakenRecords.value = {
    ...medicineTakenRecords.value,
    ...records,
  };
  saveMedicineTakenRecords();
}

function mealIdFromSlot(slot) {
  return ["breakfast", "lunch", "dinner"][Number(slot) - 1] || "";
}

function applyMedicineTaken(data) {
  if (!data || typeof data !== "object") {
    return;
  }

  const dateKey = data.dateKey || data.date || todayKey.value;
  const mealId =
    data.mealId ||
    mealIdFromSlot(data.planSlot ?? data.plan_slot ?? data.slot ?? data.medicineSlot);

  if (!dateKey || !mealId) {
    return;
  }

  if (Array.isArray(data.boxes)) {
    applyBoxConfig(data.boxes);
  }

  const key = data.key || medicationRecordKey(dateKey, mealId);
  medicineTakenRecords.value = {
    ...medicineTakenRecords.value,
    [key]: "taken",
  };
  currentNow.value = new Date();
  saveMedicineTakenRecords();
}

async function loadMedicineTakenRecordsFromServer() {
  try {
    const res = await fetch(`${SERVER_HTTP}/api/medicine/taken`);
    const result = await res.json();
    if (result.code === 0) mergeMedicineTakenRecords(result.data);
  } catch (error) {
    console.log("medicine taken records load failed:", error);
  }
}

function applyMedicinePutRecords(records) {
  if (!Array.isArray(records)) return;
  medicinePutRecords.value = records.map((record) => {
    return {
      ...record,
      boxId: Number(record.boxId ?? record.box_id),
      medicineName: record.medicineName || record.medicine_name || "",
      putCount: Number(record.putCount ?? record.put_count) || 0,
      after: Number(record.after ?? record.stockAfter ?? record.stock_count) || 0,
      recordedAt: record.recordedAt || record.createdAt || "",
    };
  });
}

async function loadMedicinePutRecordsFromServer() {
  try {
    const res = await fetch(`${SERVER_HTTP}/api/medicine/put-records`);
    const result = await res.json();
    if (result.code === 0) applyMedicinePutRecords(result.data);
  } catch (error) {
    console.log("加药记录加载失败：", error);
  }
}

function applyMedicineVideoSessions(sessions) {
  if (!Array.isArray(sessions)) return;

  medicineVideoSessions.value = sessions.map((session) => {
    return {
      ...session,
      frames: Array.isArray(session.frames) ? session.frames : [],
      frameCount: Number(session.frameCount) || (Array.isArray(session.frames) ? session.frames.length : 0),
    };
  });

  if (!selectedVideoSessionId.value && medicineVideoSessions.value.length > 0) {
    selectedVideoSessionId.value = medicineVideoSessions.value[0].id;
  }

  if (
    selectedVideoSessionId.value &&
    !medicineVideoSessions.value.some((session) => session.id === selectedVideoSessionId.value)
  ) {
    selectedVideoSessionId.value = medicineVideoSessions.value[0]?.id || "";
  }

  const frameTotal = selectedVideoSession.value?.frames?.length || 0;
  if (frameTotal > 0 && activeVideoFrameIndex.value >= frameTotal) {
    activeVideoFrameIndex.value = frameTotal - 1;
  }
}

async function loadMedicineVideoSessions() {
  try {
    const res = await fetch(`${SERVER_HTTP}/api/medicine/videos`);
    const result = await res.json();
    if (result.code === 0) applyMedicineVideoSessions(result.data);
  } catch (error) {
    console.log("medicine videos load failed:", error);
  }
}

async function deleteMedicineVideoSession(session) {
  if (!session?.id || deletingVideoSessionId.value) {
    return;
  }

  if (session.status === "recording") {
    window.alert("这条录像仍在录制中，请结束录制后再删除。");
    return;
  }

  const confirmed = window.confirm(`确定删除「${session.title || "用药录像"}」吗？删除后无法恢复。`);
  if (!confirmed) {
    return;
  }

  deletingVideoSessionId.value = session.id;
  stopFramePlayback();
  try {
    const res = await fetch(`${SERVER_HTTP}/api/medicine/videos/${encodeURIComponent(session.id)}`, {
      method: "DELETE",
    });
    const result = await res.json();
    if (!res.ok || result.code !== 0) {
      throw new Error(result.msg || "删除录像失败");
    }
    applyMedicineVideoSessions(Array.isArray(result.data) ? result.data : []);
  } catch (error) {
    console.error(error);
    window.alert(error.message || "删除录像失败，请稍后再试。");
  } finally {
    deletingVideoSessionId.value = "";
  }
}

function applyEsp32camState(state) {
  if (!state || typeof state !== "object") return;

  const wasControlEnabled = esp32camState.value.controlEnabled;
  const nextManualControlEnabled = Boolean(state.controlEnabled);
  const nextDesiredEnabled = Boolean(
    state.desiredEnabled ?? state.enabled ?? nextManualControlEnabled
  );

  esp32camState.value = {
    ...esp32camState.value,
    ...state,
    online: Boolean(state.online),
    frameCount: Number(state.frameCount) || 0,
    lastFrameSize: Number(state.lastFrameSize) || 0,
    streamClients: Number(state.streamClients) || 0,
    currentFps: Number(state.currentFps) || 0,
    averageFps: Number(state.averageFps) || 0,
    uploadMode: String(state.uploadMode || ""),
    uploadClients: Number(state.uploadClients) || 0,
    controlEnabled: nextDesiredEnabled,
    manualControlEnabled: nextManualControlEnabled,
    desiredEnabled: nextDesiredEnabled,
    medicineRecording: Boolean(state.medicineRecording),
    activeSessionId: String(state.activeSessionId || ""),
    controlUpdatedAt: state.controlUpdatedAt || null,
    controlSource: String(state.controlSource || ""),
  };

  if (!wasControlEnabled && nextDesiredEnabled) {
    refreshEsp32camStream();
  }
}

function refreshEsp32camStream() {
  esp32camStreamKey.value = Date.now();
}

async function loadEsp32camState() {
  try {
    const res = await fetch(`${SERVER_HTTP}/esp32cam/state`, { cache: "no-store" });
    const result = await res.json();
    applyEsp32camState(result);
  } catch (error) {
    esp32camState.value = {
      ...esp32camState.value,
      online: false,
    };
  }
}

async function toggleEsp32camControl() {
  if (esp32camControlSaving.value) {
    return;
  }

  const enabled = !esp32camState.value.manualControlEnabled;
  esp32camControlSaving.value = true;
  try {
    const res = await fetch(`${SERVER_HTTP}/api/esp32cam/control`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ enabled, source: "family_page" }),
    });
    const result = await res.json();
    if (!res.ok || result.code !== 0) {
      throw new Error(result.msg || "ESP32-CAM control failed");
    }
    applyEsp32camState(result.data || { controlEnabled: enabled, desiredEnabled: enabled });
    if (enabled) {
      refreshEsp32camStream();
    }
  } catch (error) {
    console.error(error);
    window.alert("ESP32-CAM 控制失败，请确认后端服务和星火设备在线");
  } finally {
    esp32camControlSaving.value = false;
  }
}

function formatEsp32camTime(value) {
  if (!value) {
    return "--";
  }

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return "--";
  }

  return date.toLocaleString();
}

function formatFps(value) {
  return `${(Number(value) || 0).toFixed(1)} FPS`;
}

function formatEsp32camUploadMode(value) {
  const mode = String(value || "");
  if (mode === "multipart-stream") {
    const count = Number(esp32camState.value.uploadClients) || 0;
    return count > 0 ? `长连接 ${count}` : "长连接";
  }
  if (mode === "single-frame") {
    return "单帧";
  }
  return "--";
}

function videoAssetUrl(url, cacheKey = "") {
  const text = String(url || "");
  if (!text) {
    return "";
  }
  const baseUrl = /^https?:\/\//i.test(text)
    ? text
    : `${SERVER_HTTP}${text.startsWith("/") ? text : `/${text}`}`;
  const key = String(cacheKey || "");
  if (!key) {
    return baseUrl;
  }
  return `${baseUrl}${baseUrl.includes("?") ? "&" : "?"}v=${encodeURIComponent(key)}`;
}

function videoSessionAssetKey(session) {
  if (!session) {
    return "";
  }

  return [
    session.id,
    session.frameCount || session.frames?.length || 0,
    session.size || 0,
    session.endedAt || session.uploadedAt || session.startedAt || "",
  ].join("-");
}

function selectVideoSession(id) {
  stopFramePlayback();
  selectedVideoSessionId.value = id;
  activeVideoFrameIndex.value = 0;
}

function stopFramePlayback() {
  if (videoPlaybackTimer) {
    window.clearInterval(videoPlaybackTimer);
    videoPlaybackTimer = null;
  }
  isVideoPlaying.value = false;
}

function toggleFramePlayback() {
  if (isVideoPlaying.value) {
    stopFramePlayback();
    return;
  }

  const frames = selectedVideoSession.value?.frames || [];
  if (frames.length <= 1) {
    return;
  }

  if (activeVideoFrameIndex.value >= frames.length - 1) {
    activeVideoFrameIndex.value = 0;
  }

  isVideoPlaying.value = true;
  videoPlaybackTimer = window.setInterval(() => {
    if (!selectedVideoSession.value || selectedVideoSession.value.frames.length === 0) {
      stopFramePlayback();
      return;
    }

    const lastIndex = selectedVideoSession.value.frames.length - 1;
    if (activeVideoFrameIndex.value >= lastIndex) {
      stopFramePlayback();
      return;
    }

    activeVideoFrameIndex.value += 1;
  }, 180);
}

function stepVideoFrame(step) {
  stopFramePlayback();
  const frames = selectedVideoSession.value?.frames || [];
  if (frames.length === 0) {
    activeVideoFrameIndex.value = 0;
    return;
  }

  activeVideoFrameIndex.value =
    (activeVideoFrameIndex.value + step + frames.length) % frames.length;
}

function formatVideoSessionMeta(session) {
  const date = session.dateKey || String(session.startedAt || "").slice(0, 10) || "--";
  const time = session.time || String(session.startedAt || "").slice(11, 16) || "--";
  const slotText = session.planSlot ? `第 ${session.planSlot} 次` : "未绑定餐次";
  return `${date} ${time} · ${slotText}`;
}

function formatVideoSessionDetail(session) {
  const status = session.status === "recording" ? "录制中" : "已完成";
  const duration = formatDurationSeconds(session.durationSeconds);
  const size = formatFileSize(session.size);
  return `${formatVideoSessionMeta(session)} · ${status} · ${duration} · ${size}`;
}

function formatDurationSeconds(value) {
  const seconds = Number(value) || 0;
  if (seconds <= 0) {
    return "时长待计算";
  }
  const minutes = Math.floor(seconds / 60);
  const rest = seconds % 60;
  return minutes > 0 ? `${minutes}分${rest}秒` : `${rest}秒`;
}

function formatFileSize(value) {
  const size = Number(value) || 0;
  if (size <= 0) {
    return "大小待计算";
  }
  if (size < 1024 * 1024) {
    return `${(size / 1024).toFixed(1)} KB`;
  }
  return `${(size / 1024 / 1024).toFixed(1)} MB`;
}

function applyBoxConfig(boxes) {
  if (!Array.isArray(boxes)) return;
  boxSlots.value = boxSlots.value.map((slot, index) => {
    const box = boxes[index] || {};
    const { addDate, ...cleanSlot } = slot;
    const { addDate: ignoredBoxAddDate, ...cleanBox } = box;
    const rawThreshold = box.lowThreshold ?? box.minThreshold ?? box.threshold ?? slot.lowThreshold ?? 5;
    const lowThreshold = Number(rawThreshold);

    return {
      ...cleanSlot,
      ...cleanBox,
      id: index + 1,
      title: `第 ${index + 1} 药仓`,
      lowThreshold: Number.isFinite(lowThreshold) && lowThreshold >= 0 ? lowThreshold : 5,
    };
  });
  reconcileBoxMedicinesWithLibrary();
  localStorage.setItem(BOX_SLOTS_STORAGE_KEY, JSON.stringify(boxSlots.value));
}

async function loadBoxSlotsFromServer() {
  try {
    const res = await fetch(`${SERVER_HTTP}/api/medicine/boxes`);
    const result = await res.json();
    if (result.code === 0) applyBoxConfig(result.data);
  } catch (error) {
    console.log("药仓信息加载失败，继续使用本地数据：", error);
  }
}

async function saveBoxSlots() {
  reconcileBoxMedicinesWithLibrary();
  localStorage.setItem(BOX_SLOTS_STORAGE_KEY, JSON.stringify(boxSlots.value));
  try {
    const res = await fetch(`${SERVER_HTTP}/api/medicine/boxes`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ boxes: boxSlots.value }),
    });
    const result = await res.json();
    if (!res.ok || result.code !== 0) {
      alert("保存失败：" + (result.msg || "后端返回错误"));
      return;
    }
    if (result.data?.boxes) {
      applyBoxConfig(result.data.boxes);
    }
    if (Array.isArray(result.data?.putRecords) && result.data.putRecords.length > 0) {
      await loadMedicinePutRecordsFromServer();
    }
    alert("6 个药仓信息已保存，并同步到药盒");
  } catch (error) {
    console.log("药仓信息上传失败：", error);
    alert("保存失败，请检查后端是否运行");
  }
}

function formatLocalDate(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");

  return `${year}-${month}-${day}`;
}

function formatDateTime(value) {
  const date = value ? new Date(value) : null;
  if (!date || Number.isNaN(date.getTime())) {
    return "--";
  }

  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  const hours = String(date.getHours()).padStart(2, "0");
  const minutes = String(date.getMinutes()).padStart(2, "0");
  const seconds = String(date.getSeconds()).padStart(2, "0");
  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}

const liveDeviceDate = computed(() => formatLocalDate(currentNow.value));
const liveDeviceTime = computed(() => {
  const now = currentNow.value;
  const hours = String(now.getHours()).padStart(2, "0");
  const minutes = String(now.getMinutes()).padStart(2, "0");
  const seconds = String(now.getSeconds()).padStart(2, "0");
  return `${hours}:${minutes}:${seconds}`;
});

function timeToMinutes(time) {
  const [hours, minutes] = String(time || "00:00")
    .split(":")
    .map((value) => Number(value));

  return (hours || 0) * 60 + (minutes || 0);
}

function isMedicationDue(dateKey, time) {
  if (dateKey < todayKey.value) {
    return true;
  }

  if (dateKey > todayKey.value) {
    return false;
  }

  const currentMinutes =
    currentNow.value.getHours() * 60 + currentNow.value.getMinutes();

  return timeToMinutes(time) <= currentMinutes;
}

function medicationRecordKey(dateKey, mealId) {
  return `${dateKey}-${mealId}`;
}

function buildMedicationMeal(dateKey, meal) {
  const key = medicationRecordKey(dateKey, meal.id);
  const storedValue = medicineTakenRecords.value[key];
  const recordStatus = storedValue === true ? "taken" : storedValue;
  const due = meal.scheduled && isMedicationDue(dateKey, meal.time);
  let status = "unset";

  if (meal.scheduled) {
    if (recordStatus === "taken" || recordStatus === "missed") {
      status = recordStatus;
    } else if (!due) {
      status = "future";
    } else if (dateKey < todayKey.value) {
      status = "missed";
    } else {
      status = "pending";
    }
  }

  return {
    ...meal,
    key,
    dateKey,
    due: due || recordStatus === "taken" || recordStatus === "missed",
    status,
    title: meal.scheduled
      ? `${meal.label} ${meal.time}：${meal.description}`
      : `${meal.label}：未设置用药计划`,
  };
}

function medicationStatusLabel(meal) {
  const labels = {
    taken: "已服",
    missed: "未服",
    pending: "待记",
    future: "未到",
    unset: "未设",
  };

  return labels[meal.status] || "待记";
}

function cycleMedicationStatus(meal) {
  if (!meal.scheduled || !meal.due) {
    return;
  }

  const storedValue = medicineTakenRecords.value[meal.key];
  const currentStatus = storedValue === true ? "taken" : storedValue;
  const records = {
    ...medicineTakenRecords.value,
  };

  if (currentStatus === "taken") {
    records[meal.key] = "missed";
  } else if (currentStatus === "missed") {
    delete records[meal.key];
  } else {
    records[meal.key] = "taken";
  }

  medicineTakenRecords.value = records;
  saveMedicineTakenRecords();
}

function getNumberStats(values, digits, unit) {
  const nums = values
    .map((value) => Number(value))
    .filter((value) => !Number.isNaN(value) && value > 0);

  if (nums.length === 0) {
    return {
      max: "暂无",
      min: "暂无",
      avg: "暂无",
    };
  }

  const max = Math.max(...nums).toFixed(digits);
  const min = Math.min(...nums).toFixed(digits);
  const avg = (nums.reduce((sum, value) => sum + value, 0) / nums.length).toFixed(digits);

  return {
    max: `${max} ${unit}`,
    min: `${min} ${unit}`,
    avg: `${avg} ${unit}`,
  };
}



const device = ref({
  temperature: 0,
  humidity: 0,
  bodyTemperature: null,
  heartRate: null,
  bloodOxygen: null,
  date: "",
  time: "",
  online: false,
  riskLevel: "正常",
});

const alarms = ref([]);
const chartRef = ref(null);
const heartChartRef = ref(null);
const oxygenChartRef = ref(null);
const bodyChartRef = ref(null);
const medicationChartRef = ref(null);

let chart = null;
let heartChart = null;
let oxygenChart = null;
let bodyChart = null;
let medicationChart = null;

const timeList = [];
const tempList = [];
const humiList = [];

const heartTimeList = [];
const heartDateList = [];
const heartRateList = ref([]);

const oxygenTimeList = [];
const oxygenDateList = [];
const bloodOxygenList = ref([]);

const bodyTimeList = [];
const bodyDateList = [];
const bodyTempList = ref([]);

const selectedHealthRange = ref("1d");
const healthRangeOptions = [
  { label: "一天", value: "1d" },
  { label: "三天", value: "3d" },
  { label: "七天", value: "7d" },
  { label: "十四天", value: "14d" },
  { label: "二十一天", value: "21d" },
  { label: "三十天", value: "30d" },
];
const healthRangeLimitMap = {
  "1d": 48,
  "3d": 144,
  "7d": 336,
  "14d": 672,
  "21d": 1008,
  "30d": 1440,
};

const hasHealthTrendData = computed(() => {
  return heartRateList.value.length > 0 || bloodOxygenList.value.length > 0;
});

const healthAlarms = computed(() => {
  return alarms.value.filter((item) => {
    const type = String(item.type || "");

    return (
      type.includes("心率") ||
      type.includes("血氧") ||
      type.includes("体温") ||
      type.includes("低热") ||
      type.includes("发热")
    );
  });
});

const healthExportRows = computed(() => {
  const rowMap = new Map();

  function ensureRow(date, time, fallbackIndex) {
    const displayDate = date || "--";
    const displayTime = time || `第 ${fallbackIndex + 1} 条`;
    const key = `${displayDate}|${displayTime}`;

    if (!rowMap.has(key)) {
      rowMap.set(key, {
        date: displayDate,
        time: displayTime,
        heartRate: "",
        bloodOxygen: "",
        bodyTemperature: "",
        order: fallbackIndex,
      });
    }

    return rowMap.get(key);
  }

  heartRateList.value.forEach((value, index) => {
    const row = ensureRow(heartDateList[index], heartTimeList[index], index);
    row.heartRate = toExportValue(value, 0);
  });

  bloodOxygenList.value.forEach((value, index) => {
    const row = ensureRow(oxygenDateList[index], oxygenTimeList[index], index);
    row.bloodOxygen = toExportValue(value, 0);
  });

  bodyTempList.value.forEach((value, index) => {
    const row = ensureRow(bodyDateList[index], bodyTimeList[index], index);
    row.bodyTemperature = toExportValue(value, 2);
  });

  if (rowMap.size === 0) {
    const hasCurrentData = [
      device.value.heartRate,
      device.value.bloodOxygen,
      device.value.bodyTemperature,
    ].some((value) => {
      const num = Number(value);
      return value !== null && value !== undefined && !Number.isNaN(num) && num > 0;
    });

    if (!hasCurrentData) {
      return [];
    }

    return [
      {
        date: device.value.date || formatLocalDate(new Date()),
        time: device.value.time || new Date().toLocaleTimeString(),
        heartRate: toExportValue(device.value.heartRate, 0),
        bloodOxygen: toExportValue(device.value.bloodOxygen, 0),
        bodyTemperature: toExportValue(device.value.bodyTemperature, 2),
      },
    ];
  }

  const rows = Array.from(rowMap.values()).sort((a, b) => {
    return a.order - b.order || a.time.localeCompare(b.time);
  });
  const limit = healthRangeLimitMap[selectedHealthRange.value] || rows.length;

  return rows.slice(Math.max(0, rows.length - limit)).map(({ order, ...row }) => row);
});

const heartOxygenExportRows = computed(() => {
  return healthExportRows.value
    .map((row) => {
      return {
        date: row.date,
        time: row.time,
        heartRate: row.heartRate,
        bloodOxygen: row.bloodOxygen,
      };
    })
    .filter((row) => row.heartRate || row.bloodOxygen);
});

const bodyTemperatureExportRows = computed(() => {
  return healthExportRows.value
    .map((row) => {
      return {
        date: row.date,
        time: row.time,
        bodyTemperature: row.bodyTemperature,
      };
    })
    .filter((row) => row.bodyTemperature);
});

const healthAlarmExportRows = computed(() => {
  return healthAlarms.value.map((item) => {
    return {
      time: item.time || "--",
      type: item.type || "--",
      message: item.message || "--",
    };
  });
});

const todayKey = computed(() => formatLocalDate(currentNow.value));
const currentMonthKey = computed(() => todayKey.value.slice(0, 7));
const currentMonthLabel = computed(() => {
  return `${currentNow.value.getFullYear()} 年 ${currentNow.value.getMonth() + 1} 月`;
});

const mealDefinitions = computed(() => {
  const definitions = [
    { id: "breakfast", label: "早餐", shortLabel: "早", fallbackTime: "08:00" },
    { id: "lunch", label: "午餐", shortLabel: "中", fallbackTime: "12:00" },
    { id: "dinner", label: "晚餐", shortLabel: "晚", fallbackTime: "19:00" },
  ];

  return definitions.map((definition, index) => {
    const slot = medicineSlots.value[index];
    const plans = Array.isArray(slot?.plans) ? slot.plans : [];
    const description = plans.length
      ? plans.map((item) => `${item.name} ${item.dose}`).join("、")
      : "未设置用药";

    return {
      ...definition,
      time: slot?.reminderTime || slot?.time || definition.fallbackTime,
      plans,
      scheduled: plans.length > 0,
      description,
    };
  });
});

const scheduledMealCount = computed(() => {
  return mealDefinitions.value.filter((meal) => meal.scheduled).length;
});

const medicationCalendarCells = computed(() => {
  const year = currentNow.value.getFullYear();
  const month = currentNow.value.getMonth();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const leadingBlankCount = (new Date(year, month, 1).getDay() + 6) % 7;
  const cellCount = Math.ceil((leadingBlankCount + daysInMonth) / 7) * 7;
  const cells = [];

  for (let index = 0; index < cellCount; index += 1) {
    const day = index - leadingBlankCount + 1;

    if (day < 1 || day > daysInMonth) {
      cells.push({
        key: `blank-${index}`,
        blank: true,
      });
      continue;
    }

    const date = new Date(year, month, day, 12);
    const dateKey = formatLocalDate(date);

    cells.push({
      key: dateKey,
      day,
      dateKey,
      blank: false,
      isToday: dateKey === todayKey.value,
      isFuture: dateKey > todayKey.value,
      meals: mealDefinitions.value.map((meal) => buildMedicationMeal(dateKey, meal)),
    });
  }

  return cells;
});

const medicationDailyStats = computed(() => {
  return medicationCalendarCells.value
    .filter((cell) => !cell.blank)
    .map((cell) => {
      const dueMeals = cell.meals.filter((meal) => meal.due);

      return {
        day: cell.day,
        total: dueMeals.length,
        done: dueMeals.filter((meal) => meal.status === "taken").length,
      };
    });
});

const monthlyMedicationStats = computed(() => {
  const total = medicationDailyStats.value.reduce((sum, item) => sum + item.total, 0);
  const done = medicationDailyStats.value.reduce((sum, item) => sum + item.done, 0);

  return {
    total,
    done,
    percent: total === 0 ? 0 : Math.round((done / total) * 100),
  };
});

const medicineCompletionStats = computed(() => {
  const today = medicationCalendarCells.value.find((cell) => cell.isToday);
  const meals = today ? today.meals.filter((meal) => meal.scheduled) : [];
  const total = meals.length;
  const done = meals.filter((meal) => meal.status === "taken").length;

  return {
    total,
    done,
    percent: total === 0 ? 0 : Math.round((done / total) * 100),
  };
});

const bodyTemperatureStats = computed(() => getNumberStats(bodyTempList.value, 2, "°C"));
const heartRateStats = computed(() => getNumberStats(heartRateList.value, 0, "次/分"));
const oxygenStats = computed(() => getNumberStats(bloodOxygenList.value, 0, "%"));
const configuredBoxCount = computed(() => {
  return boxSlots.value.filter((slot) => slot.name).length;
});

const filteredMedicineLibrary = computed(() => {
  const keyword = medicineLibrarySearch.value.trim().toLowerCase();
  if (!keyword) {
    return medicineLibrary.value;
  }

  return medicineLibrary.value.filter((item) => {
    const text = [
      item.name,
      item.genericName,
      item.category,
      item.summary,
      ...(Array.isArray(item.aliases) ? item.aliases : []),
    ]
      .join(" ")
      .toLowerCase();
    return text.includes(keyword);
  });
});

const medicineLibraryAiCount = computed(() => {
  return medicineLibrary.value.filter((item) => item.aiGenerated).length;
});

const medicineLibraryManualCount = computed(() => {
  return Math.max(medicineLibrary.value.length - medicineLibraryAiCount.value, 0);
});

const boxMedicineOptions = computed(() => {
  return boxSlots.value
    .filter((slot) => slot.name)
    .map((slot) => {
      return {
        id: slot.id,
        title: slot.title,
        medicineId: slot.medicineId || "",
        name: slot.name,
        quantity: slot.quantity,
        lowThreshold: slot.lowThreshold,
      };
    });
});

const selectedVideoSession = computed(() => {
  return medicineVideoSessions.value.find((item) => item.id === selectedVideoSessionId.value) || null;
});

const esp32camMjpegUrl = computed(() => `${SERVER_HTTP}/esp32cam/mjpeg?v=${esp32camStreamKey.value}`);

const currentVideoFrame = computed(() => {
  const frames = selectedVideoSession.value?.frames || [];
  if (frames.length === 0) {
    return null;
  }

  const index = Math.min(Math.max(activeVideoFrameIndex.value, 0), frames.length - 1);
  return frames[index] || null;
});

const currentVideoFrameKey = computed(() => {
  const frame = currentVideoFrame.value;
  if (!frame) {
    return "";
  }

  return [
    selectedVideoSession.value?.id || "",
    activeVideoFrameIndex.value,
    frame.index || "",
    frame.timestamp || "",
    frame.hash || "",
    frame.size || 0,
  ].join("-");
});

const pageTitle = computed(() => {
  const map = {
    sensor: "健康检测",
    medicine: "用药管理",
    library: "药品库",
    reminder: "用药记录",
    box: "药仓管理",
    identity: "用户身份",
    family: "家属监管",
    settings: "系统设置",
  };

  return map[currentPage.value] || "仪表盘";
});

const riskClass = computed(() => {
  if (device.value.riskLevel === "警告") {
    return "warning";
  }

  if (device.value.riskLevel === "提示") {
    return "notice";
  }

  return "normal";
});

function formatBodyTemp(value) {
  if (value === null || value === undefined) {
    return "暂无";
  }

  const num = Number(value);

  if (Number.isNaN(num) || num <= -50) {
    return "暂无";
  }

  return `${num.toFixed(2)} ℃`;
}

function formatHeartRate(value) {
  if (value === null || value === undefined) {
    return "待接入";
  }

  const num = Number(value);

  if (Number.isNaN(num) || num <= 0) {
    return "待接入";
  }

  return `${num.toFixed(0)} 次/分`;
}

function formatBloodOxygen(value) {
  if (value === null || value === undefined) {
    return "待接入";
  }

  const num = Number(value);

  if (Number.isNaN(num) || num <= 0) {
    return "待接入";
  }

  return `${num.toFixed(0)} %`;
}

function openHealthDetail(type) {
  healthDetail.value = type;
  activeHealthTab.value = type;
}

function closeHealthDetail() {
  healthDetail.value = "";
}

function toExportValue(value, digits) {
  const num = Number(value);

  if (value === null || value === undefined || Number.isNaN(num)) {
    return "";
  }

  return num.toFixed(digits);
}

function getSeriesWindow(times, values) {
  const limit = healthRangeLimitMap[selectedHealthRange.value] || values.length;
  const start = Math.max(0, values.length - limit);

  return {
    times: times.slice(start),
    values: values.slice(start),
  };
}

function formatMeasurementLabel(date, time) {
  if (date && time) {
    return `${date} ${time}`;
  }

  return date || time || "--";
}

function getCombinedHealthSeries() {
  const rowMap = new Map();

  function ensureRow(date, time, fallbackIndex) {
    const key = `${date || "--"}|${time || fallbackIndex}`;

    if (!rowMap.has(key)) {
      rowMap.set(key, {
        time: formatMeasurementLabel(date, time),
        heartRate: null,
        bloodOxygen: null,
        order: fallbackIndex,
      });
    }

    return rowMap.get(key);
  }

  heartRateList.value.forEach((value, index) => {
    const row = ensureRow(heartDateList[index], heartTimeList[index], index);
    row.heartRate = Number(value);
  });

  bloodOxygenList.value.forEach((value, index) => {
    const row = ensureRow(oxygenDateList[index], oxygenTimeList[index], index);
    row.bloodOxygen = Number(value);
  });

  const rows = Array.from(rowMap.values()).sort((a, b) => {
    return a.order - b.order || a.time.localeCompare(b.time);
  });
  const limit = healthRangeLimitMap[selectedHealthRange.value] || rows.length;
  const visibleRows = rows.slice(Math.max(0, rows.length - limit));

  return {
    times: visibleRows.map((row) => row.time),
    heartData: visibleRows.map((row) => row.heartRate),
    oxygenData: visibleRows.map((row) => row.bloodOxygen),
  };
}

function selectHealthRange(value) {
  selectedHealthRange.value = value;
}

function resetHealthZoom() {
  selectedHealthRange.value = "1d";

  [heartChart, bodyChart, oxygenChart].forEach((item) => {
    if (item) {
      item.dispatchAction({
        type: "dataZoom",
        start: 0,
        end: 100,
      });
      item.resize();
    }
  });
}

function escapeCsvValue(value) {
  const text = String(value ?? "");

  if (text.includes(",") || text.includes('"') || text.includes("\n")) {
    return `"${text.replace(/"/g, '""')}"`;
  }

  return text;
}

function downloadCsv(filename, headers, rows) {
  const csv = [headers, ...rows]
    .map((row) => row.map(escapeCsvValue).join(","))
    .join("\n");
  const blob = new Blob([`\ufeff${csv}`], {
    type: "text/csv;charset=utf-8;",
  });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");

  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

function escapeExcelXml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function downloadExcelTable(filename, headers, rows, columnWidths, options = {}) {
  const columns = headers
    .map((_, index) => `<Column ss:Width="${columnWidths[index] || 90}"/>`)
    .join("");
  const headerCells = headers
    .map((item) => `<Cell ss:StyleID="Header"><Data ss:Type="String">${escapeExcelXml(item)}</Data></Cell>`)
    .join("");
  const dataRows = rows
    .map((row) => {
      const cells = row
        .map((item) => `<Cell><Data ss:Type="String">${escapeExcelXml(item)}</Data></Cell>`)
        .join("");
      return `<Row>${cells}</Row>`;
    })
    .join("");
  const summaryRows = Array.isArray(options.summaryRows) ? options.summaryRows : [];
  const summarySection = summaryRows.length
    ? `<Row ss:Height="26"><Cell ss:StyleID="SummaryTitle" ss:MergeAcross="${headers.length - 1}"><Data ss:Type="String">${escapeExcelXml(options.summaryTitle || "数据汇总")}</Data></Cell></Row>
${summaryRows
  .map((item) => `<Row ss:Height="23"><Cell ss:StyleID="SummaryLabel"><Data ss:Type="String">${escapeExcelXml(item[0])}</Data></Cell><Cell ss:StyleID="SummaryValue" ss:MergeAcross="${Math.max(0, headers.length - 2)}"><Data ss:Type="String">${escapeExcelXml(item[1])}</Data></Cell></Row>`)
  .join("")}
<Row ss:Height="10"/>`
    : "";
  const workbook = `<?xml version="1.0" encoding="UTF-8"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
 <Styles>
  <Style ss:ID="Default"><Alignment ss:Vertical="Center"/></Style>
  <Style ss:ID="Header"><Font ss:Bold="1"/><Interior ss:Color="#EDEBFF" ss:Pattern="Solid"/></Style>
  <Style ss:ID="SummaryTitle"><Alignment ss:Horizontal="Center" ss:Vertical="Center"/><Font ss:Bold="1" ss:Size="14" ss:Color="#FFFFFF"/><Interior ss:Color="#6C63FF" ss:Pattern="Solid"/></Style>
  <Style ss:ID="SummaryLabel"><Font ss:Bold="1"/><Interior ss:Color="#F3F1FF" ss:Pattern="Solid"/></Style>
  <Style ss:ID="SummaryValue"><Alignment ss:Horizontal="Left"/><Font ss:Bold="1"/></Style>
 </Styles>
 <Worksheet ss:Name="数据明细"><Table>${columns}${summarySection}<Row>${headerCells}</Row>${dataRows}</Table></Worksheet>
</Workbook>`;
  const blob = new Blob([workbook], {
    type: "application/vnd.ms-excel;charset=utf-8;",
  });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");

  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

function exportMedicinePutRecords() {
  if (medicinePutRecords.value.length === 0) {
    alert("暂无可导出的加药记录");
    return;
  }

  const date = formatLocalDate(new Date());
  const headers = ["加药日期时间", "药仓号", "药品名称", "加药数量", "加药后库存"];
  const rows = medicinePutRecords.value.map((record) => {
    return [
      formatDateTime(record.recordedAt),
      `第 ${record.boxId} 药仓`,
      record.medicineName || "",
      record.putCount,
      record.after,
    ];
  });

  downloadExcelTable(`药仓加药记录-${date}.xls`, headers, rows, [160, 90, 140, 90, 110]);
}

function exportHeartOxygenTable() {
  if (heartOxygenExportRows.value.length === 0) {
    alert("暂无可导出的心率血氧数据");
    return;
  }

  const date = new Date().toISOString().slice(0, 10);
  const headers = [
    "日期",
    "时间",
    "心率(bpm)",
    "血氧(%)",
  ];
  const rows = heartOxygenExportRows.value.map((row) => {
    return [
      row.date,
      row.time,
      row.heartRate,
      row.bloodOxygen,
    ];
  });

  downloadExcelTable(`心率血氧数据-${date}.xls`, headers, rows, [110, 95, 90, 90]);
}

function exportBodyTemperatureTable() {
  if (bodyTemperatureExportRows.value.length === 0) {
    alert("暂无可导出的体温数据");
    return;
  }

  const date = new Date().toISOString().slice(0, 10);
  const headers = ["日期", "时间", "体温(°C)"];
  const rows = bodyTemperatureExportRows.value.map((row) => {
    return [row.date, row.time, row.bodyTemperature];
  });

  downloadExcelTable(`体温数据-${date}.xls`, headers, rows, [110, 95, 90]);
}

function exportHealthAlarmTable() {
  if (healthAlarmExportRows.value.length === 0) {
    alert("暂无可导出的异常预警数据");
    return;
  }

  const date = new Date().toISOString().slice(0, 10);
  const headers = ["时间", "异常类型", "预警内容"];
  const rows = healthAlarmExportRows.value.map((row) => {
    return [row.time, row.type, row.message];
  });

  downloadCsv(`异常预警数据-${date}.csv`, headers, rows);
}

function exportMedicationCsv() {
  const headers = ["日期", "餐次", "计划时间", "用药计划", "服药状态"];
  const rows = medicationCalendarCells.value
    .filter((cell) => !cell.blank)
    .flatMap((cell) => {
      return cell.meals.map((meal) => {
        return [
          cell.dateKey,
          meal.label,
          meal.time,
          meal.description,
          medicationStatusLabel(meal),
        ];
      });
    });

  downloadExcelTable(
    `用药记录-${currentMonthKey.value}.xls`,
    headers,
    rows,
    [110, 90, 100, 220, 100],
    {
      summaryTitle: `${currentMonthLabel.value}用药情况汇总`,
      summaryRows: [
        ["服药成功", `${monthlyMedicationStats.value.done} 次`],
        ["应服总次数", `${monthlyMedicationStats.value.total} 次`],
        [
          "本月服药成功率",
          `${monthlyMedicationStats.value.percent}%（${monthlyMedicationStats.value.done}/${monthlyMedicationStats.value.total} 次）`,
        ],
      ],
    }
  );
}

function initMedicationChart() {
  if (!medicationChartRef.value) {
    return;
  }

  if (medicationChart && medicationChart.getDom() !== medicationChartRef.value) {
    medicationChart.dispose();
    medicationChart = null;
  }

  if (!medicationChart) {
    medicationChart = echarts.init(medicationChartRef.value);
  }

  updateMedicationChart();
}

function updateMedicationChart() {
  if (!medicationChart) {
    return;
  }

  const days = medicationDailyStats.value.map((item) => `${item.day}日`);
  const totals = medicationDailyStats.value.map((item) => item.total);
  const done = medicationDailyStats.value.map((item) => item.done);
  const rates = medicationDailyStats.value.map((item) => {
    return item.total === 0 ? 0 : Math.round((item.done / item.total) * 100);
  });

  medicationChart.setOption(
    {
      animationDuration: 350,
      color: ["#24b47e", "#5265d6", "#f2a93b"],
      tooltip: {
        trigger: "axis",
        formatter(params) {
          const index = params[0]?.dataIndex || 0;
          return [
            `${currentMonthLabel.value}${medicationDailyStats.value[index]?.day || ""} 日`,
            `服药成功：${done[index] || 0} 次`,
            `应服次数：${totals[index] || 0} 次`,
            `成功率：${rates[index] || 0}%`,
          ].join("<br>");
        },
      },
      legend: {
        top: 0,
        data: ["服药成功", "应服次数", "成功率"],
        textStyle: {
          color: "#667085",
        },
      },
      grid: {
        left: 34,
        right: 40,
        top: 44,
        bottom: 30,
        containLabel: true,
      },
      xAxis: {
        type: "category",
        data: days,
        axisLine: {
          lineStyle: {
            color: "#d9dee8",
          },
        },
        axisLabel: {
          color: "#7b8496",
          interval: days.length > 20 ? 4 : 0,
        },
      },
      yAxis: [
        {
          type: "value",
          minInterval: 1,
          axisLabel: {
            color: "#7b8496",
          },
          splitLine: {
            lineStyle: {
              color: "#edf0f5",
            },
          },
        },
        {
          type: "value",
          min: 0,
          max: 100,
          axisLabel: {
            color: "#7b8496",
            formatter: "{value}%",
          },
          splitLine: {
            show: false,
          },
        },
      ],
      series: [
        {
          name: "服药成功",
          type: "bar",
          data: done,
          barMaxWidth: 12,
          itemStyle: {
            borderRadius: [3, 3, 0, 0],
          },
        },
        {
          name: "应服次数",
          type: "bar",
          data: totals,
          barMaxWidth: 12,
          itemStyle: {
            borderRadius: [3, 3, 0, 0],
          },
        },
        {
          name: "成功率",
          type: "line",
          yAxisIndex: 1,
          data: rates,
          smooth: true,
          symbolSize: 5,
        },
      ],
    },
    true
  );
}

function exportMedicationChart() {
  initMedicationChart();

  if (!medicationChart) {
    alert("图表尚未加载完成");
    return;
  }

  const link = document.createElement("a");
  link.href = medicationChart.getDataURL({
    type: "png",
    pixelRatio: 2,
    backgroundColor: "#ffffff",
  });
  link.download = `用药记录图表-${currentMonthKey.value}.png`;
  link.click();
}

function resizeVisibleCharts() {
  [chart, heartChart, oxygenChart, bodyChart, medicationChart].forEach((item) => {
    if (item) {
      item.resize();
    }
  });
}

function initChart() {
  if (!chartRef.value) {
    return;
  }

  chart = echarts.init(chartRef.value);

  chart.setOption({
    tooltip: {
      trigger: "axis",
    },
    legend: {
      data: ["环境温度", "环境湿度"],
    },
    xAxis: {
      type: "category",
      data: timeList,
    },
    yAxis: {
      type: "value",
    },
    series: [
      {
        name: "环境温度",
        type: "line",
        smooth: true,
        data: tempList,
      },
      {
        name: "环境湿度",
        type: "line",
        smooth: true,
        data: humiList,
      },
    ],
  });
}

function updateChart() {
  if (!chart) {
    return;
  }

  chart.setOption({
    xAxis: {
      type: "category",
      data: timeList,
    },
    yAxis: {
      type: "value",
    },
    series: [
      {
        name: "环境温度",
        type: "line",
        smooth: true,
        data: tempList,
      },
      {
        name: "环境湿度",
        type: "line",
        smooth: true,
        data: humiList,
      },
    ],
  });
}

function initHeartChart() {
  if (!heartChartRef.value) {
    return;
  }

  heartChart = echarts.init(heartChartRef.value);
  updateHeartChart();
}

function updateHeartChart() {
  if (!heartChart) {
    return;
  }

  const series = getCombinedHealthSeries();

  heartChart.setOption({
    tooltip: {
      trigger: "axis",
    },
    legend: {
      top: 6,
      data: ["心率 (bpm)", "血氧 (%)"],
    },
    grid: {
      left: 54,
      right: 54,
      top: 56,
      bottom: 54,
    },
    dataZoom: [
      {
        type: "inside",
        start: 0,
        end: 100,
      },
    ],
    xAxis: {
      type: "category",
      data: series.times,
      axisLabel: {
        rotate: 25,
      },
    },
    yAxis: [
      {
        type: "value",
        name: "心率",
        min: 40,
        max: 140,
      },
      {
        type: "value",
        name: "血氧",
        min: 85,
        max: 100,
        axisLabel: {
          formatter: "{value}%",
        },
      },
    ],
    series: [
      {
        name: "心率 (bpm)",
        type: "line",
        smooth: true,
        symbol: "circle",
        symbolSize: 7,
        data: series.heartData,
        areaStyle: {
          opacity: 0.08,
        },
      },
      {
        name: "血氧 (%)",
        type: "line",
        yAxisIndex: 1,
        smooth: true,
        symbol: "circle",
        symbolSize: 7,
        data: series.oxygenData,
        areaStyle: {
          opacity: 0.08,
        },
      },
    ],
  });
  return;

  heartChart.setOption({
    tooltip: {
      trigger: "axis",
      formatter(params) {
        if (!params || params.length === 0) {
          return "";
        }

        const item = params[0];
        return `${item.axisValue}<br/>心率：${Number(item.data).toFixed(0)} 次/分`;
      },
    },
    grid: {
      left: 45,
      right: 25,
      top: 35,
      bottom: 35,
    },
    xAxis: {
      type: "category",
      data: heartTimeList.map((time, index) => {
        return formatMeasurementLabel(heartDateList[index], time);
      }),
    },
    yAxis: {
      type: "value",
      min: 40,
      max: 140,
      axisLabel: {
        formatter: "{value}",
      },
    },
    series: [
      {
        name: "心率",
        type: "line",
        smooth: true,
        symbol: "circle",
        symbolSize: 8,
        data: heartRateList.value,
      },
    ],
  });
}

function initOxygenChart() {
  if (!oxygenChartRef.value) {
    return;
  }

  oxygenChart = echarts.init(oxygenChartRef.value);
  updateOxygenChart();
}

function updateOxygenChart() {
  if (!oxygenChart) {
    return;
  }

  oxygenChart.setOption({
    tooltip: {
      trigger: "axis",
      formatter(params) {
        if (!params || params.length === 0) {
          return "";
        }

        const item = params[0];
        return `${item.axisValue}<br/>血氧：${Number(item.data).toFixed(0)} %`;
      },
    },
    grid: {
      left: 45,
      right: 25,
      top: 35,
      bottom: 35,
    },
    xAxis: {
      type: "category",
      data: oxygenTimeList.map((time, index) => {
        return formatMeasurementLabel(oxygenDateList[index], time);
      }),
    },
    yAxis: {
      type: "value",
      min: 85,
      max: 100,
      axisLabel: {
        formatter: "{value}%",
      },
    },
    series: [
      {
        name: "血氧",
        type: "line",
        smooth: true,
        symbol: "circle",
        symbolSize: 8,
        data: bloodOxygenList.value,
      },
    ],
  });
}

function initBodyChart() {
  if (!bodyChartRef.value) {
    return;
  }

  bodyChart = echarts.init(bodyChartRef.value);
  updateBodyChart();
}

function updateBodyChart() {
  if (!bodyChart) {
    return;
  }

  const bodyMeasurementLabels = bodyTimeList.map((time, index) => {
    return formatMeasurementLabel(bodyDateList[index], time);
  });
  const series = getSeriesWindow(bodyMeasurementLabels, bodyTempList.value);

  bodyChart.setOption({
    tooltip: {
      trigger: "axis",
    },
    legend: {
      top: 6,
      data: ["体温 (°C)"],
    },
    grid: {
      left: 54,
      right: 28,
      top: 56,
      bottom: 54,
    },
    dataZoom: [
      {
        type: "inside",
        start: 0,
        end: 100,
      },
    ],
    xAxis: {
      type: "category",
      data: series.times,
      axisLabel: {
        rotate: 25,
      },
    },
    yAxis: {
      type: "value",
      min: 35,
      max: 39,
      axisLabel: {
        formatter: "{value}°C",
      },
    },
    series: [
      {
        name: "体温 (°C)",
        type: "line",
        smooth: true,
        symbol: "circle",
        symbolSize: 7,
        data: series.values,
        markLine: {
          symbol: "none",
          data: [
            {
              yAxis: 37.3,
              name: "低热阈值",
            },
            {
              yAxis: 38,
              name: "发热阈值",
            },
          ],
        },
      },
    ],
  });
  return;

  bodyChart.setOption({
    tooltip: {
      trigger: "axis",
      formatter(params) {
        if (!params || params.length === 0) {
          return "";
        }

        const item = params[0];
        return `${item.axisValue}<br/>体温：${Number(item.data).toFixed(2)} ℃`;
      },
    },
    grid: {
      left: 45,
      right: 25,
      top: 35,
      bottom: 35,
    },
    xAxis: {
      type: "category",
      data: bodyMeasurementLabels,
    },
    yAxis: {
      type: "value",
      min: 35,
      max: 39,
      axisLabel: {
        formatter: "{value}℃",
      },
    },
    series: [
      {
        name: "体温",
        type: "line",
        smooth: true,
        symbol: "circle",
        symbolSize: 8,
        data: bodyTempList.value,
        markLine: {
          data: [
            {
              yAxis: 37.3,
              name: "低热阈值",
            },
            {
              yAxis: 38.0,
              name: "发热阈值",
            },
          ],
        },
      },
    ],
  });
}

function disposeHealthCharts() {
  if (heartChart) {
    heartChart.dispose();
    heartChart = null;
  }

  if (oxygenChart) {
    oxygenChart.dispose();
    oxygenChart = null;
  }

  if (bodyChart) {
    bodyChart.dispose();
    bodyChart = null;
  }
}

function refreshHealthCharts() {
  if (heartChartRef.value) {
    if (heartChart && heartChart.getDom() !== heartChartRef.value) {
      heartChart.dispose();
      heartChart = null;
    }

    if (!heartChart) {
      initHeartChart();
    } else {
      heartChart.resize();
      updateHeartChart();
    }
  }

  if (oxygenChartRef.value) {
    if (oxygenChart && oxygenChart.getDom() !== oxygenChartRef.value) {
      oxygenChart.dispose();
      oxygenChart = null;
    }

    if (!oxygenChart) {
      initOxygenChart();
    } else {
      oxygenChart.resize();
      updateOxygenChart();
    }
  }

  if (bodyChartRef.value) {
    if (bodyChart && bodyChart.getDom() !== bodyChartRef.value) {
      bodyChart.dispose();
      bodyChart = null;
    }

    if (!bodyChart) {
      initBodyChart();
    } else {
      bodyChart.resize();
      updateBodyChart();
    }
  }
}

function updateHeartHistory(data) {
  heartTimeList.length = 0;
  heartDateList.length = 0;
  heartRateList.value = [];

  if (Array.isArray(data)) {
    data.forEach((item) => {
      heartDateList.push(item.date || "");
      heartTimeList.push(item.time || "");
      heartRateList.value.push(Number(item.value));
    });
  }

  nextTick(() => {
    if (!heartChart && heartChartRef.value) {
      initHeartChart();
    } else {
      updateHeartChart();
    }
  });
}

function updateOxygenHistory(data) {
  oxygenTimeList.length = 0;
  oxygenDateList.length = 0;
  bloodOxygenList.value = [];

  if (Array.isArray(data)) {
    data.forEach((item) => {
      oxygenDateList.push(item.date || "");
      oxygenTimeList.push(item.time || "");
      bloodOxygenList.value.push(Number(item.value));
    });
  }

  nextTick(() => {
    if (!oxygenChart && oxygenChartRef.value) {
      initOxygenChart();
    } else {
      updateOxygenChart();
    }
  });
}

function updateBodyHistory(data) {
  bodyTimeList.length = 0;
  bodyDateList.length = 0;
  bodyTempList.value = [];

  if (Array.isArray(data)) {
    data.forEach((item) => {
      bodyDateList.push(item.date || "");
      bodyTimeList.push(item.time || "");
      bodyTempList.value.push(Number(item.value));
    });
  }

  nextTick(() => {
    if (!bodyChart && bodyChartRef.value) {
      initBodyChart();
    } else {
      updateBodyChart();
    }
  });
}

async function loadBodyHistoryFromServer() {
  try {
    const res = await fetch(`${SERVER_HTTP}/api/device/body-temperature/history`);
    const result = await res.json();

    if (result.code === 0 && Array.isArray(result.data)) {
      updateBodyHistory(result.data);
    }
  } catch (error) {
    console.log("体温历史数据获取失败：", error);
  }
}

watch(currentPage, async (page, oldPage) => {
  if (oldPage === "sensor" && page !== "sensor") {
    disposeHealthCharts();
  }

  if (oldPage === "reminder" && page !== "reminder" && medicationChart) {
    medicationChart.dispose();
    medicationChart = null;
  }

  if (oldPage === "family" && page !== "family") {
    stopFramePlayback();
  }

  if (page === "dashboard") {
    await nextTick();

    if (!chart) {
      initChart();
    } else {
      chart.resize();
      updateChart();
    }
  }

  if (page === "sensor") {
    await nextTick();
    await nextTick();
    refreshHealthCharts();
  }

  if (page === "reminder") {
    await nextTick();
    initMedicationChart();
  }

  if (page === "family") {
    await loadEsp32camState();
    await loadMedicineVideoSessions();
  }
});

watch(
  medicationDailyStats,
  async () => {
    if (currentPage.value !== "reminder") {
      return;
    }

    await nextTick();
    initMedicationChart();
  },
  { deep: true }
);

watch(selectedHealthRange, async () => {
  await nextTick();

  if (heartChart) {
    updateHeartChart();
    heartChart.resize();
  }

  if (bodyChart) {
    updateBodyChart();
    bodyChart.resize();
  }

  if (oxygenChart) {
    updateOxygenChart();
    oxygenChart.resize();
  }
});

watch(activeHealthTab, async () => {
  await nextTick();

  if (activeHealthTab.value === "heart") {
    if (!heartChart && heartChartRef.value) {
      initHeartChart();
    } else if (heartChart) {
      heartChart.resize();
      updateHeartChart();
    }
  }

  if (activeHealthTab.value === "oxygen") {
    if (!oxygenChart && oxygenChartRef.value) {
      initOxygenChart();
    } else if (oxygenChart) {
      oxygenChart.resize();
      updateOxygenChart();
    }
  }

  if (activeHealthTab.value === "body") {
    if (!bodyChart && bodyChartRef.value) {
      initBodyChart();
    } else if (bodyChart) {
      bodyChart.resize();
      updateBodyChart();
    }
  }
});

watch(healthDetail, async () => {
  if (healthDetail.value) {
    activeHealthTab.value = healthDetail.value;
  }

  await nextTick();
  await nextTick();
  refreshHealthCharts();
});

function startDashboardApp() {
  if (dashboardStarted) {
    return;
  }

  dashboardStarted = true;
  loadAppSettings();
  loadBoxSlotsFromServer();
  loadMedicineDataFromServer();
  loadMedicineTakenRecordsFromServer();
  loadMedicinePutRecordsFromServer();
  loadMedicineLibrary();
  loadMedicineVideoSessions();
  loadEsp32camState();
  loadIdentityStatus();
  loadBodyHistoryFromServer();
  currentNow.value = new Date();
  currentTimeTimer = window.setInterval(() => {
    currentNow.value = new Date();
  }, 1000);
  esp32camStateTimer = window.setInterval(loadEsp32camState, 2000);
  window.addEventListener("resize", resizeVisibleCharts);

  initChart();

  socket = io(SERVER_WS);

  socket.on("connect", () => {
    console.log("WebSocket 已连接");
  });

  socket.on("deviceData", (data) => {
    device.value = {
      ...device.value,
      ...data,
    };

    timeList.push(data.time);
    tempList.push(data.temperature);
    humiList.push(data.humidity);

    if (timeList.length > 12) {
      timeList.shift();
      tempList.shift();
      humiList.shift();
    }

    updateChart();
  });

  socket.on("bodyTemperatureHistory", (data) => {
    updateBodyHistory(data);
  });

  socket.on("heartRateHistory", (data) => {
    updateHeartHistory(data);
  });

  socket.on("bloodOxygenHistory", (data) => {
    updateOxygenHistory(data);
  });

  socket.on("alarmData", (data) => {
    alarms.value = data;
  });

  socket.on("identityData", applyIdentityStatus);
  socket.on("medicineTaken", applyMedicineTaken);
  socket.on("medicineTakenRecords", mergeMedicineTakenRecords);
  socket.on("medicinePutRecords", applyMedicinePutRecords);
  socket.on("medicineLibrary", applyMedicineLibrary);
  socket.on("medicineVideoSessions", applyMedicineVideoSessions);
  socket.on("esp32camState", applyEsp32camState);

  socket.on("medicineConfig", (data) => {
    if (currentPage.value === "medicine") {
      return;
    }

    applyMedicineConfig(data);
  });

  socket.on("medicineBoxes", (data) => {
    applyBoxConfig(data);
  });
}

onMounted(() => {
  checkAuthSession();
});

onBeforeUnmount(() => {
  if (currentTimeTimer) {
    window.clearInterval(currentTimeTimer);
  }
  if (identityStatusTimer) {
    window.clearInterval(identityStatusTimer);
  }
  if (esp32camStateTimer) {
    window.clearInterval(esp32camStateTimer);
  }
  stopFramePlayback();

  window.removeEventListener("resize", resizeVisibleCharts);
  if (socket) {
    socket.disconnect();
  }

  [chart, heartChart, oxygenChart, bodyChart, medicationChart].forEach((item) => {
    if (item) {
      item.dispose();
    }
  });
});
</script>

<style>
* {
  box-sizing: border-box;
}

html,
body,
#app {
  margin: 0;
  padding: 0;
  width: 100%;
  height: 100%;
  min-height: 100vh;
}

body {
  overflow-x: hidden;
  overflow-y: hidden;
}
</style>

<style scoped>
.auth-page {
  min-height: 100dvh;
  display: grid;
  place-items: center;
  padding: 24px;
  background:
    radial-gradient(circle at 18% 16%, rgba(79, 172, 254, 0.22), transparent 30%),
    linear-gradient(135deg, #5f7bea 0%, #7656c8 48%, #dc73d9 100%);
}

.auth-card {
  width: min(460px, 100%);
  padding: 46px 44px;
  border: 1px solid rgba(255, 255, 255, 0.72);
  border-radius: 8px;
  background: rgba(255, 255, 255, 0.94);
  box-shadow: 0 28px 70px rgba(39, 30, 95, 0.28);
  text-align: center;
}

.auth-icon {
  width: 66px;
  height: 66px;
  display: grid;
  place-items: center;
  margin: 0 auto 18px;
  border-radius: 18px;
  background: #eef2ff;
  font-size: 34px;
}

.auth-card h1 {
  margin: 0;
  color: #252b3f;
  font-size: 28px;
  font-weight: 800;
}

.auth-card p {
  margin: 10px 0 24px;
  color: #717b91;
  font-size: 14px;
}

.auth-tabs {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 8px;
  margin-bottom: 22px;
  padding: 6px;
  border-radius: 8px;
  background: #f1f5f9;
}

.auth-tabs button,
.auth-submit,
.logout-btn {
  border: 0;
  cursor: pointer;
  font-weight: 800;
}

.auth-tabs button {
  min-height: 46px;
  border-radius: 7px;
  color: #596174;
  background: transparent;
}

.auth-tabs button.active {
  color: #5967dc;
  background: #fff;
  box-shadow: 0 8px 18px rgba(45, 55, 105, 0.12);
}

.auth-form {
  display: grid;
  gap: 16px;
}

.auth-form label {
  display: grid;
  gap: 8px;
  text-align: left;
}

.auth-form span {
  color: #3b4357;
  font-size: 14px;
  font-weight: 800;
}

.auth-form input {
  width: 100%;
  height: 52px;
  border: 1px solid #dfe6f2;
  border-radius: 8px;
  padding: 0 15px;
  outline: none;
  color: #172033;
  background: #fff;
  font-size: 15px;
}

.auth-password-field {
  position: relative;
}

.auth-password-field input {
  padding-right: 52px;
}

.auth-eye-btn {
  position: absolute;
  top: 50%;
  right: 10px;
  transform: translateY(-50%);
  width: 36px;
  height: 36px;
  display: grid;
  place-items: center;
  border: 0;
  border-radius: 8px;
  background: transparent;
  cursor: pointer;
  font-size: 18px;
  line-height: 1;
}

.auth-eye-btn:hover {
  background: #f1f5f9;
}

.auth-eye-btn:focus-visible {
  outline: 2px solid #6875ef;
  outline-offset: 2px;
}

.auth-form input:focus {
  border-color: #6875ef;
  box-shadow: 0 0 0 4px rgba(104, 117, 239, 0.12);
}

.auth-error {
  border-radius: 8px;
  padding: 10px 12px;
  color: #b42318;
  background: #fff1f0;
  font-size: 13px;
  font-weight: 700;
  text-align: left;
}

.auth-submit {
  min-height: 54px;
  border-radius: 8px;
  color: #fff;
  background: linear-gradient(105deg, #5f6df2, #8b55f4);
  box-shadow: 0 15px 28px rgba(95, 109, 242, 0.26);
  font-size: 16px;
}

.auth-submit:disabled {
  cursor: not-allowed;
  opacity: 0.62;
  box-shadow: none;
}

.top-actions {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
  justify-content: flex-end;
}

.auth-user-badge,
.logout-btn {
  min-height: 38px;
  display: inline-flex;
  align-items: center;
  border-radius: 8px;
  padding: 0 13px;
  font-size: 13px;
}

.auth-user-badge {
  color: #4f46e5;
  background: #eef2ff;
  font-weight: 800;
}

.logout-btn {
  border: 1px solid #dfe6f2;
  color: #465268;
  background: #fff;
}

.logout-btn:hover {
  border-color: #bfc8da;
  background: #f8fafc;
}

.medicine-save-row {
  margin-top: 24px;
  display: flex;
  justify-content: center;
  grid-column: 1 / -1;
}

.save-all-btn {
  width: 320px;
  height: 48px;
  border: none;
  border-radius: 12px;
  background: #6c63ff;
  color: white;
  font-size: 16px;
  font-weight: bold;
  cursor: pointer;
}

.save-all-btn:hover {
  background: #5b4be7;
}

.medicine-slots {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 22px;
}

.medicine-user-card {
  grid-column: 1 / -1;
  display: grid;
  grid-template-columns: minmax(280px, 1.4fr) repeat(2, minmax(220px, 1fr));
  gap: 24px;
  align-items: end;
  padding: 24px;
  border: 1px solid #e5e7eb;
  border-radius: 16px;
  background: white;
}

.medicine-user-card h3 {
  margin: 4px 0 6px;
  color: #28324a;
}

.medicine-user-card p {
  margin: 0;
  color: #7b8496;
  font-size: 14px;
}

.medicine-user-eyebrow {
  color: #6c63ff;
  font-size: 13px;
  font-weight: 700;
}

.medicine-user-card label {
  display: flex;
  flex-direction: column;
  gap: 8px;
  color: #333;
  font-weight: 700;
}

.medicine-user-card input {
  height: 42px;
  padding: 0 12px;
  border: 1px solid #dcdfe6;
  border-radius: 10px;
  font-size: 15px;
  outline: none;
}

.medicine-user-card input:focus {
  border-color: #6c63ff;
  box-shadow: 0 0 0 3px rgb(108 99 255 / 10%);
}

.medicine-slot-card {
  background: white;
  border-radius: 16px;
  padding: 24px;
}

.slot-title {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 18px;
}

.medicine-time-grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 10px;
  margin-bottom: 18px;
}

.medicine-time-grid label {
  margin-bottom: 0;
  font-size: 13px;
}

.medicine-time-grid input {
  min-width: 0;
  padding: 0 8px;
}

.slot-title h3 {
  margin: 0;
  font-size: 22px;
}

.slot-title input {
  width: 130px;
  height: 40px;
  border: 1px solid #dcdfe6;
  border-radius: 10px;
  padding: 0 12px;
}

.medicine-slot-card label {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-bottom: 18px;
  color: #333;
  font-weight: bold;
  text-align: center;
}

.medicine-slot-card input,
.medicine-slot-card select {
  height: 42px;
  border: 1px solid #dcdfe6;
  border-radius: 10px;
  padding: 0 12px;
  font-size: 15px;
  outline: none;
  background: white;
}

.medicine-slot-card button {
  width: 100%;
  height: 44px;
  border: none;
  border-radius: 10px;
  background: #6c63ff;
  color: white;
  font-size: 16px;
  font-weight: bold;
  cursor: pointer;
}

.medicine-slot-card .delete-btn {
  width: auto;
  height: auto;
  border-radius: 8px;
  padding: 8px 14px;
  background: #ef4444;
}

.page {
  height: 100vh;
  min-height: 100vh;
  display: flex;
  background: linear-gradient(135deg, #5b5bd6, #df73f4);
  font-family: Arial, "Microsoft YaHei", sans-serif;
  overflow: hidden;
}

.side {
  width: 210px;
  height: 100vh;
  min-height: 0;
  background: rgba(255, 255, 255, 0.96);
  padding: 26px 16px;
  box-sizing: border-box;
  flex-shrink: 0;
  overflow-y: auto;
}

.logo {
  text-align: center;
  font-size: 46px;
}

.side h2 {
  text-align: center;
  margin: 8px 0 34px;
  color: #333;
  font-size: 22px;
}

.menu {
  padding: 14px 15px;
  margin-bottom: 8px;
  border-radius: 12px;
  color: #555;
  font-weight: bold;
  font-size: 15px;
  cursor: pointer;
  user-select: none;
  transition: all 0.2s;
}

.menu:hover {
  background: #f1efff;
  color: #5b4be7;
}

.menu.active {
  background: #ecebff;
  color: #5b4be7;
}

.main {
  flex: 1;
  height: 100vh;
  min-height: 0;
  padding: 28px 34px 40px;
  box-sizing: border-box;
  overflow-x: hidden;
  overflow-y: auto;
}

.top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  color: white;
  margin-bottom: 26px;
}

.top h1 {
  margin: 0;
  font-size: 30px;
  font-weight: 800;
}

.top p {
  margin: 8px 0 0;
  opacity: 0.92;
  font-size: 16px;
}

.online {
  background: #d7ffe6;
  color: #15964f;
  padding: 11px 24px;
  border-radius: 22px;
  font-weight: bold;
  white-space: nowrap;
}

.online.offline {
  background: #f3f4f6;
  color: #777;
}

.cards {
  display: grid;
  grid-template-columns: repeat(12, minmax(0, 1fr));
  gap: 24px;
}

.card {
  grid-column: span 3;
  background: white;
  border-radius: 18px;
  padding: 26px 28px;
  display: flex;
  align-items: center;
  gap: 22px;
  border-top: 5px solid #34d399;
  box-shadow: 0 8px 22px rgba(0, 0, 0, 0.09);
  min-height: 118px;
  box-sizing: border-box;
}

.cards .card:nth-last-child(-n + 3) {
  grid-column: span 4;
}

.card.normal {
  border-top-color: #34d399;
}

.card.notice {
  border-top-color: #60a5fa;
}

.card.warning {
  border-top-color: #ef4444;
  background: #fff1f1;
}

.placeholder-card {
  border-top-color: #f5b640;
}

.card-icon {
  font-size: 44px;
  width: 54px;
  text-align: center;
  flex-shrink: 0;
}

.name {
  color: #666;
  font-weight: bold;
  font-size: 16px;
}

.value {
  margin-top: 10px;
  font-size: 36px;
  font-weight: bold;
  color: #222;
  line-height: 1.1;
}

.value span {
  font-size: 18px;
  color: #666;
  margin-left: 4px;
}

.value.small {
  font-size: 25px;
}

.content {
  margin-top: 28px;
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 24px;
  align-items: stretch;
}

.bottom {
  margin-top: 24px;
  display: grid;
  grid-template-columns: 1.8fr 1fr 1fr;
  gap: 24px;
}

.panel {
  background: white;
  border-radius: 18px;
  padding: 24px 26px;
  min-height: 250px;
  box-sizing: border-box;
  box-shadow: 0 8px 22px rgba(0, 0, 0, 0.08);
}

.panel h3 {
  margin: 0 0 18px;
  font-size: 21px;
  color: #222;
}

.module-list {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px;
}

.module-item {
  background: #f7f7fb;
  border-radius: 13px;
  padding: 15px;
  display: flex;
  flex-direction: column;
  gap: 7px;
  border-left: 5px solid #c7c7d1;
  min-height: 76px;
  box-sizing: border-box;
}

.module-item.active {
  border-left-color: #34d399;
  background: #ecfdf5;
}

.module-item b {
  font-size: 16px;
  color: #333;
}

.module-item span {
  color: #666;
  font-size: 14px;
  line-height: 1.6;
}

.decision {
  background: #f8fafc;
  border-radius: 14px;
  padding: 20px;
  line-height: 1.8;
  min-height: 170px;
}

.decision-main {
  font-size: 25px;
  font-weight: bold;
  color: #2563eb;
  margin-bottom: 12px;
}

.decision p {
  color: #555;
  margin: 0;
}

.empty {
  color: #999;
  margin-top: 32px;
  text-align: center;
}

.alarm {
  background: #fff1f1;
  border-left: 5px solid #ef4444;
  border-radius: 10px;
  padding: 13px 14px;
  margin-top: 12px;
}

.alarm-title {
  font-weight: bold;
  color: #b91c1c;
}

.alarm-msg {
  margin-top: 6px;
  color: #555;
  line-height: 1.6;
}

.chart {
  width: 100%;
  height: 285px;
}

.text {
  color: #555;
  line-height: 1.9;
  font-size: 15px;
}

.sub-page {
  background: white;
  border-radius: 20px;
  padding: 30px;
  min-height: 680px;
  box-shadow: 0 8px 22px rgba(0, 0, 0, 0.08);
}

.sub-page h2 {
  margin: 0 0 24px;
  font-size: 30px;
  color: #222;
  text-align: center;
}

.sub-wide {
  margin-top: 24px;
  background: #f8fafc;
  border-radius: 16px;
  padding: 24px;
}

.sub-wide h3 {
  margin-top: 0;
  font-size: 22px;
  text-align: center;
  color: #596078;
}

.plan-list {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 14px;
}

.plan-list div {
  background: white;
  padding: 16px;
  border-radius: 12px;
  color: #444;
  line-height: 1.7;
  border-left: 5px solid #34d399;
}

.health-wide {
  margin-top: 0;
}

.health-page {
  display: flex;
  flex-direction: column;
  gap: 24px;
}

.health-cards {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 22px;
}

.health-card {
  background: white;
  border-radius: 16px;
  padding: 34px 24px;
  text-align: center;
  border-left: 5px solid #c7c7d1;
  min-height: 220px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.health-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 10px 24px rgba(0, 0, 0, 0.08);
}

.health-card.selected {
  box-shadow: 0 0 0 3px rgba(91, 91, 214, 0.16),
    0 10px 24px rgba(0, 0, 0, 0.08);
  transform: translateY(-2px);
}

.health-card.active-health {
  border-left-color: #34d399;
  background: #ecfdf5;
}

.health-card.todo {
  border-left-color: #94a3b8;
}

.health-icon {
  font-size: 42px;
  margin-bottom: 10px;
}

.health-card h3 {
  margin: 8px 0 8px;
  font-size: 24px;
  color: #596078;
}

.health-value {
  font-size: 30px;
  font-weight: bold;
  color: #111827;
  margin-bottom: 14px;
}

.health-card p {
  color: #666;
  line-height: 1.8;
  margin: 0;
}

.health-chart-panel {
  background: white;
  border-radius: 16px;
  padding: 24px;
  min-height: 360px;
}

.health-chart-panel h3 {
  text-align: center;
  color: #596078;
  margin-bottom: 18px;
}

.health-chart {
  width: 100%;
  height: 300px;
}

.medicine-wide {
  margin-top: 0;
}

.medicine-form {
  background: white;
  border-radius: 16px;
  padding: 24px;
  display: flex;
  flex-direction: column;
  gap: 18px;
}

.medicine-form label {
  display: flex;
  flex-direction: column;
  gap: 8px;
  color: #333;
  font-weight: bold;
}

.medicine-form input {
  height: 42px;
  border: 1px solid #dcdfe6;
  border-radius: 10px;
  padding: 0 12px;
  font-size: 15px;
  outline: none;
}

.medicine-form input:focus {
  border-color: #6c63ff;
}

.medicine-form button {
  height: 44px;
  border: none;
  border-radius: 10px;
  background: #6c63ff;
  color: white;
  font-size: 16px;
  font-weight: bold;
  cursor: pointer;
}

.medicine-item {
  margin-top: 14px;
  padding: 16px;
  border-radius: 12px;
  background: #f8fafc;
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-left: 5px solid #34d399;
}

.medicine-item b {
  font-size: 18px;
  margin-right: 16px;
  color: #2563eb;
}

.medicine-item span {
  color: #444;
}

.delete-btn {
  border: none;
  border-radius: 8px;
  padding: 8px 14px;
  background: #ef4444;
  color: white;
  cursor: pointer;
}

.mini-chart-title {
  margin-top: 18px;
  margin-bottom: 8px;
  font-weight: bold;
  color: #596078;
}

.mini-health-chart {
  height: 170px;
  margin-top: auto;
}

.mini-empty {
  height: 170px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #999;
  background: #f8fafc;
  border-radius: 12px;
  margin-top: 12px;
}

.health-detail-page {
  display: flex;
  flex-direction: column;
  gap: 22px;
}

.back-btn {
  width: 160px;
  height: 42px;
  border: none;
  border-radius: 12px;
  background: #6c63ff;
  color: white;
  font-size: 15px;
  font-weight: bold;
  cursor: pointer;
}

.back-btn:hover {
  background: #5b4be7;
}

.detail-chart-panel {
  min-height: 480px;
}

.detail-health-chart {
  height: 420px;
}

.detail-alarm-panel {
  background: white;
  border-radius: 16px;
  padding: 24px;
  min-height: 260px;
}

.detail-alarm-panel h3 {
  text-align: center;
  color: #596078;
  margin-bottom: 18px;
}

.health-dashboard-page {
  gap: 24px;
}

.health-toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 16px;
  background: white;
  border-radius: 16px;
  padding: 18px 20px;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.06);
}

.health-actions {
  display: flex;
  gap: 14px;
  flex-wrap: wrap;
}

.health-actions button,
.health-range-tabs button {
  border: none;
  border-radius: 12px;
  background: #6c63ff;
  color: white;
  font-size: 15px;
  font-weight: bold;
  cursor: pointer;
  transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
}

.health-actions button {
  min-width: 140px;
  height: 46px;
}

.health-actions button:hover,
.health-range-tabs button:hover {
  background: #5b4be7;
  box-shadow: 0 10px 22px rgba(91, 75, 231, 0.24);
  transform: translateY(-1px);
}

.health-export-tip {
  color: #7c8194;
  background: #f8fafc;
  border: 1px solid #eef1f7;
  border-radius: 12px;
  padding: 12px 16px;
  font-size: 14px;
}

.health-range-tabs {
  display: flex;
  justify-content: center;
  gap: 12px;
  flex-wrap: wrap;
}

.health-range-tabs button {
  min-width: 96px;
  height: 46px;
  background: #6c63ff;
  border: 1px solid #6c63ff;
  color: white;
  box-shadow: 0 8px 18px rgba(91, 75, 231, 0.16);
}

.health-range-tabs button.active {
  background: #4338ca;
  border-color: #4338ca;
  color: white;
  box-shadow: 0 12px 26px rgba(67, 56, 202, 0.32);
}

.health-stat-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 18px;
}

.health-stat-card {
  background: white;
  border-radius: 16px;
  padding: 20px;
  min-height: 105px;
  border-top: 5px solid #34d399;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.06);
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 10px;
}

.health-stat-card span {
  color: #6b7280;
  font-weight: bold;
}

.health-stat-card strong {
  color: #111827;
  font-size: 26px;
}

.health-chart-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 22px;
}

.health-visual-panel {
  min-height: 390px;
  border-top: 5px solid #34d399;
  box-shadow: 0 10px 24px rgba(0, 0, 0, 0.08);
}

.health-visual-panel:nth-child(2) {
  border-top-color: #f5b640;
}

.dashboard-health-chart {
  height: 310px;
}

.health-data-grid {
  display: grid;
  grid-template-columns: 1.6fr 1fr;
  gap: 22px;
}

.health-table-panel {
  background: white;
  border-radius: 16px;
  padding: 24px;
  min-height: 300px;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.06);
}

.health-table-panel h3 {
  margin: 0 0 18px;
  text-align: center;
  color: #596078;
}

.health-table-wrap {
  max-height: 320px;
  overflow: auto;
  border: 1px solid #eef1f7;
  border-radius: 12px;
}

.health-table {
  width: 100%;
  border-collapse: collapse;
  min-width: 760px;
  font-size: 14px;
}

.health-table th,
.health-table td {
  padding: 12px 14px;
  border-bottom: 1px solid #eef1f7;
  text-align: center;
  color: #4b5563;
}

.health-table th {
  position: sticky;
  top: 0;
  background: #f8fafc;
  color: #374151;
  font-weight: bold;
  z-index: 1;
}

.feature-page {
  display: flex;
  flex-direction: column;
  gap: 22px;
}

.feature-grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 20px;
}

.feature-card {
  background: white;
  border-radius: 16px;
  padding: 24px;
  min-height: 180px;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.06);
  border-top: 5px solid #34d399;
}

.feature-card h3 {
  margin: 0 0 18px;
  color: #596078;
  text-align: center;
}

.highlight-card {
  border-top-color: #6c63ff;
}

.next-plan {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
  color: #111827;
}

.next-plan strong,
.big-number {
  font-size: 32px;
  font-weight: 800;
  color: #111827;
  text-align: center;
}

.muted-text {
  color: #7c8194;
  text-align: center;
  margin: 0;
}

.record-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.record-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 16px;
  background: #f8fafc;
  border-radius: 12px;
  padding: 14px 16px;
  border-left: 5px solid #34d399;
}

.record-row div {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.record-row b {
  color: #2563eb;
}

.record-row span,
.metric-line,
.mini-list div,
.contact-grid p {
  color: #4b5563;
  line-height: 1.7;
}

.record-row button,
.panel-title-row button {
  border: none;
  border-radius: 10px;
  background: #6c63ff;
  color: white;
  cursor: pointer;
  font-weight: bold;
  padding: 10px 16px;
  white-space: nowrap;
}

.record-row button.done {
  background: #10b981;
}

.slot-status {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 14px;
}

.slot-status strong {
  color: #2563eb;
  font-size: 24px;
}

.slot-status span {
  color: #10b981;
  font-weight: bold;
}

.mini-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.mini-list div {
  background: #f8fafc;
  border-radius: 10px;
  padding: 12px;
}

.panel-title-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 14px;
}

.panel-title-row h3 {
  margin: 0;
}

.contact-grid,
.settings-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 18px;
}

.contact-grid {
  grid-template-columns: minmax(0, 1fr);
}

.contact-grid div {
  background: #f8fafc;
  border-radius: 12px;
  padding: 18px;
  text-align: center;
}

.contact-grid span {
  color: #7c8194;
}

.contact-grid strong {
  display: block;
  margin: 8px 0;
  color: #111827;
  font-size: 20px;
}

.settings-page-panel {
  display: grid;
  gap: 18px;
}

.settings-heading {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 18px;
  padding: 22px;
  border: 1px solid #dfe6f2;
  border-radius: 8px;
  background: linear-gradient(135deg, #ffffff 0%, #f7fbff 100%);
  box-shadow: 0 16px 34px rgba(15, 23, 42, 0.06);
}

.settings-heading h3,
.settings-heading p,
.settings-section-title h4,
.settings-section-title p {
  margin: 0;
}

.settings-heading h3 {
  margin-top: 4px;
  color: #0f1f3d;
  font-size: 24px;
  text-align: left;
}

.settings-heading p {
  margin-top: 6px;
  color: #69758a;
  line-height: 1.6;
}

.settings-save-btn {
  flex: 0 0 auto;
  min-width: 128px;
  height: 42px;
  border: none;
  border-radius: 8px;
  color: #fff;
  background: #3157d5;
  font-size: 15px;
  font-weight: 800;
  cursor: pointer;
  box-shadow: 0 12px 22px rgba(49, 87, 213, 0.2);
}

.settings-save-btn:hover {
  background: #2548bd;
}

.settings-section {
  display: grid;
  gap: 16px;
  padding: 20px;
  border: 1px solid #e5eaf3;
  border-radius: 8px;
  background: #fff;
  box-shadow: 0 10px 24px rgba(15, 23, 42, 0.045);
}

.settings-section-title {
  display: flex;
  align-items: center;
  gap: 14px;
}

.settings-section-title span {
  width: 42px;
  height: 42px;
  display: grid;
  place-items: center;
  border-radius: 50%;
  color: #3157d5;
  background: #eef4ff;
  font-weight: 900;
}

.settings-section-title h4 {
  color: #18243d;
  font-size: 18px;
}

.settings-section-title p {
  margin-top: 4px;
  color: #7a8495;
  line-height: 1.5;
}

.settings-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 16px;
}

.settings-grid label {
  display: flex;
  flex-direction: column;
  gap: 8px;
  color: #263247;
  font-weight: 800;
}

.settings-grid small {
  color: #7a8495;
  font-size: 12px;
  font-weight: 600;
}

.settings-grid input {
  height: 44px;
  border: 1px solid #d8deea;
  border-radius: 10px;
  padding: 0 14px;
  font-size: 15px;
  outline: none;
  background: #fff;
  box-sizing: border-box;
}

.settings-grid input:focus {
  border-color: #3157d5;
  box-shadow: 0 0 0 3px rgba(49, 87, 213, 0.12);
}

.box-grid {
  grid-template-columns: repeat(3, minmax(0, 1fr));
}

.box-slot-card {
  border-top-color: #f5b640;
}

.box-slot-title {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 18px;
}

.box-slot-title h3 {
  margin: 0;
  text-align: left;
}

.box-slot-title span {
  border-radius: 999px;
  background: #dcfce7;
  color: #15803d;
  font-size: 13px;
  font-weight: bold;
  padding: 7px 12px;
  white-space: nowrap;
}

.box-slot-title span.emptyBox {
  background: #f3f4f6;
  color: #6b7280;
}

.box-library-tip {
  color: #64748b;
  font-size: 12px;
  line-height: 1.5;
}

.box-form {
  display: grid;
  gap: 14px;
}

.box-form label {
  display: flex;
  flex-direction: column;
  gap: 8px;
  color: #374151;
  font-weight: bold;
}

.box-form input,
.box-form select {
  width: 100%;
  height: 42px;
  border: 1px solid #dcdfe6;
  border-radius: 10px;
  padding: 0 12px;
  font-size: 15px;
  outline: none;
  background-color: #fff;
  box-sizing: border-box;
}

.box-form select {
  padding-right: 36px;
  appearance: none;
  background-image: linear-gradient(45deg, transparent 50%, #64748b 50%),
    linear-gradient(135deg, #64748b 50%, transparent 50%);
  background-position: calc(100% - 18px) 18px, calc(100% - 12px) 18px;
  background-size: 6px 6px, 6px 6px;
  background-repeat: no-repeat;
}

.box-form input:focus,
.box-form select:focus {
  border-color: #6c63ff;
  box-shadow: 0 0 0 3px rgba(108, 99, 255, 0.12);
}

.box-form select:disabled {
  color: #94a3b8;
  background-color: #f8fafc;
  cursor: not-allowed;
}

.box-record-panel {
  margin-top: 28px;
  padding: 24px;
  border-radius: 16px;
  background: white;
  box-shadow: 0 12px 28px rgba(36, 44, 66, 0.08);
}

.box-record-heading {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  margin-bottom: 18px;
}

.box-record-heading h3,
.box-record-heading p {
  margin: 0;
}

.box-record-heading h3 {
  color: #253044;
  font-size: 22px;
}

.box-record-heading p {
  margin-top: 4px;
  color: #8992a2;
  font-size: 13px;
}

.box-record-table-wrap {
  max-height: 360px;
}

.box-record-table {
  min-width: 720px;
}

.medication-record-page {
  display: flex;
  flex-direction: column;
  gap: 20px;
  color: #253044;
}

.record-toolbar {
  min-height: 82px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 24px;
  background: white;
  border: 1px solid #e7eaf0;
  border-radius: 8px;
  padding: 18px 22px;
}

.record-toolbar h3,
.record-toolbar p,
.calendar-heading h3,
.calendar-heading p,
.side-panel-heading h3,
.side-panel-heading p {
  margin: 0;
}

.record-toolbar h3 {
  margin-top: 4px;
  font-size: 24px;
  color: #202939;
  text-align: left;
}

.record-toolbar p {
  margin-top: 5px;
  color: #7a8495;
  font-size: 14px;
}

.record-eyebrow {
  color: #5265d6;
  font-size: 13px;
  font-weight: 700;
}

.record-actions {
  display: flex;
  gap: 10px;
  flex-shrink: 0;
}

.record-actions button {
  height: 40px;
  min-width: 104px;
  border-radius: 7px;
  padding: 0 16px;
  font-size: 14px;
  font-weight: 700;
  cursor: pointer;
}

.secondary-action {
  border: 1px solid #cfd5df;
  background: white;
  color: #445066;
}

.primary-action {
  border: 1px solid #5265d6;
  background: #5265d6;
  color: white;
}

.record-summary-grid {
  display: grid;
  grid-template-columns: minmax(190px, 0.75fr) minmax(190px, 0.75fr) minmax(280px, 1.5fr);
  gap: 16px;
}

.record-summary-card {
  min-height: 116px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 7px;
  background: white;
  border: 1px solid #e7eaf0;
  border-left: 5px solid #24b47e;
  border-radius: 8px;
  padding: 18px 20px;
}

.record-summary-card > span {
  color: #677286;
  font-size: 14px;
  font-weight: 700;
}

.record-summary-card strong {
  color: #1d2737;
  font-size: 32px;
  line-height: 1;
}

.record-summary-card small {
  color: #8a93a3;
  font-size: 12px;
}

.due-summary {
  border-left-color: #5265d6;
}

.rate-summary {
  border-left-color: #f2a93b;
}

.rate-summary-content {
  display: grid;
  grid-template-columns: auto minmax(100px, 1fr);
  align-items: center;
  gap: 18px;
}

.rate-progress {
  height: 9px;
  overflow: hidden;
  background: #eef1f5;
  border-radius: 5px;
}

.rate-progress span {
  display: block;
  height: 100%;
  border-radius: inherit;
  background: #f2a93b;
  transition: width 0.25s ease;
}

.record-content-grid {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 330px;
  align-items: start;
  gap: 18px;
}

.medication-calendar-panel,
.meal-plan-panel,
.monthly-chart-panel {
  background: white;
  border: 1px solid #e7eaf0;
  border-radius: 8px;
}

.medication-calendar-panel {
  min-width: 0;
  padding: 20px;
}

.calendar-heading {
  min-height: 48px;
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 18px;
  margin-bottom: 16px;
}

.calendar-heading h3,
.side-panel-heading h3 {
  color: #273247;
  font-size: 18px;
  text-align: left;
}

.calendar-heading p,
.side-panel-heading p {
  margin-top: 5px;
  color: #8a93a3;
  font-size: 12px;
}

.calendar-legend {
  display: flex;
  align-items: center;
  gap: 14px;
  color: #6f798b;
  font-size: 12px;
  white-space: nowrap;
}

.calendar-legend span {
  display: inline-flex;
  align-items: center;
  gap: 5px;
}

.legend-dot {
  width: 8px;
  height: 8px;
  display: inline-block;
  border-radius: 50%;
}

.taken-dot {
  background: #24b47e;
}

.missed-dot {
  background: #e45b67;
}

.pending-dot {
  background: #f2a93b;
}

.calendar-weekdays,
.medication-calendar {
  display: grid;
  grid-template-columns: repeat(7, minmax(92px, 1fr));
}

.calendar-weekdays {
  border: 1px solid #e5e9ef;
  border-bottom: 0;
  background: #f6f8fb;
}

.calendar-weekdays span {
  padding: 9px 6px;
  color: #647084;
  font-size: 13px;
  font-weight: 700;
  text-align: center;
}

.medication-calendar {
  overflow: hidden;
  border-top: 1px solid #e5e9ef;
  border-left: 1px solid #e5e9ef;
}

.calendar-day {
  min-width: 0;
  min-height: 122px;
  background: white;
  border-right: 1px solid #e5e9ef;
  border-bottom: 1px solid #e5e9ef;
  padding: 8px;
}

.calendar-day.blank {
  background: #fafbfc;
}

.calendar-day.today {
  position: relative;
  background: #f4f7ff;
  box-shadow: inset 0 0 0 2px #5265d6;
}

.calendar-day.future {
  background: #fbfcfd;
}

.calendar-date {
  height: 24px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 5px;
}

.calendar-date strong {
  color: #39455a;
  font-size: 15px;
}

.calendar-date span {
  color: #5265d6;
  font-size: 10px;
  font-weight: 700;
}

.meal-status-list {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.meal-status {
  width: 100%;
  height: 23px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 4px;
  border: 0;
  border-radius: 4px;
  padding: 0 7px;
  color: #6f798b;
  background: #f1f3f6;
  font-size: 11px;
  cursor: pointer;
}

.meal-status:disabled {
  cursor: default;
}

.meal-status.taken {
  color: #147552;
  background: #dff6ec;
}

.meal-status.missed {
  color: #b33442;
  background: #fde8eb;
}

.meal-status.pending {
  color: #9a6816;
  background: #fff1d6;
}

.meal-status.future,
.meal-status.unset {
  color: #8b94a3;
  background: #f1f3f6;
}

.meal-name {
  width: 18px;
  height: 18px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.75);
  font-weight: 800;
}

.meal-state {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.record-side-panel {
  display: flex;
  flex-direction: column;
  gap: 18px;
}

.meal-plan-panel,
.monthly-chart-panel {
  padding: 18px;
}

.side-panel-heading {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 15px;
}

.side-panel-heading > span {
  color: #5265d6;
  background: #eef0ff;
  border-radius: 6px;
  padding: 5px 8px;
  font-size: 11px;
  font-weight: 700;
  white-space: nowrap;
}

.meal-plan-list {
  display: flex;
  flex-direction: column;
}

.meal-plan-row {
  min-height: 62px;
  display: grid;
  grid-template-columns: 36px minmax(0, 1fr);
  align-items: center;
  gap: 11px;
  border-top: 1px solid #edf0f4;
}

.meal-plan-row:first-child {
  border-top: 0;
}

.meal-plan-icon {
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 7px;
  color: #9a6816;
  background: #fff0d2;
  font-size: 13px;
  font-weight: 800;
}

.meal-plan-icon.lunch {
  color: #3653a7;
  background: #e6edff;
}

.meal-plan-icon.dinner {
  color: #7850a2;
  background: #f0e7fa;
}

.meal-plan-row div:last-child {
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.meal-plan-row b {
  color: #354156;
  font-size: 13px;
}

.meal-plan-row span {
  overflow: hidden;
  color: #8992a2;
  font-size: 11px;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.medication-chart {
  width: 100%;
  height: 270px;
}

.medicine-video-page {
  display: flex;
  flex-direction: column;
  gap: 20px;
  color: #253044;
}

.video-toolbar {
  min-height: 82px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 24px;
  background: white;
  border: 1px solid #e7eaf0;
  border-radius: 8px;
  padding: 18px 22px;
}

.video-toolbar h3,
.video-toolbar p,
.video-viewer-heading h3,
.video-viewer-heading p {
  margin: 0;
}

.video-toolbar h3 {
  margin-top: 4px;
  color: #202939;
  font-size: 24px;
  text-align: left;
}

.video-toolbar p,
.video-viewer-heading p {
  margin-top: 5px;
  color: #7a8495;
  font-size: 14px;
}

.esp32-live-panel {
  display: grid;
  gap: 18px;
  background: linear-gradient(180deg, #ffffff 0%, #f8fbff 100%);
  border: 1px solid #dfe6f2;
  border-radius: 8px;
  padding: 22px;
  box-shadow: 0 18px 40px rgba(15, 23, 42, 0.07);
}

.esp32-live-heading {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 16px;
}

.esp32-live-heading h3,
.esp32-live-heading p {
  margin: 0;
}

.esp32-live-heading h3 {
  margin-top: 4px;
  color: #0f1f3d;
  font-size: 24px;
  text-align: left;
}

.esp32-live-heading p {
  margin-top: 6px;
  color: #69758a;
  font-size: 14px;
}

.esp32-live-actions {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 10px;
  flex-wrap: wrap;
}

.esp32-control-button {
  min-width: 104px;
  min-height: 36px;
  border: 1px solid #3157d5;
  border-radius: 8px;
  padding: 8px 14px;
  color: #3157d5;
  background: #ffffff;
  font-weight: 900;
  cursor: pointer;
  box-shadow: 0 8px 18px rgba(49, 87, 213, 0.1);
}

.esp32-control-button.active {
  color: #ffffff;
  background: #3157d5;
}

.esp32-control-button:disabled {
  cursor: wait;
  opacity: 0.65;
}

.esp32-live-badge {
  min-width: 72px;
  border-radius: 999px;
  padding: 8px 13px;
  color: #991b1b;
  background: #fee2e2;
  font-size: 13px;
  font-weight: 900;
  text-align: center;
  box-shadow: inset 0 0 0 1px rgba(153, 27, 27, 0.06);
}

.esp32-live-badge.online {
  color: #166534;
  background: #dcfce7;
  box-shadow: inset 0 0 0 1px rgba(22, 101, 52, 0.08);
}

.esp32-live-grid {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 300px;
  gap: 18px;
  align-items: stretch;
}

.esp32-live-viewer {
  width: 100%;
  min-height: 320px;
  aspect-ratio: 16 / 9;
  display: grid;
  place-items: center;
  overflow: hidden;
  border-radius: 8px;
  border: 1px solid rgba(15, 23, 42, 0.12);
  background: #0f172a;
  box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.04);
}

.esp32-live-viewer img {
  width: 100%;
  height: 100%;
  object-fit: contain;
  display: block;
}

.esp32-live-placeholder {
  width: 100%;
  height: 100%;
  min-height: 320px;
  display: grid;
  place-content: center;
  gap: 10px;
  padding: 24px;
  color: #d8e0ef;
  text-align: center;
  background:
    linear-gradient(135deg, rgba(15, 23, 42, 0.94), rgba(30, 41, 59, 0.94)),
    repeating-linear-gradient(45deg, rgba(255, 255, 255, 0.04) 0 12px, transparent 12px 24px);
}

.esp32-live-placeholder b {
  color: #ffffff;
  font-size: 20px;
}

.esp32-live-placeholder span {
  color: #b7c3d7;
  font-size: 14px;
  font-weight: 800;
}

.esp32-live-stats {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 12px;
}

.esp32-live-stats div,
.esp32-open-link {
  min-height: 86px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 8px;
  border: 1px solid #dfe6f2;
  border-radius: 8px;
  padding: 14px;
  background: #fff;
  text-decoration: none;
  box-shadow: 0 8px 18px rgba(15, 23, 42, 0.04);
}

.esp32-live-stats .wide,
.esp32-open-link {
  grid-column: 1 / -1;
}

.esp32-live-stats b {
  overflow: hidden;
  color: #10213f;
  font-size: 17px;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.esp32-live-stats span,
.esp32-open-link {
  color: #6b7890;
  font-size: 13px;
  font-weight: 800;
}

.esp32-open-link {
  min-height: 54px;
  align-items: center;
  color: #ffffff;
  background: #3157d5;
  border-color: #3157d5;
  box-shadow: 0 12px 22px rgba(49, 87, 213, 0.2);
}

.esp32-open-link:hover {
  background: #2548bd;
  border-color: #2548bd;
}

.video-layout {
  display: grid;
  grid-template-columns: 360px minmax(0, 1fr);
  gap: 18px;
  align-items: start;
}

.video-list-panel,
.video-viewer-panel {
  background: white;
  border: 1px solid #e7eaf0;
  border-radius: 8px;
}

.video-list-panel {
  display: flex;
  flex-direction: column;
  gap: 10px;
  max-height: 680px;
  overflow: auto;
  padding: 14px;
}

.video-list-item {
  width: 100%;
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto;
  align-items: center;
  gap: 12px;
  border: 1px solid #e7eaf0;
  border-radius: 8px;
  padding: 10px;
  color: #334155;
  background: #fbfcfe;
  text-align: left;
}

.video-list-item.active {
  border-color: #5265d6;
  background: #f4f7ff;
  box-shadow: inset 0 0 0 1px #5265d6;
}

.video-list-main {
  min-width: 0;
  min-height: 58px;
  display: grid;
  grid-template-columns: 74px minmax(0, 1fr) auto;
  align-items: center;
  gap: 12px;
  border: 0;
  padding: 0;
  color: inherit;
  background: transparent;
  cursor: pointer;
  text-align: left;
}

.video-list-item img,
.video-thumb-placeholder {
  width: 74px;
  height: 52px;
  border-radius: 6px;
  object-fit: cover;
  background: #e7eaf0;
}

.video-thumb-placeholder {
  display: grid;
  place-items: center;
  color: #647084;
  font-size: 12px;
  font-weight: 800;
}

.video-list-item strong,
.video-list-item small {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.video-list-item strong {
  color: #263247;
  font-size: 14px;
}

.video-list-item small {
  margin-top: 5px;
  color: #7a8495;
  font-size: 12px;
}

.video-list-item i {
  border-radius: 999px;
  padding: 5px 8px;
  color: #147552;
  background: #dff6ec;
  font-size: 11px;
  font-style: normal;
  font-weight: 800;
  white-space: nowrap;
}

.video-list-item i.recording {
  color: #9a6816;
  background: #fff1d6;
}

.video-delete-button {
  min-width: 64px;
  min-height: 34px;
  border: 1px solid #fecaca;
  border-radius: 8px;
  padding: 8px 10px;
  color: #b91c1c;
  background: #fff5f5;
  cursor: pointer;
  font-size: 12px;
  font-weight: 900;
  white-space: nowrap;
}

.video-delete-button:hover:not(:disabled) {
  border-color: #fca5a5;
  background: #fee2e2;
}

.video-delete-button:disabled {
  color: #9ca3af;
  background: #f3f4f6;
  border-color: #e5e7eb;
  cursor: not-allowed;
}

.video-viewer-panel {
  min-height: 520px;
  padding: 18px;
}

.video-viewer-heading {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 16px;
  margin-bottom: 14px;
}

.video-viewer-heading h3 {
  color: #273247;
  font-size: 20px;
  text-align: left;
}

.video-viewer-heading span {
  border-radius: 6px;
  padding: 6px 10px;
  color: #5265d6;
  background: #eef0ff;
  font-size: 12px;
  font-weight: 800;
  white-space: nowrap;
}

.video-viewer-actions {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
  justify-content: flex-end;
}

.video-player {
  width: 100%;
  aspect-ratio: 16 / 9;
  display: grid;
  place-items: center;
  overflow: hidden;
  border-radius: 8px;
  background: #0f172a;
}

.video-player video,
.video-player img {
  width: 100%;
  height: 100%;
  object-fit: contain;
}

.video-frame-empty,
.video-empty {
  min-height: 320px;
  display: grid;
  place-items: center;
  color: #8a93a3;
}

.frame-control {
  display: grid;
  grid-template-columns: auto auto auto minmax(160px, 1fr) auto;
  align-items: center;
  gap: 10px;
  margin-top: 14px;
}

.frame-control button {
  min-height: 38px;
  border: 1px solid #cfd5df;
  border-radius: 7px;
  padding: 0 14px;
  color: #445066;
  background: white;
  cursor: pointer;
  font-weight: 700;
}

.frame-control .primary-action {
  border-color: #5265d6;
  color: white;
  background: #5265d6;
}

.frame-control input {
  width: 100%;
}

.frame-control span {
  color: #647084;
  font-size: 13px;
  font-weight: 800;
  white-space: nowrap;
}

.identity-page {
  display: flex;
  flex-direction: column;
  gap: 24px;
}

.identity-hero {
  display: flex;
  align-items: center;
  gap: 20px;
  padding: 30px 34px;
  border-radius: 20px;
  color: white;
  background: linear-gradient(120deg, #5145cd 0%, #7164e8 58%, #9474ed 100%);
  box-shadow: 0 18px 36px rgba(79, 70, 191, 0.24);
}

.identity-avatar {
  display: grid;
  flex: 0 0 72px;
  width: 72px;
  height: 72px;
  place-items: center;
  border: 2px solid rgba(255, 255, 255, 0.5);
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.18);
  font-size: 30px;
  font-weight: 800;
}

.identity-hero h2 {
  margin: 3px 0 6px;
  font-size: 28px;
}

.identity-hero p {
  margin: 0;
  color: rgba(255, 255, 255, 0.78);
}

.identity-eyebrow {
  color: #dcd8ff;
  font-size: 12px;
  font-weight: 800;
  letter-spacing: 1.8px;
}

.face-status {
  margin-left: auto;
  padding: 9px 16px;
  border: 1px solid rgba(255, 255, 255, 0.34);
  border-radius: 999px;
  background: rgba(22, 18, 75, 0.24);
  font-weight: 700;
  white-space: nowrap;
}

.face-status::before {
  content: "";
  display: inline-block;
  width: 8px;
  height: 8px;
  margin-right: 8px;
  border-radius: 50%;
  background: #fbbf24;
}

.face-status.registered::before {
  background: #5df2aa;
}

.identity-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 24px;
}

.identity-card {
  display: flex;
  flex-direction: column;
  gap: 18px;
  padding: 28px;
  border: 1px solid #ecebf7;
  border-radius: 18px;
  background: white;
  box-shadow: 0 10px 26px rgba(35, 32, 92, 0.07);
}

.identity-card-title {
  display: flex;
  align-items: center;
  gap: 13px;
  padding-bottom: 17px;
  border-bottom: 1px solid #eff0f6;
}

.identity-card-title > span {
  display: grid;
  width: 42px;
  height: 42px;
  place-items: center;
  border-radius: 12px;
  color: #6757e8;
  background: #efedff;
  font-weight: 800;
}

.identity-card-title h3,
.identity-card-title p,
.face-device-row p {
  margin: 0;
}

.identity-card-title h3 {
  color: #33364b;
}

.identity-card-title p,
.face-device-row p,
.face-help {
  margin-top: 4px;
  color: #9297a8;
  font-size: 13px;
}

.identity-card label,
.identity-modal label {
  display: flex;
  flex-direction: column;
  gap: 8px;
  color: #45485d;
  font-weight: 700;
}

.identity-card input,
.identity-modal input {
  height: 46px;
  box-sizing: border-box;
  padding: 0 14px;
  border: 1px solid #dfe1eb;
  border-radius: 11px;
  outline: none;
  font-size: 15px;
}

.identity-card input:focus,
.identity-modal input:focus {
  border-color: #6c63ff;
  box-shadow: 0 0 0 3px rgba(108, 99, 255, 0.1);
}

.identity-primary-btn {
  min-height: 46px;
  padding: 0 22px;
  border: 0;
  border-radius: 11px;
  color: white;
  background: linear-gradient(105deg, #6659f3, #7f6bef);
  box-shadow: 0 9px 18px rgba(102, 89, 243, 0.22);
  cursor: pointer;
  font-size: 15px;
  font-weight: 700;
}

.identity-primary-btn:disabled {
  cursor: not-allowed;
  opacity: 0.58;
  box-shadow: none;
}

.danger-btn {
  background: linear-gradient(105deg, #dc2626, #ef4444);
  box-shadow: 0 9px 18px rgba(220, 38, 38, 0.2);
}

.face-register-card {
  background: linear-gradient(145deg, white, #fbfaff);
}

.face-device-row {
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 16px;
  border-radius: 14px;
  background: #f7f7fc;
}

.face-device-icon,
.modal-face-icon {
  display: grid;
  place-items: center;
  border-radius: 50%;
  color: #6757e8;
  background: #eae7ff;
}

.face-device-icon {
  width: 46px;
  height: 46px;
  font-size: 27px;
}

.modal-face-icon.danger {
  color: #dc2626;
  background: #fee2e2;
}

.face-device-row i {
  width: 10px;
  height: 10px;
  margin-left: auto;
  border-radius: 50%;
  background: #c3c6d0;
}

.face-device-row i.online {
  background: #22c55e;
  box-shadow: 0 0 0 5px rgba(34, 197, 94, 0.12);
}

.face-state-row {
  display: flex;
  justify-content: space-between;
  padding: 15px 2px;
  color: #676b7d;
}

.face-state-row strong {
  color: #d08a12;
}

.face-state-row strong.success {
  color: #119b5a;
}

.face-help {
  margin: -6px 0 0;
  text-align: center;
}

.face-users-card {
  margin-top: 24px;
}

.face-refresh-btn {
  min-height: 38px;
  margin-left: auto;
  padding: 0 16px;
  border: 1px solid #dfe1eb;
  border-radius: 10px;
  color: #4f46e5;
  background: white;
  cursor: pointer;
  font-weight: 800;
}

.face-refresh-btn:disabled,
.face-delete-btn:disabled {
  cursor: not-allowed;
  opacity: 0.55;
}

.face-users-list {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 12px;
}

.face-user-item {
  display: flex;
  align-items: center;
  gap: 12px;
  min-height: 72px;
  padding: 13px;
  border: 1px solid #ecebf7;
  border-radius: 12px;
  background: #fbfbff;
}

.face-user-avatar {
  display: grid;
  width: 42px;
  height: 42px;
  flex: 0 0 auto;
  place-items: center;
  border-radius: 50%;
  color: #6757e8;
  background: #efedff;
  font-weight: 900;
}

.face-user-item strong,
.face-user-item p,
.face-users-empty strong,
.face-users-empty p {
  margin: 0;
}

.face-user-item p,
.face-users-empty p {
  margin-top: 4px;
  color: #9297a8;
  font-size: 13px;
}

.face-delete-btn {
  min-height: 36px;
  margin-left: auto;
  padding: 0 14px;
  border: 1px solid #fecaca;
  border-radius: 10px;
  color: #dc2626;
  background: #fff5f5;
  cursor: pointer;
  font-weight: 800;
}

.face-users-empty {
  padding: 22px;
  border: 1px dashed #dfe1eb;
  border-radius: 12px;
  background: #fbfbff;
  text-align: center;
}

.identity-modal-backdrop {
  position: fixed;
  inset: 0;
  z-index: 1000;
  display: grid;
  place-items: center;
  padding: 20px;
  background: rgba(26, 23, 58, 0.52);
  backdrop-filter: blur(4px);
}

.identity-modal {
  position: relative;
  width: min(430px, 100%);
  box-sizing: border-box;
  padding: 34px;
  border-radius: 20px;
  background: white;
  box-shadow: 0 28px 70px rgba(16, 12, 47, 0.28);
}

.identity-modal h3 {
  margin: 16px 0 8px;
  color: #303247;
  font-size: 24px;
  text-align: center;
}

.identity-modal > p {
  margin: 0 0 22px;
  color: #858a9d;
  line-height: 1.7;
  text-align: center;
}

.identity-modal-close {
  position: absolute;
  top: 14px;
  right: 16px;
  border: 0;
  color: #898da0;
  background: transparent;
  cursor: pointer;
  font-size: 25px;
}

.modal-face-icon,
.success-check {
  width: 68px;
  height: 68px;
  margin: 0 auto;
  font-size: 38px;
}

.identity-modal-actions {
  display: grid;
  grid-template-columns: 1fr 1.4fr;
  gap: 12px;
  margin-top: 24px;
}

.modal-cancel {
  border: 1px solid #dedfea;
  border-radius: 11px;
  color: #626679;
  background: white;
  cursor: pointer;
  font-weight: 700;
}

.success-modal {
  text-align: center;
}

.success-check {
  display: grid;
  place-items: center;
  border-radius: 50%;
  color: white;
  background: linear-gradient(135deg, #27c984, #16a966);
  box-shadow: 0 12px 24px rgba(22, 169, 102, 0.25);
}

.success-modal .identity-primary-btn {
  width: 100%;
}

.medicine-library-page {
  display: grid;
  gap: 18px;
}

.library-toolbar {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 18px;
  padding: 18px;
  border: 1px solid rgba(34, 197, 94, 0.16);
  border-radius: 8px;
  background: linear-gradient(135deg, rgba(240, 253, 244, 0.92), rgba(255, 255, 255, 0.98));
}

.library-toolbar h3,
.library-modal-heading h3 {
  margin: 4px 0 6px;
  color: #12352b;
}

.library-toolbar p,
.library-modal-heading p {
  margin: 0;
  color: #64748b;
  line-height: 1.6;
}

.library-actions {
  min-width: min(520px, 100%);
  display: flex;
  gap: 10px;
  align-items: center;
}

.library-actions input,
.library-ai-row input {
  flex: 1;
  min-width: 0;
  height: 42px;
  border: 1px solid rgba(15, 23, 42, 0.12);
  border-radius: 8px;
  padding: 0 12px;
  font-size: 14px;
  outline: none;
  background: #fff;
}

.library-actions input:focus,
.library-ai-row input:focus,
.library-form-grid input:focus,
.library-form-grid textarea:focus {
  border-color: rgba(34, 197, 94, 0.65);
  box-shadow: 0 0 0 3px rgba(34, 197, 94, 0.12);
}

.library-stat-grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 12px;
}

.library-stat-card {
  min-height: 96px;
  padding: 16px;
  border-radius: 8px;
  border: 1px solid rgba(15, 23, 42, 0.08);
  background: #fff;
  display: grid;
  align-content: center;
  gap: 6px;
}

.library-stat-card span {
  color: #64748b;
  font-size: 13px;
}

.library-stat-card strong {
  color: #0f172a;
  font-size: 30px;
}

.medicine-library-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
  gap: 14px;
}

.medicine-library-card {
  min-height: 230px;
  border: 1px solid rgba(15, 23, 42, 0.09);
  border-radius: 8px;
  padding: 16px;
  text-align: left;
  background: #fff;
  color: inherit;
  cursor: pointer;
  display: flex;
  flex-direction: column;
  gap: 10px;
  transition: transform 0.18s ease, border-color 0.18s ease, box-shadow 0.18s ease;
}

.medicine-library-card:hover {
  transform: translateY(-2px);
  border-color: rgba(34, 197, 94, 0.34);
  box-shadow: 0 18px 36px rgba(15, 23, 42, 0.08);
}

.library-card-top {
  display: flex;
  justify-content: space-between;
  gap: 8px;
  color: #64748b;
  font-size: 12px;
}

.library-card-top span,
.library-source-badge {
  border-radius: 999px;
  padding: 4px 8px;
  background: rgba(34, 197, 94, 0.12);
  color: #15803d;
  font-style: normal;
  white-space: nowrap;
}

.medicine-library-card h3 {
  margin: 0;
  color: #0f172a;
  font-size: 20px;
}

.medicine-library-card p {
  margin: 0;
  color: #64748b;
  line-height: 1.55;
}

.medicine-library-card .library-card-category {
  color: #15803d;
  font-weight: 700;
}

.library-card-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-top: auto;
}

.library-card-tags span {
  max-width: 100%;
  overflow-wrap: anywhere;
  border-radius: 999px;
  padding: 4px 8px;
  background: #f1f5f9;
  color: #475569;
  font-size: 12px;
}

.library-empty-state {
  min-height: 260px;
  display: grid;
  place-items: center;
  justify-items: center;
  gap: 10px;
  padding: 28px;
  border: 1px dashed rgba(15, 23, 42, 0.18);
  border-radius: 8px;
  background: rgba(248, 250, 252, 0.9);
  text-align: center;
}

.library-empty-state strong {
  color: #0f172a;
  font-size: 20px;
}

.library-empty-state p {
  max-width: 520px;
  margin: 0;
  color: #64748b;
  line-height: 1.6;
}

.library-safety-note {
  margin: 0;
  padding: 12px 14px;
  border-left: 4px solid #16a34a;
  border-radius: 8px;
  background: rgba(240, 253, 244, 0.92);
  color: #166534;
  line-height: 1.6;
}

.library-safety-note.in-modal {
  margin-top: 14px;
}

.medicine-library-modal {
  width: min(920px, calc(100vw - 28px));
  max-height: calc(100dvh - 40px);
  overflow: auto;
  position: relative;
  border-radius: 8px;
  background: #fff;
  padding: 24px;
  box-shadow: 0 28px 80px rgba(15, 23, 42, 0.22);
}

.library-modal-heading {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 18px;
  padding-right: 36px;
}

.library-source-badge {
  margin-top: 4px;
  font-size: 12px;
  font-weight: 700;
}

.library-ai-row {
  display: flex;
  gap: 10px;
  margin-top: 18px;
}

.library-ai-message {
  margin: 10px 0 0;
  color: #166534;
  line-height: 1.5;
}

.library-ai-message.error {
  color: #b91c1c;
}

.library-form-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 14px;
  margin-top: 18px;
}

.library-form-grid label {
  display: grid;
  gap: 7px;
  color: #334155;
  font-weight: 700;
  font-size: 13px;
}

.library-form-grid label.wide {
  grid-column: 1 / -1;
}

.library-form-grid input,
.library-form-grid textarea {
  width: 100%;
  border: 1px solid rgba(15, 23, 42, 0.12);
  border-radius: 8px;
  padding: 10px 12px;
  font: inherit;
  font-weight: 400;
  color: #0f172a;
  background: #fff;
  outline: none;
  resize: vertical;
}

.library-modal-actions {
  justify-content: flex-end;
  margin-top: 18px;
}

@media (max-width: 1400px) {
  .cards {
    grid-template-columns: repeat(6, minmax(0, 1fr));
  }

  .card,
  .cards .card:nth-last-child(-n + 3) {
    grid-column: span 3;
  }

  .cards .card:last-child {
    grid-column: span 6;
  }

  .content,
  .bottom,
  .plan-list,
  .medicine-slots,
  .health-cards,
  .health-chart-grid,
  .health-data-grid,
  .feature-grid {
    grid-template-columns: 1fr;
  }

  .identity-grid {
    grid-template-columns: 1fr;
  }

  .record-content-grid {
    grid-template-columns: 1fr;
  }

  .video-layout {
    grid-template-columns: 1fr;
  }

  .esp32-live-grid {
    grid-template-columns: 1fr;
  }

  .medicine-user-card {
    grid-template-columns: 1fr 1fr;
  }

  .medicine-user-card > div:first-child {
    grid-column: 1 / -1;
  }

  .record-side-panel {
    display: grid;
    grid-template-columns: minmax(280px, 0.8fr) minmax(400px, 1.2fr);
  }
}

@media (max-width: 1000px) {
  .page {
    width: 100%;
    height: 100dvh;
    min-height: 100dvh;
    flex-direction: column;
    overflow: hidden;
  }

  .identity-hero {
    align-items: flex-start;
    flex-wrap: wrap;
  }

  .face-status {
    margin-left: 0;
  }
  .medicine-user-card {
    grid-template-columns: 1fr;
  }

  .medicine-user-card > div:first-child {
    grid-column: auto;
  }
  .side {
    width: 100%;
    max-width: 100%;
    height: auto;
    min-height: 0;
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 12px;
    overflow-x: auto;
    overflow-y: hidden;
    border-bottom: 1px solid rgba(91, 91, 214, 0.12);
    scrollbar-width: none;
  }

  .side::-webkit-scrollbar {
    display: none;
  }

  .logo,
  .side h2 {
    display: none;
  }

  .menu {
    flex: 0 0 auto;
    min-height: 42px;
    display: flex;
    align-items: center;
    margin: 0;
    padding: 0 14px;
    border-radius: 999px;
    white-space: nowrap;
    font-size: 14px;
  }

  .main {
    width: 100%;
    min-width: 0;
    min-height: 0;
    height: auto;
    flex: 1;
    padding: 22px 16px 28px;
    overflow-x: hidden;
  }

  .main > *,
  .sub-page > *,
  .sub-wide > *,
  .cards,
  .card,
  .panel,
  .content,
  .bottom {
    min-width: 0;
    max-width: 100%;
  }

  .cards {
    grid-template-columns: 1fr;
  }

  .card,
  .cards .card:nth-last-child(-n + 3),
  .cards .card:last-child {
    grid-column: auto;
  }

  .top {
    flex-direction: column;
    align-items: flex-start;
    gap: 16px;
  }

  .top h1 {
    font-size: 22px;
    line-height: 1.35;
  }

  .top p {
    font-size: 14px;
  }

  .top-actions {
    width: 100%;
    justify-content: flex-start;
  }

  .sub-page,
  .sub-wide,
  .medicine-slots,
  .medicine-slot-card,
  .medicine-user-card {
    width: 100%;
    min-width: 0;
    max-width: 100%;
  }

  .sub-page {
    min-height: auto;
    border-radius: 14px;
    padding: 18px 14px;
  }

  .sub-page h2 {
    margin-bottom: 16px;
    font-size: 24px;
  }

  .sub-wide {
    margin-top: 14px;
    border-radius: 12px;
    padding: 14px;
  }

  .sub-wide h3 {
    font-size: 18px;
    line-height: 1.35;
  }

  .medicine-slot-card,
  .medicine-user-card {
    border-radius: 12px;
    padding: 16px;
  }

  .medicine-time-grid {
    grid-template-columns: 1fr;
    gap: 12px;
  }

  .medicine-slot-card label {
    text-align: left;
  }

  .medicine-slot-card input,
  .medicine-slot-card select,
  .medicine-user-card input {
    width: 100%;
    min-width: 0;
    box-sizing: border-box;
    font-size: 16px;
  }

  .medicine-slot-card select,
  .medicine-item,
  .medicine-item div,
  .medicine-item span {
    min-width: 0;
    max-width: 100%;
  }

  .medicine-item b,
  .medicine-item span {
    display: block;
    overflow-wrap: anywhere;
  }

  .medicine-item b {
    margin: 0 0 6px;
  }

  .medicine-slot-card button,
  .save-all-btn {
    width: 100%;
  }

  .medicine-item {
    align-items: stretch;
    flex-direction: column;
    gap: 12px;
  }

  .medicine-slot-card .delete-btn {
    width: 100%;
  }

  .health-toolbar {
    align-items: stretch;
    flex-direction: column;
  }

  .settings-heading {
    align-items: stretch;
    flex-direction: column;
  }

  .settings-grid {
    grid-template-columns: 1fr;
  }

  .library-toolbar,
  .library-actions,
  .library-ai-row,
  .library-modal-heading {
    align-items: stretch;
    flex-direction: column;
  }

  .library-actions {
    min-width: 0;
  }

  .library-stat-grid,
  .library-form-grid {
    grid-template-columns: 1fr;
  }

  .library-form-grid label.wide {
    grid-column: auto;
  }

  .medicine-library-modal {
    padding: 20px;
  }

  .health-actions button {
    flex: 1;
  }

  .health-stat-grid {
    grid-template-columns: 1fr;
  }

  .esp32-live-heading {
    flex-direction: column;
  }

  .esp32-live-actions {
    justify-content: flex-start;
  }

  .esp32-live-badge {
    align-self: flex-start;
  }

  .esp32-live-stats {
    grid-template-columns: 1fr;
  }

  .record-row,
  .panel-title-row {
    align-items: stretch;
    flex-direction: column;
  }

  .contact-grid,
  .settings-grid {
    grid-template-columns: 1fr;
  }

  .record-toolbar,
  .calendar-heading {
    align-items: stretch;
    flex-direction: column;
  }

  .record-summary-grid,
  .record-side-panel {
    grid-template-columns: 1fr;
  }

  .record-actions button {
    flex: 1;
  }

  .calendar-legend {
    flex-wrap: wrap;
    white-space: normal;
  }

  .medication-calendar-panel {
    overflow-x: auto;
  }

  .calendar-weekdays,
  .medication-calendar {
    min-width: 720px;
  }
}
</style>

const express = require("express");
const http = require("http");
const cors = require("cors");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
require("dotenv").config();
const OpenAI = require("openai");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const DATA_DIR = path.join(__dirname, "data");
const USERS_FILE = path.join(DATA_DIR, "users.json");
const APP_SETTINGS_FILE = path.join(DATA_DIR, "app-settings.json");
const MEDICINE_LIBRARY_FILE = path.join(DATA_DIR, "medicine-library.json");
const MEDICINE_VIDEO_DIR = path.join(__dirname, "uploads", "medicine-videos");
const MEDICINE_VIDEO_RETENTION_DAYS = Number(process.env.MEDICINE_VIDEO_RETENTION_DAYS) || 7;
const MEDICINE_VIDEO_RETENTION_MS = MEDICINE_VIDEO_RETENTION_DAYS * 24 * 60 * 60 * 1000;
const ESP32CAM_STREAM_KEY = process.env.STREAM_KEY || "CHANGE_ME_STREAM_KEY";
const ESP32CAM_MJPEG_BOUNDARY = "esp32cam";
const ESP32CAM_UPLOAD_BOUNDARY = "esp32camupload";
const ESP32CAM_MAX_FRAME_SIZE = 2 * 1024 * 1024;
const ESP32CAM_MAX_STREAM_BUFFER_SIZE = 4 * 1024 * 1024;
const MEDICINE_VIDEO_DUPLICATE_LOG_INTERVAL = 30;

fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(MEDICINE_VIDEO_DIR, { recursive: true });
if (!fs.existsSync(MEDICINE_LIBRARY_FILE)) {
  fs.writeFileSync(MEDICINE_LIBRARY_FILE, "[]\n", "utf8");
}
if (!fs.existsSync(USERS_FILE)) {
  fs.writeFileSync(USERS_FILE, "[]\n", "utf8");
}
if (!fs.existsSync(APP_SETTINGS_FILE)) {
  fs.writeFileSync(APP_SETTINGS_FILE, "{}\n", "utf8");
}

app.use(cors());
app.use(express.json());
app.use("/uploads/medicine-videos", express.static(MEDICINE_VIDEO_DIR));

const io = new Server(server, {
  cors: {
    origin: "*",
  },
});

const DEFAULT_AUTH_ACCOUNT = "00000000000";
const DEFAULT_AUTH_PASSWORD = "CHANGE_ME_PASSWORD";
const AUTH_TOKEN_TTL_MS = 7 * 24 * 60 * 60 * 1000;
const AUTH_SECRET = process.env.AUTH_SECRET || "CHANGE_ME_AUTH_SECRET";
const ACCOUNT_PATTERN = /^\d{11}$/;

function readUsers() {
  try {
    const text = fs.readFileSync(USERS_FILE, "utf8");
    const data = JSON.parse(text || "[]");
    return Array.isArray(data) ? data : [];
  } catch (error) {
    console.error("读取账号数据失败：", error);
    return [];
  }
}

function writeUsers(users) {
  fs.writeFileSync(`${USERS_FILE}.tmp`, `${JSON.stringify(users, null, 2)}\n`, "utf8");
  fs.renameSync(`${USERS_FILE}.tmp`, USERS_FILE);
}

function normalizeAppSettings(settings) {
  const data = settings && typeof settings === "object" ? settings : {};
  return {
    lowFeverLimit: Number(data.lowFeverLimit) || 37.3,
    feverLimit: Number(data.feverLimit) || 38,
    envTempLimit: Number(data.envTempLimit) || 30,
    humidityLimit: Number(data.humidityLimit) || 75,
    familyName: String(data.familyName || data.family_name || "").trim(),
    familyPhone: String(data.familyPhone || data.family_phone || data.contactPhone || "").trim(),
  };
}

function readAppSettings() {
  try {
    const text = fs.readFileSync(APP_SETTINGS_FILE, "utf8");
    return normalizeAppSettings(JSON.parse(text || "{}"));
  } catch (error) {
    console.error("read app settings failed:", error);
    return normalizeAppSettings({});
  }
}

function writeAppSettings(settings) {
  const normalized = normalizeAppSettings(settings);
  fs.writeFileSync(`${APP_SETTINGS_FILE}.tmp`, `${JSON.stringify(normalized, null, 2)}\n`, "utf8");
  fs.renameSync(`${APP_SETTINGS_FILE}.tmp`, APP_SETTINGS_FILE);
  return normalized;
}

function hashPassword(password, salt = crypto.randomBytes(16).toString("hex")) {
  const hash = crypto.pbkdf2Sync(password, salt, 120000, 64, "sha512").toString("hex");
  return { salt, hash };
}

function verifyPassword(password, user) {
  if (!user?.salt || !user?.passwordHash) {
    return false;
  }

  const { hash } = hashPassword(password, user.salt);
  return crypto.timingSafeEqual(Buffer.from(hash, "hex"), Buffer.from(user.passwordHash, "hex"));
}

function createPublicUser(user) {
  return {
    account: user.account,
    createdAt: user.createdAt,
  };
}

function createAuthToken(user) {
  const payload = Buffer.from(
    JSON.stringify({
      account: user.account,
      exp: Date.now() + AUTH_TOKEN_TTL_MS,
    })
  ).toString("base64url");
  const signature = crypto.createHmac("sha256", AUTH_SECRET).update(payload).digest("base64url");
  return `${payload}.${signature}`;
}

function verifyAuthToken(token) {
  if (!token || typeof token !== "string" || !token.includes(".")) {
    return null;
  }

  const [payload, signature] = token.split(".");
  const expectedSignature = crypto.createHmac("sha256", AUTH_SECRET).update(payload).digest("base64url");

  if (
    signature.length !== expectedSignature.length ||
    !crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expectedSignature))
  ) {
    return null;
  }

  try {
    const data = JSON.parse(Buffer.from(payload, "base64url").toString("utf8"));
    if (!data?.account || Date.now() > Number(data.exp)) {
      return null;
    }

    return data;
  } catch {
    return null;
  }
}

function seedDefaultUser() {
  const users = readUsers();
  if (users.some((user) => user.account === DEFAULT_AUTH_ACCOUNT)) {
    return;
  }

  const now = new Date().toISOString();
  const password = hashPassword(DEFAULT_AUTH_PASSWORD);
  users.push({
    account: DEFAULT_AUTH_ACCOUNT,
    salt: password.salt,
    passwordHash: password.hash,
    createdAt: now,
    updatedAt: now,
  });
  writeUsers(users);
}

function getBearerToken(req) {
  const header = String(req.get("authorization") || "");
  return header.startsWith("Bearer ") ? header.slice("Bearer ".length).trim() : "";
}

seedDefaultUser();

let latestData = {
  temperature: 0,
  humidity: 0,
  bodyTemperature: null,
  heartRate: null,
  bloodOxygen: null,
  date: "",
  time: "",
  online: false,
  riskLevel: "正常",
};

let bodyTemperatureHistory = [];
let heartRateHistory = [];
let bloodOxygenHistory = [];

let alarms = [];
let esp32camFrame = null;
const ESP32CAM_FPS_WINDOW_MS = 5000;
let esp32camFrameTimestamps = [];
let esp32camFirstFrameAt = null;
let esp32camSessionFrameCount = 0;
let esp32camState = {
  online: false,
  deviceId: "",
  frameCount: 0,
  lastFrameAt: null,
  lastFrameSize: 0,
  lastRemoteAddress: "",
  lastUserAgent: "",
  streamClients: 0,
  currentFps: 0,
  averageFps: 0,
  uploadMode: "",
  uploadClients: 0,
};
let esp32camControl = {
  enabled: false,
  source: "default",
  updatedAt: new Date().toISOString(),
};
let esp32camClients = new Set();
let esp32camUploadClients = new Set();
let medicineTakenRecords = {};
let recentMedicineStockDeductions = new Map();
let medicineVideoSessions = [];
let medicineVideoSequence = 0;
let activeMedicineCameraSessionId = "";
let medicinePatient = {
  name: "",
  phone: "",
};
let appSettings = readAppSettings();
let faceIdentity = {
  registered: false,
  registeredName: "",
  registrationState: "unregistered",
  message: "尚未注册人脸",
  updatedAt: new Date().toISOString(),
};
let faceUsers = [];
let k230CommandQueue = [];
let k230CommandSequence = 0;
let k230DeviceLastSeen = 0;
let pendingFacePassword = "";
let pendingFaceOperation = null;
let faceRegistrationExpiresAt = 0;
let faceRegisterVerifyTimer = null;
let medicineUpdatedAt = new Date().toISOString();
let medicineBoxes = Array.from({ length: 6 }, function (_, index) {
  return {
    id: index + 1,
    title: `第 ${index + 1} 药仓`,
    name: "",
    quantity: 0,
    lowThreshold: 5,
  };
});
let medicinePutRecords = [];
let medicinePlans = [
  {
    slot: 1,
    earliestTime: "07:30",
    reminderTime: "08:00",
    latestTime: "08:30",
    time: "08:00",
    medicines: [
      {
        name: "降压药",
        dose: "1粒",
      },
    ],
  },
  {
    slot: 2,
    earliestTime: "11:30",
    reminderTime: "12:00",
    latestTime: "12:30",
    time: "12:00",
    medicines: [
      {
        name: "降糖药",
        dose: "1粒",
      },
    ],
  },
  {
    slot: 3,
    earliestTime: "20:17",
    reminderTime: "20:47",
    latestTime: "21:17",
    time: "20:47",
    medicines: [],
  },
];
let openaiClient = null;
let deepseekClient = null;

function readMedicineLibrary() {
  try {
    const text = fs.readFileSync(MEDICINE_LIBRARY_FILE, "utf8");
    const data = JSON.parse(text || "[]");
    return Array.isArray(data) ? data.map(normalizeMedicineLibraryItem) : [];
  } catch (error) {
    console.error("读取药品库失败：", error);
    return [];
  }
}

function writeMedicineLibrary(items) {
  fs.writeFileSync(
    MEDICINE_LIBRARY_FILE,
    `${JSON.stringify(items.map(normalizeMedicineLibraryItem), null, 2)}\n`,
    "utf8"
  );
}

function createMedicineLibraryId() {
  return `medicine_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

function normalizeStringList(value) {
  if (Array.isArray(value)) {
    return value.map((item) => String(item || "").trim()).filter(Boolean);
  }

  if (typeof value === "string") {
    return value
      .split(/\r?\n|、|，|,/)
      .map((item) => item.trim())
      .filter(Boolean);
  }

  return [];
}

function normalizeMedicineSources(value) {
  if (!Array.isArray(value)) {
    return [];
  }

  return value
    .map(function (item) {
      if (typeof item === "string") {
        return { title: item.trim(), url: "" };
      }

      return {
        title: String(item?.title || item?.name || "资料来源").trim(),
        url: String(item?.url || item?.link || "").trim(),
      };
    })
    .filter((item) => item.title || item.url);
}

function normalizeMedicineLibraryItem(item) {
  const now = new Date().toISOString();
  return {
    id: String(item?.id || createMedicineLibraryId()),
    name: String(item?.name || "").trim(),
    genericName: String(item?.genericName || "").trim(),
    aliases: normalizeStringList(item?.aliases),
    category: String(item?.category || "资料未提供").trim(),
    summary: String(item?.summary || "").trim(),
    uses: normalizeStringList(item?.uses),
    dosageForms: normalizeStringList(item?.dosageForms),
    contraindications: normalizeStringList(item?.contraindications),
    adverseReactions: normalizeStringList(item?.adverseReactions),
    warnings: normalizeStringList(item?.warnings),
    sources: normalizeMedicineSources(item?.sources),
    dataSource: String(item?.dataSource || (item?.aiGenerated ? "AI 检索整理" : "人工录入")).trim(),
    aiGenerated: Boolean(item?.aiGenerated),
    createdAt: item?.createdAt || now,
    updatedAt: item?.updatedAt || now,
  };
}

function getAiProvider() {
  const provider = String(process.env.AI_PROVIDER || "").trim().toLowerCase();
  if (provider) {
    return provider;
  }
  return process.env.DEEPSEEK_API_KEY ? "deepseek" : "openai";
}

function getOpenAIClient() {
  if (!process.env.OPENAI_API_KEY) {
    return null;
  }

  if (!openaiClient) {
    openaiClient = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
      timeout: 30000,
    });
  }

  return openaiClient;
}

function getDeepSeekClient() {
  if (!process.env.DEEPSEEK_API_KEY) {
    return null;
  }

  if (!deepseekClient) {
    deepseekClient = new OpenAI({
      apiKey: process.env.DEEPSEEK_API_KEY,
      baseURL: process.env.DEEPSEEK_BASE_URL || "https://api.deepseek.com",
      timeout: 30000,
    });
  }

  return deepseekClient;
}

function getMedicineJsonSchema() {
  return {
    type: "object",
    additionalProperties: false,
    required: [
      "name",
      "genericName",
      "aliases",
      "category",
      "summary",
      "uses",
      "dosageForms",
      "contraindications",
      "adverseReactions",
      "warnings",
      "sources",
      "disclaimer",
    ],
    properties: {
      name: { type: "string" },
      genericName: { type: "string" },
      aliases: { type: "array", items: { type: "string" } },
      category: { type: "string" },
      summary: { type: "string" },
      uses: { type: "array", items: { type: "string" } },
      dosageForms: { type: "array", items: { type: "string" } },
      contraindications: { type: "array", items: { type: "string" } },
      adverseReactions: { type: "array", items: { type: "string" } },
      warnings: { type: "array", items: { type: "string" } },
      sources: {
        type: "array",
        items: {
          type: "object",
          additionalProperties: false,
          required: ["title", "url"],
          properties: {
            title: { type: "string" },
            url: { type: "string" },
          },
        },
      },
      disclaimer: { type: "string" },
    },
  };
}

function getMedicinePromptMessages(name) {
  const exampleJson = JSON.stringify({
    name: "布洛芬",
    genericName: "布洛芬",
    aliases: ["ibuprofen"],
    category: "资料未提供",
    summary: "资料未提供",
    uses: ["资料未提供"],
    dosageForms: ["资料未提供"],
    contraindications: ["资料未提供"],
    adverseReactions: ["资料未提供"],
    warnings: ["资料未提供"],
    sources: [{ title: "AI 生成草稿，请人工核对", url: "" }],
    disclaimer: "本内容仅用于药品科普展示，不构成诊断、治疗或用药建议。具体用药请咨询医生或药师。",
  });

  return [
    {
      role: "system",
      content:
        "你是药品说明书信息整理助手。只整理公开药品资料，不提供诊断、处方、个性化剂量或替代医生药师的建议。资料不足时写“资料未提供”。必须输出合法 JSON，不要输出 Markdown。JSON 字段必须完全符合示例。",
    },
    {
      role: "user",
      content:
        `请整理药品“${name}”的公开药品科普信息。` +
        "重点返回药品简介、常见用途、剂型、禁忌、不良反应、注意事项和资料来源。" +
        "不要建议用户自行服药，不要给出个性化用药剂量。" +
        `请只输出 JSON，示例结构如下：${exampleJson}`,
    },
  ];
}

function parseMedicineDraftJson(content) {
  const text = String(content || "").trim();
  if (!text) {
    throw new Error("AI 未返回药品信息");
  }

  try {
    return JSON.parse(text);
  } catch (error) {
    const match = text.match(/\{[\s\S]*\}/);
    if (match) {
      return JSON.parse(match[0]);
    }
    throw error;
  }
}

async function createMedicineDraftWithOpenAI(name) {
  const client = getOpenAIClient();
  if (!client) {
    const error = new Error("后端未配置 OPENAI_API_KEY，请在 backend/.env 中填写后重启服务");
    error.statusCode = 503;
    throw error;
  }

  const response = await client.responses.create({
    model: process.env.OPENAI_MODEL || "gpt-5.5",
    reasoning: { effort: "low" },
    input: getMedicinePromptMessages(name),
    tools: [
      {
        type: "web_search",
        filters: {
          allowed_domains: [
            "dailymed.nlm.nih.gov",
            "www.fda.gov",
            "open.fda.gov",
            "www.nmpa.gov.cn",
            "app.gjzwfw.gov.cn",
          ],
        },
      },
    ],
    tool_choice: "auto",
    include: ["web_search_call.action.sources"],
    text: {
      format: {
        type: "json_schema",
        name: "medicine_info",
        strict: true,
        schema: getMedicineJsonSchema(),
      },
    },
  });

  const draft = JSON.parse(response.output_text || "{}");
  return normalizeMedicineLibraryItem({
    ...draft,
    id: "",
    name: draft.name || name,
    aiGenerated: true,
    dataSource: "AI 检索整理",
  });
}

async function createMedicineDraftWithDeepSeek(name) {
  const client = getDeepSeekClient();
  if (!client) {
    const error = new Error("后端未配置 DEEPSEEK_API_KEY，请在 backend/.env 中填写后重启服务");
    error.statusCode = 503;
    throw error;
  }

  const completion = await client.chat.completions.create({
    model: process.env.DEEPSEEK_MODEL || "deepseek-v4-flash",
    messages: getMedicinePromptMessages(name),
    response_format: { type: "json_object" },
    max_tokens: 2200,
    temperature: 0.2,
    stream: false,
    thinking: { type: "disabled" },
  });
  const content = completion.choices?.[0]?.message?.content || "";
  const draft = parseMedicineDraftJson(content);

  return normalizeMedicineLibraryItem({
    ...draft,
    id: "",
    name: draft.name || name,
    aiGenerated: true,
    dataSource: "DeepSeek 生成草稿",
  });
}

async function createMedicineDraftWithAI(name) {
  const provider = getAiProvider();

  if (provider === "deepseek") {
    return createMedicineDraftWithDeepSeek(name);
  }

  if (provider === "openai") {
    return createMedicineDraftWithOpenAI(name);
  }

  const error = new Error(`不支持的 AI_PROVIDER：${provider}`);
  error.statusCode = 400;
  throw error;
}

function getMedicineConfig() {
  return {
    patient: medicinePatient,
    boxes: medicineBoxes,
    plans: medicinePlans,
    settings: appSettings,
    familyContact: {
      name: appSettings.familyName,
      phone: appSettings.familyPhone,
    },
    familyName: appSettings.familyName,
    familyPhone: appSettings.familyPhone,
    updatedAt: medicineUpdatedAt,
  };
}

function getActiveFaceStates() {
  return ["waiting_device", "authenticating", "checking", "registering", "loading_faces", "deleting_face"];
}

function isFaceOperationBusy() {
  return (
    faceRegistrationExpiresAt &&
    Date.now() <= faceRegistrationExpiresAt &&
    getActiveFaceStates().includes(faceIdentity.registrationState)
  );
}

function getIdentityStatus() {
  const faceActive = getActiveFaceStates().includes(faceIdentity.registrationState);

  if (
    faceRegistrationExpiresAt &&
    Date.now() > faceRegistrationExpiresAt &&
    faceActive
  ) {
    clearFaceRegisterVerifyTimer();
    pendingFacePassword = "";
    pendingFaceOperation = null;
    faceRegistrationExpiresAt = 0;
    faceIdentity = {
      ...faceIdentity,
      registrationState: "failed",
      message: "等待 K230 响应超时，请检查星火开发板连接后重试",
      updatedAt: new Date().toISOString(),
    };
  }

  return {
    user: medicinePatient,
    faceRegistered:
      faceIdentity.registered && faceIdentity.registeredName === medicinePatient.name,
    registeredName: faceIdentity.registeredName,
    registrationState: faceIdentity.registrationState,
    message: faceIdentity.message,
    faceUsers,
    updatedAt: faceIdentity.updatedAt,
    deviceOnline: Date.now() - k230DeviceLastSeen < 30000,
  };
}

function updateFaceIdentity(patch) {
  faceIdentity = {
    ...faceIdentity,
    ...patch,
    updatedAt: new Date().toISOString(),
  };
  io.emit("identityData", getIdentityStatus());
}

function enqueueK230Command(command) {
  k230CommandSequence += 1;
  k230CommandQueue.push({
    id: k230CommandSequence,
    command,
    createdAt: new Date().toISOString(),
  });
}

function enqueueK230PasswordAuth() {
  enqueueK230Command("MODE:NORMAL");
  enqueueK230Command("MODE:EDIT");
}

function sanitizeFaceName(name) {
  return String(name || "").trim();
}

function clearFaceRegisterVerifyTimer() {
  if (faceRegisterVerifyTimer) {
    clearTimeout(faceRegisterVerifyTimer);
    faceRegisterVerifyTimer = null;
  }
}

function scheduleFaceRegisterVerification() {
  if (!pendingFaceOperation || pendingFaceOperation.type !== "register" || faceRegisterVerifyTimer) {
    return;
  }

  faceRegisterVerifyTimer = setTimeout(function () {
    faceRegisterVerifyTimer = null;
    if (!pendingFaceOperation || pendingFaceOperation.type !== "register") {
      return;
    }

    enqueueK230Command("USER:LIST");
    updateFaceIdentity({
      registrationState: "checking",
      message: "正在确认人脸是否已注册成功",
    });
  }, 8000);
}

function clearPendingFaceOperation() {
  clearFaceRegisterVerifyTimer();
  pendingFacePassword = "";
  pendingFaceOperation = null;
  faceRegistrationExpiresAt = 0;
}

function finishFaceRegistration(registered, state, message, registeredName = "") {
  clearPendingFaceOperation();
  updateFaceIdentity({
    registered,
    registeredName: registered ? registeredName || medicinePatient.name : "",
    registrationState: state,
    message,
  });
  enqueueK230Command("MODE:NORMAL");
}

function normalizeMedicinePlans(plans) {
  return plans.map(function (plan, index) {
    const medicines = Array.isArray(plan.medicines) ? plan.medicines : [];
    const reminderTime = plan.reminderTime || plan.time;

    return {
      slot: Number(plan.slot) || index + 1,
      period: plan.period || ["morning", "noon", "evening"][index] || `slot${index + 1}`,
      earliestTime: plan.earliestTime || reminderTime,
      reminderTime: reminderTime,
      latestTime: plan.latestTime || reminderTime,
      // 兼容旧版开发板：time 始终等于提醒时间。
      time: reminderTime,
      medicines: medicines.map(function (medicine) {
        const parsedDoseCount = Number(
          medicine.doseCount ?? String(medicine.dose || "").match(/\d+/)?.[0]
        );

        return {
          boxId: Number(medicine.boxId) || null,
          boxName: medicine.boxName || "",
          medicineId: medicine.medicineId || "",
          name: medicine.name || "",
          doseCount: Number.isInteger(parsedDoseCount) ? parsedDoseCount : null,
          dose: medicine.dose || (parsedDoseCount ? `${parsedDoseCount}粒` : ""),
        };
      }),
    };
  });
}

function normalizeMedicineBoxes(boxes) {
  return Array.from({ length: 6 }, function (_, index) {
    const box = boxes[index] || {};
    const quantity = Number(box.quantity);
    const lowThreshold = Number(box.lowThreshold ?? box.minThreshold ?? box.threshold);

    return {
      id: index + 1,
      title: `第 ${index + 1} 药仓`,
      medicineId: String(box.medicineId || box.medicine_id || "").trim(),
      medicine_id: String(box.medicineId || box.medicine_id || "").trim(),
      name: String(box.name || "").trim(),
      quantity: Number.isInteger(quantity) && quantity >= 0 ? quantity : 0,
      lowThreshold: Number.isInteger(lowThreshold) && lowThreshold >= 0 ? lowThreshold : 5,
    };
  });
}

function appendMedicinePutRecord(record) {
  const boxId = Number(record.boxId ?? record.box_id);
  const putCount = Number(record.putCount ?? record.put_count);
  const after = Number(record.after);

  if (!Number.isInteger(boxId) || boxId < 1 || boxId > medicineBoxes.length || !Number.isInteger(putCount) || putCount <= 0) {
    return null;
  }

    const normalizedRecord = {
      id: `${Date.now()}-${medicinePutRecords.length + 1}`,
      recordedAt: record.recordedAt || new Date().toISOString(),
      boxId,
      box_id: boxId,
      boxName: record.boxName || `第 ${boxId} 药仓`,
      medicineId: String(record.medicineId || record.medicine_id || "").trim(),
      medicine_id: String(record.medicineId || record.medicine_id || "").trim(),
      medicineName: String(record.medicineName || "").trim(),
      putCount,
    put_count: putCount,
    after: Number.isInteger(after) && after >= 0 ? after : 0,
    source: record.source || "unknown",
  };

  medicinePutRecords.unshift(normalizedRecord);
  if (medicinePutRecords.length > 500) {
    medicinePutRecords = medicinePutRecords.slice(0, 500);
  }

  io.emit("medicinePutRecords", medicinePutRecords);
  return normalizedRecord;
}

function validateMedicineTimes(plans) {
  const timePattern = /^([01]\d|2[0-3]):[0-5]\d$/;
  const normalized = plans.map(function (plan) {
    const reminderTime = String(plan.reminderTime || plan.time || "");
    return {
      earliestTime: String(plan.earliestTime || reminderTime),
      reminderTime,
      latestTime: String(plan.latestTime || reminderTime),
    };
  });

  for (let index = 0; index < normalized.length; index += 1) {
    const current = normalized[index];
    if (
      !timePattern.test(current.earliestTime) ||
      !timePattern.test(current.reminderTime) ||
      !timePattern.test(current.latestTime)
    ) {
      return "用药时间格式不正确";
    }

    if (
      current.earliestTime > current.reminderTime ||
      current.reminderTime > current.latestTime
    ) {
      return `第 ${index + 1} 次用药必须满足：最早时间 ≤ 提醒时间 ≤ 最晚时间`;
    }

    const next = normalized[index + 1];
    if (next && current.latestTime > next.earliestTime) {
      return `第 ${index + 1} 次最晚时间不能超过第 ${index + 2} 次最早时间`;
    }
  }

  return "";
}

function addAlarm(type, message) {
  alarms.unshift({
    time: latestData.time || new Date().toLocaleTimeString(),
    type: type,
    message: message,
  });

  if (alarms.length > 8) {
    alarms.pop();
  }
}

function checkEnvRisk(data) {
  let risk = "正常";

  if (data.temperature >= 35) {
    risk = "警告";
    addAlarm("环境温度过高", "当前药盒环境温度过高，可能影响药品保存");
  }

  if (data.temperature <= 5) {
    risk = "警告";
    addAlarm("环境温度过低", "当前药盒环境温度过低，请注意药品保存环境");
  }

  if (data.humidity >= 80) {
    risk = "警告";
    addAlarm("环境湿度过高", "当前药盒环境湿度过高，药品可能受潮");
  }

  if (data.humidity <= 20 && data.humidity > 0) {
    risk = "提示";
    addAlarm("环境湿度过低", "当前环境湿度较低，请注意药品保存条件");
  }

  return risk;
}

function checkBodyRisk(bodyTemperature) {
  if (bodyTemperature === null || Number.isNaN(bodyTemperature)) {
    return;
  }

  if (bodyTemperature >= 38.0) {
    addAlarm("体温异常", "检测到体温偏高，请及时关注老人健康状态");
  } else if (bodyTemperature >= 37.3) {
    addAlarm("低热提醒", "检测到体温略高，建议继续观察");
  } else if (bodyTemperature < 35.0) {
    addAlarm("体温过低", "检测到体温偏低，可能为测量姿势异常或环境影响");
  }
}

function pushHistory(list, item, maxLength) {
  list.push(item);

  if (list.length > maxLength) {
    list.shift();
  }
}

function formatDateKey(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function formatClockTime(date) {
  const hours = String(date.getHours()).padStart(2, "0");
  const minutes = String(date.getMinutes()).padStart(2, "0");
  return `${hours}:${minutes}`;
}

function normalizeDateKey(value) {
  const text = String(value || "").trim();
  return /^\d{4}-\d{2}-\d{2}$/.test(text) ? text : formatDateKey(new Date());
}

function normalizeClockTime(value) {
  const match = String(value || "").match(/(\d{1,2}):(\d{1,2})/);
  if (!match) {
    return formatClockTime(new Date());
  }

  const hours = Number(match[1]);
  const minutes = Number(match[2]);
  if (hours < 0 || hours > 23 || minutes < 0 || minutes > 59) {
    return formatClockTime(new Date());
  }

  return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`;
}

function timeToMinutes(time) {
  const match = String(time || "").match(/(\d{1,2}):(\d{1,2})/);
  if (!match) {
    return null;
  }

  return Number(match[1]) * 60 + Number(match[2]);
}

function mealIdFromSlot(slot) {
  return ["breakfast", "lunch", "dinner"][slot - 1] || `slot${slot}`;
}

function inferCurrentMedicineSlot(time) {
  const currentMinutes = timeToMinutes(time);
  if (currentMinutes === null) {
    return null;
  }

  const matchedIndex = medicinePlans.findIndex(function (plan) {
    const earliest = timeToMinutes(plan.earliestTime || plan.time);
    const latest = timeToMinutes(plan.latestTime || plan.time);
    if (earliest === null || latest === null) {
      return false;
    }
    return currentMinutes >= earliest && currentMinutes <= latest;
  });

  return matchedIndex >= 0 ? Number(medicinePlans[matchedIndex].slot) || matchedIndex + 1 : null;
}

function getMedicineTakenSlot(payload, time) {
  const slot = Number(
    payload.plan_slot ??
      payload.planSlot ??
      payload.slot ??
      payload.plan ??
      payload.medicineSlot
  );

  if (Number.isInteger(slot) && slot >= 1 && slot <= medicinePlans.length) {
    return slot;
  }

  return inferCurrentMedicineSlot(time);
}

function shouldRecordMedicineTaken(payload) {
  const eventName = String(payload.event || payload.trigger_type || payload.tool || "").trim();
  const status = String(payload.status || payload.permission || "").trim().toLowerCase();

  if (eventName === "medicine_taken") {
    return !["failed", "fail", "error", "missed"].includes(status);
  }

  if (payload.taken === true || payload.taken === "true") {
    return true;
  }

  if (
    ["medicine_session_result", "medicine_box_result"].includes(eventName) &&
    ["taken", "completed", "success", "done"].includes(status)
  ) {
    return true;
  }

  return eventName === "medication_detected" && status === "allowed";
}

function getMedicineBoxId(medicine) {
  const boxId = Number(medicine.boxId ?? medicine.box_id ?? medicine.cabinetId);
  return Number.isInteger(boxId) && boxId >= 1 && boxId <= medicineBoxes.length ? boxId : null;
}

function getMedicineDoseCount(medicine) {
  const parsedDose = Number(
    medicine.doseCount ??
      medicine.dose_count ??
      medicine.count ??
      medicine.quantity ??
      String(medicine.dose || "").match(/\d+/)?.[0]
  );

  return Number.isInteger(parsedDose) && parsedDose > 0 ? parsedDose : 0;
}

function getPayloadMedicineItems(payload) {
  if (Array.isArray(payload.medicines) && payload.medicines.length > 0) {
    return payload.medicines;
  }

  const boxId = Number(payload.box_id ?? payload.boxId ?? payload.cabinetId);
  const doseCount = Number(payload.dose_count ?? payload.doseCount ?? payload.count);
  if (Number.isInteger(boxId) && boxId >= 1) {
    return [{ boxId, doseCount: Number.isInteger(doseCount) && doseCount > 0 ? doseCount : 1 }];
  }

  return [];
}

function buildMedicineStockDeductions(plan, payload) {
  const payloadMedicines = getPayloadMedicineItems(payload);
  const medicines = payloadMedicines.length > 0
    ? payloadMedicines
    : Array.isArray(plan.medicines) && plan.medicines.length > 0
    ? plan.medicines
    : [];

  return medicines.reduce(function (deductions, medicine) {
    const boxId = getMedicineBoxId(medicine);
    const doseCount = getMedicineDoseCount(medicine);

    if (!boxId || doseCount <= 0) {
      return deductions;
    }

    deductions[boxId] = (deductions[boxId] || 0) + doseCount;
    return deductions;
  }, {});
}

function getMedicineTakenEventName(payload) {
  return String(payload.event || payload.trigger_type || payload.tool || "").trim();
}

function shouldDeductStockForTaken(payload, alreadyTaken) {
  return !alreadyTaken;
}

function getMedicineStockDeductionFingerprint(payload, slot, deductions) {
  const boxes = Object.keys(deductions)
    .sort()
    .map(function (boxId) {
      return `${boxId}:${deductions[boxId]}`;
    })
    .join(",");

  return [
    getMedicineTakenEventName(payload) || "taken",
    slot,
    payload.sessionId || payload.session_id || "",
    payload.eventId || payload.event_id || "",
    boxes,
  ].join("|");
}

function consumeRecentMedicineStockDeduction(fingerprint) {
  const now = Date.now();
  const ttlMs = 5000;

  recentMedicineStockDeductions.forEach(function (createdAt, key) {
    if (now - createdAt > ttlMs) {
      recentMedicineStockDeductions.delete(key);
    }
  });

  if (recentMedicineStockDeductions.has(fingerprint)) {
    return false;
  }

  recentMedicineStockDeductions.set(fingerprint, now);
  return true;
}

function deductMedicineBoxStock(plan, payload) {
  const deductions = buildMedicineStockDeductions(plan, payload);
  const stockChanges = [];

  medicineBoxes = medicineBoxes.map(function (box) {
    const doseCount = deductions[box.id] || 0;
    if (doseCount <= 0) {
      return box;
    }

    const before = Number(box.quantity) || 0;
    const after = Math.max(0, before - doseCount);
    stockChanges.push({
      boxId: box.id,
      boxName: box.title,
      medicineId: box.medicineId || "",
      medicineName: box.name,
      doseCount,
      before,
      after,
    });

    return {
      ...box,
      quantity: after,
    };
  });

  return stockChanges;
}

function getPutMedicineTasks() {
  const boxes = medicineBoxes.map(function (box) {
    const quantity = Number(box.quantity) || 0;
    const parsedThreshold = Number(box.lowThreshold ?? box.minThreshold ?? box.threshold);
    const lowThreshold = Number.isInteger(parsedThreshold) && parsedThreshold >= 0 ? parsedThreshold : 5;
    const needsRefill = quantity <= lowThreshold;
    const putCount = needsRefill ? Math.max(1, lowThreshold - quantity) : 0;
    const targetCount = quantity + putCount;

    return {
      id: box.id,
      box_id: box.id,
      boxId: box.id,
      title: box.title,
      boxName: box.title,
      name: box.name,
      medicineId: box.medicineId || "",
      medicine_id: box.medicineId || "",
      medicine_name: box.name,
      medicineName: box.name,
      quantity,
      stock_count: quantity,
      stockCount: quantity,
      lowThreshold,
      min_threshold: lowThreshold,
      minThreshold: lowThreshold,
      target_count: targetCount,
      targetCount,
      put_count: putCount,
      putCount,
      status: quantity === 0 ? "empty" : needsRefill ? "low" : "normal",
    };
  });

  const tasks = boxes
    .filter(function (box) {
      return box.name && box.quantity <= box.lowThreshold;
    })
    .map(function (box) {
      const putCount = Math.max(1, box.lowThreshold - box.quantity);
      const targetCount = box.quantity + putCount;

      return {
        box_id: box.id,
        boxId: box.id,
        medicineId: box.medicineId || "",
        medicine_id: box.medicineId || "",
        medicine_name: box.name,
        medicineName: box.name,
        action: "refill",
        bound: true,
        stock_count: box.quantity,
        stockCount: box.quantity,
        lowThreshold: box.lowThreshold,
        min_threshold: box.lowThreshold,
        minThreshold: box.lowThreshold,
        target_count: targetCount,
        targetCount,
        put_count: putCount,
        putCount,
        stock_source: "cloud",
        stockSource: "cloud",
        confirm_binding: false,
      };
    });

  return { boxes, tasks };
}

function recordMedicinePut(payload, source) {
  const boxId = Number(payload.box_id ?? payload.boxId ?? payload.id);
  const putCount = Number(payload.put_count ?? payload.putCount ?? payload.count ?? payload.amount ?? payload.quantity);

  if (!Number.isInteger(boxId) || boxId < 1 || boxId > medicineBoxes.length || !Number.isInteger(putCount) || putCount <= 0) {
    return null;
  }

  let event = null;
  medicineBoxes = medicineBoxes.map(function (box) {
    if (box.id !== boxId) {
      return box;
    }

    const before = Number(box.quantity) || 0;
    const after = before + putCount;
    event = {
      boxId,
      box_id: boxId,
      boxName: box.title,
      medicineId: box.medicineId || "",
      medicine_id: box.medicineId || "",
      medicineName: box.name,
      putCount,
      put_count: putCount,
      before,
      after,
      source,
      recordedAt: new Date().toISOString(),
    };

    return {
      ...box,
      quantity: after,
    };
  });

  if (!event) {
    return null;
  }

  medicineUpdatedAt = new Date().toISOString();
  appendMedicinePutRecord(event);
  io.emit("medicinePut", event);
  io.emit("medicineBoxes", medicineBoxes);
  io.emit("medicineConfig", getMedicineConfig());
  return event;
}

function recordMedicineTaken(payload, source) {
  if (!payload || !shouldRecordMedicineTaken(payload)) {
    return null;
  }

  const dateKey = normalizeDateKey(payload.date || payload.dateKey);
  const time = normalizeClockTime(payload.time || payload.timestamp);
  const slot = getMedicineTakenSlot(payload, time);

  if (!slot) {
    return null;
  }

  const mealId = payload.mealId || mealIdFromSlot(slot);
  const key = `${dateKey}-${mealId}`;
  const plan = medicinePlans[slot - 1] || {};
  const alreadyTaken = medicineTakenRecords[key] === "taken";
  const deductions = buildMedicineStockDeductions(plan, payload);
  const shouldDeductStock =
    Object.keys(deductions).length > 0 &&
    shouldDeductStockForTaken(payload, alreadyTaken) &&
    consumeRecentMedicineStockDeduction(
      getMedicineStockDeductionFingerprint(payload, slot, deductions)
    );
  const stockChanges = shouldDeductStock ? deductMedicineBoxStock(plan, payload) : [];

  if (stockChanges.length > 0) {
    medicineUpdatedAt = new Date().toISOString();
  }

  const event = {
    key,
    dateKey,
    time,
    mealId,
    slot,
    planSlot: slot,
    status: "taken",
    source,
    userName: payload.user_name || payload.userName || medicinePatient.name || "",
    medicines: Array.isArray(plan.medicines) ? plan.medicines : [],
    stockChanges,
    boxes: medicineBoxes,
    duplicated: alreadyTaken,
    recordedAt: new Date().toISOString(),
  };

  medicineTakenRecords[key] = "taken";
  io.emit("medicineTaken", event);
  io.emit("medicineTakenRecords", medicineTakenRecords);

  if (stockChanges.length > 0) {
    io.emit("medicineBoxes", medicineBoxes);
    io.emit("medicineConfig", getMedicineConfig());
  }

  return event;
}

function getMedicineTakenStatus(dateKey = formatDateKey(new Date())) {
  const normalizedDateKey = normalizeDateKey(dateKey);
  const slotStatus = {};
  const takenSlots = [];

  medicinePlans.forEach(function (plan, index) {
    const slot = Number(plan.slot) || index + 1;
    const mealId = mealIdFromSlot(slot);
    const key = `${normalizedDateKey}-${mealId}`;
    const status = medicineTakenRecords[key] || "pending";

    slotStatus[String(slot)] = status;
    if (status === "taken") {
      takenSlots.push(slot);
    }
  });

  return {
    dateKey: normalizedDateKey,
    takenSlots,
    slotStatus,
  };
}

function emitMedicineVideoSessions() {
  io.emit("medicineVideoSessions", medicineVideoSessions);
}

function getMedicineVideoSessionTime(session) {
  const candidates = [session.endedAt, session.uploadedAt, session.startedAt];
  for (const value of candidates) {
    const time = Date.parse(value);
    if (Number.isFinite(time)) {
      return time;
    }
  }

  if (session.dateKey) {
    const time = Date.parse(`${session.dateKey}T${session.time || "00:00"}:00`);
    if (Number.isFinite(time)) {
      return time;
    }
  }

  return Date.now();
}

function getMedicineVideoFileNameFromUrl(url) {
  const text = String(url || "");
  const prefix = "/uploads/medicine-videos/";
  if (!text.startsWith(prefix)) {
    return "";
  }

  try {
    return decodeURIComponent(text.slice(prefix.length));
  } catch (error) {
    return text.slice(prefix.length);
  }
}

function deleteMedicineVideoFile(fileName) {
  const safeName = path.basename(String(fileName || ""));
  if (!safeName) {
    return;
  }

  const filePath = path.join(MEDICINE_VIDEO_DIR, safeName);
  if (!filePath.startsWith(MEDICINE_VIDEO_DIR)) {
    return;
  }

  try {
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
  } catch (error) {
    console.error("删除过期用药录像文件失败：", filePath, error);
  }
}

function deleteMedicineVideoSessionFiles(session) {
  const fileNames = new Set();
  if (session.fileName) {
    fileNames.add(session.fileName);
  }
  if (session.videoUrl) {
    fileNames.add(getMedicineVideoFileNameFromUrl(session.videoUrl));
  }
  if (session.thumbnailUrl) {
    fileNames.add(getMedicineVideoFileNameFromUrl(session.thumbnailUrl));
  }
  (session.frames || []).forEach((frame) => {
    if (frame?.url) {
      fileNames.add(getMedicineVideoFileNameFromUrl(frame.url));
    }
  });

  fileNames.forEach(deleteMedicineVideoFile);
}

function pruneExpiredMedicineVideoSessions(emit = false) {
  const cutoff = Date.now() - MEDICINE_VIDEO_RETENTION_MS;
  const keptSessions = [];
  const expiredSessions = [];

  medicineVideoSessions.forEach((session) => {
    if (getMedicineVideoSessionTime(session) < cutoff) {
      expiredSessions.push(session);
      return;
    }
    keptSessions.push(session);
  });

  if (expiredSessions.length === 0) {
    return 0;
  }

  expiredSessions.forEach(deleteMedicineVideoSessionFiles);
  medicineVideoSessions = keptSessions;
  if (emit) {
    emitMedicineVideoSessions();
  }
  return expiredSessions.length;
}

function normalizeVideoSession(session) {
  const frames = Array.isArray(session.frames) ? session.frames : [];
  return {
    id: session.id,
    title: session.title,
    status: session.status,
    source: session.source,
    planSlot: session.planSlot,
    dateKey: session.dateKey,
    time: session.time,
    startedAt: session.startedAt,
    endedAt: session.endedAt,
    uploadedAt: session.uploadedAt,
    durationSeconds: session.durationSeconds,
    contentType: session.contentType,
    fileName: session.fileName,
    videoUrl: session.videoUrl,
    thumbnailUrl: session.thumbnailUrl || frames[0]?.url || "",
    frameCount: frames.length,
    frames,
    duplicateFrameCount: Number(session.duplicateFrameCount) || 0,
    lastDuplicateFrameAt: session.lastDuplicateFrameAt || "",
    size: session.size || frames.reduce((sum, frame) => sum + (frame.size || 0), 0),
  };
}

function pushMedicineVideoSession(session) {
  pruneExpiredMedicineVideoSessions(false);
  medicineVideoSessions.unshift(normalizeVideoSession(session));
  if (medicineVideoSessions.length > 80) {
    const overflowSessions = medicineVideoSessions.slice(80);
    overflowSessions.forEach(deleteMedicineVideoSessionFiles);
    medicineVideoSessions = medicineVideoSessions.slice(0, 80);
  }
  emitMedicineVideoSessions();
}

function updateMedicineVideoSession(sessionId, patch, options = {}) {
  pruneExpiredMedicineVideoSessions(false);
  const index = medicineVideoSessions.findIndex((item) => item.id === sessionId);
  if (index < 0) {
    return null;
  }

  const updated = normalizeVideoSession({
    ...medicineVideoSessions[index],
    ...patch,
  });
  medicineVideoSessions.splice(index, 1, updated);
  if (options.emit !== false) {
    emitMedicineVideoSessions();
  }
  return updated;
}

function findMedicineVideoSession(sessionId) {
  pruneExpiredMedicineVideoSessions(false);
  return medicineVideoSessions.find((item) => item.id === sessionId) || null;
}

function getActiveMedicineCameraSession() {
  if (!activeMedicineCameraSessionId) {
    return null;
  }

  const session = findMedicineVideoSession(activeMedicineCameraSessionId);
  if (!session || session.status !== "recording") {
    activeMedicineCameraSessionId = "";
    return null;
  }

  return session;
}

function getEsp32camDesiredState() {
  const medicineSession = getActiveMedicineCameraSession();
  const medicineRecording = Boolean(medicineSession);
  const desiredEnabled = esp32camControl.enabled || medicineRecording;

  return {
    desiredEnabled,
    medicineRecording,
    activeSessionId: medicineSession ? medicineSession.id : "",
    source: medicineRecording ? "medicine_recording" : esp32camControl.source,
    updatedAt: medicineRecording
      ? medicineSession.updatedAt || medicineSession.startedAt || esp32camControl.updatedAt
      : esp32camControl.updatedAt,
  };
}

function deleteMedicineVideoSession(sessionId) {
  pruneExpiredMedicineVideoSessions(false);
  const index = medicineVideoSessions.findIndex((item) => item.id === sessionId);
  if (index < 0) {
    return null;
  }

  const session = medicineVideoSessions[index];
  if (session.status === "recording" || activeMedicineCameraSessionId === session.id) {
    return { busy: true, session };
  }

  medicineVideoSessions.splice(index, 1);
  deleteMedicineVideoSessionFiles(session);
  emitMedicineVideoSessions();
  return { busy: false, session };
}

function createMedicineVideoId() {
  medicineVideoSequence += 1;
  return `${Date.now()}-${medicineVideoSequence}`;
}

function sanitizeVideoFileName(value, fallback) {
  const text = String(value || "").trim();
  const safe = text.replace(/[^\w.-]+/g, "_").replace(/^_+|_+$/g, "");
  return safe || fallback;
}

function getVideoExtension(contentType, fileName) {
  const known = {
    "video/mp4": ".mp4",
    "video/webm": ".webm",
    "video/x-msvideo": ".avi",
    "video/avi": ".avi",
    "application/octet-stream": "",
    "image/jpeg": ".jpg",
  };
  const ext = path.extname(String(fileName || "")).toLowerCase();
  if (ext && /^[.\w]+$/.test(ext)) {
    return ext;
  }
  return known[String(contentType || "").split(";")[0].toLowerCase()] || ".mjpeg";
}

function getPublicMedicineVideoUrl(fileName) {
  return `/uploads/medicine-videos/${encodeURIComponent(fileName)}`;
}

function hashMedicineVideoFrame(frameBuffer) {
  return crypto.createHash("sha1").update(frameBuffer).digest("hex");
}

function parsePositiveInteger(value, fallback = null) {
  const number = Number(value);
  return Number.isInteger(number) && number > 0 ? number : fallback;
}

function createVideoSessionFromMetadata(data, source) {
  const id = createMedicineVideoId();
  const startedAt = data.startedAt || new Date().toISOString();
  const planSlot = parsePositiveInteger(data.planSlot ?? data.slot, null);
  const dateKey = normalizeDateKey(data.date || data.dateKey || startedAt.slice(0, 10));
  const time = normalizeClockTime(data.time || startedAt);
  const session = normalizeVideoSession({
    id,
    title: data.title || `用药录像 ${dateKey} ${time}`,
    status: "recording",
    source,
    planSlot,
    dateKey,
    time,
    startedAt,
    endedAt: "",
    uploadedAt: new Date().toISOString(),
    durationSeconds: 0,
    contentType: "image/jpeg-sequence",
    fileName: "",
    videoUrl: "",
    thumbnailUrl: "",
    frames: [],
    size: 0,
  });

  pruneExpiredMedicineVideoSessions(false);
  medicineVideoSessions.unshift(session);
  emitMedicineVideoSessions();
  console.log("[medicine-video] session started", {
    id: session.id,
    source: session.source,
    planSlot: session.planSlot,
    dateKey: session.dateKey,
    time: session.time,
  });
  return session;
}

function finishVideoSession(sessionId, data = {}) {
  const session = findMedicineVideoSession(sessionId);
  if (!session) {
    return null;
  }

  const endedAt = data.endedAt || new Date().toISOString();
  const startedAtMs = Date.parse(session.startedAt);
  const endedAtMs = Date.parse(endedAt);
  const durationSeconds =
    Number.isFinite(startedAtMs) && Number.isFinite(endedAtMs)
      ? Math.max(0, Math.round((endedAtMs - startedAtMs) / 1000))
      : session.durationSeconds || 0;

  const updated = updateMedicineVideoSession(sessionId, {
    status: "completed",
    endedAt,
    durationSeconds,
  });
  if (updated) {
    console.log("[medicine-video] session finished", {
      id: updated.id,
      status: updated.status,
      frames: updated.frames.length,
      durationSeconds: updated.durationSeconds,
    });
  }
  return updated;
}

function appendMedicineVideoFrame(sessionId, frameBuffer, timestamp = new Date().toISOString()) {
  const session = findMedicineVideoSession(sessionId);
  if (!session || !Buffer.isBuffer(frameBuffer) || frameBuffer.length === 0) {
    return null;
  }

  const frameHash = hashMedicineVideoFrame(frameBuffer);
  const lastFrame = session.frames[session.frames.length - 1];
  if (lastFrame?.hash && lastFrame.hash === frameHash) {
    const duplicateFrameCount = (Number(session.duplicateFrameCount) || 0) + 1;
    const duplicateFrame = {
      index: session.frames.length + 1,
      timestamp,
      size: 0,
      hash: frameHash,
      url: lastFrame.url,
      duplicateOf: lastFrame.index,
    };
    const updated = updateMedicineVideoSession(session.id, {
      status: "recording",
      frames: [...session.frames, duplicateFrame],
      duplicateFrameCount,
      lastDuplicateFrameAt: timestamp,
    });

    if (updated && duplicateFrameCount % MEDICINE_VIDEO_DUPLICATE_LOG_INTERVAL === 0) {
      console.log("[medicine-video] duplicate frame skipped", {
        id: updated.id,
        duplicateFrameCount,
        savedFrames: updated.frames.length,
      });
    }
    return updated;
  }

  const frameIndex = session.frames.length + 1;
  const fileName = sanitizeVideoFileName(
    `${session.id}-frame-${String(frameIndex).padStart(5, "0")}.jpg`,
    `${session.id}-frame.jpg`
  );
  const filePath = path.join(MEDICINE_VIDEO_DIR, fileName);
  fs.writeFileSync(filePath, frameBuffer);

  const frame = {
    index: frameIndex,
    timestamp,
    size: frameBuffer.length,
    hash: frameHash,
    url: getPublicMedicineVideoUrl(fileName),
  };
  const frames = [...session.frames, frame];

  const updated = updateMedicineVideoSession(session.id, {
    status: "recording",
    frames,
    thumbnailUrl: session.thumbnailUrl || frame.url,
    size: (session.size || 0) + frameBuffer.length,
  });
  if (updated && (frameIndex === 1 || frameIndex % 30 === 0)) {
    console.log("[medicine-video] frame saved", {
      id: updated.id,
      frameIndex,
      size: frameBuffer.length,
    });
  }
  return updated;
}

function saveMedicineVideoFrame(req, res, sessionId) {
  const session = findMedicineVideoSession(sessionId);
  if (!session) {
    res.status(404).json({ code: 1, msg: "medicine video session not found" });
    return;
  }

  if (!Buffer.isBuffer(req.body) || req.body.length === 0) {
    res.status(400).json({ code: 1, msg: "empty frame body" });
    return;
  }

  const updated = appendMedicineVideoFrame(
    session.id,
    req.body,
    req.headers["x-frame-timestamp"] || new Date().toISOString()
  );

  res.status(201).json({ code: 0, msg: "frame saved", data: updated });
}

function isValidBodyTemperature(value) {
  if (value === undefined || value === null || value === "") {
    return false;
  }

  const num = Number(value);

  if (Number.isNaN(num)) {
    return false;
  }

  if (num <= -50) {
    return false;
  }

  return true;
}

function isValidNumber(value) {
  if (value === undefined || value === null || value === "") {
    return false;
  }

  const num = Number(value);

  return !Number.isNaN(num);
}

function getEsp32camState() {
  const now = Date.now();
  const desiredState = getEsp32camDesiredState();
  const lastFrameTime = esp32camState.lastFrameAt
    ? Date.parse(esp32camState.lastFrameAt)
    : 0;
  const online = Boolean(lastFrameTime && now - lastFrameTime < 15000);
  const recentFrameTimes = online
    ? esp32camFrameTimestamps.filter((time) => now - time <= ESP32CAM_FPS_WINDOW_MS)
    : [];
  const recentSpan = recentFrameTimes.length > 1
    ? (recentFrameTimes[recentFrameTimes.length - 1] - recentFrameTimes[0]) / 1000
    : Math.min((now - (lastFrameTime || now)) / 1000, ESP32CAM_FPS_WINDOW_MS / 1000);
  const averageSpan = online && esp32camFirstFrameAt
    ? (now - esp32camFirstFrameAt) / 1000
    : 0;
  const currentFps = recentFrameTimes.length > 1 && recentSpan > 0
    ? (recentFrameTimes.length - 1) / recentSpan
    : 0;
  const averageFps = averageSpan > 0
    ? esp32camSessionFrameCount / averageSpan
    : 0;

  return {
    ...esp32camState,
    online,
    streamClients: esp32camClients.size,
    currentFps: Number(currentFps.toFixed(1)),
    averageFps: Number(averageFps.toFixed(1)),
    uploadClients: esp32camUploadClients.size,
    enabled: desiredState.desiredEnabled,
    controlEnabled: esp32camControl.enabled,
    desiredEnabled: desiredState.desiredEnabled,
    medicineRecording: desiredState.medicineRecording,
    activeSessionId: desiredState.activeSessionId,
    controlSource: esp32camControl.source,
    controlUpdatedAt: esp32camControl.updatedAt,
  };
}

function parseEsp32camControlEnabled(value) {
  if (typeof value === "boolean") {
    return value;
  }
  if (typeof value === "number") {
    return value !== 0;
  }
  if (typeof value === "string") {
    const text = value.trim().toLowerCase();
    if (["true", "1", "on", "enable", "enabled"].includes(text)) {
      return true;
    }
    if (["false", "0", "off", "disable", "disabled"].includes(text)) {
      return false;
    }
  }
  return null;
}

function setEsp32camControl(enabled, source = "web") {
  esp32camControl = {
    enabled: Boolean(enabled),
    source,
    updatedAt: new Date().toISOString(),
  };
  if (!esp32camControl.enabled) {
    closeEsp32camViewers();
    closeEsp32camUploaders();
    esp32camFrame = null;
    esp32camFrameTimestamps = [];
    esp32camFirstFrameAt = null;
    esp32camSessionFrameCount = 0;
    esp32camState = {
      ...esp32camState,
      online: false,
      lastFrameAt: null,
      lastFrameSize: 0,
      streamClients: 0,
      currentFps: 0,
      averageFps: 0,
      uploadMode: "",
      uploadClients: 0,
    };
  }
  io.emit("esp32camState", getEsp32camState());
  return esp32camControl;
}

function archiveEsp32camFrameForMedicine(frame, receivedAt) {
  const session = getActiveMedicineCameraSession();
  if (!session) {
    return;
  }

  const updated = appendMedicineVideoFrame(
    session.id,
    frame,
    new Date(receivedAt).toISOString()
  );
  if (!updated) {
    activeMedicineCameraSessionId = "";
  }
}

function recordEsp32camFrameTime(now) {
  const lastFrameTime = esp32camState.lastFrameAt
    ? Date.parse(esp32camState.lastFrameAt)
    : 0;

  if (!lastFrameTime || now - lastFrameTime > 15000) {
    esp32camFrameTimestamps = [];
    esp32camFirstFrameAt = now;
    esp32camSessionFrameCount = 0;
  }

  esp32camSessionFrameCount += 1;
  esp32camFrameTimestamps.push(now);
  esp32camFrameTimestamps = esp32camFrameTimestamps.filter(
    (time) => now - time <= ESP32CAM_FPS_WINDOW_MS
  );
}

function isEsp32camAuthorized(req) {
  if (!ESP32CAM_STREAM_KEY) {
    return true;
  }

  return req.get("x-stream-key") === ESP32CAM_STREAM_KEY;
}

function getEsp32camMultipartBoundary(req) {
  const contentType = String(req.get("content-type") || "");
  const match = contentType.match(/boundary=(?:"([^"]+)"|([^;\s]+))/i);
  return (match?.[1] || match?.[2] || ESP32CAM_UPLOAD_BOUNDARY).trim();
}

function parseMultipartHeaders(headerText) {
  const headers = {};
  headerText.split(/\r?\n/).forEach((line) => {
    const separatorIndex = line.indexOf(":");
    if (separatorIndex <= 0) {
      return;
    }

    const name = line.slice(0, separatorIndex).trim().toLowerCase();
    const value = line.slice(separatorIndex + 1).trim();
    if (name) {
      headers[name] = value;
    }
  });
  return headers;
}

function receiveEsp32camFrame(frame, req, options = {}) {
  if (!Buffer.isBuffer(frame) || frame.length === 0) {
    return null;
  }

  const receivedAt = Date.now();
  const desiredState = getEsp32camDesiredState();
  if (!desiredState.desiredEnabled) {
    return getEsp32camState();
  }

  recordEsp32camFrameTime(receivedAt);

  const frameCopy = Buffer.from(frame);
  if (desiredState.medicineRecording) {
    archiveEsp32camFrameForMedicine(frameCopy, receivedAt);
  }

  esp32camFrame = frameCopy;
  esp32camState = {
    online: true,
    deviceId: String(req.get("x-device-id") || options.deviceId || ""),
    frameCount: esp32camState.frameCount + 1,
    lastFrameAt: new Date(receivedAt).toISOString(),
    lastFrameSize: esp32camFrame.length,
    lastRemoteAddress: req.ip || req.socket.remoteAddress || "",
    lastUserAgent: String(req.get("user-agent") || ""),
    streamClients: esp32camClients.size,
    currentFps: esp32camState.currentFps,
    averageFps: esp32camState.averageFps,
    uploadMode: options.uploadMode || esp32camState.uploadMode || "single-frame",
    uploadClients: esp32camUploadClients.size,
  };

  if (desiredState.desiredEnabled) {
    broadcastEsp32camFrame(esp32camFrame);
  }

  io.emit("esp32camState", getEsp32camState());
  return getEsp32camState();
}

function createEsp32camStreamParser(req, boundary, onFrame) {
  const boundaryBuffer = Buffer.from(`--${boundary}`);
  const headerEndBuffer = Buffer.from("\r\n\r\n");
  let buffer = Buffer.alloc(0);

  function append(chunk) {
    buffer = Buffer.concat([buffer, chunk]);

    if (buffer.length > ESP32CAM_MAX_STREAM_BUFFER_SIZE) {
      const keepSize = Math.max(boundaryBuffer.length + 8, ESP32CAM_MAX_FRAME_SIZE);
      buffer = buffer.subarray(buffer.length - keepSize);
    }

    parse();
  }

  function parse() {
    for (;;) {
      let boundaryIndex = buffer.indexOf(boundaryBuffer);
      if (boundaryIndex < 0) {
        const keepSize = Math.max(0, boundaryBuffer.length - 1);
        if (buffer.length > keepSize) {
          buffer = buffer.subarray(buffer.length - keepSize);
        }
        return;
      }

      if (boundaryIndex > 0) {
        buffer = buffer.subarray(boundaryIndex);
      }

      const lineEndIndex = buffer.indexOf("\r\n");
      if (lineEndIndex < 0) {
        return;
      }

      const boundaryLine = buffer.subarray(0, lineEndIndex).toString("ascii");
      if (boundaryLine.endsWith("--")) {
        buffer = Buffer.alloc(0);
        return;
      }

      const headerStartIndex = lineEndIndex + 2;
      const headerEndIndex = buffer.indexOf(headerEndBuffer, headerStartIndex);
      if (headerEndIndex < 0) {
        return;
      }

      const headerText = buffer.subarray(headerStartIndex, headerEndIndex).toString("latin1");
      const headers = parseMultipartHeaders(headerText);
      const contentLength = Number(headers["content-length"]);
      if (!Number.isInteger(contentLength) || contentLength <= 0 || contentLength > ESP32CAM_MAX_FRAME_SIZE) {
        buffer = buffer.subarray(headerEndIndex + headerEndBuffer.length);
        continue;
      }

      const frameStartIndex = headerEndIndex + headerEndBuffer.length;
      const frameEndIndex = frameStartIndex + contentLength;
      if (buffer.length < frameEndIndex + 2) {
        return;
      }

      const contentType = String(headers["content-type"] || "").toLowerCase();
      if (!contentType || contentType.includes("image/jpeg")) {
        onFrame(buffer.subarray(frameStartIndex, frameEndIndex), headers);
      }

      buffer = buffer.subarray(frameEndIndex);
      if (buffer.subarray(0, 2).toString("ascii") === "\r\n") {
        buffer = buffer.subarray(2);
      }
    }
  }

  req.on("data", append);
}

function writeEsp32camMjpegFrame(res, frame) {
  res.write(`--${ESP32CAM_MJPEG_BOUNDARY}\r\n`);
  res.write("Content-Type: image/jpeg\r\n");
  res.write(`Content-Length: ${frame.length}\r\n\r\n`);
  res.write(frame);
  res.write("\r\n");
}

function broadcastEsp32camFrame(frame) {
  for (const client of Array.from(esp32camClients)) {
    try {
      writeEsp32camMjpegFrame(client, frame);
    } catch (error) {
      esp32camClients.delete(client);
    }
  }
}

function closeEsp32camViewers() {
  for (const client of Array.from(esp32camClients)) {
    try {
      client.end();
    } catch (error) {
      // Ignore stale viewer sockets.
    }
    esp32camClients.delete(client);
  }
  esp32camState.streamClients = 0;
}

function closeEsp32camUploaders() {
  for (const client of Array.from(esp32camUploadClients)) {
    try {
      if (typeof client.destroy === "function") {
        client.destroy();
      }
    } catch (error) {
      // Ignore stale uploader sockets.
    }
    esp32camUploadClients.delete(client);
  }
  esp32camState.uploadClients = 0;
  esp32camState.uploadMode = "";
}

function isEsp32camAcceptingFrames() {
  return getEsp32camDesiredState().desiredEnabled;
}

function getEsp32camPageHtml() {
  return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ESP32-CAM</title>
  <style>
    :root {
      color-scheme: light;
      font-family: Arial, "Microsoft YaHei", sans-serif;
      color: #172033;
      background: #f4f6fa;
    }

    body {
      margin: 0;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }

    header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 16px;
      padding: 16px 24px;
      background: #ffffff;
      border-bottom: 1px solid #dce3ee;
    }

    h1 {
      margin: 0;
      font-size: 20px;
      font-weight: 700;
    }

    main {
      width: min(1120px, calc(100% - 32px));
      margin: 24px auto;
      display: grid;
      gap: 16px;
    }

    .viewer {
      overflow: hidden;
      background: #111827;
      border: 1px solid #dce3ee;
      border-radius: 8px;
      aspect-ratio: 16 / 9;
      display: grid;
      place-items: center;
    }

    img {
      width: 100%;
      height: 100%;
      object-fit: contain;
      display: block;
    }

    .status {
      display: grid;
      grid-template-columns: repeat(4, minmax(0, 1fr));
      gap: 12px;
    }

    .item {
      background: #ffffff;
      border: 1px solid #dce3ee;
      border-radius: 8px;
      padding: 14px 16px;
    }

    .label {
      color: #667085;
      font-size: 13px;
      margin-bottom: 8px;
    }

    .value {
      font-size: 18px;
      font-weight: 700;
      word-break: break-word;
    }

    .online {
      color: #16a34a;
    }

    .offline {
      color: #dc2626;
    }

    @media (max-width: 720px) {
      header {
        padding: 14px 16px;
      }

      .status {
        grid-template-columns: repeat(2, minmax(0, 1fr));
      }
    }
  </style>
</head>
<body>
  <header>
    <h1>ESP32-CAM</h1>
    <div id="connection" class="offline">Waiting for frames</div>
  </header>
  <main>
    <section class="viewer">
      <img id="stream" src="/esp32cam/mjpeg" alt="ESP32-CAM MJPEG stream">
    </section>
    <section class="status">
      <div class="item">
        <div class="label">Status</div>
        <div id="online" class="value offline">Offline</div>
      </div>
      <div class="item">
        <div class="label">Frames</div>
        <div id="frameCount" class="value">0</div>
      </div>
      <div class="item">
        <div class="label">FPS</div>
        <div id="currentFps" class="value">0.0</div>
      </div>
      <div class="item">
        <div class="label">Upload</div>
        <div id="uploadMode" class="value">-</div>
      </div>
      <div class="item">
        <div class="label">Last Frame</div>
        <div id="lastFrameAt" class="value">-</div>
      </div>
      <div class="item">
        <div class="label">Viewers</div>
        <div id="streamClients" class="value">0</div>
      </div>
    </section>
  </main>
  <script>
    async function refreshState() {
      try {
        const response = await fetch("/esp32cam/state", { cache: "no-store" });
        const state = await response.json();
        const online = document.getElementById("online");
        const connection = document.getElementById("connection");
        online.textContent = state.online ? "Online" : "Offline";
        online.className = "value " + (state.online ? "online" : "offline");
        connection.textContent = state.online ? "Receiving frames" : "Waiting for frames";
        connection.className = state.online ? "online" : "offline";
        document.getElementById("frameCount").textContent = state.frameCount || 0;
        document.getElementById("currentFps").textContent = (Number(state.currentFps) || 0).toFixed(1);
        document.getElementById("uploadMode").textContent =
          state.uploadMode === "multipart-stream"
            ? "Stream " + (state.uploadClients || 0)
            : state.uploadMode === "single-frame"
              ? "Single"
              : "-";
        document.getElementById("lastFrameAt").textContent = state.lastFrameAt
          ? new Date(state.lastFrameAt).toLocaleString()
          : "-";
        document.getElementById("streamClients").textContent = state.streamClients || 0;
      } catch (error) {
        document.getElementById("connection").textContent = "State unavailable";
      }
    }

    refreshState();
    setInterval(refreshState, 2000);
  </script>
</body>
</html>`;
}

app.post(
  "/api/esp32cam/frame",
  express.raw({ type: "*/*", limit: "2mb" }),
  function (req, res) {
    if (!isEsp32camAuthorized(req)) {
      res.status(401).json({ code: 1, msg: "invalid stream key" });
      return;
    }

    if (!isEsp32camAcceptingFrames()) {
      res.status(409).json({ code: 1, msg: "ESP32-CAM monitoring is disabled" });
      return;
    }

    if (!Buffer.isBuffer(req.body) || req.body.length === 0) {
      res.status(400).json({ code: 1, msg: "empty frame body" });
      return;
    }

    const state = receiveEsp32camFrame(req.body, req, { uploadMode: "single-frame" });

    res.json({
      code: 0,
      msg: "frame received",
      data: state,
    });
  }
);

app.post("/api/esp32cam/stream", function (req, res) {
  if (!isEsp32camAuthorized(req)) {
    res.status(401).json({ code: 1, msg: "invalid stream key" });
    return;
  }

  if (!isEsp32camAcceptingFrames()) {
    res.status(409).json({ code: 1, msg: "ESP32-CAM monitoring is disabled" });
    return;
  }

  const boundary = getEsp32camMultipartBoundary(req);
  if (!boundary) {
    res.status(400).json({ code: 1, msg: "missing multipart boundary" });
    return;
  }

  req.socket.setNoDelay(true);
  req.socket.setTimeout(0);

  esp32camUploadClients.add(req);
  esp32camState.uploadMode = "multipart-stream";
  esp32camState.uploadClients = esp32camUploadClients.size;
  io.emit("esp32camState", getEsp32camState());

  res.writeHead(200, {
    "Content-Type": "text/plain; charset=utf-8",
    "Cache-Control": "no-cache, no-store, must-revalidate",
    "Connection": "keep-alive",
    "X-Accel-Buffering": "no",
  });
  res.write("stream accepted\n");

  createEsp32camStreamParser(req, boundary, function (frame) {
    receiveEsp32camFrame(frame, req, { uploadMode: "multipart-stream" });
  });

  let cleanedUp = false;
  function cleanup() {
    if (cleanedUp) {
      return;
    }
    cleanedUp = true;
    esp32camUploadClients.delete(req);
    esp32camState.uploadClients = esp32camUploadClients.size;
    if (esp32camUploadClients.size === 0 && esp32camState.uploadMode === "multipart-stream") {
      esp32camState.uploadMode = "";
    }
    io.emit("esp32camState", getEsp32camState());
    if (!res.writableEnded) {
      res.end();
    }
  }

  req.on("end", cleanup);
  req.on("close", cleanup);
  req.on("aborted", cleanup);
  req.on("error", cleanup);
});

app.get("/esp32cam/", function (req, res) {
  res.type("html").send(getEsp32camPageHtml());
});

app.get("/esp32cam", function (req, res) {
  res.redirect(301, "/esp32cam/");
});

app.get("/esp32cam/mjpeg", function (req, res) {
  if (!getEsp32camDesiredState().desiredEnabled) {
    res.status(409).type("text/plain").send("ESP32-CAM monitoring is disabled");
    return;
  }

  res.writeHead(200, {
    "Content-Type": `multipart/x-mixed-replace; boundary=${ESP32CAM_MJPEG_BOUNDARY}`,
    "Cache-Control": "no-cache, no-store, must-revalidate, no-transform",
    "Connection": "keep-alive",
    "X-Accel-Buffering": "no",
    "Pragma": "no-cache",
  });

  req.socket.setNoDelay(true);
  req.socket.setTimeout(0);
  if (typeof res.flushHeaders === "function") {
    res.flushHeaders();
  }

  esp32camClients.add(res);
  esp32camState.streamClients = esp32camClients.size;

  if (esp32camFrame) {
    writeEsp32camMjpegFrame(res, esp32camFrame);
  }

  req.on("close", function () {
    esp32camClients.delete(res);
    esp32camState.streamClients = esp32camClients.size;
  });
});

app.get("/esp32cam/jpg", function (req, res) {
  if (!esp32camFrame) {
    res.status(404).json({ code: 1, msg: "no frame received yet" });
    return;
  }

  res.set({
    "Content-Type": "image/jpeg",
    "Content-Length": esp32camFrame.length,
    "Cache-Control": "no-cache, no-store, must-revalidate",
  });
  res.end(esp32camFrame);
});

app.get("/esp32cam/state", function (req, res) {
  res.json(getEsp32camState());
});

app.get(["/api/device/camera/control", "/api/esp32cam/control"], function (req, res) {
  const desiredState = getEsp32camDesiredState();
  res.json({
    code: 0,
    data: {
      enabled: desiredState.desiredEnabled,
      controlEnabled: esp32camControl.enabled,
      desiredEnabled: desiredState.desiredEnabled,
      medicineRecording: desiredState.medicineRecording,
      activeSessionId: desiredState.activeSessionId,
      source: desiredState.source,
      updatedAt: desiredState.updatedAt,
    },
  });
});

app.post(["/api/device/camera/control", "/api/esp32cam/control"], function (req, res) {
  const enabled = parseEsp32camControlEnabled(
    req.body?.enabled ?? req.body?.controlEnabled ?? req.body?.desiredEnabled
  );

  if (enabled === null) {
    res.status(400).json({ code: 1, msg: "enabled must be true or false" });
    return;
  }

  const control = setEsp32camControl(enabled, req.body?.source || "web");
  res.json({
    code: 0,
    msg: control.enabled ? "ESP32-CAM enabled" : "ESP32-CAM disabled",
    data: getEsp32camState(),
  });
});

app.get("/", function (req, res) {
  res.send("Smart medicine box backend is running");
});

app.get("/api/auth/session", function (req, res) {
  const tokenData = verifyAuthToken(getBearerToken(req));
  if (!tokenData) {
    res.status(401).json({ code: 1, msg: "登录已失效，请重新登录" });
    return;
  }

  const user = readUsers().find((item) => item.account === tokenData.account);
  if (!user) {
    res.status(401).json({ code: 1, msg: "账号不存在，请重新登录" });
    return;
  }

  res.json({ code: 0, data: { user: createPublicUser(user) } });
});

app.post("/api/auth/register", function (req, res) {
  const account = String(req.body?.account || "").trim();
  const password = String(req.body?.password || "");

  if (!ACCOUNT_PATTERN.test(account)) {
    res.status(400).json({ code: 1, msg: "账号必须是 11 位数字" });
    return;
  }

  if (password.length < 6) {
    res.status(400).json({ code: 1, msg: "密码至少需要 6 位" });
    return;
  }

  const users = readUsers();
  if (users.some((user) => user.account === account)) {
    res.status(409).json({ code: 1, msg: "账号已存在，请直接登录" });
    return;
  }

  const now = new Date().toISOString();
  const passwordData = hashPassword(password);
  const user = {
    account,
    salt: passwordData.salt,
    passwordHash: passwordData.hash,
    createdAt: now,
    updatedAt: now,
  };

  users.push(user);
  writeUsers(users);

  const token = createAuthToken(user);
  res.json({
    code: 0,
    msg: "注册成功",
    data: {
      token,
      user: createPublicUser(user),
    },
  });
});

app.post("/api/auth/login", function (req, res) {
  const account = String(req.body?.account || "").trim();
  const password = String(req.body?.password || "");

  if (!ACCOUNT_PATTERN.test(account)) {
    res.status(400).json({ code: 1, msg: "账号必须是 11 位数字" });
    return;
  }

  if (password.length < 6) {
    res.status(400).json({ code: 1, msg: "密码至少需要 6 位" });
    return;
  }

  const user = readUsers().find((item) => item.account === account);
  if (!user || !verifyPassword(password, user)) {
    res.status(401).json({ code: 1, msg: "账号或密码错误" });
    return;
  }

  const token = createAuthToken(user);
  res.json({
    code: 0,
    msg: "登录成功",
    data: {
      token,
      user: createPublicUser(user),
    },
  });
});

app.get("/api/device/latest", function (req, res) {
  res.json(latestData);
});

app.get("/api/device/body-temperature/history", function (req, res) {
  res.json({
    code: 0,
    data: bodyTemperatureHistory,
  });
});

app.get("/api/device/heart-rate/history", function (req, res) {
  res.json({
    code: 0,
    data: heartRateHistory,
  });
});

app.get("/api/device/blood-oxygen/history", function (req, res) {
  res.json({
    code: 0,
    data: bloodOxygenHistory,
  });
});

app.get("/api/alarm/list", function (req, res) {
  res.json(alarms);
});

app.get("/api/user/profile", function (req, res) {
  res.json({ code: 0, data: getIdentityStatus() });
});

app.get("/api/app/settings", function (req, res) {
  res.json({ code: 0, data: appSettings });
});

app.post("/api/app/settings", function (req, res) {
  const nextSettings = normalizeAppSettings({
    ...appSettings,
    ...(req.body || {}),
  });

  if (nextSettings.familyPhone && !/^1[3-9]\d{9}$/.test(nextSettings.familyPhone)) {
    res.status(400).json({ code: 1, msg: "family phone format error" });
    return;
  }

  appSettings = writeAppSettings(nextSettings);
  medicineUpdatedAt = new Date().toISOString();

  const medicineConfig = getMedicineConfig();
  io.emit("appSettings", appSettings);
  io.emit("medicineConfig", medicineConfig);
  res.json({ code: 0, msg: "settings saved", data: medicineConfig });
});

app.post("/api/user/profile", function (req, res) {
  const name = String(req.body?.name || "").trim();
  const phone = String(req.body?.phone || "").trim();

  if (!name || name.length > 30 || /[|,\r\n]/.test(name) || !/^1[3-9]\d{9}$/.test(phone)) {
    res.status(400).json({ code: 1, msg: "姓名或手机号码格式不正确" });
    return;
  }

  const identityChanged = medicinePatient.name && medicinePatient.name !== name;
  medicinePatient = { name, phone };
  medicineUpdatedAt = new Date().toISOString();

  if (identityChanged && faceIdentity.registeredName !== name) {
    updateFaceIdentity({
      registered: false,
      registrationState: "unregistered",
      message: "用户已变更，请重新注册人脸",
    });
  } else {
    io.emit("identityData", getIdentityStatus());
  }

  io.emit("medicineConfig", getMedicineConfig());
  res.json({ code: 0, msg: "用户信息已保存", data: getIdentityStatus() });
});

app.post("/api/face/register", function (req, res) {
  const password = String(req.body?.password || "");

  if (isFaceOperationBusy()) {
    res.status(409).json({ code: 1, msg: "K230 正在处理上一项人脸操作，请稍后再试" });
    return;
  }

  if (!medicinePatient.name || !/^1[3-9]\d{9}$/.test(medicinePatient.phone)) {
    res.status(400).json({ code: 1, msg: "请先保存完整的用户信息" });
    return;
  }

  if (!password || password.length > 64 || /[\r\n]/.test(password)) {
    res.status(400).json({ code: 1, msg: "请输入有效的 K230 编辑密码" });
    return;
  }

  pendingFacePassword = password;
  pendingFaceOperation = { type: "register", targetName: medicinePatient.name };
  faceRegistrationExpiresAt = Date.now() + 2 * 60 * 1000;
  k230CommandQueue = [];
  enqueueK230PasswordAuth();
  updateFaceIdentity({
    registrationState: "waiting_device",
    message: "注册请求已发送，等待 K230 响应",
  });

  res.status(202).json({ code: 0, msg: "注册请求已发送", data: getIdentityStatus() });
});

app.get("/api/face/users", function (req, res) {
  res.json({ code: 0, data: { users: faceUsers, status: getIdentityStatus() } });
});

app.post("/api/face/users/refresh", function (req, res) {
  const password = String(req.body?.password || "");

  if (isFaceOperationBusy()) {
    res.status(409).json({ code: 1, msg: "K230 正在处理上一项人脸操作，请稍后再试" });
    return;
  }

  if (password && (password.length > 64 || /[\r\n]/.test(password))) {
    res.status(400).json({ code: 1, msg: "请输入有效的 K230 编辑密码" });
    return;
  }

  pendingFacePassword = password;
  pendingFaceOperation = { type: "list", authComplete: !password };
  faceRegistrationExpiresAt = Date.now() + 60 * 1000;
  k230CommandQueue = [];
  if (password) {
    enqueueK230PasswordAuth();
  } else {
    enqueueK230Command("USER:LIST");
  }
  updateFaceIdentity({
    registrationState: password ? "waiting_device" : "loading_faces",
    message: password ? "刷新名单请求已发送，等待 K230 校验密码" : "正在从 K230 读取已注册人脸",
  });

  res.status(202).json({ code: 0, msg: "人脸名单刷新请求已发送", data: getIdentityStatus() });
});

app.post("/api/face/users/delete", function (req, res) {
  const name = sanitizeFaceName(req.body?.name);
  const password = String(req.body?.password || "");

  if (isFaceOperationBusy()) {
    res.status(409).json({ code: 1, msg: "K230 正在处理上一项人脸操作，请稍后再试" });
    return;
  }

  if (!name || name.length > 48 || /[\r\n|]/.test(name)) {
    res.status(400).json({ code: 1, msg: "请选择有效的人脸用户" });
    return;
  }

  if (!password || password.length > 64 || /[\r\n]/.test(password)) {
    res.status(400).json({ code: 1, msg: "请输入有效的 K230 编辑密码" });
    return;
  }

  pendingFacePassword = password;
  pendingFaceOperation = { type: "delete", targetName: name };
  faceRegistrationExpiresAt = Date.now() + 60 * 1000;
  k230CommandQueue = [];
  enqueueK230PasswordAuth();
  updateFaceIdentity({
    registrationState: "waiting_device",
    message: `删除 ${name} 的请求已发送，等待 K230 响应`,
  });

  res.status(202).json({ code: 0, msg: "删除请求已发送", data: getIdentityStatus() });
});

// 星火开发板轮询该接口，并把 command 原样通过 UART3 发送给 K230。
app.get("/api/device/k230/command", function (req, res) {
  k230DeviceLastSeen = Date.now();
  const command = k230CommandQueue.shift() || null;
  res.json({ code: 0, data: command });
});

// 星火开发板将 K230 返回的一整行文本提交到该接口。
app.post("/api/device/k230/result", function (req, res) {
  const line = String(req.body?.line || "").trim();
  k230DeviceLastSeen = Date.now();

  if (!line || line.length > 2048 || /[\r\n]/.test(line)) {
    res.status(400).json({ code: 1, msg: "K230 返回内容格式不正确" });
    return;
  }

  try {
    const event = JSON.parse(line);
    recordMedicineTaken(event, "k230_result");
  } catch (error) {
    // Non-JSON K230 protocol lines are handled below.
  }

  if (line === "EDIT:INPUT_PASSWORD") {
    if (!pendingFacePassword) {
      finishFaceRegistration(false, "failed", "注册请求已失效，请重新操作");
    } else {
      enqueueK230Command(pendingFacePassword);
      updateFaceIdentity({
        registrationState: "authenticating",
        message: "正在校验 K230 密码",
      });
    }
  } else if (line === "EDIT:AUTH_OK" || line === "EDIT:ALREADY") {
    if (!pendingFaceOperation || pendingFaceOperation.authComplete) {
      res.json({ code: 0, msg: "ok", data: getIdentityStatus() });
      return;
    }

    pendingFaceOperation.authComplete = true;
    if (pendingFaceOperation.type === "delete") {
      enqueueK230Command(`USER:DEL|${pendingFaceOperation.targetName}`);
      updateFaceIdentity({
        registrationState: "deleting_face",
        message: `正在删除 ${pendingFaceOperation.targetName} 的人脸信息`,
      });
    } else if (pendingFaceOperation.type === "register") {
      pendingFaceOperation.registerCommandSent = true;
      enqueueK230Command(`USER:REGISTER|${pendingFaceOperation.targetName}`);
      updateFaceIdentity({
        registrationState: "registering",
        message: "请正对 K230 摄像头，正在采集人脸",
      });
    } else {
      enqueueK230Command("USER:LIST");
      updateFaceIdentity({ registrationState: "checking", message: "正在查询人脸注册状态" });
    }
  } else if (line === "EDIT:PASSWORD_FAIL") {
    const message =
      pendingFaceOperation?.type === "delete"
        ? "密码错误，未删除人脸信息"
        : pendingFaceOperation?.type === "list"
        ? "密码错误，未能刷新人脸名单"
        : "密码错误，未能进入 K230 编辑模式";
    clearPendingFaceOperation();
    updateFaceIdentity({ registrationState: "failed", message });
    enqueueK230Command("MODE:NORMAL");
  } else if (line.startsWith("USER:LIST:OK:")) {
    const names = line.slice("USER:LIST:OK:".length).split(",").map((item) => item.trim()).filter(Boolean);
    faceUsers = Array.from(new Set(names));
    if (pendingFaceOperation?.type === "list") {
      clearPendingFaceOperation();
      const currentUserRegistered = medicinePatient.name ? faceUsers.includes(medicinePatient.name) : false;
      updateFaceIdentity({
        registered: currentUserRegistered,
        registeredName: currentUserRegistered ? medicinePatient.name : "",
        registrationState: currentUserRegistered ? "registered" : "unregistered",
        message: "人脸名单已更新",
      });
    } else if (pendingFaceOperation?.type === "register") {
      const targetName = pendingFaceOperation.targetName || medicinePatient.name;
      if (names.includes(targetName)) {
        finishFaceRegistration(true, "registered", "人脸注册成功", targetName);
      } else if (pendingFaceOperation.registerCommandSent) {
        finishFaceRegistration(false, "failed", "未在 K230 名单中确认到该人脸，请重新注册");
      } else {
        pendingFaceOperation.registerCommandSent = true;
        enqueueK230Command(`USER:REGISTER|${targetName}`);
        updateFaceIdentity({ registrationState: "registering", message: "请正对 K230 摄像头，正在采集人脸" });
      }
    } else {
      const currentUserRegistered = medicinePatient.name ? faceUsers.includes(medicinePatient.name) : false;
      updateFaceIdentity({
        registered: currentUserRegistered,
        registeredName: currentUserRegistered ? medicinePatient.name : "",
        message: "人脸名单已更新",
      });
    }
  } else if (line.startsWith("USER:REGISTER:OK:")) {
    const registeredName = line.slice("USER:REGISTER:OK:".length).trim() || medicinePatient.name;
    if (registeredName && !faceUsers.includes(registeredName)) {
      faceUsers.push(registeredName);
    }
    finishFaceRegistration(true, "registered", "人脸注册成功", registeredName);
  } else if (line.startsWith("USER:REGISTER:WAIT:")) {
    scheduleFaceRegisterVerification();
    updateFaceIdentity({
      registrationState: "registering",
      message: "请正对 K230 摄像头，正在采集人脸",
    });
  } else if (line.startsWith("USER:REGISTER:ERR:") || line === "USER:ERR:unknown_cmd") {
    const detail = line.startsWith("USER:REGISTER:ERR:")
      ? line.slice("USER:REGISTER:ERR:".length)
      : "K230 固件暂不支持网页注册命令";
    finishFaceRegistration(false, "failed", `人脸注册失败：${detail}`);
  } else if (line.startsWith("USER:DEL:OK:")) {
    const deletedName = line.slice("USER:DEL:OK:".length).trim() || pendingFaceOperation?.targetName || "";
    faceUsers = faceUsers.filter((name) => name !== deletedName);
    const currentUserRegistered = medicinePatient.name ? faceUsers.includes(medicinePatient.name) : false;
    clearPendingFaceOperation();
    updateFaceIdentity({
      registered: currentUserRegistered,
      registeredName: currentUserRegistered ? medicinePatient.name : "",
      registrationState: currentUserRegistered ? "registered" : "unregistered",
      message: `已删除 ${deletedName} 的人脸信息`,
    });
    enqueueK230Command("MODE:NORMAL");
  } else if (line.startsWith("USER:DEL:ERR:")) {
    const detail = line.slice("USER:DEL:ERR:".length).trim() || "unknown";
    clearPendingFaceOperation();
    updateFaceIdentity({
      registrationState: "failed",
      message: `删除人脸失败：${detail}`,
    });
    enqueueK230Command("MODE:NORMAL");
  }

  res.json({ code: 0, msg: "ok", data: getIdentityStatus() });
});

app.get("/api/medicine/plans", function (req, res) {
  res.json({
    code: 0,
    data: getMedicineConfig(),
  });
});

app.get("/api/medicine/boxes", function (req, res) {
  res.json({ code: 0, data: medicineBoxes });
});

app.get("/api/medicine/put-records", function (req, res) {
  res.json({ code: 0, data: medicinePutRecords });
});

app.get("/api/medicine/taken", function (req, res) {
  res.json({ code: 0, data: medicineTakenRecords });
});

app.get("/api/device/medicine-taken-status", function (req, res) {
  res.json({
    code: 0,
    data: getMedicineTakenStatus(req.query.date),
  });
});

app.post("/api/medicine/taken", function (req, res) {
  const event = recordMedicineTaken(req.body || {}, "medicine_taken_api");

  if (!event) {
    res.status(400).json({ code: 1, msg: "medicine taken payload format error" });
    return;
  }

  res.json({ code: 0, msg: "medicine taken recorded", data: event });
});

app.get("/api/medicine/library", function (req, res) {
  const keyword = String(req.query.keyword || "").trim().toLowerCase();
  let library = readMedicineLibrary();

  if (keyword) {
    library = library.filter(function (item) {
      const haystack = [
        item.name,
        item.genericName,
        item.category,
        item.summary,
        ...item.aliases,
      ]
        .join(" ")
        .toLowerCase();
      return haystack.includes(keyword);
    });
  }

  res.json({ code: 0, data: library });
});

app.post("/api/medicine/library/ai-search", async function (req, res) {
  const name = String(req.body?.name || "").trim();

  if (!name) {
    res.status(400).json({ code: 1, msg: "请输入药品名称" });
    return;
  }

  try {
    const draft = await createMedicineDraftWithAI(name);
    res.json({
      code: 0,
      msg: "AI 检索完成，请核对后保存",
      data: {
        ...draft,
        id: "",
        createdAt: "",
        updatedAt: "",
      },
    });
  } catch (error) {
    console.error("AI 药品检索失败：", error);
    res.status(error.statusCode || 500).json({
      code: 1,
      msg: error.message || "AI 检索失败，请稍后重试，也可以手动填写药品信息",
    });
  }
});

app.post("/api/medicine/library", function (req, res) {
  const item = normalizeMedicineLibraryItem(req.body || {});

  if (!item.name) {
    res.status(400).json({ code: 1, msg: "药品名称不能为空" });
    return;
  }

  const library = readMedicineLibrary();
  const duplicated = library.some(
    (existing) => existing.name.trim().toLowerCase() === item.name.trim().toLowerCase()
  );

  if (duplicated) {
    res.status(409).json({ code: 1, msg: "药品库中已存在同名药品，请打开原卡片进行编辑" });
    return;
  }

  const now = new Date().toISOString();
  const saved = {
    ...item,
    id: createMedicineLibraryId(),
    createdAt: now,
    updatedAt: now,
  };

  library.unshift(saved);
  writeMedicineLibrary(library);
  io.emit("medicineLibrary", library);
  res.status(201).json({ code: 0, msg: "药品已保存", data: saved });
});

app.get("/api/medicine/library/:id", function (req, res) {
  const item = readMedicineLibrary().find((medicine) => medicine.id === req.params.id);

  if (!item) {
    res.status(404).json({ code: 1, msg: "未找到该药品" });
    return;
  }

  res.json({ code: 0, data: item });
});

app.put("/api/medicine/library/:id", function (req, res) {
  const library = readMedicineLibrary();
  const index = library.findIndex((medicine) => medicine.id === req.params.id);

  if (index < 0) {
    res.status(404).json({ code: 1, msg: "未找到该药品" });
    return;
  }

  const item = normalizeMedicineLibraryItem({
    ...req.body,
    id: req.params.id,
    createdAt: library[index].createdAt,
    updatedAt: new Date().toISOString(),
  });

  if (!item.name) {
    res.status(400).json({ code: 1, msg: "药品名称不能为空" });
    return;
  }

  const duplicated = library.some(
    (existing) =>
      existing.id !== req.params.id &&
      existing.name.trim().toLowerCase() === item.name.trim().toLowerCase()
  );

  if (duplicated) {
    res.status(409).json({ code: 1, msg: "药品库中已存在同名药品" });
    return;
  }

  library[index] = item;
  writeMedicineLibrary(library);
  io.emit("medicineLibrary", library);
  res.json({ code: 0, msg: "药品信息已更新", data: item });
});

app.delete("/api/medicine/library/:id", function (req, res) {
  const library = readMedicineLibrary();
  const nextLibrary = library.filter((medicine) => medicine.id !== req.params.id);

  if (nextLibrary.length === library.length) {
    res.status(404).json({ code: 1, msg: "未找到该药品" });
    return;
  }

  writeMedicineLibrary(nextLibrary);
  io.emit("medicineLibrary", nextLibrary);
  res.json({ code: 0, msg: "药品已删除", data: nextLibrary });
});

app.get("/api/medicine/videos", function (req, res) {
  pruneExpiredMedicineVideoSessions(true);
  res.json({ code: 0, data: medicineVideoSessions });
});

app.get("/api/medicine/videos/:id", function (req, res) {
  const session = findMedicineVideoSession(req.params.id);
  if (!session) {
    res.status(404).json({ code: 1, msg: "medicine video session not found" });
    return;
  }
  res.json({ code: 0, data: session });
});

app.delete("/api/medicine/videos/:id", function (req, res) {
  const result = deleteMedicineVideoSession(req.params.id);
  if (!result) {
    res.status(404).json({ code: 1, msg: "medicine video session not found" });
    return;
  }

  if (result.busy) {
    res.status(409).json({ code: 1, msg: "录像正在录制中，请结束后再删除" });
    return;
  }

  res.json({
    code: 0,
    msg: "用药录像已删除",
    data: medicineVideoSessions,
  });
});

app.post("/api/medicine/videos/start", function (req, res) {
  const session = createVideoSessionFromMetadata(req.body || {}, "web_or_device_start");
  res.status(201).json({
    code: 0,
    msg: "medicine video session started",
    data: session,
  });
});

app.post(
  "/api/medicine/videos/:id/frames",
  express.raw({ type: ["image/jpeg", "application/octet-stream"], limit: "8mb" }),
  function (req, res) {
    saveMedicineVideoFrame(req, res, req.params.id);
  }
);

app.post("/api/medicine/videos/:id/finish", function (req, res) {
  const session = finishVideoSession(req.params.id, req.body || {});
  if (!session) {
    res.status(404).json({ code: 1, msg: "medicine video session not found" });
    return;
  }
  res.json({ code: 0, msg: "medicine video session finished", data: session });
});

app.post(
  "/api/medicine/videos/upload",
  express.raw({ type: ["video/*", "application/octet-stream", "multipart/x-mixed-replace"], limit: "200mb" }),
  function (req, res) {
    if (!Buffer.isBuffer(req.body) || req.body.length === 0) {
      res.status(400).json({ code: 1, msg: "empty video body" });
      return;
    }

    const id = createMedicineVideoId();
    const contentType = String(req.headers["content-type"] || "application/octet-stream").split(";")[0];
    const originalName = req.headers["x-file-name"] || "";
    const extension = getVideoExtension(contentType, originalName);
    const fileName = sanitizeVideoFileName(originalName, `${id}${extension || ".mjpeg"}`);
    const safeFileName = fileName.includes(".") ? fileName : `${fileName}${extension || ".mjpeg"}`;
    const filePath = path.join(MEDICINE_VIDEO_DIR, safeFileName);
    fs.writeFileSync(filePath, req.body);

    const startedAt = req.headers["x-started-at"] || new Date().toISOString();
    const endedAt = req.headers["x-ended-at"] || new Date().toISOString();
    const startedAtMs = Date.parse(startedAt);
    const endedAtMs = Date.parse(endedAt);
    const durationSeconds =
      Number.isFinite(startedAtMs) && Number.isFinite(endedAtMs)
        ? Math.max(0, Math.round((endedAtMs - startedAtMs) / 1000))
        : 0;
    const dateKey = normalizeDateKey(req.headers["x-date"] || String(startedAt).slice(0, 10));
    const time = normalizeClockTime(req.headers["x-time"] || startedAt);

    const session = normalizeVideoSession({
      id,
      title: req.headers["x-title"] || `用药录像 ${dateKey} ${time}`,
      status: "completed",
      source: "raw_video_upload",
      planSlot: parsePositiveInteger(req.headers["x-plan-slot"], null),
      dateKey,
      time,
      startedAt,
      endedAt,
      uploadedAt: new Date().toISOString(),
      durationSeconds,
      contentType,
      fileName: safeFileName,
      videoUrl: getPublicMedicineVideoUrl(safeFileName),
      thumbnailUrl: "",
      frames: [],
      size: req.body.length,
    });

    pushMedicineVideoSession(session);
    res.status(201).json({ code: 0, msg: "video uploaded", data: session });
  }
);

app.post("/api/device/camera/session/start", function (req, res) {
  const session = createVideoSessionFromMetadata(req.body || {}, "esp32_camera");
  res.status(201).json({ code: 0, data: session });
});

app.post(
  "/api/device/camera/session/:id/frame",
  express.raw({ type: ["image/jpeg", "application/octet-stream"], limit: "8mb" }),
  function (req, res) {
    saveMedicineVideoFrame(req, res, req.params.id);
  }
);

app.post("/api/device/camera/session/:id/finish", function (req, res) {
  const session = finishVideoSession(req.params.id, req.body || {});
  if (!session) {
    res.status(404).json({ code: 1, msg: "medicine video session not found" });
    return;
  }
  res.json({ code: 0, data: session });
});

app.post("/api/device/camera/medicine-recording/start", function (req, res) {
  const activeSession = activeMedicineCameraSessionId
    ? findMedicineVideoSession(activeMedicineCameraSessionId)
    : null;

  if (activeSession && activeSession.status === "recording") {
    res.json({ code: 0, data: activeSession });
    return;
  }

  const session = createVideoSessionFromMetadata(
    {
      ...(req.body || {}),
      title: req.body?.title || "用药过程录像",
    },
    "spark_medicine_auto_record"
  );
  activeMedicineCameraSessionId = session.id;
  io.emit("esp32camState", getEsp32camState());
  res.status(201).json({ code: 0, data: session });
});

app.post("/api/device/camera/medicine-recording/finish", function (req, res) {
  if (!activeMedicineCameraSessionId) {
    res.json({ code: 0, data: null });
    return;
  }

  const session = finishVideoSession(activeMedicineCameraSessionId, req.body || {});
  activeMedicineCameraSessionId = "";
  if (!session) {
    res.status(404).json({ code: 1, msg: "medicine video session not found" });
    return;
  }
  io.emit("esp32camState", getEsp32camState());
  res.json({ code: 0, data: session });
});


app.get("/api/device/put-medicine-context", function (req, res) {
  const context = getPutMedicineTasks();
  res.json({
    code: 0,
    data: {
      patient: medicinePatient,
      mode: "refill",
      status: context.tasks.length > 0 ? "ready" : "no_low_stock",
      speech: context.tasks.length > 0 ? "\u8bf7\u6309\u63d0\u793a\u9010\u4e2a\u6253\u5f00\u4f4e\u5e93\u5b58\u836f\u4ed3\u8865\u836f" : "\u5f53\u524d\u6ca1\u6709\u4f4e\u4e8e\u9608\u503c\u7684\u836f\u4ed3\uff0c\u65e0\u9700\u8865\u836f",
      boxes: context.boxes,
      tasks: context.tasks,
      updatedAt: medicineUpdatedAt,
    },
  });
});

app.post("/api/device/put-medicine-done", function (req, res) {
  const event = recordMedicinePut(req.body || {}, "device_put_api");
  if (!event) {
    res.status(400).json({ code: 1, msg: "medicine put payload format error" });
    return;
  }
  res.json({ code: 0, msg: "medicine put recorded", data: event });
});

app.post("/api/medicine/put", function (req, res) {
  const event = recordMedicinePut(req.body || {}, "medicine_put_api");
  if (!event) {
    res.status(400).json({ code: 1, msg: "medicine put payload format error" });
    return;
  }
  res.json({ code: 0, msg: "medicine put recorded", data: event });
});

app.post("/api/medicine/boxes", function (req, res) {
  const boxes = req.body?.boxes || req.body;

  if (!Array.isArray(boxes) || boxes.length !== 6) {
    res.status(400).json({ code: 1, msg: "必须提交 6 个药仓的信息" });
    return;
  }

  const invalidBox = boxes.some(function (box) {
    const quantity = Number(box.quantity);
    const lowThreshold = Number(box.lowThreshold ?? box.minThreshold ?? box.threshold);
    return (
      (box.name && (!Number.isInteger(quantity) || quantity < 0)) ||
      (box.name && (!Number.isInteger(lowThreshold) || lowThreshold < 0))
    );
  });

  if (invalidBox) {
    res.status(400).json({ code: 1, msg: "药仓剩余药量或低库存阈值格式不正确" });
    return;
  }

  const previousBoxes = medicineBoxes;
  medicineBoxes = normalizeMedicineBoxes(boxes);
  medicineUpdatedAt = new Date().toISOString();
  const putRecords = [];

  medicineBoxes.forEach(function (box, index) {
    const previousBox = previousBoxes[index] || {};
    const before = Number(previousBox.quantity) || 0;
    const after = Number(box.quantity) || 0;
    const putCount = after - before;

    if (box.name && putCount > 0) {
      const record = appendMedicinePutRecord({
        boxId: box.id,
        boxName: box.title,
        medicineId: box.medicineId || "",
        medicineName: box.name,
        putCount,
        after,
        source: "web_box_save",
      });
      if (record) {
        putRecords.push(record);
      }
    }
  });

  const medicineConfig = getMedicineConfig();

  io.emit("medicineConfig", medicineConfig);
  io.emit("medicineBoxes", medicineBoxes);
  res.json({ code: 0, msg: "medicine boxes saved", data: { ...medicineConfig, putRecords } });
});

// 开发板既可以通过该接口主动拉取，也可以监听 medicineConfig 事件实时接收。
app.get("/api/device/medicine-config", function (req, res) {
  res.json({
    code: 0,
    data: getMedicineConfig(),
  });
});

app.get("/api/device/medicine-plans", function (req, res) {
  res.json({
    code: 0,
    data: getMedicineConfig(),
  });
});

app.post("/api/medicine/plans", function (req, res) {
  const data = req.body || {};
  const isLegacyPayload = Array.isArray(data);
  const plans = isLegacyPayload ? data : data.plans;

  if (!Array.isArray(plans)) {
    res.status(400).json({
      code: 1,
      msg: "medicine plans format error",
    });
    return;
  }

  const timeError = validateMedicineTimes(plans);

  if (timeError) {
    res.status(400).json({ code: 1, msg: timeError });
    return;
  }

  if (!isLegacyPayload) {
    const invalidMedicine = plans.some(function (plan) {
      if (!Array.isArray(plan.medicines)) {
        return true;
      }

      return plan.medicines.some(function (medicine) {
        const boxId = Number(medicine.boxId);
        const doseCount = Number(medicine.doseCount);
        return (
          !Number.isInteger(boxId) ||
          boxId < 1 ||
          !medicine.name ||
          !Number.isInteger(doseCount) ||
          doseCount < 1 ||
          doseCount > 99
        );
      });
    });

    if (invalidMedicine) {
      res.status(400).json({ code: 1, msg: "药仓、药品或单次剂量格式不正确" });
      return;
    }
  }

  medicinePlans = normalizeMedicinePlans(plans);
  medicineUpdatedAt = new Date().toISOString();
  const medicineConfig = getMedicineConfig();

  console.log("收到网页设置的用药配置：", medicineConfig);

  io.emit("medicineConfig", medicineConfig);
  // 保留旧事件，避免已部署的旧版开发板立即失效。
  io.emit("medicinePlans", medicinePlans);

  res.json({
    code: 0,
    msg: "medicine plans saved",
    data: medicineConfig,
  });
});

app.post("/api/device/upload", function (req, res) {
  const data = req.body;
  const medicineTakenEvent = recordMedicineTaken(data, "device_upload");

  const temperature = isValidNumber(data.temperature)
    ? Number(data.temperature)
    : latestData.temperature;

  const humidity = isValidNumber(data.humidity)
    ? Number(data.humidity)
    : latestData.humidity;

  const hasBodyTemperature = isValidBodyTemperature(data.bodyTemperature);
  const bodyTemperatureRaw = hasBodyTemperature
    ? Number(data.bodyTemperature)
    : latestData.bodyTemperature;

  const hasHeartRate = isValidNumber(data.heartRate);
  const heartRateRaw = hasHeartRate
    ? Number(data.heartRate)
    : latestData.heartRate;

  const bloodOxygenValue =
    data.bloodOxygen ?? data.spo2 ?? data.SpO2 ?? data.blood_oxygen;
  const hasBloodOxygen = isValidNumber(bloodOxygenValue);
  const bloodOxygenRaw = hasBloodOxygen
    ? Number(bloodOxygenValue)
    : latestData.bloodOxygen;

  latestData = {
    temperature: temperature,
    humidity: humidity,
    bodyTemperature: bodyTemperatureRaw,
    heartRate: heartRateRaw,
    bloodOxygen: bloodOxygenRaw,
    date: data.date || latestData.date || "",
    time: data.time || new Date().toLocaleTimeString(),
    online: true,
    riskLevel: "正常",
  };

  latestData.riskLevel = checkEnvRisk(latestData);

  if (hasBodyTemperature) {
    pushHistory(
      bodyTemperatureHistory,
      {
        value: Number(data.bodyTemperature),
        date: latestData.date,
        time: latestData.time,
        timestamp: Date.now(),
      },
      20
    );

    checkBodyRisk(Number(data.bodyTemperature));
  }

  if (hasHeartRate) {
    pushHistory(
      heartRateHistory,
      {
        value: Number(data.heartRate),
        date: latestData.date,
        time: latestData.time,
        timestamp: Date.now(),
      },
      20
    );
  }

  if (hasBloodOxygen) {
    pushHistory(
      bloodOxygenHistory,
      {
        value: Number(bloodOxygenValue),
        date: latestData.date,
        time: latestData.time,
        timestamp: Date.now(),
      },
      20
    );
  }

  console.log("收到药盒数据：", latestData);

  io.emit("deviceData", latestData);
  io.emit("bodyTemperatureHistory", bodyTemperatureHistory);
  io.emit("heartRateHistory", heartRateHistory);
  io.emit("bloodOxygenHistory", bloodOxygenHistory);
  io.emit("alarmData", alarms);

  res.json({
    code: 0,
    msg: "ok",
    riskLevel: latestData.riskLevel,
    medicineTaken: medicineTakenEvent,
  });
});

io.on("connection", function (socket) {
  console.log("网页已连接 WebSocket");

  socket.emit("deviceData", latestData);
  socket.emit("bodyTemperatureHistory", bodyTemperatureHistory);
  socket.emit("heartRateHistory", heartRateHistory);
  socket.emit("bloodOxygenHistory", bloodOxygenHistory);
  socket.emit("alarmData", alarms);
  socket.emit("medicineConfig", getMedicineConfig());
  socket.emit("medicinePlans", medicinePlans);
  socket.emit("medicineTakenRecords", medicineTakenRecords);
  socket.emit("medicinePutRecords", medicinePutRecords);
  socket.emit("medicineLibrary", readMedicineLibrary());
  socket.emit("identityData", getIdentityStatus());
});

const PORT = Number(process.env.PORT) || 3000;
server.requestTimeout = 0;
server.timeout = 0;
server.listen(PORT, "0.0.0.0", function () {
  pruneExpiredMedicineVideoSessions(false);
  setInterval(function () {
    pruneExpiredMedicineVideoSessions(true);
  }, 60 * 60 * 1000);
  console.log(`智能药盒后端运行：http://127.0.0.1:${PORT}`);
});

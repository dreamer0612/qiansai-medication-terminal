#ifndef _APPLICATION_H_
#define _APPLICATION_H_

#include <freertos/FreeRTOS.h>
#include <freertos/event_groups.h>
#include <freertos/task.h>
#include <esp_timer.h>

#include <string>
#include <mutex>
#include <deque>
#include <memory>
#include <vector>
#include <atomic>
#include <cstdint>
#include <cJSON.h>

#include "protocol.h"
#include "ota.h"
#include "audio_service.h"
#include "device_state.h"
#include "device_state_machine.h"

// Main event bits
#define MAIN_EVENT_SCHEDULE             (1 << 0)
#define MAIN_EVENT_SEND_AUDIO           (1 << 1)
#define MAIN_EVENT_WAKE_WORD_DETECTED   (1 << 2)
#define MAIN_EVENT_VAD_CHANGE           (1 << 3)
#define MAIN_EVENT_ERROR                (1 << 4)
#define MAIN_EVENT_ACTIVATION_DONE      (1 << 5)
#define MAIN_EVENT_CLOCK_TICK           (1 << 6)
#define MAIN_EVENT_NETWORK_CONNECTED    (1 << 7)
#define MAIN_EVENT_NETWORK_DISCONNECTED (1 << 8)
#define MAIN_EVENT_TOGGLE_CHAT          (1 << 9)
#define MAIN_EVENT_START_LISTENING      (1 << 10)
#define MAIN_EVENT_STOP_LISTENING       (1 << 11)
#define MAIN_EVENT_STATE_CHANGED        (1 << 12)


enum AecMode {
    kAecOff,
    kAecOnDeviceSide,
    kAecOnServerSide,
};

class Application {
public:
    static Application& GetInstance() {
        static Application instance;
        return instance;
    }
    // Delete copy constructor and assignment operator
    Application(const Application&) = delete;
    Application& operator=(const Application&) = delete;

    /**
     * Initialize the application
     * This sets up display, audio, network callbacks, etc.
     * Network connection starts asynchronously.
     */
    void Initialize();

    /**
     * Run the main event loop
     * This function runs in the main task and never returns.
     * It handles all events including network, state changes, and user interactions.
     */
    void Run();

    DeviceState GetDeviceState() const { return state_machine_.GetState(); }
    bool IsVoiceDetected() const { return audio_service_.IsVoiceDetected(); }
    
    /**
     * Request state transition
     * Returns true if transition was successful
     */
    bool SetDeviceState(DeviceState state);

    /**
     * Schedule a callback to be executed in the main task
     */
    void Schedule(std::function<void()>&& callback);

    /**
     * Alert with status, message, emotion and optional sound
     */
    void Alert(const char* status, const char* message, const char* emotion = "", const std::string_view& sound = "");
    void DismissAlert();

    void AbortSpeaking(AbortReason reason);

    /**
     * Toggle chat state (event-based, thread-safe)
     * Sends MAIN_EVENT_TOGGLE_CHAT to be handled in Run()
     */
    void ToggleChatState();

    /**
     * Start listening (event-based, thread-safe)
     * Sends MAIN_EVENT_START_LISTENING to be handled in Run()
     */
    void StartListening();

    /**
     * Stop listening (event-based, thread-safe)
     * Sends MAIN_EVENT_STOP_LISTENING to be handled in Run()
     */
    void StopListening();

    void Reboot();
    void WakeWordInvoke(const std::string& wake_word);
    bool UpgradeFirmware(const std::string& url, const std::string& version = "");
    bool CanEnterSleepMode();
    void SendMcpMessage(const std::string& payload);
    void SetAecMode(AecMode mode);
    AecMode GetAecMode() const { return aec_mode_; }
    void PlaySound(const std::string_view& sound);
    AudioService& GetAudioService() { return audio_service_; }
    bool SendMedicineFlowAcknowledgement(const std::string& command, int plan_slot = 0);
    bool SendMedicineOpenRequest(int plan_slot, int box_id);
    bool SendMedicineTakenDone(int plan_slot = 0, int box_id = 0);
    cJSON* AuthenticateMedicineUser(int plan_slot = 0);
    cJSON* StartMedicineFaceAuthentication();
    cJSON* OpenMedicineAfterUserReady();
    cJSON* ConfirmCurrentMedicineTaken();
    cJSON* StartPutMedicine(int plan_slot = 0);
    cJSON* StartPutFaceAuthentication();
    cJSON* OpenMedicineForPutAfterUserReady();
    cJSON* ConfirmCurrentMedicinePut(int put_count);
    cJSON* MeasureHeartSpo2();
    cJSON* GetLastHeartSpo2Result();
    cJSON* MeasureBodyTemperature();
    cJSON* GetLastBodyTemperatureResult();
    void ResetMedicineSession();
    
    /**
     * Reset protocol resources (thread-safe)
     * Can be called from any task to release resources allocated after network connected
     * This includes closing audio channel, resetting protocol and ota objects
     */
    void ResetProtocol();

private:
    Application();
    ~Application();

    std::mutex mutex_;
    std::deque<std::function<void()>> main_tasks_;
    std::unique_ptr<Protocol> protocol_;
    EventGroupHandle_t event_group_ = nullptr;
    esp_timer_handle_t clock_timer_handle_ = nullptr;
    DeviceStateMachine state_machine_;
    ListeningMode listening_mode_ = kListeningModeAutoStop;
    AecMode aec_mode_ = kAecOff;
    std::string last_error_message_;
    AudioService audio_service_;
    std::unique_ptr<Ota> ota_;

    bool has_server_time_ = false;
    bool aborted_ = false;
    bool assets_version_checked_ = false;
    bool play_popup_on_listening_ = false;  // Flag to play popup sound after state changes to listening
    bool proactive_reminder_active_ = false;
    bool proactive_reminder_waiting_greeting_tts_ = false;
    bool proactive_reminder_send_after_greeting_stop_ = false;
    bool proactive_reminder_text_sent_ = false;
    bool proactive_reminder_tts_started_ = false;
    int proactive_reminder_text_send_attempts_ = 0;
    std::string proactive_reminder_text_;
    std::atomic_bool medicine_reminder_loop_active_{false};
    std::atomic<uint32_t> medicine_reminder_loop_generation_{0};
    std::atomic_bool vitals_measurement_in_progress_{false};
    bool last_vitals_result_valid_ = false;
    int last_vitals_heart_rate_ = 0;
    int last_vitals_spo2_ = 0;
    int64_t last_vitals_result_time_us_ = 0;
    std::atomic_bool body_temperature_measurement_in_progress_{false};
    bool last_body_temperature_result_valid_ = false;
    double last_body_temperature_ = 0.0;
    int64_t last_body_temperature_result_time_us_ = 0;
    int clock_ticks_ = 0;
    TaskHandle_t activation_task_handle_ = nullptr;

    enum class MedicineFlowState {
        kIdle,
        kWaitAuthAck,
        kWaitAuthPromptDone,
        kWaitFaceResult,
        kWaitFaceBroadcastDone,
        kWaitUserReady,
        kWaitMedicinePlan,
        kWaitMedicinePromptDone,
        kWaitBoxOpened,
        kWaitUserTaken,
        kWaitBoxClosed,
        kWaitSessionResult,
    };

    struct MedicineItem {
        int box_id = 0;
        std::string name;
        int dose_count = 0;
        int target_count = 0;
        int stock_count = 0;
        int put_count = 0;
        bool bound = false;
        bool confirm_binding = false;
        std::string action;
        std::string status;
        std::string stock_source;
    };

    mutable std::mutex medicine_mutex_;
    MedicineFlowState medicine_flow_state_ = MedicineFlowState::kIdle;
    std::string medicine_flow_mode_ = "take";
    int current_medicine_plan_slot_ = 0;
    int current_medicine_box_id_ = 0;
    size_t current_medicine_index_ = 0;
    std::string current_put_mode_;
    std::vector<MedicineItem> current_medicines_;


    // Event handlers
    void HandleStateChangedEvent();
    void HandleToggleChatEvent();
    void HandleStartListeningEvent();
    void HandleStopListeningEvent();
    void HandleNetworkConnectedEvent();
    void HandleNetworkDisconnectedEvent();
    void HandleActivationDoneEvent();
    void HandleWakeWordDetectedEvent();
    void PlayLocalMedicineReminderAnnouncement(const std::string& message);
    void ContinueOpenAudioChannel(ListeningMode mode);
    void ContinueWakeWordInvoke(const std::string& wake_word);
    void ContinueMedicineReminderWake(const std::string& speech);
    void ScheduleProactiveReminderText(int delay_ms);
    void SendProactiveReminderText();
    void CheckProactiveReminderTextResponse();
    void AnnounceMedicineReminder(const std::string& payload);
    void StopLocalMedicineReminderAnnouncement(const cJSON* root);
    void ScheduleLocalMedicineReminderLoop(uint32_t generation);
    void HandleStarfireAsyncMessage(const std::string& tool, const std::string& payload);
    void HandleMedicineAuthAck(const cJSON* root);
    void HandleMedicineAuthRequired(const cJSON* root);
    void HandleMedicineAlreadyTaken(const cJSON* root);
    void HandleFaceAuthResult(const cJSON* root);
    void HandleMedicinePlan(const cJSON* root);
    void HandleMedicineBoxResult(const cJSON* root);
    void HandleMedicineTakenAck(const cJSON* root);
    void HandleMedicineSessionResult(const cJSON* root);
    void HandleMeasurementMessage(const std::string& tool, const cJSON* root);
    void WaitForHeartSpo2Result(uint64_t sequence);
    void WaitForBodyTemperatureResult(uint64_t sequence);
    void PromptCurrentMedicine();
    void ShowStarfireMessage(const char* message, int timeout_ms = 8000);

    // Activation task (runs in background)
    void ActivationTask();

    // Helper methods
    void CheckAssetsVersion();
    void CheckNewVersion();
    void InitializeProtocol();
    void ShowActivationCode(const std::string& code, const std::string& message);
    void SetListeningMode(ListeningMode mode);
    ListeningMode GetDefaultListeningMode() const;
    
    // State change handler called by state machine
    void OnStateChanged(DeviceState old_state, DeviceState new_state);
};


class TaskPriorityReset {
public:
    TaskPriorityReset(BaseType_t priority) {
        original_priority_ = uxTaskPriorityGet(NULL);
        vTaskPrioritySet(NULL, priority);
    }
    ~TaskPriorityReset() {
        vTaskPrioritySet(NULL, original_priority_);
    }

private:
    BaseType_t original_priority_;
};

#endif // _APPLICATION_H_

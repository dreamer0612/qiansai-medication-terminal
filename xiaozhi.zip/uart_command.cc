#include "uart_command.h"
#include <esp_log.h>
#include <cstring>
#include <chrono>
#include <cJSON.h>

#define TAG "UART_CMD"

const std::string UartCommand::STATE_REPORT_HEADER = "[State Report]";

UartCommand& UartCommand::GetInstance() {
    static UartCommand instance;
    return instance;
}

UartCommand::~UartCommand() {
    Deinitialize();
}

void UartCommand::Initialize() {
    if (initialized_) {
        ESP_LOGW(TAG, "UART command already initialized");
        return;
    }

    ESP_LOGI(TAG, "Initializing UART command module");

#ifdef CONFIG_UART_COMMAND_ENABLED
    uart_config_t uart_config = {
        .baud_rate = CONFIG_UART_COMMAND_BAUD_RATE,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .rx_flow_ctrl_thresh = 122,
    };

    uart_port_t uart_num = static_cast<uart_port_t>(CONFIG_UART_COMMAND_PORT);

    esp_err_t ret = uart_param_config(uart_num, &uart_config);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to configure UART: %s", esp_err_to_name(ret));
        return;
    }

    ret = uart_set_pin(uart_num,
                       CONFIG_UART_COMMAND_TX_PIN,
                       CONFIG_UART_COMMAND_RX_PIN,
                       UART_PIN_NO_CHANGE,
                       UART_PIN_NO_CHANGE);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to set UART pins: %s", esp_err_to_name(ret));
        return;
    }

    ret = uart_driver_install(uart_num,
                             UART_BUFFER_SIZE * 2,
                             UART_BUFFER_SIZE * 2,
                             UART_QUEUE_LENGTH,
                             &uart_queue_,
                             0);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to install UART driver: %s", esp_err_to_name(ret));
        return;
    }

#ifdef CONFIG_UART_COMMAND_ENABLE_RX
    BaseType_t task_ret = xTaskCreate(UartTaskWrapper, "uart_task", 4096, this, 5, &task_handle_);
    if (task_ret != pdPASS) {
        ESP_LOGE(TAG, "Failed to create UART task");
        uart_driver_delete(uart_num);
        return;
    }
#endif

    initialized_ = true;
    ESP_LOGI(TAG, "UART command module initialized successfully");
    ESP_LOGI(TAG, "Port: %d, Baud: %d, TX: %d, RX: %d", 
             CONFIG_UART_COMMAND_PORT, 
             CONFIG_UART_COMMAND_BAUD_RATE,
             CONFIG_UART_COMMAND_TX_PIN,
             CONFIG_UART_COMMAND_RX_PIN);
#else
    ESP_LOGW(TAG, "UART command module not enabled in config");
#endif
}

void UartCommand::Deinitialize() {
    if (!initialized_) {
        return;
    }

    ESP_LOGI(TAG, "Deinitializing UART command module");

    if (task_handle_) {
        vTaskDelete(task_handle_);
        task_handle_ = nullptr;
    }

#ifdef CONFIG_UART_COMMAND_ENABLED
    if (uart_queue_) {
        uart_driver_delete(static_cast<uart_port_t>(CONFIG_UART_COMMAND_PORT));
        uart_queue_ = nullptr;
    }
#endif

    initialized_ = false;
}

void UartCommand::UartTaskWrapper(void* arg) {
    UartCommand* instance = static_cast<UartCommand*>(arg);
    instance->UartTask();
}

void UartCommand::UartTask() {
    uart_event_t event;
    uint8_t* data = (uint8_t*)malloc(UART_BUFFER_SIZE);
    std::string rx_buffer;

    ESP_LOGI(TAG, "UART receive task started");

    while (true) {
#ifdef CONFIG_UART_COMMAND_ENABLED
        if (xQueueReceive(uart_queue_, (void *)&event, pdMS_TO_TICKS(100))) {
            switch (event.type) {
                case UART_DATA:
                    if (event.size > 0 && event.size < UART_BUFFER_SIZE) {
                        int len = uart_read_bytes(static_cast<uart_port_t>(CONFIG_UART_COMMAND_PORT), data, event.size, pdMS_TO_TICKS(100));
                        if (len > 0) {
                            data[len] = '\0';
                            rx_buffer.append((char*)data, len);
                            
                            size_t newline_pos;
                            while ((newline_pos = rx_buffer.find('\n')) != std::string::npos) {
                                std::string line = rx_buffer.substr(0, newline_pos);
                                rx_buffer.erase(0, newline_pos + 1);
                                
                                if (!line.empty() && line.back() == '\r') {
                                    line.pop_back();
                                }
                                
                                ESP_LOGI(TAG, "UART RX: %s", line.c_str());
                                
                                if (command_callback_) {
                                    command_callback_("rx", line);
                                }
                                
                                ParseUartData(line);
                            }
                        }
                    }
                    break;

                case UART_FIFO_OVF:
                    ESP_LOGW(TAG, "UART FIFO overflow");
                    uart_flush_input(static_cast<uart_port_t>(CONFIG_UART_COMMAND_PORT));
                    xQueueReset(uart_queue_);
                    rx_buffer.clear();
                    break;

                case UART_BUFFER_FULL:
                    ESP_LOGW(TAG, "UART buffer full");
                    uart_flush_input(static_cast<uart_port_t>(CONFIG_UART_COMMAND_PORT));
                    xQueueReset(uart_queue_);
                    rx_buffer.clear();
                    break;

                default:
                    break;
            }
        }
#endif
    }

    free(data);
}

void UartCommand::ParseUartData(const std::string& data) {
    if (data.find(STATE_REPORT_HEADER) == 0) {
        std::string state_json = data.substr(STATE_REPORT_HEADER.length());
        
        {
            std::lock_guard<std::mutex> lock(state_mutex_);
            last_state_report_ = state_json;
        }
        
        ESP_LOGI(TAG, "State report received: %s", state_json.c_str());
        
        if (state_report_callback_) {
            state_report_callback_(state_json);
        }
        return;
    }

    cJSON* root = cJSON_Parse(data.c_str());
    if (root == nullptr) {
        ESP_LOGW(TAG, "Ignoring non-JSON UART message: %s", data.c_str());
        return;
    }

    auto tool = cJSON_GetObjectItem(root, "tool");
    if (!cJSON_IsString(tool)) {
        ESP_LOGW(TAG, "Ignoring UART JSON without tool field: %s", data.c_str());
        cJSON_Delete(root);
        return;
    }

    {
        std::lock_guard<std::mutex> lock(state_mutex_);
        last_async_message_ = data;
        last_async_tool_ = tool->valuestring;
        ++async_message_sequence_;
        async_messages_.push_back({async_message_sequence_, last_async_tool_, data});
        while (async_messages_.size() > ASYNC_MESSAGE_HISTORY_SIZE) {
            async_messages_.pop_front();
        }
    }
    async_message_cv_.notify_all();

    ESP_LOGI(TAG, "Async message received: tool=%s, payload=%s", tool->valuestring, data.c_str());

    if (async_message_callback_) {
        async_message_callback_(tool->valuestring, data);
    }

    cJSON_Delete(root);
}

bool UartCommand::SendCommand(const std::string& command) {
    return SendCommand(command, "");
}

bool UartCommand::SendCommand(const std::string& command, const std::string& payload) {
    if (!initialized_) {
        ESP_LOGE(TAG, "UART command module not initialized");
        return false;
    }

#ifdef CONFIG_UART_COMMAND_ENABLED
    std::string full_command;

#ifdef CONFIG_UART_COMMAND_FORMAT_JSON
    full_command = "{\"cmd\":\"" + command + "\",\"data\":\"" + payload + "\"}\n";
#elif CONFIG_UART_COMMAND_FORMAT_SIMPLE
    full_command = command + ":" + payload + "\n";
#else
    full_command = command + "\n";
#endif

    ESP_LOGI(TAG, "Sending command: %s", full_command.c_str());

    std::lock_guard<std::mutex> lock(tx_mutex_);
    auto uart_num = static_cast<uart_port_t>(CONFIG_UART_COMMAND_PORT);
    int expected_len = static_cast<int>(full_command.size());
    int len = uart_write_bytes(uart_num, full_command.data(), expected_len);
    if (len != expected_len) {
        ESP_LOGE(TAG, "Failed to send complete command (sent %d/%d bytes)", len, expected_len);
        return false;
    }

    esp_err_t wait_result = uart_wait_tx_done(uart_num, pdMS_TO_TICKS(200));
    if (wait_result != ESP_OK) {
        ESP_LOGE(TAG, "UART TX did not finish: %s", esp_err_to_name(wait_result));
        return false;
    }

    return true;
#else
    return false;
#endif
}

bool UartCommand::SendJsonCommand(const std::string& command, const std::string& json_payload) {
    if (!initialized_) {
        ESP_LOGE(TAG, "UART command module not initialized");
        return false;
    }

#ifdef CONFIG_UART_COMMAND_ENABLED
    cJSON* args = cJSON_Parse(json_payload.c_str());
    if (!cJSON_IsObject(args)) {
        ESP_LOGE(TAG, "Refusing invalid JSON args for command %s: %s", command.c_str(), json_payload.c_str());
        cJSON_Delete(args);
        return false;
    }

    cJSON* frame = cJSON_CreateObject();
    cJSON_AddStringToObject(frame, "tool", command.c_str());
    cJSON_AddItemToObject(frame, "args", args);
    char* encoded = cJSON_PrintUnformatted(frame);
    if (encoded == nullptr) {
        ESP_LOGE(TAG, "Failed to encode JSON command: %s", command.c_str());
        cJSON_Delete(frame);
        return false;
    }

    std::string full_command(encoded);
    full_command.push_back('\n');
    cJSON_free(encoded);
    cJSON_Delete(frame);

    ESP_LOGI(TAG, "Sending JSON command: %s", full_command.c_str());
    ESP_LOG_BUFFER_HEX_LEVEL(TAG, full_command.data(), full_command.size(), ESP_LOG_INFO);

    std::lock_guard<std::mutex> lock(tx_mutex_);
    auto uart_num = static_cast<uart_port_t>(CONFIG_UART_COMMAND_PORT);
    int expected_len = static_cast<int>(full_command.size());
    int len = uart_write_bytes(uart_num, full_command.data(), expected_len);
    if (len != expected_len) {
        ESP_LOGE(TAG, "Failed to send complete JSON command (sent %d/%d bytes)", len, expected_len);
        return false;
    }

    esp_err_t wait_result = uart_wait_tx_done(uart_num, pdMS_TO_TICKS(200));
    if (wait_result != ESP_OK) {
        ESP_LOGE(TAG, "UART TX did not finish for command %s: %s", command.c_str(), esp_err_to_name(wait_result));
        return false;
    }

    return true;
#else
    return false;
#endif
}

void UartCommand::SetCommandCallback(std::function<void(const std::string&, const std::string&)> callback) {
    command_callback_ = std::move(callback);
}

void UartCommand::SetStateReportCallback(std::function<void(const std::string&)> callback) {
    state_report_callback_ = std::move(callback);
}

void UartCommand::SetAsyncMessageCallback(std::function<void(const std::string&, const std::string&)> callback) {
    async_message_callback_ = std::move(callback);
}

std::string UartCommand::GetLastStateReport() const {
    std::lock_guard<std::mutex> lock(state_mutex_);
    return last_state_report_;
}

std::string UartCommand::GetLastAsyncMessage() const {
    std::lock_guard<std::mutex> lock(state_mutex_);
    return last_async_message_;
}

uint64_t UartCommand::GetAsyncMessageSequence() const {
    std::lock_guard<std::mutex> lock(state_mutex_);
    return async_message_sequence_;
}

bool UartCommand::WaitForAsyncMessage(const std::string& tool, uint64_t after_sequence,
                                      int timeout_ms, std::string& message) {
    std::unique_lock<std::mutex> lock(state_mutex_);
    auto find_message = [this, &tool, after_sequence, &message]() {
        for (const auto& record : async_messages_) {
            if (record.sequence > after_sequence && record.tool == tool) {
                message = record.message;
                return true;
            }
        }
        return false;
    };
    bool received = async_message_cv_.wait_for(
        lock, std::chrono::milliseconds(timeout_ms), find_message);
    return received;
}

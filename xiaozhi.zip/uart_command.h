#ifndef UART_COMMAND_H
#define UART_COMMAND_H

#include <string>
#include <functional>
#include <mutex>
#include <condition_variable>
#include <cstdint>
#include <deque>
#include <freertos/FreeRTOS.h>
#include <freertos/queue.h>
#include <driver/uart.h>

class UartCommand {
public:
    static UartCommand& GetInstance();

    void Initialize();
    void Deinitialize();
    
    bool SendCommand(const std::string& command);
    bool SendCommand(const std::string& command, const std::string& payload);
    bool SendJsonCommand(const std::string& command, const std::string& json_payload);
    
    bool IsInitialized() const { return initialized_; }
    
    void SetCommandCallback(std::function<void(const std::string&, const std::string&)> callback);
    void SetStateReportCallback(std::function<void(const std::string&)> callback);
    void SetAsyncMessageCallback(std::function<void(const std::string&, const std::string&)> callback);
    
    std::string GetLastStateReport() const;
    std::string GetLastAsyncMessage() const;
    uint64_t GetAsyncMessageSequence() const;
    bool WaitForAsyncMessage(const std::string& tool, uint64_t after_sequence,
                             int timeout_ms, std::string& message);
    
private:
    struct AsyncMessageRecord {
        uint64_t sequence;
        std::string tool;
        std::string message;
    };

    UartCommand() = default;
    ~UartCommand();
    
    void UartTask();
    static void UartTaskWrapper(void* arg);
    void ParseUartData(const std::string& data);
    
    bool initialized_ = false;
    QueueHandle_t uart_queue_ = nullptr;
    TaskHandle_t task_handle_ = nullptr;
    std::function<void(const std::string&, const std::string&)> command_callback_;
    std::function<void(const std::string&)> state_report_callback_;
    std::function<void(const std::string&, const std::string&)> async_message_callback_;
    
    mutable std::mutex state_mutex_;
    std::condition_variable async_message_cv_;
    std::mutex tx_mutex_;
    std::string last_state_report_;
    std::string last_async_message_;
    std::string last_async_tool_;
    uint64_t async_message_sequence_ = 0;
    std::deque<AsyncMessageRecord> async_messages_;
    
    static const int UART_BUFFER_SIZE = 1024;
    static const int UART_QUEUE_LENGTH = 10;
    static const size_t ASYNC_MESSAGE_HISTORY_SIZE = 32;
    static const std::string STATE_REPORT_HEADER;
};

#endif // UART_COMMAND_H

/*
 * MCP Server Implementation
 * Reference: https://modelcontextprotocol.io/specification/2024-11-05
 */

#include "sdkconfig.h"
#include "mcp_server.h"
#include <esp_log.h>
#include <esp_app_desc.h>
#include <algorithm>
#include <cstring>
#include <esp_pthread.h>

#include "application.h"
#include "display.h"
#include "oled_display.h"
#include "board.h"
#include "settings.h"
#include "lvgl_theme.h"
#include "lvgl_display.h"
#include "uart_command.h"

#define TAG "MCP"

namespace {

std::string JsonToString(cJSON* json) {
    char* json_str = cJSON_PrintUnformatted(json);
    std::string result(json_str ? json_str : "{}");
    cJSON_free(json_str);
    return result;
}

cJSON* CreateUartCommandResult(const char* command, bool success) {
    cJSON* result = cJSON_CreateObject();
    cJSON_AddBoolToObject(result, "success", success);
    cJSON_AddStringToObject(result, "command", command);
    cJSON_AddStringToObject(result, "protocol", "starfire_one_medicine_box");
    cJSON_AddStringToObject(result, "message", success ? "Command sent to Starfire One host" : "Failed to send command");
    return result;
}

bool SendStarfireCommand(const char* command, cJSON* args) {
    std::string payload = JsonToString(args);
    return UartCommand::GetInstance().SendJsonCommand(command, payload);
}

bool IsStarfireCommand(const std::string& command) {
    const char* commands[] = {
        "open_lid",
        "close_lid",
        "take_medicine",
        "put_medicine",
        "prepare_put_medicine",
        "medicine_auth_prompt_done",
        "face_auth_broadcast_done",
        "face_auth_result_announced",
        "face_auth_success_announced",
        "medicine_open_request",
        "put_open_request",
        "medicine_plan_announced",
        "medicine_broadcast_done",
        "medicine_taken_done",
        "medicine_put_done",
        "put_medicine_done",
        "medicine_box_taken",
        "set_timer",
        "query_state",
        "get_stock",
        "measure_heart_spo2",
        "measure_body_temperature",
        "make_phone_call",
        "send_sms"
    };

    for (const auto& supported : commands) {
        if (command == supported) {
            return true;
        }
    }
    return false;
}

void NormalizeStarfireCommandName(std::string& command) {
    if (command == "measure_vitals" || command == "measure_heart_rate") {
        command = "measure_heart_spo2";
    } else if (command == "measure_body_temp" || command == "measure_temperature") {
        command = "measure_body_temperature";
    } else if (command == "phone_call" || command == "call_phone" || command == "make_call") {
        command = "make_phone_call";
    } else if (command == "send_text_message" || command == "text_message") {
        command = "send_sms";
    }
}

void CopyNumberAlias(cJSON* args, const char* canonical, const char* alias) {
    if (cJSON_GetObjectItem(args, canonical) != nullptr) {
        return;
    }

    auto value = cJSON_GetObjectItem(args, alias);
    if (cJSON_IsNumber(value)) {
        cJSON_AddNumberToObject(args, canonical, value->valueint);
    }
}

void CopyStringAlias(cJSON* args, const char* canonical, const char* alias) {
    if (cJSON_GetObjectItem(args, canonical) != nullptr) {
        return;
    }

    auto value = cJSON_GetObjectItem(args, alias);
    if (cJSON_IsString(value)) {
        cJSON_AddStringToObject(args, canonical, value->valuestring);
    }
}

std::string NormalizeStarfireArgs(const std::string& command, const std::string& raw_args) {
    cJSON* args = nullptr;
    if (raw_args.empty()) {
        args = cJSON_CreateObject();
    } else {
        args = cJSON_Parse(raw_args.c_str());
    }

    if (args == nullptr || !cJSON_IsObject(args)) {
        if (args != nullptr) {
            cJSON_Delete(args);
        }
        throw std::runtime_error("args must be a JSON object string");
    }

    if (command == "take_medicine" || command == "put_medicine") {
        CopyNumberAlias(args, "plan_slot", "slot");
    } else if (command == "medicine_auth_prompt_done" || command == "face_auth_broadcast_done" ||
               command == "face_auth_result_announced" || command == "face_auth_success_announced" ||
               command == "prepare_put_medicine" || command == "medicine_open_request" ||
               command == "put_open_request" || command == "medicine_plan_announced" ||
               command == "medicine_broadcast_done" || command == "medicine_taken_done" ||
               command == "medicine_put_done" || command == "put_medicine_done" ||
               command == "medicine_box_taken") {
        CopyNumberAlias(args, "plan_slot", "slot");
        CopyNumberAlias(args, "box_id", "boxId");
        CopyNumberAlias(args, "put_count", "count");
    } else if (command == "send_sms") {
        CopyStringAlias(args, "content", "message");
        CopyStringAlias(args, "content", "text");
    } else if (command == "set_timer") {
        CopyStringAlias(args, "user_name", "user");
        CopyStringAlias(args, "user_name", "name");
        if (cJSON_GetObjectItem(args, "user_name") == nullptr) {
            cJSON_AddStringToObject(args, "user_name", "patient");
        }
    }

    std::string normalized = JsonToString(args);
    cJSON_Delete(args);
    return normalized;
}

} // namespace

McpServer::McpServer() {
}

McpServer::~McpServer() {
    for (auto tool : tools_) {
        delete tool;
    }
    tools_.clear();
}

void McpServer::AddCommonTools() {
    // *Important* To speed up the response time, we add the common tools to the beginning of
    // the tools list to utilize the prompt cache.
    // **重要** 为了提升响应速度，我们把常用的工具放在前面，利用 prompt cache 的特性。

    // Backup the original tools list and restore it after adding the common tools.
    auto original_tools = std::move(tools_);
    auto& board = Board::GetInstance();

    // Do not add custom tools here.
    // Custom tools must be added in the board's InitializeTools function.

    AddTool("self.get_device_status",
        "Provides the real-time information of the device, including the current status of the audio speaker, screen, battery, network, etc.\n"
        "Use this tool for: \n"
        "1. Answering questions about current condition (e.g. what is the current volume of the audio speaker?)\n"
        "2. As the first step to control the device (e.g. turn up / down the volume of the audio speaker, etc.)",
        PropertyList(),
        [&board](const PropertyList& properties) -> ReturnValue {
            return board.GetDeviceStatusJson();
        });

    AddTool("self.audio_speaker.set_volume", 
        "Set the volume of the audio speaker. If the current volume is unknown, you must call `self.get_device_status` tool first and then call this tool.",
        PropertyList({
            Property("volume", kPropertyTypeInteger, 0, 100)
        }), 
        [&board](const PropertyList& properties) -> ReturnValue {
            auto codec = board.GetAudioCodec();
            codec->SetOutputVolume(properties["volume"].value<int>());
            return true;
        });
    
    auto backlight = board.GetBacklight();
    if (backlight) {
        AddTool("self.screen.set_brightness",
            "Set the brightness of the screen.",
            PropertyList({
                Property("brightness", kPropertyTypeInteger, 0, 100)
            }),
            [backlight](const PropertyList& properties) -> ReturnValue {
                uint8_t brightness = static_cast<uint8_t>(properties["brightness"].value<int>());
                backlight->SetBrightness(brightness, true);
                return true;
            });
    }

#ifdef HAVE_LVGL
    auto display = board.GetDisplay();
    if (display && display->GetTheme() != nullptr) {
        AddTool("self.screen.set_theme",
            "Set the theme of the screen. The theme can be `light` or `dark`.",
            PropertyList({
                Property("theme", kPropertyTypeString)
            }),
            [display](const PropertyList& properties) -> ReturnValue {
                auto theme_name = properties["theme"].value<std::string>();
                auto& theme_manager = LvglThemeManager::GetInstance();
                auto theme = theme_manager.GetTheme(theme_name);
                if (theme != nullptr) {
                    display->SetTheme(theme);
                    return true;
                }
                return false;
            });
    }

    auto camera = board.GetCamera();
    if (camera) {
        AddTool("self.camera.take_photo",
            "Always remember you have a camera. If the user asks you to see something, use this tool to take a photo and then explain it.\n"
            "Args:\n"
            "  `question`: The question that you want to ask about the photo.\n"
            "Return:\n"
            "  A JSON object that provides the photo information.",
            PropertyList({
                Property("question", kPropertyTypeString)
            }),
            [camera](const PropertyList& properties) -> ReturnValue {
                // Lower the priority to do the camera capture
                TaskPriorityReset priority_reset(1);

                if (!camera->Capture()) {
                    throw std::runtime_error("Failed to capture photo");
                }
                auto question = properties["question"].value<std::string>();
                return camera->Explain(question);
            });
    }
#endif

    #ifdef CONFIG_UART_COMMAND_ENABLED
    AddTool("self.medicine_box.open_lid",
        "Emergency-only: directly open a specified medicine-box lid without face authentication.\n"
        "Use this tool only when the user clearly indicates an urgent safety or rescue situation, "
        "or when immediate access to medicine is necessary and the normal face-authenticated medicine flow cannot be used in time.\n"
        "For ordinary medicine taking, scheduled reminders, refill/fill workflows, or non-urgent requests, do not use this tool. "
        "Use the formal take_medicine flow instead so Starfire One can perform face authentication and record the medicine session.\n"
        "\n"
        "打开指定的药盒仓门。\n"
        "\n"
        "Args:\n"
        "  box_id: 药盒编号，取值范围 1-6（对应6个药仓）\n"
        "\n"
        "Return:\n"
        "  JSON格式结果，包含 success(是否成功)、message(执行信息)、box_id(药盒编号)。",
        PropertyList({
            Property("box_id", kPropertyTypeInteger)
        }),
        [](const PropertyList& properties) -> ReturnValue {
            int box_id = properties["box_id"].value<int>();
            
            if (box_id < 1 || box_id > 6) {
                throw std::runtime_error("Invalid box_id, must be between 1-6");
            }
            
            std::string json_payload = "{\"box_id\":" + std::to_string(box_id) + "}";
            bool success = UartCommand::GetInstance().SendJsonCommand("open_lid", json_payload);
            
            cJSON *result = cJSON_CreateObject();
            cJSON_AddBoolToObject(result, "success", success);
            cJSON_AddNumberToObject(result, "box_id", box_id);
            cJSON_AddStringToObject(result, "message", success ? "Open lid command sent" : "Failed to send command");
            
            return result;
        });

    AddTool("self.medicine_box.close_lid",
        "关闭指定的药盒仓门。\n"
        "\n"
        "Args:\n"
        "  box_id: 药盒编号，取值范围 1-6（对应6个药仓）；传入0表示关闭所有仓门\n"
        "\n"
        "Return:\n"
        "  JSON格式结果，包含 success(是否成功)、message(执行信息)、box_id(药盒编号)。",
        PropertyList({
            Property("box_id", kPropertyTypeInteger)
        }),
        [](const PropertyList& properties) -> ReturnValue {
            int box_id = properties["box_id"].value<int>();
            
            if (box_id < 0 || box_id > 6) {
                throw std::runtime_error("Invalid box_id, must be between 0-6");
            }
            
            std::string json_payload = "{\"box_id\":" + std::to_string(box_id) + "}";
            bool success = UartCommand::GetInstance().SendJsonCommand("close_lid", json_payload);
            if (success) {
                Application::GetInstance().ResetMedicineSession();
            }
            
            cJSON *result = cJSON_CreateObject();
            cJSON_AddBoolToObject(result, "success", success);
            cJSON_AddNumberToObject(result, "box_id", box_id);
            cJSON_AddStringToObject(result, "message", success ? "Close lid command sent" : "Failed to send command");
            
            return result;
        });

    AddTool("self.medicine_box.take_medicine",
        "Start medicine taking and complete only the initial Starfire One authentication acknowledgement. Use when the user says 我要吃药, 吃药, 开始用药, or 我要取药. Speak the returned speech exactly to remind the user to look at the camera. After the user says 开始验证, 我准备好了, or 可以验证了, call start_face_auth.\n"
        "Args:\n"
        "  plan_slot: optional medicine plan slot, 1-3. Use 0 to let the host choose by current time.\n"
        "Return:\n"
        "  JSON result. On success status is waiting_face_auth_prompt_done and no face query has started yet.",
        PropertyList({
            Property("plan_slot", kPropertyTypeInteger, 0, 0, 3)
        }),
        [](const PropertyList& properties) -> ReturnValue {
            int plan_slot = properties["plan_slot"].value<int>();
            return Application::GetInstance().AuthenticateMedicineUser(plan_slot);
        });

    AddTool("self.medicine_box.start_face_auth",
        "Start the K230 face authentication after the user has heard the face-verification prompt and says 开始验证, 我准备好了, 可以验证了, or 看摄像头了. This tool sends medicine_auth_prompt_done, waits for face_auth_result, and returns the authentication result. Speak the returned speech exactly. On success, wait for the user to say 准备好了 before calling prepare_medicine.",
        PropertyList(),
        [](const PropertyList& properties) -> ReturnValue {
            return Application::GetInstance().StartMedicineFaceAuthentication();
        });

    AddTool("self.medicine_box.prepare_medicine",
        "Continue an authenticated medicine flow after the user explicitly says 准备好了, 准备好取药, or 可以取药了. This tool obtains the medicine plan, opens the first box, and returns its medicine name and dose. Speak the returned speech and medicine details.",
        PropertyList(),
        [](const PropertyList& properties) -> ReturnValue {
            return Application::GetInstance().OpenMedicineAfterUserReady();
        });

    AddTool("self.medicine_box.medicine_taken_done",
        "Use when the user says 吃完了, 取完了, 拿好了, 下一个, or 继续. This tool closes the current box and either opens the next planned box or completes the medicine session. Speak the returned speech and medicine details.",
        PropertyList(),
        [](const PropertyList& properties) -> ReturnValue {
            return Application::GetInstance().ConfirmCurrentMedicineTaken();
        });

    AddTool("self.medicine_box.put_medicine",
        "Start the medicine fill/refill flow. Use when the user says 我要放药, 首次放药, 初始化药盒, 我要补药, 加药, or 补充药品. This only starts the authenticated put flow. Speak the returned speech exactly. After the user says 开始验证, 我准备好了, or 可以验证了, call start_put_face_auth.",
        PropertyList({
            Property("plan_slot", kPropertyTypeInteger, 0, 0, 3)
        }),
        [](const PropertyList& properties) -> ReturnValue {
            int plan_slot = properties["plan_slot"].value<int>();
            return Application::GetInstance().StartPutMedicine(plan_slot);
        });

    AddTool("self.medicine_box.start_put_face_auth",
        "Start face authentication for the refill flow after the user says 开始验证, 我准备好了, 可以验证了, or 看摄像头了. Speak the returned speech exactly. On success, wait for the user to say 准备好了 before calling prepare_put_medicine.",
        PropertyList(),
        [](const PropertyList& properties) -> ReturnValue {
            return Application::GetInstance().StartPutFaceAuthentication();
        });

    AddTool("self.medicine_box.prepare_put_medicine",
        "Continue an authenticated fill/refill flow after the user explicitly says 准备好了, 可以放药了, or 准备好放药. This tool asks Starfire One for the actual box context and executable put tasks. It opens a box only when the context status is ready; if Starfire reports needs_user_confirmation, mismatch, stock_unknown, sensor_error, or another blocking status, speak the returned speech and do not continue. Speak the returned speech exactly.",
        PropertyList(),
        [](const PropertyList& properties) -> ReturnValue {
            return Application::GetInstance().OpenMedicineForPutAfterUserReady();
        });

    AddTool("self.medicine_box.medicine_put_done",
        "Use when the user confirms the opened put box is done. If the user says 放了10颗, 放了两粒, or 我放了5颗, extract the number as put_count. If the user only says 放好了 or 完成了, omit the number or pass -1 so the device uses the recommended task count. This tool records the stock/binding result with Starfire One and opens the next task box or completes the fill/refill flow. Speak only the returned speech.",
        PropertyList({
            Property("put_count", kPropertyTypeInteger, -1, -1, 999)
        }),
        [](const PropertyList& properties) -> ReturnValue {
            int put_count = properties["put_count"].value<int>();
            return Application::GetInstance().ConfirmCurrentMedicinePut(put_count);
        });

    AddTool("self.medicine_box.set_timer",
        "Set a Starfire One medicine reminder time.\n"
        "Args:\n"
        "  slot: reminder slot, 1-6\n"
        "  time: reminder time in HH:MM format\n"
        "  user_name: patient name, optional; defaults to patient\n"
        "Return:\n"
        "  JSON result. The host responds with a state report.",
        PropertyList({
            Property("slot", kPropertyTypeInteger, 1, 6),
            Property("time", kPropertyTypeString),
            Property("user_name", kPropertyTypeString, "patient")
        }),
        [](const PropertyList& properties) -> ReturnValue {
            int slot = properties["slot"].value<int>();
            auto time = properties["time"].value<std::string>();
            auto user_name = properties["user_name"].value<std::string>();

            cJSON* args = cJSON_CreateObject();
            cJSON_AddNumberToObject(args, "slot", slot);
            cJSON_AddStringToObject(args, "time", time.c_str());
            cJSON_AddStringToObject(args, "user_name", user_name.c_str());
            bool success = SendStarfireCommand("set_timer", args);
            cJSON_Delete(args);

            cJSON* result = CreateUartCommandResult("set_timer", success);
            cJSON_AddNumberToObject(result, "slot", slot);
            cJSON_AddStringToObject(result, "time", time.c_str());
            cJSON_AddStringToObject(result, "user_name", user_name.c_str());
            return result;
        });

    AddTool("self.medicine_box.get_stock",
        "Ask the Starfire One host to report medicine box stock and current state.",
        PropertyList(),
        [](const PropertyList& properties) -> ReturnValue {
            cJSON* args = cJSON_CreateObject();
            bool success = SendStarfireCommand("get_stock", args);
            cJSON_Delete(args);

            std::string last_state = UartCommand::GetInstance().GetLastStateReport();
            cJSON* result = CreateUartCommandResult("get_stock", success);
            cJSON_AddBoolToObject(result, "has_state", !last_state.empty());
            if (!last_state.empty()) {
                cJSON* state_json = cJSON_Parse(last_state.c_str());
                if (state_json) {
                    cJSON_AddItemToObject(result, "state", state_json);
                } else {
                    cJSON_AddStringToObject(result, "state_raw", last_state.c_str());
                }
            }
            return result;
        });

    AddTool("self.medicine_box.measure_heart_spo2",
        "Use when the user says 我要测心率血氧, 测一下心率血氧, 测心率, or 测血氧. This starts a two-turn measurement flow: the device plays local prepare/start prompts, sends measure_heart_spo2 to Starfire One, returns status=measuring quickly, then later plays a local measurement-finished sound and caches the result. Reply that measurement has started, ask the user to keep their finger stable, and tell them to ask 结果是多少 after hearing 测量结束.",
        PropertyList(),
        [](const PropertyList& properties) -> ReturnValue {
            return Application::GetInstance().MeasureHeartSpo2();
        });

    AddTool("self.medicine_box.get_last_heart_spo2_result",
        "Use when the user asks for the heart/spo2 result after measurement, such as 结果是多少, 刚才测得多少, 心率多少, 血氧多少, 测完了吗, or 检测结果. Return the cached heartRate and spo2 if available. Speak the returned speech exactly.",
        PropertyList(),
        [](const PropertyList& properties) -> ReturnValue {
            return Application::GetInstance().GetLastHeartSpo2Result();
        });

    AddTool("self.medicine_box.measure_body_temperature",
        "Use when the user says 我要测体温, 测一下体温, 量体温, or 测温度. This starts a two-turn measurement flow: the device plays the same local prepare/start prompts as vitals, sends measure_body_temperature to Starfire One, returns status=measuring quickly, then later plays a local measurement-finished sound and caches bodyTemperature. Reply that body temperature measurement has started, ask the user to stay still, and tell them to ask 结果是多少 after hearing 测量结束.",
        PropertyList(),
        [](const PropertyList& properties) -> ReturnValue {
            return Application::GetInstance().MeasureBodyTemperature();
        });

    AddTool("self.medicine_box.get_last_body_temperature_result",
        "Use when the user asks for the body temperature result after measurement, such as 结果是多少, 刚才测得多少, 体温多少, 温度多少, 测完了吗, 检测结果, or ASR-misheard phrases like 结果一帽子. Return the cached bodyTemperature if available. Speak the returned speech exactly.",
        PropertyList(),
        [](const PropertyList& properties) -> ReturnValue {
            return Application::GetInstance().GetLastBodyTemperatureResult();
        });

    AddTool("self.communication.make_phone_call",
        "Use when the user asks to 打电话, 拨打电话, 联系家属, 呼叫帮助, or call for help. This sends a UART JSON request to Starfire One only; do not ask for or provide a phone number because the slave decides the target number/contact. IMPORTANT SAFETY RULE: if the user indicates a severe situation that may threaten personal safety, such as falling and being unable to get up, chest pain, breathing difficulty, stroke-like symptoms, fire, violence, or any emergency needing immediate human help, and the issue is beyond what the LLM can safely handle, call this tool to request phone help. After the tool returns, briefly tell the user that the phone request has been sent.",
        PropertyList(),
        [](const PropertyList& properties) -> ReturnValue {
            cJSON* args = cJSON_CreateObject();
            bool success = SendStarfireCommand("make_phone_call", args);
            cJSON_Delete(args);

            cJSON* result = CreateUartCommandResult("make_phone_call", success);
            cJSON_AddStringToObject(result, "status", success ? "requested" : "request_failed");
            cJSON_AddStringToObject(result, "speech", success ? "已为你发起电话请求。" : "电话请求发送失败，请尝试其他方式求助。");
            return result;
        });

    AddTool("self.communication.send_sms",
        "Use when the user asks to 发短信, 发消息, 通知家属, or send an SMS. The slave handles the target number/contact; do not ask for a phone number unless the user explicitly wants to specify message content with a recipient in natural language. You must write a concise SMS content from the user context and pass it as content. For serious emergencies where immediate human help is needed, prefer make_phone_call first; use SMS only when the user asks for text notification or when a short written notice is appropriate.",
        PropertyList({
            Property("content", kPropertyTypeString)
        }),
        [](const PropertyList& properties) -> ReturnValue {
            auto content = properties["content"].value<std::string>();
            cJSON* args = cJSON_CreateObject();
            cJSON_AddStringToObject(args, "content", content.c_str());
            bool success = SendStarfireCommand("send_sms", args);
            cJSON_Delete(args);

            cJSON* result = CreateUartCommandResult("send_sms", success);
            cJSON_AddStringToObject(result, "status", success ? "requested" : "request_failed");
            cJSON_AddStringToObject(result, "content", content.c_str());
            cJSON_AddStringToObject(result, "speech", success ? "短信请求已发送。" : "短信请求发送失败，请尝试其他方式联系。");
            return result;
        });

    AddTool("self.medicine_box.query_state",
        "查询药盒从机的状态信息。\n"
        "\n"
        "说明：当从机主动上报状态时，状态会缓存到此工具返回。当LLM需要查询药盒状态时调用此工具。\n"
        "\n"
        "Args:\n"
        "  request: 是否请求从机上报最新状态\n"
        "    - true: 发送查询命令给从机，等待从机回复后返回\n"
        "    - false: 仅返回缓存的上次状态（无请求开销）\n"
        "\n"
        "Return:\n"
        "  JSON格式状态信息，包含:\n"
        "  - has_state: 是否有缓存的状态\n"
        "  - state: 从机上报的JSON状态数据（如有）\n"
        "  - initialized: UART模块是否就绪\n"
        "  - port/baud_rate: 通信参数",
        PropertyList({
            Property("request", kPropertyTypeBoolean, true)
        }),
        [](const PropertyList& properties) -> ReturnValue {
            bool request_update = properties["request"].value<bool>();
            
            cJSON *result = cJSON_CreateObject();
            
            if (request_update) {
                bool success = UartCommand::GetInstance().SendJsonCommand("query_state", "{}");
                cJSON_AddBoolToObject(result, "query_sent", success);
                ESP_LOGI(TAG, "Query state command sent: %s", success ? "yes" : "no");
            }
            
            std::string last_state = UartCommand::GetInstance().GetLastStateReport();
            cJSON_AddBoolToObject(result, "has_state", !last_state.empty());
            
            if (!last_state.empty()) {
                cJSON *state_json = cJSON_Parse(last_state.c_str());
                if (state_json) {
                    cJSON_AddItemToObject(result, "state", state_json);
                } else {
                    cJSON_AddStringToObject(result, "state_raw", last_state.c_str());
                }
            } else {
                cJSON_AddStringToObject(result, "state", "");
            }
            
            cJSON_AddBoolToObject(result, "initialized", UartCommand::GetInstance().IsInitialized());
            cJSON_AddNumberToObject(result, "port", CONFIG_UART_COMMAND_PORT);
            cJSON_AddNumberToObject(result, "baud_rate", CONFIG_UART_COMMAND_BAUD_RATE);
            
            return result;
        });

    AddTool("self.medicine_box.send_command",
        "Send a Starfire One UART JSON-line command.\n"
        "\n"
        "Args:\n"
        "  command: command name\n"
        "    - open_lid: emergency-only direct lid opening without face authentication (args: {\"box_id\":1}); use only for urgent safety/rescue situations or when immediate medicine access is necessary and the normal authenticated flow cannot be used in time\n"
        "    - take_medicine: start the formal medicine flow (args: {})\n"
        "    - put_medicine: start the fill/refill authentication flow (args: {})\n"
        "    - prepare_put_medicine: request actual box context and put task list after authentication (args: {\"plan_slot\":1,\"mode\":\"auto\"})\n"
        "    - medicine_auth_prompt_done: start face authentication after auth acknowledgement (debug only)\n"
        "    - face_auth_broadcast_done: continue after the user says they are ready to take medicine (debug only)\n"
        "    - face_auth_result_announced / face_auth_success_announced: compatible face prompt confirmations\n"
        "    - put_open_request: request opening a put-task box (args: {\"box_id\":1,\"medicine_name\":\"xxx\",\"action\":\"bind_and_fill\",\"put_count\":14})\n"
        "    - medicine_open_request: compatible request opening a planned box (debug only)\n"
        "    - medicine_plan_announced / medicine_broadcast_done: compatible medicine prompt confirmations\n"
        "    - medicine_taken_done: confirm the current box is taken (args: {\"plan_slot\":1,\"box_id\":2})\n"
        "    - put_medicine_done: confirm fill/refill count and optional binding (args: {\"plan_slot\":1,\"box_id\":2,\"put_count\":10,\"confirm_binding\":true})\n"
        "    - medicine_put_done: compatible confirm refill count (args: {\"plan_slot\":1,\"box_id\":2,\"put_count\":10})\n"
        "    - medicine_box_taken: compatible current-box taken confirmation\n"
        "    - close_lid: safe-close boxes (args: {\"box_id\":0})\n"
        "    - set_timer: set reminder (args: {\"slot\":1,\"time\":\"08:00\"})\n"
        "    - get_stock: query stock\n"
        "    - make_phone_call: ask the slave to make a phone call (args: {})\n"
        "    - send_sms: ask the slave to send an SMS (args: {\"content\":\"message text\"})\n"
        "  args: command arguments as a JSON object string\n"
        "\n"
        "Return:\n"
        "  JSON result with success, command, protocol, message, and normalized args.",
        PropertyList({
            Property("command", kPropertyTypeString),
            Property("args", kPropertyTypeString, "{}")
        }),
        [](const PropertyList& properties) -> ReturnValue {
            auto command = properties["command"].value<std::string>();
            auto args = properties["args"].value<std::string>();

            NormalizeStarfireCommandName(command);
            if (!IsStarfireCommand(command)) {
                throw std::runtime_error("Unsupported Starfire One command: " + command);
            }
            auto normalized_args = NormalizeStarfireArgs(command, args);
            
            bool success = UartCommand::GetInstance().SendJsonCommand(command, normalized_args);
            if (success && (command == "close_lid" || command == "take_medicine" || command == "put_medicine")) {
                Application::GetInstance().ResetMedicineSession();
            }
            
            cJSON *result = CreateUartCommandResult(command.c_str(), success);
            cJSON_AddStringToObject(result, "args", normalized_args.c_str());
            
            return result;
        });
#endif

    // Restore the original tools list to the end of the tools list
    tools_.insert(tools_.end(), original_tools.begin(), original_tools.end());
}

void McpServer::AddUserOnlyTools() {
    // System tools
    AddUserOnlyTool("self.get_system_info",
        "Get the system information",
        PropertyList(),
        [this](const PropertyList& properties) -> ReturnValue {
            auto& board = Board::GetInstance();
            return board.GetSystemInfoJson();
        });

    AddUserOnlyTool("self.reboot", "Reboot the system",
        PropertyList(),
        [this](const PropertyList& properties) -> ReturnValue {
            auto& app = Application::GetInstance();
            app.Schedule([&app]() {
                ESP_LOGW(TAG, "User requested reboot");
                vTaskDelay(pdMS_TO_TICKS(1000));

                app.Reboot();
            });
            return true;
        });

    // Firmware upgrade
    AddUserOnlyTool("self.upgrade_firmware", "Upgrade firmware from a specific URL. This will download and install the firmware, then reboot the device.",
        PropertyList({
            Property("url", kPropertyTypeString, "The URL of the firmware binary file to download and install")
        }),
        [this](const PropertyList& properties) -> ReturnValue {
            auto url = properties["url"].value<std::string>();
            ESP_LOGI(TAG, "User requested firmware upgrade from URL: %s", url.c_str());
            
            auto& app = Application::GetInstance();
            app.Schedule([url, &app]() {
                bool success = app.UpgradeFirmware(url);
                if (!success) {
                    ESP_LOGE(TAG, "Firmware upgrade failed");
                }
            });
            
            return true;
        });

    // Display control
#ifdef HAVE_LVGL
    auto display = dynamic_cast<LvglDisplay*>(Board::GetInstance().GetDisplay());
    if (display) {
        AddUserOnlyTool("self.screen.get_info", "Information about the screen, including width, height, etc.",
            PropertyList(),
            [display](const PropertyList& properties) -> ReturnValue {
                cJSON *json = cJSON_CreateObject();
                cJSON_AddNumberToObject(json, "width", display->width());
                cJSON_AddNumberToObject(json, "height", display->height());
                if (dynamic_cast<OledDisplay*>(display)) {
                    cJSON_AddBoolToObject(json, "monochrome", true);
                } else {
                    cJSON_AddBoolToObject(json, "monochrome", false);
                }
                return json;
            });

#if CONFIG_LV_USE_SNAPSHOT
        AddUserOnlyTool("self.screen.snapshot", "Snapshot the screen and upload it to a specific URL",
            PropertyList({
                Property("url", kPropertyTypeString),
                Property("quality", kPropertyTypeInteger, 80, 1, 100)
            }),
            [display](const PropertyList& properties) -> ReturnValue {
                auto url = properties["url"].value<std::string>();
                auto quality = properties["quality"].value<int>();

                std::string jpeg_data;
                if (!display->SnapshotToJpeg(jpeg_data, quality)) {
                    throw std::runtime_error("Failed to snapshot screen");
                }

                ESP_LOGI(TAG, "Upload snapshot %u bytes to %s", jpeg_data.size(), url.c_str());
                
                // 构造multipart/form-data请求体
                std::string boundary = "----ESP32_SCREEN_SNAPSHOT_BOUNDARY";
                
                auto http = Board::GetInstance().GetNetwork()->CreateHttp(3);
                http->SetHeader("Content-Type", "multipart/form-data; boundary=" + boundary);
                if (!http->Open("POST", url)) {
                    throw std::runtime_error("Failed to open URL: " + url);
                }
                {
                    // 文件字段头部
                    std::string file_header;
                    file_header += "--" + boundary + "\r\n";
                    file_header += "Content-Disposition: form-data; name=\"file\"; filename=\"screenshot.jpg\"\r\n";
                    file_header += "Content-Type: image/jpeg\r\n";
                    file_header += "\r\n";
                    http->Write(file_header.c_str(), file_header.size());
                }

                // JPEG数据
                http->Write((const char*)jpeg_data.data(), jpeg_data.size());

                {
                    // multipart尾部
                    std::string multipart_footer;
                    multipart_footer += "\r\n--" + boundary + "--\r\n";
                    http->Write(multipart_footer.c_str(), multipart_footer.size());
                }
                http->Write("", 0);

                if (http->GetStatusCode() != 200) {
                    throw std::runtime_error("Unexpected status code: " + std::to_string(http->GetStatusCode()));
                }
                std::string result = http->ReadAll();
                http->Close();
                ESP_LOGI(TAG, "Snapshot screen result: %s", result.c_str());
                return true;
            });
        
        AddUserOnlyTool("self.screen.preview_image", "Preview an image on the screen",
            PropertyList({
                Property("url", kPropertyTypeString)
            }),
            [display](const PropertyList& properties) -> ReturnValue {
                auto url = properties["url"].value<std::string>();
                auto http = Board::GetInstance().GetNetwork()->CreateHttp(3);

                if (!http->Open("GET", url)) {
                    throw std::runtime_error("Failed to open URL: " + url);
                }
                int status_code = http->GetStatusCode();
                if (status_code != 200) {
                    throw std::runtime_error("Unexpected status code: " + std::to_string(status_code));
                }

                size_t content_length = http->GetBodyLength();
                char* data = (char*)heap_caps_malloc(content_length, MALLOC_CAP_8BIT);
                if (data == nullptr) {
                    throw std::runtime_error("Failed to allocate memory for image: " + url);
                }
                size_t total_read = 0;
                while (total_read < content_length) {
                    int ret = http->Read(data + total_read, content_length - total_read);
                    if (ret < 0) {
                        heap_caps_free(data);
                        throw std::runtime_error("Failed to download image: " + url);
                    }
                    if (ret == 0) {
                        break;
                    }
                    total_read += ret;
                }
                http->Close();

                auto image = std::make_unique<LvglAllocatedImage>(data, content_length);
                display->SetPreviewImage(std::move(image));
                return true;
            });
#endif // CONFIG_LV_USE_SNAPSHOT
    }
#endif // HAVE_LVGL

    // Assets download url
    auto& assets = Assets::GetInstance();
    if (assets.partition_valid()) {
        AddUserOnlyTool("self.assets.set_download_url", "Set the download url for the assets",
            PropertyList({
                Property("url", kPropertyTypeString)
            }),
            [](const PropertyList& properties) -> ReturnValue {
                auto url = properties["url"].value<std::string>();
                Settings settings("assets", true);
                settings.SetString("download_url", url);
                return true;
            });
    }
}

void McpServer::AddTool(McpTool* tool) {
    // Prevent adding duplicate tools
    if (std::find_if(tools_.begin(), tools_.end(), [tool](const McpTool* t) { return t->name() == tool->name(); }) != tools_.end()) {
        ESP_LOGW(TAG, "Tool %s already added", tool->name().c_str());
        return;
    }

    ESP_LOGI(TAG, "Add tool: %s%s", tool->name().c_str(), tool->user_only() ? " [user]" : "");
    tools_.push_back(tool);
}

void McpServer::AddTool(const std::string& name, const std::string& description, const PropertyList& properties, std::function<ReturnValue(const PropertyList&)> callback) {
    AddTool(new McpTool(name, description, properties, callback));
}

void McpServer::AddUserOnlyTool(const std::string& name, const std::string& description, const PropertyList& properties, std::function<ReturnValue(const PropertyList&)> callback) {
    auto tool = new McpTool(name, description, properties, callback);
    tool->set_user_only(true);
    AddTool(tool);
}

void McpServer::ParseMessage(const std::string& message) {
    cJSON* json = cJSON_Parse(message.c_str());
    if (json == nullptr) {
        ESP_LOGE(TAG, "Failed to parse MCP message: %s", message.c_str());
        return;
    }
    ParseMessage(json);
    cJSON_Delete(json);
}

void McpServer::ParseCapabilities(const cJSON* capabilities) {
    auto vision = cJSON_GetObjectItem(capabilities, "vision");
    if (cJSON_IsObject(vision)) {
        auto url = cJSON_GetObjectItem(vision, "url");
        auto token = cJSON_GetObjectItem(vision, "token");
        if (cJSON_IsString(url)) {
            auto camera = Board::GetInstance().GetCamera();
            if (camera) {
                std::string url_str = std::string(url->valuestring);
                std::string token_str;
                if (cJSON_IsString(token)) {
                    token_str = std::string(token->valuestring);
                }
                camera->SetExplainUrl(url_str, token_str);
            }
        }
    }
}

void McpServer::ParseMessage(const cJSON* json) {
    // Check JSONRPC version
    auto version = cJSON_GetObjectItem(json, "jsonrpc");
    if (version == nullptr || !cJSON_IsString(version) || strcmp(version->valuestring, "2.0") != 0) {
        ESP_LOGE(TAG, "Invalid JSONRPC version: %s", version ? version->valuestring : "null");
        return;
    }
    
    // Check method
    auto method = cJSON_GetObjectItem(json, "method");
    if (method == nullptr || !cJSON_IsString(method)) {
        ESP_LOGE(TAG, "Missing method");
        return;
    }
    
    auto method_str = std::string(method->valuestring);
    if (method_str.find("notifications") == 0) {
        return;
    }
    
    // Check params
    auto params = cJSON_GetObjectItem(json, "params");
    if (params != nullptr && !cJSON_IsObject(params)) {
        ESP_LOGE(TAG, "Invalid params for method: %s", method_str.c_str());
        return;
    }

    auto id = cJSON_GetObjectItem(json, "id");
    if (id == nullptr || !cJSON_IsNumber(id)) {
        ESP_LOGE(TAG, "Invalid id for method: %s", method_str.c_str());
        return;
    }
    auto id_int = id->valueint;
    
    if (method_str == "initialize") {
        if (cJSON_IsObject(params)) {
            auto capabilities = cJSON_GetObjectItem(params, "capabilities");
            if (cJSON_IsObject(capabilities)) {
                ParseCapabilities(capabilities);
            }
        }
        auto app_desc = esp_app_get_description();
        std::string message = "{\"protocolVersion\":\"2024-11-05\",\"capabilities\":{\"tools\":{}},\"serverInfo\":{\"name\":\"" BOARD_NAME "\",\"version\":\"";
        message += app_desc->version;
        message += "\"}}";
        ReplyResult(id_int, message);
    } else if (method_str == "tools/list") {
        std::string cursor_str = "";
        bool list_user_only_tools = false;
        if (params != nullptr) {
            auto cursor = cJSON_GetObjectItem(params, "cursor");
            if (cJSON_IsString(cursor)) {
                cursor_str = std::string(cursor->valuestring);
            }
            auto with_user_tools = cJSON_GetObjectItem(params, "withUserTools");
            if (cJSON_IsBool(with_user_tools)) {
                list_user_only_tools = with_user_tools->valueint == 1;
            }
        }
        GetToolsList(id_int, cursor_str, list_user_only_tools);
    } else if (method_str == "tools/call") {
        if (!cJSON_IsObject(params)) {
            ESP_LOGE(TAG, "tools/call: Missing params");
            ReplyError(id_int, "Missing params");
            return;
        }
        auto tool_name = cJSON_GetObjectItem(params, "name");
        if (!cJSON_IsString(tool_name)) {
            ESP_LOGE(TAG, "tools/call: Missing name");
            ReplyError(id_int, "Missing name");
            return;
        }
        auto tool_arguments = cJSON_GetObjectItem(params, "arguments");
        if (tool_arguments != nullptr && !cJSON_IsObject(tool_arguments)) {
            ESP_LOGE(TAG, "tools/call: Invalid arguments");
            ReplyError(id_int, "Invalid arguments");
            return;
        }
        DoToolCall(id_int, std::string(tool_name->valuestring), tool_arguments);
    } else {
        ESP_LOGE(TAG, "Method not implemented: %s", method_str.c_str());
        ReplyError(id_int, "Method not implemented: " + method_str);
    }
}

void McpServer::ReplyResult(int id, const std::string& result) {
    std::string payload = "{\"jsonrpc\":\"2.0\",\"id\":";
    payload += std::to_string(id) + ",\"result\":";
    payload += result;
    payload += "}";
    Application::GetInstance().SendMcpMessage(payload);
}

void McpServer::ReplyError(int id, const std::string& message) {
    std::string payload = "{\"jsonrpc\":\"2.0\",\"id\":";
    payload += std::to_string(id);
    payload += ",\"error\":{\"message\":\"";
    payload += message;
    payload += "\"}}";
    Application::GetInstance().SendMcpMessage(payload);
}

void McpServer::GetToolsList(int id, const std::string& cursor, bool list_user_only_tools) {
    const int max_payload_size = 8000;
    std::string json = "{\"tools\":[";
    
    bool found_cursor = cursor.empty();
    auto it = tools_.begin();
    std::string next_cursor = "";
    
    while (it != tools_.end()) {
        // 如果我们还没有找到起始位置，继续搜索
        if (!found_cursor) {
            if ((*it)->name() == cursor) {
                found_cursor = true;
            } else {
                ++it;
                continue;
            }
        }

        if (!list_user_only_tools && (*it)->user_only()) {
            ++it;
            continue;
        }
        
        // 添加tool前检查大小
        std::string tool_json = (*it)->to_json() + ",";
        if (json.length() + tool_json.length() + 30 > max_payload_size) {
            // 如果添加这个tool会超出大小限制，设置next_cursor并退出循环
            next_cursor = (*it)->name();
            break;
        }
        
        json += tool_json;
        ++it;
    }
    
    if (json.back() == ',') {
        json.pop_back();
    }
    
    if (json.back() == '[' && !tools_.empty()) {
        // 如果没有添加任何tool，返回错误
        ESP_LOGE(TAG, "tools/list: Failed to add tool %s because of payload size limit", next_cursor.c_str());
        ReplyError(id, "Failed to add tool " + next_cursor + " because of payload size limit");
        return;
    }

    if (next_cursor.empty()) {
        json += "]}";
    } else {
        json += "],\"nextCursor\":\"" + next_cursor + "\"}";
    }
    
    ReplyResult(id, json);
}

void McpServer::DoToolCall(int id, const std::string& tool_name, const cJSON* tool_arguments) {
    auto tool_iter = std::find_if(tools_.begin(), tools_.end(), 
                                 [&tool_name](const McpTool* tool) { 
                                     return tool->name() == tool_name; 
                                 });
    
    if (tool_iter == tools_.end()) {
        ESP_LOGE(TAG, "tools/call: Unknown tool: %s", tool_name.c_str());
        ReplyError(id, "Unknown tool: " + tool_name);
        return;
    }

    PropertyList arguments = (*tool_iter)->properties();
    try {
        for (auto& argument : arguments) {
            bool found = false;
            if (cJSON_IsObject(tool_arguments)) {
                auto value = cJSON_GetObjectItem(tool_arguments, argument.name().c_str());
                if (argument.type() == kPropertyTypeBoolean && cJSON_IsBool(value)) {
                    argument.set_value<bool>(value->valueint == 1);
                    found = true;
                } else if (argument.type() == kPropertyTypeInteger && cJSON_IsNumber(value)) {
                    argument.set_value<int>(value->valueint);
                    found = true;
                } else if (argument.type() == kPropertyTypeString && cJSON_IsString(value)) {
                    argument.set_value<std::string>(value->valuestring);
                    found = true;
                }
            }

            if (!argument.has_default_value() && !found) {
                ESP_LOGE(TAG, "tools/call: Missing valid argument: %s", argument.name().c_str());
                ReplyError(id, "Missing valid argument: " + argument.name());
                return;
            }
        }
    } catch (const std::exception& e) {
        ESP_LOGE(TAG, "tools/call: %s", e.what());
        ReplyError(id, e.what());
        return;
    }

    // Use main thread to call the tool
    auto& app = Application::GetInstance();
    app.Schedule([this, id, tool_iter, arguments = std::move(arguments)]() {
        try {
            ReplyResult(id, (*tool_iter)->Call(arguments));
        } catch (const std::exception& e) {
            ESP_LOGE(TAG, "tools/call: %s", e.what());
            ReplyError(id, e.what());
        }
    });
}

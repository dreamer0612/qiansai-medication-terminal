#include "application.h"
#include "board.h"
#include "display.h"
#include "system_info.h"
#include "audio_codec.h"
#include "mqtt_protocol.h"
#include "websocket_protocol.h"
#include "assets/lang_config.h"
#include "mcp_server.h"
#include "assets.h"
#include "settings.h"
#include "uart_command.h"

#include <cstdio>
#include <cstring>
#include <esp_log.h>
#include <cJSON.h>
#include <driver/gpio.h>
#include <arpa/inet.h>
#include <font_awesome.h>

#define TAG "Application"

namespace {

struct ReminderTextTaskArg {
    Application* app;
    int delay_ms;
};

struct MedicineReminderLoopTaskArg {
    Application* app;
    uint32_t generation;
};

struct VitalsMeasurementTaskArg {
    Application* app;
    uint64_t sequence;
};

std::string JsonString(const cJSON* root, const char* name, const char* fallback = "") {
    auto item = cJSON_GetObjectItem(root, name);
    return cJSON_IsString(item) ? item->valuestring : fallback;
}

bool IsValidUtf8(const char* text) {
    if (text == nullptr) {
        return false;
    }

    const auto* bytes = reinterpret_cast<const uint8_t*>(text);
    size_t len = strlen(text);
    size_t i = 0;
    while (i < len) {
        if (bytes[i] <= 0x7F) {
            ++i;
        } else if ((bytes[i] & 0xE0) == 0xC0) {
            if (i + 1 >= len || (bytes[i + 1] & 0xC0) != 0x80 || bytes[i] < 0xC2) {
                return false;
            }
            i += 2;
        } else if ((bytes[i] & 0xF0) == 0xE0) {
            if (i + 2 >= len ||
                (bytes[i + 1] & 0xC0) != 0x80 ||
                (bytes[i + 2] & 0xC0) != 0x80) {
                return false;
            }
            i += 3;
        } else if ((bytes[i] & 0xF8) == 0xF0) {
            if (i + 3 >= len ||
                (bytes[i + 1] & 0xC0) != 0x80 ||
                (bytes[i + 2] & 0xC0) != 0x80 ||
                (bytes[i + 3] & 0xC0) != 0x80 ||
                bytes[i] > 0xF4) {
                return false;
            }
            i += 4;
        } else {
            return false;
        }
    }
    return true;
}

std::string JsonUtf8String(const cJSON* root, const char* name, const char* fallback = "") {
    auto item = cJSON_GetObjectItem(root, name);
    if (!cJSON_IsString(item) || item->valuestring == nullptr || item->valuestring[0] == '\0') {
        return fallback;
    }
    return IsValidUtf8(item->valuestring) ? item->valuestring : fallback;
}

int JsonInt(const cJSON* root, const char* name, int fallback = 0) {
    auto item = cJSON_GetObjectItem(root, name);
    return cJSON_IsNumber(item) ? item->valueint : fallback;
}

bool JsonBool(const cJSON* root, const char* name, bool fallback = false) {
    auto item = cJSON_GetObjectItem(root, name);
    return cJSON_IsBool(item) ? cJSON_IsTrue(item) : fallback;
}

std::string JsonToString(cJSON* json) {
    char* encoded = cJSON_PrintUnformatted(json);
    std::string result(encoded ? encoded : "{}");
    cJSON_free(encoded);
    return result;
}

bool WaitForAsyncMessageAny(const std::vector<std::string>& tools, uint64_t after_sequence,
                            int timeout_ms, std::string& tool, std::string& message) {
    int64_t deadline = esp_timer_get_time() + static_cast<int64_t>(timeout_ms) * 1000;
    while (esp_timer_get_time() < deadline) {
        for (const auto& candidate : tools) {
            if (UartCommand::GetInstance().WaitForAsyncMessage(candidate, after_sequence, 50, message)) {
                tool = candidate;
                return true;
            }
        }
        vTaskDelay(pdMS_TO_TICKS(20));
    }
    return false;
}

std::string BuildSlaveDisplayMessage(const std::string& tool, const std::string& payload) {
    cJSON* root = cJSON_Parse(payload.c_str());
    if (root == nullptr) {
        return "Starfire One: " + payload;
    }

    std::string message;
    if (tool == "measurement_ack") {
        message = "Measurement accepted: " + JsonString(root, "type", "unknown");
    } else if (tool == "measurement_result") {
        auto type = JsonString(root, "type", "unknown");
        auto status = JsonString(root, "status", "unknown");
        message = "Measurement " + type + ": " + status;
        auto heart_rate = cJSON_GetObjectItem(root, "heartRate");
        auto spo2 = cJSON_GetObjectItem(root, "spo2");
        auto body_temperature = cJSON_GetObjectItem(root, "bodyTemperature");
        if (cJSON_IsNumber(heart_rate) && cJSON_IsNumber(spo2)) {
            message += ", HR " + std::to_string(heart_rate->valueint);
            message += ", SpO2 " + std::to_string(spo2->valueint);
        } else if (cJSON_IsNumber(body_temperature)) {
            char buffer[32];
            snprintf(buffer, sizeof(buffer), "%.2f", body_temperature->valuedouble);
            message += ", temp ";
            message += buffer;
        }
    } else if (tool == "medicine_auth_ack") {
        message = "Medicine authentication accepted";
    } else if (tool == "medicine_already_taken") {
        message = "当前时间段已经服药，请勿重复服药。";
    } else if (tool == "face_auth_result") {
        message = "Face authentication: " + JsonString(root, "status", "unknown");
        auto user = JsonString(root, "user_name");
        if (!user.empty()) {
            message += ", user " + user;
        }
    } else if (tool == "medicine_box_result") {
        message = "Medicine box: " + JsonString(root, "status", "unknown");
    } else if (tool == "voice_alarm") {
        message = JsonString(root, "voice_text", "Medicine reminder");
    } else {
        message = "Starfire One message: " + tool;
    }

    cJSON_Delete(root);
    return message;
}

std::string BuildSlaveMcpNotification(const std::string& tool, const std::string& payload) {
    cJSON* root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "jsonrpc", "2.0");
    cJSON_AddStringToObject(root, "method", "notifications/message");

    cJSON* params = cJSON_CreateObject();
    cJSON_AddStringToObject(params, "level", "info");
    cJSON_AddStringToObject(params, "logger", "starfire_one");

    cJSON* data = cJSON_CreateObject();
    cJSON_AddStringToObject(data, "source", "uart");
    cJSON_AddStringToObject(data, "tool", tool.c_str());

    cJSON* payload_json = cJSON_Parse(payload.c_str());
    if (payload_json != nullptr) {
        cJSON_AddItemToObject(data, "payload", payload_json);
    } else {
        cJSON_AddStringToObject(data, "payload_raw", payload.c_str());
    }

    cJSON_AddItemToObject(params, "data", data);
    cJSON_AddItemToObject(root, "params", params);

    char* json_str = cJSON_PrintUnformatted(root);
    std::string notification(json_str ? json_str : "{}");
    cJSON_free(json_str);
    cJSON_Delete(root);
    return notification;
}

std::string BuildMedicineReminderSpeech(const std::string& payload) {
    cJSON* root = cJSON_Parse(payload.c_str());
    if (root == nullptr) {
        return "吃药时间到了，请按时服药。";
    }

    std::string user_name = JsonUtf8String(root, "user_name", "用户");
    std::string speech = user_name + "，吃药时间到了。";

    auto medicines = cJSON_GetObjectItem(root, "medicines");
    if (cJSON_IsArray(medicines) && cJSON_GetArraySize(medicines) > 0) {
        speech += "请服用";
        int count = cJSON_GetArraySize(medicines);
        for (int i = 0; i < count; ++i) {
            auto medicine = cJSON_GetArrayItem(medicines, i);
            if (!cJSON_IsObject(medicine)) {
                continue;
            }

            if (i > 0) {
                speech += "，";
            }

            auto name = cJSON_GetObjectItem(medicine, "name");
            auto box_id = cJSON_GetObjectItem(medicine, "box_id");
            auto dose_count = cJSON_GetObjectItem(medicine, "dose_count");
            if (cJSON_IsString(name) && name->valuestring[0] != '\0' && IsValidUtf8(name->valuestring)) {
                speech += name->valuestring;
            } else if (cJSON_IsNumber(box_id)) {
                speech += std::to_string(box_id->valueint) + "号药盒的药";
            } else {
                speech += "药品";
            }

            if (cJSON_IsNumber(dose_count) && dose_count->valueint > 0) {
                speech += std::to_string(dose_count->valueint) + "份";
            }
        }
        speech += "。";
    } else {
        auto voice_text = JsonUtf8String(root, "voice_text");
        if (!voice_text.empty()) {
            speech += voice_text;
        } else {
            speech += "请按时服药。";
        }
    }

    cJSON_Delete(root);
    return speech;
}

const std::string_view& LocalMedicineReminderSound() {
#ifdef HAVE_MEDICINE_REMINDER_OGG
    return Lang::Sounds::OGG_MEDICINE_REMINDER;
#else
    // Placeholder until main/assets/common/medicine_reminder.ogg is recorded.
    return Lang::Sounds::OGG_POPUP;
#endif
}

const std::string_view& LocalVitalsPrepareSound() {
#ifdef HAVE_VITALS_PREPARE_OGG
    return Lang::Sounds::OGG_VITALS_PREPARE;
#else
    return Lang::Sounds::OGG_POPUP;
#endif
}

const std::string_view& LocalVitalsStartSound() {
#ifdef HAVE_VITALS_START_OGG
    return Lang::Sounds::OGG_VITALS_START;
#else
    return Lang::Sounds::OGG_POPUP;
#endif
}

const std::string_view& LocalVitalsSuccessSound() {
#ifdef HAVE_VITALS_SUCCESS_OGG
    return Lang::Sounds::OGG_VITALS_SUCCESS;
#else
    return Lang::Sounds::OGG_SUCCESS;
#endif
}

std::string BuildMedicineReminderTextInput(const std::string& speech) {
    return "请立即直接播报以下吃药提醒，不要问候，不要询问确认，不要等待用户回复。播报内容：" + speech;
}

bool LooksLikeMedicineReminderSentence(const std::string& text, const std::string& reminder_text) {
    if (text.empty()) {
        return false;
    }
    if (!reminder_text.empty() &&
        (reminder_text.find(text) != std::string::npos || text.find(reminder_text) != std::string::npos)) {
        return true;
    }
    return text.find("吃药") != std::string::npos ||
        text.find("服药") != std::string::npos ||
        text.find("用药") != std::string::npos ||
        text.find("药时间") != std::string::npos;
}

} // namespace


Application::Application() {
    event_group_ = xEventGroupCreate();

#if CONFIG_USE_DEVICE_AEC && CONFIG_USE_SERVER_AEC
#error "CONFIG_USE_DEVICE_AEC and CONFIG_USE_SERVER_AEC cannot be enabled at the same time"
#elif CONFIG_USE_DEVICE_AEC
    aec_mode_ = kAecOnDeviceSide;
#elif CONFIG_USE_SERVER_AEC
    aec_mode_ = kAecOnServerSide;
#else
    aec_mode_ = kAecOff;
#endif

    esp_timer_create_args_t clock_timer_args = {
        .callback = [](void* arg) {
            Application* app = (Application*)arg;
            xEventGroupSetBits(app->event_group_, MAIN_EVENT_CLOCK_TICK);
        },
        .arg = this,
        .dispatch_method = ESP_TIMER_TASK,
        .name = "clock_timer",
        .skip_unhandled_events = true
    };
    esp_timer_create(&clock_timer_args, &clock_timer_handle_);
}

Application::~Application() {
    if (clock_timer_handle_ != nullptr) {
        esp_timer_stop(clock_timer_handle_);
        esp_timer_delete(clock_timer_handle_);
    }
    vEventGroupDelete(event_group_);
}

bool Application::SetDeviceState(DeviceState state) {
    return state_machine_.TransitionTo(state);
}

void Application::Initialize() {
    auto& board = Board::GetInstance();
    SetDeviceState(kDeviceStateStarting);

    // Setup the display
    auto display = board.GetDisplay();
    display->SetupUI();
    // Print board name/version info
    display->SetChatMessage("system", SystemInfo::GetUserAgent().c_str());

    // Setup the audio service
    auto codec = board.GetAudioCodec();
    audio_service_.Initialize(codec);
    audio_service_.Start();

    AudioServiceCallbacks callbacks;
    callbacks.on_send_queue_available = [this]() {
        xEventGroupSetBits(event_group_, MAIN_EVENT_SEND_AUDIO);
    };
    callbacks.on_wake_word_detected = [this](const std::string& wake_word) {
        xEventGroupSetBits(event_group_, MAIN_EVENT_WAKE_WORD_DETECTED);
    };
    callbacks.on_vad_change = [this](bool speaking) {
        xEventGroupSetBits(event_group_, MAIN_EVENT_VAD_CHANGE);
    };
    audio_service_.SetCallbacks(callbacks);

    // Add state change listeners
    state_machine_.AddStateChangeListener([this](DeviceState old_state, DeviceState new_state) {
        xEventGroupSetBits(event_group_, MAIN_EVENT_STATE_CHANGED);
    });

    // Start the clock timer to update the status bar
    esp_timer_start_periodic(clock_timer_handle_, 1000000);

    // Add MCP common tools (only once during initialization)
    auto& mcp_server = McpServer::GetInstance();
    mcp_server.AddCommonTools();
    mcp_server.AddUserOnlyTools();

#ifdef CONFIG_UART_COMMAND_ENABLED
    // Initialize UART command module
    UartCommand::GetInstance().Initialize();
    
    // Set state report callback for async state updates from slave
    UartCommand::GetInstance().SetStateReportCallback([this](const std::string& state_json) {
        ESP_LOGI(TAG, "State report from slave: %s", state_json.c_str());
        Schedule([this, state_json]() {
            auto display = Board::GetInstance().GetDisplay();
            display->ShowNotification("Starfire One state updated");

            cJSON* payload = cJSON_CreateObject();
            cJSON_AddStringToObject(payload, "tool", "state_report");
            cJSON* state = cJSON_Parse(state_json.c_str());
            if (state != nullptr) {
                cJSON_AddItemToObject(payload, "state", state);
            } else {
                cJSON_AddStringToObject(payload, "state_raw", state_json.c_str());
            }
            char* payload_str = cJSON_PrintUnformatted(payload);
            std::string message = BuildSlaveMcpNotification("state_report", payload_str ? payload_str : "{}");
            cJSON_free(payload_str);
            cJSON_Delete(payload);
            SendMcpMessage(message);
        });
    });

    UartCommand::GetInstance().SetAsyncMessageCallback([this](const std::string& tool, const std::string& payload) {
        ESP_LOGI(TAG, "Async message from slave: tool=%s, payload=%s", tool.c_str(), payload.c_str());
        bool suppress_measurement_notification =
            (tool == "measurement_ack" || tool == "measurement_result") &&
            (vitals_measurement_in_progress_.load() ||
             body_temperature_measurement_in_progress_.load());
        Schedule([this, tool, payload, suppress_measurement_notification]() {
            if (suppress_measurement_notification) {
                cJSON* root = cJSON_Parse(payload.c_str());
                if (root != nullptr) {
                    HandleMeasurementMessage(tool, root);
                    cJSON_Delete(root);
                }
                return;
            }
            if (tool == "voice_alarm") {
                cJSON* root = cJSON_Parse(payload.c_str());
                auto event = root != nullptr ? JsonString(root, "event") : "";
                auto voice_code = root != nullptr ? JsonString(root, "voice_code") : "";
                if (event == "medicine_reminder_stop" || voice_code == "STOP_MEDICINE_REMINDER") {
                    StopLocalMedicineReminderAnnouncement(root);
                } else {
                    AnnounceMedicineReminder(payload);
                }
                if (root != nullptr) {
                    cJSON_Delete(root);
                }
            } else if (tool == "voice_alarm_stop") {
                cJSON* root = cJSON_Parse(payload.c_str());
                if (root != nullptr) {
                    StopLocalMedicineReminderAnnouncement(root);
                    cJSON_Delete(root);
                } else {
                    medicine_reminder_loop_active_.store(false);
                    medicine_reminder_loop_generation_.fetch_add(1);
                    audio_service_.ResetDecoder();
                    ShowStarfireMessage("服药提醒已停止", 5000);
                }
            } else if (tool == "medicine_auth_required") {
                cJSON* root = cJSON_Parse(payload.c_str());
                if (root != nullptr) {
                    HandleMedicineAuthRequired(root);
                    cJSON_Delete(root);
                }
            } else if (tool == "medicine_already_taken") {
                cJSON* root = cJSON_Parse(payload.c_str());
                if (root != nullptr) {
                    HandleMedicineAlreadyTaken(root);
                    cJSON_Delete(root);
                } else {
                    ShowStarfireMessage("当前时间段已经服药，请勿重复服药。", 10000);
                    ResetMedicineSession();
                }
            } else {
                cJSON* root = cJSON_Parse(payload.c_str());
                auto voice_code = root != nullptr ? JsonString(root, "voice_code") : "";
                if (voice_code == "TAKE_MEDICINE") {
                    if (root != nullptr) {
                        cJSON_Delete(root);
                    }
                    AnnounceMedicineReminder(payload);
                    return;
                }
                if (voice_code == "STOP_MEDICINE_REMINDER") {
                    if (root != nullptr) {
                        StopLocalMedicineReminderAnnouncement(root);
                        cJSON_Delete(root);
                    } else {
                        medicine_reminder_loop_active_.store(false);
                        medicine_reminder_loop_generation_.fetch_add(1);
                        audio_service_.ResetDecoder();
                        ShowStarfireMessage("服药提醒已停止", 5000);
                    }
                    return;
                }
                if (root != nullptr) {
                    cJSON_Delete(root);
                }
                SendMcpMessage(BuildSlaveMcpNotification(tool, payload));
                auto message = BuildSlaveDisplayMessage(tool, payload);
                ShowStarfireMessage(message.c_str());
            }
        });
    });
#endif

    // Set network event callback for UI updates and network state handling
    board.SetNetworkEventCallback([this](NetworkEvent event, const std::string& data) {
        auto display = Board::GetInstance().GetDisplay();
        
        switch (event) {
            case NetworkEvent::Scanning:
                display->ShowNotification(Lang::Strings::SCANNING_WIFI, 30000);
                xEventGroupSetBits(event_group_, MAIN_EVENT_NETWORK_DISCONNECTED);
                break;
            case NetworkEvent::Connecting: {
                if (data.empty()) {
                    // Cellular network - registering without carrier info yet
                    display->SetStatus(Lang::Strings::REGISTERING_NETWORK);
                } else {
                    // WiFi or cellular with carrier info
                    std::string msg = Lang::Strings::CONNECT_TO;
                    msg += data;
                    msg += "...";
                    display->ShowNotification(msg.c_str(), 30000);
                }
                break;
            }
            case NetworkEvent::Connected: {
                std::string msg = Lang::Strings::CONNECTED_TO;
                msg += data;
                display->ShowNotification(msg.c_str(), 30000);
                xEventGroupSetBits(event_group_, MAIN_EVENT_NETWORK_CONNECTED);
                break;
            }
            case NetworkEvent::Disconnected:
                xEventGroupSetBits(event_group_, MAIN_EVENT_NETWORK_DISCONNECTED);
                break;
            case NetworkEvent::WifiConfigModeEnter:
                // WiFi config mode enter is handled by WifiBoard internally
                break;
            case NetworkEvent::WifiConfigModeExit:
                // WiFi config mode exit is handled by WifiBoard internally
                break;
            // Cellular modem specific events
            case NetworkEvent::ModemDetecting:
                display->SetStatus(Lang::Strings::DETECTING_MODULE);
                break;
            case NetworkEvent::ModemErrorNoSim:
                Alert(Lang::Strings::ERROR, Lang::Strings::PIN_ERROR, "triangle_exclamation", Lang::Sounds::OGG_ERR_PIN);
                break;
            case NetworkEvent::ModemErrorRegDenied:
                Alert(Lang::Strings::ERROR, Lang::Strings::REG_ERROR, "triangle_exclamation", Lang::Sounds::OGG_ERR_REG);
                break;
            case NetworkEvent::ModemErrorInitFailed:
                Alert(Lang::Strings::ERROR, Lang::Strings::MODEM_INIT_ERROR, "triangle_exclamation", Lang::Sounds::OGG_EXCLAMATION);
                break;
            case NetworkEvent::ModemErrorTimeout:
                display->SetStatus(Lang::Strings::REGISTERING_NETWORK);
                break;
        }
    });

    // Start network asynchronously
    board.StartNetwork();

    // Update the status bar immediately to show the network state
    display->UpdateStatusBar(true);
}

void Application::Run() {
    // Set the priority of the main task to 10
    vTaskPrioritySet(nullptr, 10);

    const EventBits_t ALL_EVENTS = 
        MAIN_EVENT_SCHEDULE |
        MAIN_EVENT_SEND_AUDIO |
        MAIN_EVENT_WAKE_WORD_DETECTED |
        MAIN_EVENT_VAD_CHANGE |
        MAIN_EVENT_CLOCK_TICK |
        MAIN_EVENT_ERROR |
        MAIN_EVENT_NETWORK_CONNECTED |
        MAIN_EVENT_NETWORK_DISCONNECTED |
        MAIN_EVENT_TOGGLE_CHAT |
        MAIN_EVENT_START_LISTENING |
        MAIN_EVENT_STOP_LISTENING |
        MAIN_EVENT_ACTIVATION_DONE |
        MAIN_EVENT_STATE_CHANGED;

    while (true) {
        auto bits = xEventGroupWaitBits(event_group_, ALL_EVENTS, pdTRUE, pdFALSE, portMAX_DELAY);

        if (bits & MAIN_EVENT_ERROR) {
            SetDeviceState(kDeviceStateIdle);
            Alert(Lang::Strings::ERROR, last_error_message_.c_str(), "circle_xmark", Lang::Sounds::OGG_EXCLAMATION);
        }

        if (bits & MAIN_EVENT_NETWORK_CONNECTED) {
            HandleNetworkConnectedEvent();
        }

        if (bits & MAIN_EVENT_NETWORK_DISCONNECTED) {
            HandleNetworkDisconnectedEvent();
        }

        if (bits & MAIN_EVENT_ACTIVATION_DONE) {
            HandleActivationDoneEvent();
        }

        if (bits & MAIN_EVENT_STATE_CHANGED) {
            HandleStateChangedEvent();
        }

        if (bits & MAIN_EVENT_TOGGLE_CHAT) {
            HandleToggleChatEvent();
        }

        if (bits & MAIN_EVENT_START_LISTENING) {
            HandleStartListeningEvent();
        }

        if (bits & MAIN_EVENT_STOP_LISTENING) {
            HandleStopListeningEvent();
        }

        if (bits & MAIN_EVENT_SEND_AUDIO) {
            while (auto packet = audio_service_.PopPacketFromSendQueue()) {
                if (protocol_ && !protocol_->SendAudio(std::move(packet))) {
                    break;
                }
            }
        }

        if (bits & MAIN_EVENT_WAKE_WORD_DETECTED) {
            HandleWakeWordDetectedEvent();
        }

        if (bits & MAIN_EVENT_VAD_CHANGE) {
            if (GetDeviceState() == kDeviceStateListening) {
                auto led = Board::GetInstance().GetLed();
                led->OnStateChanged();
            }
        }

        if (bits & MAIN_EVENT_SCHEDULE) {
            std::unique_lock<std::mutex> lock(mutex_);
            auto tasks = std::move(main_tasks_);
            lock.unlock();
            for (auto& task : tasks) {
                task();
            }
        }

        if (bits & MAIN_EVENT_CLOCK_TICK) {
            clock_ticks_++;
            auto display = Board::GetInstance().GetDisplay();
            display->UpdateStatusBar();
        
            // Print debug info every 10 seconds
            if (clock_ticks_ % 10 == 0) {
                SystemInfo::PrintHeapStats();
            }
        }
    }
}

void Application::HandleNetworkConnectedEvent() {
    ESP_LOGI(TAG, "Network connected");
    auto state = GetDeviceState();

    if (state == kDeviceStateStarting || state == kDeviceStateWifiConfiguring) {
        // Network is ready, start activation
        SetDeviceState(kDeviceStateActivating);
        if (activation_task_handle_ != nullptr) {
            ESP_LOGW(TAG, "Activation task already running");
            return;
        }

        xTaskCreate([](void* arg) {
            Application* app = static_cast<Application*>(arg);
            app->ActivationTask();
            app->activation_task_handle_ = nullptr;
            vTaskDelete(NULL);
        }, "activation", 4096 * 2, this, 2, &activation_task_handle_);
    }

    // Update the status bar immediately to show the network state
    auto display = Board::GetInstance().GetDisplay();
    display->UpdateStatusBar(true);
}

void Application::HandleNetworkDisconnectedEvent() {
    // Close current conversation when network disconnected
    auto state = GetDeviceState();
    if (state == kDeviceStateConnecting || state == kDeviceStateListening || state == kDeviceStateSpeaking) {
        ESP_LOGI(TAG, "Closing audio channel due to network disconnection");
        protocol_->CloseAudioChannel();
    }

    // Update the status bar immediately to show the network state
    auto display = Board::GetInstance().GetDisplay();
    display->UpdateStatusBar(true);
}

void Application::HandleActivationDoneEvent() {
    ESP_LOGI(TAG, "Activation done");

    SystemInfo::PrintHeapStats();
    SetDeviceState(kDeviceStateIdle);

    has_server_time_ = ota_->HasServerTime();

    auto display = Board::GetInstance().GetDisplay();
    std::string message = std::string(Lang::Strings::VERSION) + ota_->GetCurrentVersion();
    display->ShowNotification(message.c_str());
    display->SetChatMessage("system", "");

    // Release OTA object after activation is complete
    ota_.reset();
    auto& board = Board::GetInstance();
    board.SetPowerSaveLevel(PowerSaveLevel::LOW_POWER);

    Schedule([this]() {
        // Play the success sound to indicate the device is ready
        audio_service_.PlaySound(Lang::Sounds::OGG_SUCCESS);
    });
}

void Application::ActivationTask() {
    // Create OTA object for activation process
    ota_ = std::make_unique<Ota>();

    // Check for new assets version
    CheckAssetsVersion();

    // Check for new firmware version
    CheckNewVersion();

    // Initialize the protocol
    InitializeProtocol();

    // Signal completion to main loop
    xEventGroupSetBits(event_group_, MAIN_EVENT_ACTIVATION_DONE);
}

void Application::CheckAssetsVersion() {
    // Only allow CheckAssetsVersion to be called once
    if (assets_version_checked_) {
        return;
    }
    assets_version_checked_ = true;

    auto& board = Board::GetInstance();
    auto display = board.GetDisplay();
    auto& assets = Assets::GetInstance();

    if (!assets.partition_valid()) {
        ESP_LOGW(TAG, "Assets partition is disabled for board %s", BOARD_NAME);
        return;
    }
    
    Settings settings("assets", true);
    // Check if there is a new assets need to be downloaded
    std::string download_url = settings.GetString("download_url");

    if (!download_url.empty()) {
        settings.EraseKey("download_url");

        char message[256];
        snprintf(message, sizeof(message), Lang::Strings::FOUND_NEW_ASSETS, download_url.c_str());
        Alert(Lang::Strings::LOADING_ASSETS, message, "cloud_arrow_down", Lang::Sounds::OGG_UPGRADE);
        
        // Wait for the audio service to be idle for 3 seconds
        vTaskDelay(pdMS_TO_TICKS(3000));
        SetDeviceState(kDeviceStateUpgrading);
        board.SetPowerSaveLevel(PowerSaveLevel::PERFORMANCE);
        display->SetChatMessage("system", Lang::Strings::PLEASE_WAIT);

        bool success = assets.Download(download_url, [this, display](int progress, size_t speed) -> void {
            char buffer[32];
            snprintf(buffer, sizeof(buffer), "%d%% %uKB/s", progress, speed / 1024);
            Schedule([display, message = std::string(buffer)]() {
                display->SetChatMessage("system", message.c_str());
            });
        });

        board.SetPowerSaveLevel(PowerSaveLevel::LOW_POWER);
        vTaskDelay(pdMS_TO_TICKS(1000));

        if (!success) {
            Alert(Lang::Strings::ERROR, Lang::Strings::DOWNLOAD_ASSETS_FAILED, "circle_xmark", Lang::Sounds::OGG_EXCLAMATION);
            vTaskDelay(pdMS_TO_TICKS(2000));
            SetDeviceState(kDeviceStateActivating);
            return;
        }
    }

    // Apply assets
    assets.Apply();
    display->SetChatMessage("system", "");
    display->SetEmotion("microchip_ai");
}

void Application::CheckNewVersion() {
    const int MAX_RETRY = 10;
    int retry_count = 0;
    int retry_delay = 10; // Initial retry delay in seconds

    auto& board = Board::GetInstance();
    while (true) {
        auto display = board.GetDisplay();
        display->SetStatus(Lang::Strings::CHECKING_NEW_VERSION);

        esp_err_t err = ota_->CheckVersion();
        if (err != ESP_OK) {
            retry_count++;
            if (retry_count >= MAX_RETRY) {
                ESP_LOGE(TAG, "Too many retries, exit version check");
                return;
            }

            char error_message[128];
            snprintf(error_message, sizeof(error_message), "code=%d, url=%s", err, ota_->GetCheckVersionUrl().c_str());
            char buffer[256];
            snprintf(buffer, sizeof(buffer), Lang::Strings::CHECK_NEW_VERSION_FAILED, retry_delay, error_message);
            Alert(Lang::Strings::ERROR, buffer, "cloud_slash", Lang::Sounds::OGG_EXCLAMATION);

            ESP_LOGW(TAG, "Check new version failed, retry in %d seconds (%d/%d)", retry_delay, retry_count, MAX_RETRY);
            for (int i = 0; i < retry_delay; i++) {
                vTaskDelay(pdMS_TO_TICKS(1000));
                if (GetDeviceState() == kDeviceStateIdle) {
                    break;
                }
            }
            retry_delay *= 2; // Double the retry delay
            continue;
        }
        retry_count = 0;
        retry_delay = 10; // Reset retry delay

        if (ota_->HasNewVersion()) {
            if (UpgradeFirmware(ota_->GetFirmwareUrl(), ota_->GetFirmwareVersion())) {
                return; // This line will never be reached after reboot
            }
            // If upgrade failed, continue to normal operation
        }

        // No new version, mark the current version as valid
        ota_->MarkCurrentVersionValid();
        if (!ota_->HasActivationCode() && !ota_->HasActivationChallenge()) {
            // Exit the loop if done checking new version
            break;
        }

        display->SetStatus(Lang::Strings::ACTIVATION);
        // Activation code is shown to the user and waiting for the user to input
        if (ota_->HasActivationCode()) {
            ShowActivationCode(ota_->GetActivationCode(), ota_->GetActivationMessage());
        }

        // This will block the loop until the activation is done or timeout
        for (int i = 0; i < 10; ++i) {
            ESP_LOGI(TAG, "Activating... %d/%d", i + 1, 10);
            esp_err_t err = ota_->Activate();
            if (err == ESP_OK) {
                break;
            } else if (err == ESP_ERR_TIMEOUT) {
                vTaskDelay(pdMS_TO_TICKS(3000));
            } else {
                vTaskDelay(pdMS_TO_TICKS(10000));
            }
            if (GetDeviceState() == kDeviceStateIdle) {
                break;
            }
        }
    }
}

void Application::InitializeProtocol() {
    auto& board = Board::GetInstance();
    auto display = board.GetDisplay();
    auto codec = board.GetAudioCodec();

    display->SetStatus(Lang::Strings::LOADING_PROTOCOL);

    if (ota_->HasMqttConfig()) {
        protocol_ = std::make_unique<MqttProtocol>();
    } else if (ota_->HasWebsocketConfig()) {
        protocol_ = std::make_unique<WebsocketProtocol>();
    } else {
        ESP_LOGW(TAG, "No protocol specified in the OTA config, using MQTT");
        protocol_ = std::make_unique<MqttProtocol>();
    }

    protocol_->OnConnected([this]() {
        DismissAlert();
    });

    protocol_->OnNetworkError([this](const std::string& message) {
        last_error_message_ = message;
        xEventGroupSetBits(event_group_, MAIN_EVENT_ERROR);
    });
    
    protocol_->OnIncomingAudio([this](std::unique_ptr<AudioStreamPacket> packet) {
        if (GetDeviceState() == kDeviceStateSpeaking) {
            audio_service_.PushPacketToDecodeQueue(std::move(packet));
        }
    });
    
    protocol_->OnAudioChannelOpened([this, codec, &board]() {
        board.SetPowerSaveLevel(PowerSaveLevel::PERFORMANCE);
        if (protocol_->server_sample_rate() != codec->output_sample_rate()) {
            ESP_LOGW(TAG, "Server sample rate %d does not match device output sample rate %d, resampling may cause distortion",
                protocol_->server_sample_rate(), codec->output_sample_rate());
        }
    });
    
    protocol_->OnAudioChannelClosed([this, &board]() {
        board.SetPowerSaveLevel(PowerSaveLevel::LOW_POWER);
        Schedule([this]() {
            auto display = Board::GetInstance().GetDisplay();
            display->SetChatMessage("system", "");
            SetDeviceState(kDeviceStateIdle);
        });
    });
    
    protocol_->OnIncomingJson([this, display](const cJSON* root) {
        // Parse JSON data
        auto type = cJSON_GetObjectItem(root, "type");
        if (strcmp(type->valuestring, "tts") == 0) {
            auto state = cJSON_GetObjectItem(root, "state");
            if (strcmp(state->valuestring, "start") == 0) {
                Schedule([this]() {
                    if (proactive_reminder_active_ &&
                        proactive_reminder_waiting_greeting_tts_ &&
                        !proactive_reminder_text_sent_) {
                        ESP_LOGI(TAG, "Wake greeting TTS started, waiting for sentence_start to skip it");
                        aborted_ = false;
                        SetDeviceState(kDeviceStateSpeaking);
                        return;
                    }
                    if (proactive_reminder_active_ && proactive_reminder_text_sent_) {
                        proactive_reminder_tts_started_ = true;
                    }
                    aborted_ = false;
                    SetDeviceState(kDeviceStateSpeaking);
                });
            } else if (strcmp(state->valuestring, "stop") == 0) {
                Schedule([this]() {
                    if (proactive_reminder_active_ &&
                        proactive_reminder_text_sent_ &&
                        proactive_reminder_tts_started_) {
                        ESP_LOGI(TAG, "Proactive medicine reminder TTS finished");
                        proactive_reminder_active_ = false;
                        proactive_reminder_waiting_greeting_tts_ = false;
                        proactive_reminder_send_after_greeting_stop_ = false;
                        proactive_reminder_text_sent_ = false;
                        proactive_reminder_tts_started_ = false;
                        proactive_reminder_text_send_attempts_ = 0;
                        proactive_reminder_text_.clear();
                        SetDeviceState(kDeviceStateIdle);
                        return;
                    }
                    if (proactive_reminder_active_ &&
                        proactive_reminder_send_after_greeting_stop_ &&
                        !proactive_reminder_text_sent_) {
                        proactive_reminder_send_after_greeting_stop_ = false;
                        ESP_LOGI(TAG, "Greeting tts.stop received, schedule proactive reminder text");
                        ScheduleProactiveReminderText(300);
                        return;
                    }
                    if (proactive_reminder_active_ &&
                        proactive_reminder_text_sent_ &&
                        !proactive_reminder_tts_started_) {
                        ESP_LOGI(TAG, "Ignore stale greeting tts.stop during proactive reminder");
                        return;
                    }
                    if (proactive_reminder_active_ &&
                        proactive_reminder_waiting_greeting_tts_ &&
                        !proactive_reminder_text_sent_) {
                        ESP_LOGI(TAG, "Ignore greeting tts.stop before proactive reminder text is sent");
                        return;
                    }
                    if (GetDeviceState() == kDeviceStateSpeaking) {
                        if (listening_mode_ == kListeningModeManualStop) {
                            SetDeviceState(kDeviceStateIdle);
                        } else {
                            SetDeviceState(kDeviceStateListening);
                        }
                    }
                });
            } else if (strcmp(state->valuestring, "sentence_start") == 0) {
                auto text = cJSON_GetObjectItem(root, "text");
                if (cJSON_IsString(text)) {
                    ESP_LOGI(TAG, "<< %s", text->valuestring);
                    Schedule([this, display, message = std::string(text->valuestring)]() {
                        if (proactive_reminder_active_ &&
                            proactive_reminder_waiting_greeting_tts_ &&
                            !proactive_reminder_text_sent_) {
                            proactive_reminder_waiting_greeting_tts_ = false;
                            proactive_reminder_send_after_greeting_stop_ = true;
                            proactive_reminder_text_sent_ = false;
                            proactive_reminder_tts_started_ = false;
                            ESP_LOGI(TAG, "Skip wake greeting sentence, wait for tts.stop before reminder text");
                            if (protocol_) {
                                protocol_->SendAbortSpeaking(kAbortReasonNone);
                                SetDeviceState(kDeviceStateListening);
                            }
                            return;
                        }
                        if (proactive_reminder_active_ &&
                            proactive_reminder_text_sent_ &&
                            !proactive_reminder_tts_started_ &&
                            LooksLikeMedicineReminderSentence(message, proactive_reminder_text_)) {
                            ESP_LOGI(TAG, "Proactive medicine reminder sentence started");
                            proactive_reminder_tts_started_ = true;
                            aborted_ = false;
                            SetDeviceState(kDeviceStateSpeaking);
                        }
                        display->SetChatMessage("assistant", message.c_str());
                    });
                }
            }
        } else if (strcmp(type->valuestring, "stt") == 0) {
            auto text = cJSON_GetObjectItem(root, "text");
            if (cJSON_IsString(text)) {
                ESP_LOGI(TAG, ">> %s", text->valuestring);
                Schedule([display, message = std::string(text->valuestring)]() {
                    display->SetChatMessage("user", message.c_str());
                });
            }
        } else if (strcmp(type->valuestring, "llm") == 0) {
            auto emotion = cJSON_GetObjectItem(root, "emotion");
            if (cJSON_IsString(emotion)) {
                Schedule([display, emotion_str = std::string(emotion->valuestring)]() {
                    display->SetEmotion(emotion_str.c_str());
                });
            }
        } else if (strcmp(type->valuestring, "mcp") == 0) {
            auto payload = cJSON_GetObjectItem(root, "payload");
            if (cJSON_IsObject(payload)) {
                McpServer::GetInstance().ParseMessage(payload);
            }
        } else if (strcmp(type->valuestring, "system") == 0) {
            auto command = cJSON_GetObjectItem(root, "command");
            if (cJSON_IsString(command)) {
                ESP_LOGI(TAG, "System command: %s", command->valuestring);
                if (strcmp(command->valuestring, "reboot") == 0) {
                    // Do a reboot if user requests a OTA update
                    Schedule([this]() {
                        Reboot();
                    });
                } else {
                    ESP_LOGW(TAG, "Unknown system command: %s", command->valuestring);
                }
            }
        } else if (strcmp(type->valuestring, "alert") == 0) {
            auto status = cJSON_GetObjectItem(root, "status");
            auto message = cJSON_GetObjectItem(root, "message");
            auto emotion = cJSON_GetObjectItem(root, "emotion");
            if (cJSON_IsString(status) && cJSON_IsString(message) && cJSON_IsString(emotion)) {
                Alert(status->valuestring, message->valuestring, emotion->valuestring, Lang::Sounds::OGG_VIBRATION);
            } else {
                ESP_LOGW(TAG, "Alert command requires status, message and emotion");
            }
#if CONFIG_RECEIVE_CUSTOM_MESSAGE
        } else if (strcmp(type->valuestring, "custom") == 0) {
            auto payload = cJSON_GetObjectItem(root, "payload");
            char* root_str = cJSON_PrintUnformatted(root);
            ESP_LOGI(TAG, "Received custom message: %s", root_str ? root_str : "{}");
            cJSON_free(root_str);
            if (cJSON_IsObject(payload)) {
                char* payload_raw = cJSON_PrintUnformatted(payload);
                std::string payload_str(payload_raw ? payload_raw : "{}");
                cJSON_free(payload_raw);
                Schedule([display, payload_str]() {
                    display->SetChatMessage("system", payload_str.c_str());
                });
            } else {
                ESP_LOGW(TAG, "Invalid custom message format: missing payload");
            }
#endif
        } else {
            ESP_LOGW(TAG, "Unknown message type: %s", type->valuestring);
        }
    });
    
    protocol_->Start();
}

void Application::ShowActivationCode(const std::string& code, const std::string& message) {
    struct digit_sound {
        char digit;
        const std::string_view& sound;
    };
    static const std::array<digit_sound, 10> digit_sounds{{
        digit_sound{'0', Lang::Sounds::OGG_0},
        digit_sound{'1', Lang::Sounds::OGG_1}, 
        digit_sound{'2', Lang::Sounds::OGG_2},
        digit_sound{'3', Lang::Sounds::OGG_3},
        digit_sound{'4', Lang::Sounds::OGG_4},
        digit_sound{'5', Lang::Sounds::OGG_5},
        digit_sound{'6', Lang::Sounds::OGG_6},
        digit_sound{'7', Lang::Sounds::OGG_7},
        digit_sound{'8', Lang::Sounds::OGG_8},
        digit_sound{'9', Lang::Sounds::OGG_9}
    }};

    // This sentence uses 9KB of SRAM, so we need to wait for it to finish
    Alert(Lang::Strings::ACTIVATION, message.c_str(), "link", Lang::Sounds::OGG_ACTIVATION);

    for (const auto& digit : code) {
        auto it = std::find_if(digit_sounds.begin(), digit_sounds.end(),
            [digit](const digit_sound& ds) { return ds.digit == digit; });
        if (it != digit_sounds.end()) {
            audio_service_.PlaySound(it->sound);
        }
    }
}

void Application::Alert(const char* status, const char* message, const char* emotion, const std::string_view& sound) {
    ESP_LOGW(TAG, "Alert [%s] %s: %s", emotion, status, message);
    auto display = Board::GetInstance().GetDisplay();
    display->SetStatus(status);
    display->SetEmotion(emotion);
    display->SetChatMessage("system", message);
    if (!sound.empty()) {
        audio_service_.PlaySound(sound);
    }
}

void Application::DismissAlert() {
    if (GetDeviceState() == kDeviceStateIdle) {
        auto display = Board::GetInstance().GetDisplay();
        display->SetStatus(Lang::Strings::STANDBY);
        display->SetEmotion("neutral");
        display->SetChatMessage("system", "");
    }
}

void Application::ToggleChatState() {
    xEventGroupSetBits(event_group_, MAIN_EVENT_TOGGLE_CHAT);
}

void Application::StartListening() {
    xEventGroupSetBits(event_group_, MAIN_EVENT_START_LISTENING);
}

void Application::StopListening() {
    xEventGroupSetBits(event_group_, MAIN_EVENT_STOP_LISTENING);
}

void Application::AnnounceMedicineReminder(const std::string& payload) {
    auto speech = BuildMedicineReminderSpeech(payload);
    PlayLocalMedicineReminderAnnouncement(speech);
}

void Application::PlayLocalMedicineReminderAnnouncement(const std::string& message) {
    auto display = Board::GetInstance().GetDisplay();
    display->ShowNotification(message.c_str(), 10000);
    display->SetChatMessage("system", message.c_str());

    auto state = GetDeviceState();
    if (state == kDeviceStateActivating ||
        state == kDeviceStateUpgrading ||
        state == kDeviceStateWifiConfiguring ||
        state == kDeviceStateAudioTesting ||
        state == kDeviceStateFatalError) {
        ESP_LOGW(TAG, "Skip local medicine reminder sound in state: %d", state);
        return;
    }

    if (state == kDeviceStateSpeaking) {
        AbortSpeaking(kAbortReasonNone);
    }

    uint32_t generation = medicine_reminder_loop_generation_.fetch_add(1) + 1;
    if (medicine_reminder_loop_active_.exchange(true)) {
        ESP_LOGI(TAG, "Restart local medicine reminder loop");
        audio_service_.ResetDecoder();
    } else {
        ESP_LOGI(TAG, "Start local medicine reminder loop");
    }

    audio_service_.PlaySound(LocalMedicineReminderSound());
    ScheduleLocalMedicineReminderLoop(generation);
}

void Application::ScheduleLocalMedicineReminderLoop(uint32_t generation) {
    auto* task_arg = new MedicineReminderLoopTaskArg{this, generation};
    BaseType_t task_ret = xTaskCreate([](void* arg) {
        auto* task_arg = static_cast<MedicineReminderLoopTaskArg*>(arg);
        auto app = task_arg->app;
        uint32_t generation = task_arg->generation;
        delete task_arg;

        while (app->medicine_reminder_loop_active_.load() &&
               app->medicine_reminder_loop_generation_.load() == generation) {
            vTaskDelay(pdMS_TO_TICKS(4000));
            if (!app->medicine_reminder_loop_active_.load() ||
                app->medicine_reminder_loop_generation_.load() != generation) {
                break;
            }
            app->Schedule([app, generation]() {
                if (app->medicine_reminder_loop_active_.load() &&
                    app->medicine_reminder_loop_generation_.load() == generation) {
                    app->audio_service_.PlaySound(LocalMedicineReminderSound());
                }
            });
        }
        vTaskDelete(nullptr);
    }, "med_remind_loop", 4096, task_arg, 5, nullptr);
    if (task_ret != pdPASS) {
        delete task_arg;
        medicine_reminder_loop_active_.store(false);
        ESP_LOGE(TAG, "Failed to start local medicine reminder loop");
    }
}

void Application::StopLocalMedicineReminderAnnouncement(const cJSON* root) {
    int plan_slot = JsonInt(root, "plan_slot", JsonInt(root, "slot", 0));
    auto reason = JsonString(root, "reason", "unknown");
    ESP_LOGI(TAG, "Stop local medicine reminder loop: plan_slot=%d, reason=%s",
             plan_slot, reason.c_str());
    medicine_reminder_loop_active_.store(false);
    medicine_reminder_loop_generation_.fetch_add(1);
    audio_service_.ResetDecoder();
    ShowStarfireMessage("服药提醒已停止", 5000);
}

void Application::ContinueMedicineReminderWake(const std::string& speech) {
    auto state = GetDeviceState();
    if (state != kDeviceStateConnecting &&
        state != kDeviceStateIdle &&
        state != kDeviceStateListening &&
        state != kDeviceStateSpeaking) {
        ESP_LOGW(TAG, "Skip medicine reminder wake in state: %d", state);
        return;
    }

    if (!protocol_) {
        return;
    }

    if (!protocol_->IsAudioChannelOpened()) {
        if (!protocol_->OpenAudioChannel()) {
            audio_service_.EnableWakeWordDetection(true);
            SetDeviceState(kDeviceStateIdle);
            return;
        }
    }

    if (state == kDeviceStateSpeaking) {
        AbortSpeaking(kAbortReasonNone);
    }

    ESP_LOGI(TAG, "Medicine reminder wakes assistant with virtual wake word");
    proactive_reminder_active_ = true;
    proactive_reminder_waiting_greeting_tts_ = true;
    proactive_reminder_send_after_greeting_stop_ = false;
    proactive_reminder_text_sent_ = false;
    proactive_reminder_tts_started_ = false;
    proactive_reminder_text_send_attempts_ = 0;
    proactive_reminder_text_ = BuildMedicineReminderTextInput(speech);

    SetListeningMode(kListeningModeManualStop);
    protocol_->SendWakeWordDetected("你好小智");
}

void Application::ScheduleProactiveReminderText(int delay_ms) {
    auto* task_arg = new ReminderTextTaskArg{this, delay_ms};
    xTaskCreate([](void* arg) {
        auto* task_arg = static_cast<ReminderTextTaskArg*>(arg);
        auto app = task_arg->app;
        int delay_ms = task_arg->delay_ms;
        delete task_arg;
        vTaskDelay(pdMS_TO_TICKS(delay_ms > 0 ? delay_ms : 1));
        app->Schedule([app]() {
            app->SendProactiveReminderText();
        });
        vTaskDelete(nullptr);
    }, "reminder_text", 4096, task_arg, 5, nullptr);
}

void Application::SendProactiveReminderText() {
    if (!protocol_) {
        return;
    }
    if (!proactive_reminder_active_ || proactive_reminder_tts_started_) {
        return;
    }
    if (proactive_reminder_text_sent_ && proactive_reminder_text_send_attempts_ > 0) {
        return;
    }

    proactive_reminder_text_sent_ = true;
    proactive_reminder_tts_started_ = false;
    ++proactive_reminder_text_send_attempts_;
    ESP_LOGI(TAG, "Stop listening before proactive reminder text, attempt=%d", proactive_reminder_text_send_attempts_);
    protocol_->SendStopListening();
    audio_service_.EnableVoiceProcessing(false);
    SetDeviceState(kDeviceStateIdle);

    xTaskCreate([](void* arg) {
        auto app = static_cast<Application*>(arg);
        vTaskDelay(pdMS_TO_TICKS(150));
        app->Schedule([app]() {
            if (!app->protocol_ ||
                !app->proactive_reminder_active_ ||
                app->proactive_reminder_tts_started_) {
                return;
            }
            ESP_LOGI(TAG, "Restart listening before proactive reminder text");
            app->SetListeningMode(kListeningModeManualStop);
        });
        vTaskDelay(pdMS_TO_TICKS(250));
        app->Schedule([app]() {
            if (!app->protocol_ ||
                !app->proactive_reminder_active_ ||
                app->proactive_reminder_tts_started_) {
                return;
            }
            ESP_LOGI(TAG, "Send proactive reminder text after listening restart");
            app->protocol_->SendTextInput(app->proactive_reminder_text_);
        });
        vTaskDelay(pdMS_TO_TICKS(1500));
        app->Schedule([app]() {
            app->CheckProactiveReminderTextResponse();
        });
        vTaskDelete(nullptr);
    }, "reminder_retry", 4096, this, 5, nullptr);
}

void Application::CheckProactiveReminderTextResponse() {
    if (!proactive_reminder_active_ ||
        proactive_reminder_tts_started_ ||
        proactive_reminder_text_send_attempts_ >= 2) {
        return;
    }
    ESP_LOGW(TAG, "No proactive reminder TTS after text input, retry");
    proactive_reminder_text_sent_ = false;
    ScheduleProactiveReminderText(1);
}

void Application::ShowStarfireMessage(const char* message, int timeout_ms) {
    auto display = Board::GetInstance().GetDisplay();
    display->ShowNotification(message, timeout_ms);
    display->SetChatMessage("system", message);
}

void Application::ResetMedicineSession() {
    std::lock_guard<std::mutex> lock(medicine_mutex_);
    medicine_flow_state_ = MedicineFlowState::kIdle;
    medicine_flow_mode_ = "take";
    current_medicine_plan_slot_ = 0;
    current_medicine_box_id_ = 0;
    current_medicine_index_ = 0;
    current_put_mode_.clear();
    current_medicines_.clear();
}

bool Application::SendMedicineFlowAcknowledgement(const std::string& command, int plan_slot) {
#ifndef CONFIG_UART_COMMAND_ENABLED
    ESP_LOGW(TAG, "Cannot send %s: UART command support is disabled", command.c_str());
    return false;
#else
    bool auth_prompt = command == "medicine_auth_prompt_done";
    bool face_prompt = command == "face_auth_broadcast_done" ||
        command == "face_auth_result_announced" || command == "face_auth_success_announced";
    if (!auth_prompt && !face_prompt) {
        ESP_LOGW(TAG, "Unsupported medicine acknowledgement: %s", command.c_str());
        return false;
    }
    {
        std::lock_guard<std::mutex> lock(medicine_mutex_);
        if (plan_slot <= 0) {
            plan_slot = current_medicine_plan_slot_;
        }
    }
    if (plan_slot <= 0) {
        return false;
    }
    cJSON* args = cJSON_CreateObject();
    cJSON_AddNumberToObject(args, "plan_slot", plan_slot);
    auto payload = JsonToString(args);
    cJSON_Delete(args);
    bool success = UartCommand::GetInstance().SendJsonCommand(command, payload);
    if (success) {
        std::lock_guard<std::mutex> lock(medicine_mutex_);
        current_medicine_plan_slot_ = plan_slot;
        medicine_flow_state_ = auth_prompt ? MedicineFlowState::kWaitFaceResult :
            MedicineFlowState::kWaitMedicinePlan;
    }
    return success;
#endif
}

bool Application::SendMedicineOpenRequest(int plan_slot, int box_id) {
#ifndef CONFIG_UART_COMMAND_ENABLED
    return false;
#else
    if (plan_slot <= 0 || box_id <= 0) {
        return false;
    }
    cJSON* args = cJSON_CreateObject();
    cJSON_AddNumberToObject(args, "plan_slot", plan_slot);
    cJSON_AddNumberToObject(args, "box_id", box_id);
    auto payload = JsonToString(args);
    cJSON_Delete(args);
    bool success = UartCommand::GetInstance().SendJsonCommand("medicine_open_request", payload);
    if (success) {
        std::lock_guard<std::mutex> lock(medicine_mutex_);
        medicine_flow_state_ = MedicineFlowState::kWaitBoxOpened;
        current_medicine_plan_slot_ = plan_slot;
        current_medicine_box_id_ = box_id;
    }
    return success;
#endif
}

bool Application::SendMedicineTakenDone(int plan_slot, int box_id) {
#ifndef CONFIG_UART_COMMAND_ENABLED
    return false;
#else
    {
        std::lock_guard<std::mutex> lock(medicine_mutex_);
        if (plan_slot <= 0) plan_slot = current_medicine_plan_slot_;
        if (box_id <= 0) box_id = current_medicine_box_id_;
    }
    if (plan_slot <= 0 || box_id <= 0) {
        return false;
    }
    cJSON* args = cJSON_CreateObject();
    cJSON_AddNumberToObject(args, "plan_slot", plan_slot);
    cJSON_AddNumberToObject(args, "box_id", box_id);
    auto payload = JsonToString(args);
    cJSON_Delete(args);
    bool success = UartCommand::GetInstance().SendJsonCommand("medicine_taken_done", payload);
    if (success) {
        std::lock_guard<std::mutex> lock(medicine_mutex_);
        medicine_flow_state_ = MedicineFlowState::kWaitBoxClosed;
        current_medicine_plan_slot_ = plan_slot;
        current_medicine_box_id_ = box_id;
    }
    return success;
#endif
}

cJSON* Application::AuthenticateMedicineUser(int requested_plan_slot) {
    cJSON* result = cJSON_CreateObject();
#ifndef CONFIG_UART_COMMAND_ENABLED
    cJSON_AddStringToObject(result, "status", "uart_disabled");
    return result;
#else
    ResetMedicineSession();
    ShowStarfireMessage("正在确认用药计划", 30000);

    cJSON* args = cJSON_CreateObject();
    if (requested_plan_slot > 0) {
        cJSON_AddNumberToObject(args, "plan_slot", requested_plan_slot);
    }
    auto payload = JsonToString(args);
    cJSON_Delete(args);

    auto sequence = UartCommand::GetInstance().GetAsyncMessageSequence();
    if (!UartCommand::GetInstance().SendJsonCommand("take_medicine", payload)) {
        cJSON_AddStringToObject(result, "status", "send_failed");
        return result;
    }
    {
        std::lock_guard<std::mutex> lock(medicine_mutex_);
        medicine_flow_mode_ = "take";
        medicine_flow_state_ = MedicineFlowState::kWaitAuthAck;
    }

    std::string message;
    std::string message_tool;
    if (!WaitForAsyncMessageAny({"medicine_auth_ack", "medicine_already_taken"}, sequence, 10000,
                                message_tool, message)) {
        cJSON_AddStringToObject(result, "status", "auth_ack_timeout");
        ShowStarfireMessage("药盒无响应，请稍后重试");
        ResetMedicineSession();
        return result;
    }

    if (message_tool == "medicine_already_taken") {
        cJSON* already_taken = cJSON_Parse(message.c_str());
        if (already_taken != nullptr) {
            HandleMedicineAlreadyTaken(already_taken);
            int plan_slot = JsonInt(already_taken, "plan_slot", JsonInt(already_taken, "slot", requested_plan_slot));
            int box_id = JsonInt(already_taken, "box_id", 0);
            cJSON_AddNumberToObject(result, "plan_slot", plan_slot);
            cJSON_AddNumberToObject(result, "slot", plan_slot);
            cJSON_AddNumberToObject(result, "box_id", box_id);
            cJSON_Delete(already_taken);
        } else {
            ShowStarfireMessage("当前时间段已经服药，请勿重复服药。", 10000);
            ResetMedicineSession();
        }
        cJSON_AddStringToObject(result, "status", "already_taken");
        cJSON_AddBoolToObject(result, "taken", true);
        cJSON_AddStringToObject(result, "speech", "当前时间段已经服药，请勿重复服药。");
        return result;
    }

    cJSON* auth_ack = cJSON_Parse(message.c_str());
    auto auth_status = JsonString(auth_ack, "status");
    int plan_slot = JsonInt(auth_ack, "plan_slot", JsonInt(auth_ack, "slot", requested_plan_slot));
    cJSON_Delete(auth_ack);
    if (auth_status != "accepted" || plan_slot <= 0) {
        cJSON_AddStringToObject(result, "status", "not_in_medicine_window");
        cJSON_AddStringToObject(result, "speech", "当前不在用药时间段内");
        ResetMedicineSession();
        return result;
    }

    {
        std::lock_guard<std::mutex> lock(medicine_mutex_);
        medicine_flow_mode_ = "take";
        current_medicine_plan_slot_ = plan_slot;
        medicine_flow_state_ = MedicineFlowState::kWaitAuthPromptDone;
    }
    ShowStarfireMessage("正在进行人脸认证，请看向摄像头", 30000);
    cJSON_AddStringToObject(result, "status", "waiting_face_auth_prompt_done");
    cJSON_AddNumberToObject(result, "plan_slot", plan_slot);
    cJSON_AddStringToObject(result, "speech", "请看向摄像头，准备人脸验证。");
    return result;
#endif
}

cJSON* Application::StartPutMedicine(int requested_plan_slot) {
    cJSON* result = cJSON_CreateObject();
#ifndef CONFIG_UART_COMMAND_ENABLED
    cJSON_AddStringToObject(result, "status", "uart_disabled");
    return result;
#else
    ResetMedicineSession();
    ShowStarfireMessage("正在确认放药计划", 30000);

    cJSON* args = cJSON_CreateObject();
    if (requested_plan_slot > 0) {
        cJSON_AddNumberToObject(args, "plan_slot", requested_plan_slot);
    }
    cJSON_AddStringToObject(args, "mode", "put");
    auto payload = JsonToString(args);
    cJSON_Delete(args);

    auto sequence = UartCommand::GetInstance().GetAsyncMessageSequence();
    if (!UartCommand::GetInstance().SendJsonCommand("put_medicine", payload)) {
        cJSON_AddStringToObject(result, "status", "send_failed");
        return result;
    }
    {
        std::lock_guard<std::mutex> lock(medicine_mutex_);
        medicine_flow_mode_ = "put";
        medicine_flow_state_ = MedicineFlowState::kWaitAuthAck;
    }

    std::string message;
    if (!UartCommand::GetInstance().WaitForAsyncMessage("medicine_auth_ack", sequence, 10000, message)) {
        cJSON_AddStringToObject(result, "status", "auth_ack_timeout");
        ShowStarfireMessage("药盒无响应，请稍后重试");
        ResetMedicineSession();
        return result;
    }

    cJSON* auth_ack = cJSON_Parse(message.c_str());
    auto auth_status = JsonString(auth_ack, "status");
    int plan_slot = JsonInt(auth_ack, "plan_slot", JsonInt(auth_ack, "slot", requested_plan_slot));
    cJSON_Delete(auth_ack);
    if (auth_status != "accepted" || plan_slot <= 0) {
        cJSON_AddStringToObject(result, "status", "not_in_medicine_window");
        cJSON_AddStringToObject(result, "speech", "当前不能放药。");
        ResetMedicineSession();
        return result;
    }

    {
        std::lock_guard<std::mutex> lock(medicine_mutex_);
        medicine_flow_mode_ = "put";
        current_medicine_plan_slot_ = plan_slot;
        medicine_flow_state_ = MedicineFlowState::kWaitAuthPromptDone;
    }
    ShowStarfireMessage("正在进行人脸认证，请看向摄像头", 30000);
    cJSON_AddStringToObject(result, "status", "waiting_face_auth_prompt_done");
    cJSON_AddNumberToObject(result, "plan_slot", plan_slot);
    cJSON_AddStringToObject(result, "speech", "请看向摄像头，准备人脸验证。");
    return result;
#endif
}

cJSON* Application::StartMedicineFaceAuthentication() {
    cJSON* result = cJSON_CreateObject();
#ifndef CONFIG_UART_COMMAND_ENABLED
    cJSON_AddStringToObject(result, "status", "uart_disabled");
    return result;
#else
    int plan_slot = 0;
    std::string flow_mode;
    {
        std::lock_guard<std::mutex> lock(medicine_mutex_);
        if (medicine_flow_state_ != MedicineFlowState::kWaitAuthPromptDone) {
            cJSON_AddStringToObject(result, "status", "not_waiting_face_auth");
            cJSON_AddStringToObject(result, "speech", "当前没有等待人脸验证的用药流程");
            return result;
        }
        plan_slot = current_medicine_plan_slot_;
        flow_mode = medicine_flow_mode_;
        medicine_flow_state_ = MedicineFlowState::kWaitFaceResult;
    }
    if (plan_slot <= 0) {
        cJSON_AddStringToObject(result, "status", "missing_plan_slot");
        ResetMedicineSession();
        return result;
    }

    cJSON* confirm_args = cJSON_CreateObject();
    cJSON_AddNumberToObject(confirm_args, "plan_slot", plan_slot);
    if (!flow_mode.empty()) {
        cJSON_AddStringToObject(confirm_args, "mode", flow_mode.c_str());
    }
    auto payload = JsonToString(confirm_args);
    cJSON_Delete(confirm_args);
    auto sequence = UartCommand::GetInstance().GetAsyncMessageSequence();
    if (!UartCommand::GetInstance().SendJsonCommand("medicine_auth_prompt_done", payload)) {
        cJSON_AddStringToObject(result, "status", "auth_start_failed");
        ResetMedicineSession();
        return result;
    }

    std::string message;
    if (!UartCommand::GetInstance().WaitForAsyncMessage("face_auth_result", sequence, 30000, message)) {
        cJSON_AddStringToObject(result, "status", "face_auth_timeout");
        cJSON_AddStringToObject(result, "speech", "人脸认证超时，请重新开始");
        ResetMedicineSession();
        return result;
    }

    cJSON* face_result = cJSON_Parse(message.c_str());
    auto face_status = JsonString(face_result, "status");
    auto user_name = JsonString(face_result, "user_name");
    cJSON_Delete(face_result);
    cJSON_AddNumberToObject(result, "plan_slot", plan_slot);
    if (!user_name.empty()) {
        cJSON_AddStringToObject(result, "user_name", user_name.c_str());
    }

    if (face_status == "success") {
        {
            std::lock_guard<std::mutex> lock(medicine_mutex_);
            medicine_flow_state_ = MedicineFlowState::kWaitUserReady;
        }
        cJSON_AddStringToObject(result, "status", "authenticated_waiting_user_ready");
        cJSON_AddStringToObject(result, "speech", "验证成功。");
        cJSON_AddStringToObject(result, "next_action",
            flow_mode == "put" ? "wait_user_ready_to_put_medicine" : "wait_user_ready_to_take_medicine");
        ShowStarfireMessage(flow_mode == "put" ? "验证成功，等待用户准备放药" :
            "验证成功，等待用户准备取药", 30000);
    } else if (face_status == "busy") {
        cJSON_AddStringToObject(result, "status", "busy");
        cJSON_AddStringToObject(result, "speech", "当前正在处理用药流程，请稍后再试");
        ResetMedicineSession();
    } else {
        cJSON_AddStringToObject(result, "status", "face_auth_failed");
        cJSON_AddStringToObject(result, "speech", "人脸认证失败，无法打开药盒");
        ResetMedicineSession();
    }
    return result;
#endif
}

cJSON* Application::StartPutFaceAuthentication() {
    {
        std::lock_guard<std::mutex> lock(medicine_mutex_);
        if (medicine_flow_mode_ != "put") {
            cJSON* result = cJSON_CreateObject();
            cJSON_AddStringToObject(result, "status", "not_waiting_put_face_auth");
            cJSON_AddStringToObject(result, "speech", "当前没有等待放药验证的流程。");
            return result;
        }
    }
    return StartMedicineFaceAuthentication();
}

cJSON* Application::OpenMedicineAfterUserReady() {
    cJSON* result = cJSON_CreateObject();
#ifndef CONFIG_UART_COMMAND_ENABLED
    cJSON_AddStringToObject(result, "status", "uart_disabled");
    return result;
#else
    int plan_slot = 0;
    std::string flow_mode;
    {
        std::lock_guard<std::mutex> lock(medicine_mutex_);
        if (medicine_flow_state_ != MedicineFlowState::kWaitUserReady || medicine_flow_mode_ == "put") {
            cJSON_AddStringToObject(result, "status", "not_waiting_user_ready");
            cJSON_AddStringToObject(result, "speech", "当前没有等待取药的用药流程");
            return result;
        }
        plan_slot = current_medicine_plan_slot_;
        flow_mode = medicine_flow_mode_;
        medicine_flow_state_ = MedicineFlowState::kWaitMedicinePlan;
    }
    ShowStarfireMessage("正在打开药盒", 30000);

    cJSON* args = cJSON_CreateObject();
    cJSON_AddNumberToObject(args, "plan_slot", plan_slot);
    cJSON_AddStringToObject(args, "mode", flow_mode.c_str());
    auto payload = JsonToString(args);
    cJSON_Delete(args);
    auto sequence = UartCommand::GetInstance().GetAsyncMessageSequence();
    if (!UartCommand::GetInstance().SendJsonCommand("face_auth_broadcast_done", payload)) {
        cJSON_AddStringToObject(result, "status", "plan_request_failed");
        return result;
    }

    std::string message;
    if (!UartCommand::GetInstance().WaitForAsyncMessage("medicine_plan", sequence, 10000, message)) {
        cJSON_AddStringToObject(result, "status", "medicine_plan_timeout");
        cJSON_AddStringToObject(result, "speech", "获取用药计划超时，请重新开始");
        ResetMedicineSession();
        return result;
    }

    cJSON* plan = cJSON_Parse(message.c_str());
    std::vector<MedicineItem> medicines;
    auto array = cJSON_GetObjectItem(plan, "medicines");
    if (cJSON_IsArray(array)) {
        cJSON* medicine = nullptr;
        cJSON_ArrayForEach(medicine, array) {
            MedicineItem item;
            item.box_id = JsonInt(medicine, "box_id", JsonInt(medicine, "boxId", 0));
            item.name = JsonString(medicine, "name");
            item.dose_count = JsonInt(medicine, "dose_count", 0);
            item.target_count = JsonInt(medicine, "target_count", JsonInt(medicine, "targetCount", 0));
            if (item.box_id > 0) medicines.push_back(std::move(item));
        }
    }
    cJSON_Delete(plan);
    if (medicines.empty()) {
        cJSON_AddStringToObject(result, "status", "empty_medicine_plan");
        cJSON_AddStringToObject(result, "speech", "当前用药计划中没有可取药品");
        ResetMedicineSession();
        return result;
    }

    MedicineItem current = medicines.front();
    int expected_remaining = static_cast<int>(medicines.size()) - 1;
    {
        std::lock_guard<std::mutex> lock(medicine_mutex_);
        current_medicines_ = std::move(medicines);
        current_medicine_index_ = 0;
        current_medicine_box_id_ = current.box_id;
        medicine_flow_state_ = MedicineFlowState::kWaitBoxOpened;
    }

    args = cJSON_CreateObject();
    cJSON_AddNumberToObject(args, "plan_slot", plan_slot);
    cJSON_AddNumberToObject(args, "box_id", current.box_id);
    cJSON_AddStringToObject(args, "mode", flow_mode.c_str());
    payload = JsonToString(args);
    cJSON_Delete(args);
    sequence = UartCommand::GetInstance().GetAsyncMessageSequence();
    if (!UartCommand::GetInstance().SendJsonCommand("medicine_open_request", payload) ||
        !UartCommand::GetInstance().WaitForAsyncMessage("medicine_box_result", sequence, 10000, message)) {
        cJSON_AddStringToObject(result, "status", "open_box_timeout");
        cJSON_AddStringToObject(result, "speech", "药盒打开失败，请稍后重试");
        ResetMedicineSession();
        return result;
    }

    cJSON* box_result = cJSON_Parse(message.c_str());
    if (box_result == nullptr) {
        cJSON_AddStringToObject(result, "status", "invalid_medicine_box_result");
        cJSON_AddStringToObject(result, "speech", "药盒打开结果格式错误。");
        ResetMedicineSession();
        return result;
    }
    auto box_status = JsonString(box_result, "status");
    int remaining = JsonInt(box_result, "remaining_boxes", expected_remaining);
    cJSON_Delete(box_result);
    if (box_status != "opened") {
        cJSON_AddStringToObject(result, "status", box_status.empty() ? "open_box_failed" : box_status.c_str());
        ResetMedicineSession();
        return result;
    }
    {
        std::lock_guard<std::mutex> lock(medicine_mutex_);
        medicine_flow_state_ = MedicineFlowState::kWaitUserTaken;
    }
    cJSON_AddStringToObject(result, "status", "box_opened");
    cJSON_AddNumberToObject(result, "plan_slot", plan_slot);
    cJSON_AddNumberToObject(result, "box_id", current.box_id);
    cJSON_AddStringToObject(result, "medicine_name", current.name.c_str());
    cJSON_AddNumberToObject(result, "dose_count", current.dose_count);
    cJSON_AddNumberToObject(result, "remaining_boxes", remaining);
    std::string speech = "请取 " + std::to_string(current.box_id) + " 号药盒";
    if (!current.name.empty()) speech += "，" + current.name;
    if (current.dose_count > 0) speech += " " + std::to_string(current.dose_count) + " 粒";
    speech += "。取完请说取完了。";
    cJSON_AddStringToObject(result, "speech", speech.c_str());
    return result;
#endif
}

cJSON* Application::OpenMedicineForPutAfterUserReady() {
    cJSON* result = cJSON_CreateObject();
#ifndef CONFIG_UART_COMMAND_ENABLED
    cJSON_AddStringToObject(result, "status", "uart_disabled");
    return result;
#else
    int plan_slot = 0;
    {
        std::lock_guard<std::mutex> lock(medicine_mutex_);
        if (medicine_flow_state_ != MedicineFlowState::kWaitUserReady || medicine_flow_mode_ != "put") {
            cJSON_AddStringToObject(result, "status", "not_waiting_put_ready");
            cJSON_AddStringToObject(result, "speech", "当前没有等待放药的流程。");
            return result;
        }
        plan_slot = current_medicine_plan_slot_;
        medicine_flow_state_ = MedicineFlowState::kWaitMedicinePlan;
    }
    ShowStarfireMessage("正在检查药盒状态", 30000);

    cJSON* args = cJSON_CreateObject();
    cJSON_AddNumberToObject(args, "plan_slot", plan_slot);
    cJSON_AddStringToObject(args, "mode", "auto");
    auto payload = JsonToString(args);
    cJSON_Delete(args);
    auto sequence = UartCommand::GetInstance().GetAsyncMessageSequence();
    if (!UartCommand::GetInstance().SendJsonCommand("prepare_put_medicine", payload)) {
        cJSON_AddStringToObject(result, "status", "put_context_request_failed");
        ResetMedicineSession();
        return result;
    }

    std::string message;
    std::string message_tool;
    if (!WaitForAsyncMessageAny({"put_medicine_context", "medicine_plan"}, sequence, 10000, message_tool, message)) {
        sequence = UartCommand::GetInstance().GetAsyncMessageSequence();
        if (!UartCommand::GetInstance().SendJsonCommand("face_auth_broadcast_done", payload) ||
            !WaitForAsyncMessageAny({"medicine_plan"}, sequence, 10000, message_tool, message)) {
            cJSON_AddStringToObject(result, "status", "put_context_timeout");
            cJSON_AddStringToObject(result, "speech", "获取药盒状态超时。");
            ResetMedicineSession();
            return result;
        }
    }

    cJSON* context = cJSON_Parse(message.c_str());
    if (context == nullptr) {
        cJSON_AddStringToObject(result, "status", "invalid_put_context");
        cJSON_AddStringToObject(result, "speech", "放药任务格式错误。");
        ResetMedicineSession();
        return result;
    }

    std::string put_mode = JsonString(context, "mode", "refill");
    std::string context_status = JsonString(context, "status", message_tool == "medicine_plan" ? "ready" : "ready");
    if (context_status != "ready" && context_status != "completed") {
        std::string speech = JsonString(context, "speech", "当前药盒状态需要确认，暂不打开药盒。");
        cJSON_AddStringToObject(result, "status", context_status.c_str());
        cJSON_AddStringToObject(result, "mode", put_mode.c_str());
        cJSON_AddStringToObject(result, "speech", speech.c_str());
        cJSON_Delete(context);
        {
            std::lock_guard<std::mutex> lock(medicine_mutex_);
            medicine_flow_state_ = MedicineFlowState::kWaitUserReady;
        }
        ShowStarfireMessage(speech.c_str(), 10000);
        return result;
    }
    if (context_status == "completed") {
        std::string speech = JsonString(context, "speech", "当前不需要放药。");
        cJSON_AddStringToObject(result, "status", "completed");
        cJSON_AddStringToObject(result, "mode", put_mode.c_str());
        cJSON_AddStringToObject(result, "speech", speech.c_str());
        cJSON_Delete(context);
        ResetMedicineSession();
        return result;
    }

    std::vector<MedicineItem> medicines;
    auto array = cJSON_GetObjectItem(context, "tasks");
    if (!cJSON_IsArray(array)) {
        array = cJSON_GetObjectItem(context, "medicines");
    }
    if (cJSON_IsArray(array)) {
        cJSON* medicine = nullptr;
        cJSON_ArrayForEach(medicine, array) {
            MedicineItem item;
            item.box_id = JsonInt(medicine, "box_id", JsonInt(medicine, "boxId", 0));
            auto fallback_name = JsonString(medicine, "name");
            item.name = JsonString(medicine, "medicine_name", fallback_name.c_str());
            item.dose_count = JsonInt(medicine, "dose_count", 0);
            item.target_count = JsonInt(medicine, "target_count", JsonInt(medicine, "targetCount", 0));
            item.stock_count = JsonInt(medicine, "stock_count", JsonInt(medicine, "stockCount", 0));
            item.put_count = JsonInt(medicine, "put_count", JsonInt(medicine, "putCount", 0));
            item.bound = JsonBool(medicine, "bound", false);
            item.confirm_binding = JsonBool(medicine, "confirm_binding",
                JsonString(medicine, "action") == "bind_and_fill");
            item.action = JsonString(medicine, "action", item.confirm_binding ? "bind_and_fill" : "refill");
            item.status = JsonString(medicine, "status", "ready");
            auto fallback_stock_source = JsonString(medicine, "stockSource");
            item.stock_source = JsonString(medicine, "stock_source", fallback_stock_source.c_str());
            if (item.action == "skip" || item.status == "stock_ok") {
                continue;
            }
            if (item.box_id > 0) medicines.push_back(std::move(item));
        }
    }
    cJSON_Delete(context);
    if (medicines.empty()) {
        cJSON_AddStringToObject(result, "status", "no_put_tasks");
        cJSON_AddStringToObject(result, "speech", "当前没有需要放药的药盒。");
        ResetMedicineSession();
        return result;
    }

    MedicineItem current = medicines.front();
    if (current.put_count <= 0 && current.target_count > current.stock_count) {
        current.put_count = current.target_count - current.stock_count;
    }
    if (current.put_count <= 0 && current.target_count > 0 &&
        (current.action == "bind_and_fill" || current.action == "initial_fill")) {
        current.put_count = current.target_count;
    }
    medicines[0] = current;
    int expected_remaining = static_cast<int>(medicines.size()) - 1;
    {
        std::lock_guard<std::mutex> lock(medicine_mutex_);
        current_medicines_ = std::move(medicines);
        current_medicine_index_ = 0;
        current_medicine_box_id_ = current.box_id;
        medicine_flow_mode_ = "put";
        current_put_mode_ = put_mode;
        medicine_flow_state_ = MedicineFlowState::kWaitBoxOpened;
    }

    args = cJSON_CreateObject();
    cJSON_AddNumberToObject(args, "plan_slot", plan_slot);
    cJSON_AddNumberToObject(args, "box_id", current.box_id);
    cJSON_AddStringToObject(args, "mode", put_mode.c_str());
    cJSON_AddStringToObject(args, "action", current.action.c_str());
    cJSON_AddStringToObject(args, "medicine_name", current.name.c_str());
    cJSON_AddNumberToObject(args, "target_count", current.target_count);
    cJSON_AddNumberToObject(args, "put_count", current.put_count);
    cJSON_AddBoolToObject(args, "confirm_binding", current.confirm_binding);
    payload = JsonToString(args);
    cJSON_Delete(args);
    sequence = UartCommand::GetInstance().GetAsyncMessageSequence();
    bool open_received = UartCommand::GetInstance().SendJsonCommand("put_open_request", payload) &&
        WaitForAsyncMessageAny({"put_box_result", "medicine_box_result"}, sequence, 10000, message_tool, message);
    if (!open_received) {
        sequence = UartCommand::GetInstance().GetAsyncMessageSequence();
        open_received = UartCommand::GetInstance().SendJsonCommand("medicine_open_request", payload) &&
            WaitForAsyncMessageAny({"medicine_box_result"}, sequence, 10000, message_tool, message);
    }
    if (!open_received) {
        cJSON_AddStringToObject(result, "status", "open_box_timeout");
        cJSON_AddStringToObject(result, "speech", "药盒打开失败。");
        ResetMedicineSession();
        return result;
    }

    cJSON* box_result = cJSON_Parse(message.c_str());
    if (box_result == nullptr) {
        cJSON_AddStringToObject(result, "status", "invalid_put_box_result");
        cJSON_AddStringToObject(result, "speech", "药盒打开结果格式错误。");
        ResetMedicineSession();
        return result;
    }
    auto box_status = JsonString(box_result, "status");
    int remaining = JsonInt(box_result, "remaining_boxes", expected_remaining);
    cJSON_Delete(box_result);
    if (box_status != "opened") {
        cJSON_AddStringToObject(result, "status", box_status.empty() ? "open_box_failed" : box_status.c_str());
        ResetMedicineSession();
        return result;
    }
    {
        std::lock_guard<std::mutex> lock(medicine_mutex_);
        medicine_flow_state_ = MedicineFlowState::kWaitUserTaken;
    }

    cJSON_AddStringToObject(result, "status", "box_opened");
    cJSON_AddStringToObject(result, "mode", put_mode.c_str());
    cJSON_AddStringToObject(result, "action", current.action.c_str());
    cJSON_AddNumberToObject(result, "plan_slot", plan_slot);
    cJSON_AddNumberToObject(result, "box_id", current.box_id);
    cJSON_AddStringToObject(result, "medicine_name", current.name.c_str());
    cJSON_AddNumberToObject(result, "stock_count", current.stock_count);
    cJSON_AddNumberToObject(result, "put_count", current.put_count);
    cJSON_AddNumberToObject(result, "target_count", current.target_count);
    cJSON_AddNumberToObject(result, "remaining_boxes", remaining);
    std::string speech;
    if (put_mode == "initial_fill" || current.action == "bind_and_fill" || current.action == "initial_fill") {
        speech = "首次放药：请向 " + std::to_string(current.box_id) + " 号药盒放入";
        speech += current.name.empty() ? "药品" : current.name;
        if (current.put_count > 0) speech += " " + std::to_string(current.put_count) + " 颗";
        speech += "。放好后请说放好了或放了几颗。";
    } else {
        speech = std::to_string(current.box_id) + " 号药盒";
        speech += current.name.empty() ? "药品" : current.name;
        if (current.target_count > 0) {
            speech += "目标库存 " + std::to_string(current.target_count) + " 颗";
        }
        if (current.put_count > 0) {
            speech += "，请补 " + std::to_string(current.put_count) + " 颗";
        } else {
            speech += "，请按实际需要补药";
        }
        speech += "。放好后请说放了几颗。";
    }
    cJSON_AddStringToObject(result, "speech", speech.c_str());
    return result;
#endif
}

cJSON* Application::ConfirmCurrentMedicineTaken() {
    cJSON* result = cJSON_CreateObject();
#ifndef CONFIG_UART_COMMAND_ENABLED
    cJSON_AddStringToObject(result, "status", "uart_disabled");
    return result;
#else
    int plan_slot = 0;
    int box_id = 0;
    {
        std::lock_guard<std::mutex> lock(medicine_mutex_);
        if (medicine_flow_state_ != MedicineFlowState::kWaitUserTaken) {
            cJSON_AddStringToObject(result, "status", "no_open_medicine_box");
            cJSON_AddStringToObject(result, "speech", "当前没有等待确认的已打开药盒");
            return result;
        }
        plan_slot = current_medicine_plan_slot_;
        box_id = current_medicine_box_id_;
        medicine_flow_state_ = MedicineFlowState::kWaitBoxClosed;
    }

    cJSON* args = cJSON_CreateObject();
    cJSON_AddNumberToObject(args, "plan_slot", plan_slot);
    cJSON_AddNumberToObject(args, "box_id", box_id);
    auto payload = JsonToString(args);
    cJSON_Delete(args);
    auto sequence = UartCommand::GetInstance().GetAsyncMessageSequence();
    if (!UartCommand::GetInstance().SendJsonCommand("medicine_taken_done", payload)) {
        cJSON_AddStringToObject(result, "status", "taken_command_failed");
        return result;
    }

    std::string message;
    if (!UartCommand::GetInstance().WaitForAsyncMessage("medicine_taken_ack", sequence, 10000, message)) {
        cJSON_AddStringToObject(result, "status", "close_box_timeout");
        cJSON_AddStringToObject(result, "speech", "关闭药盒超时，请检查药盒");
        return result;
    }
    cJSON* taken_ack = cJSON_Parse(message.c_str());
    int remaining = JsonInt(taken_ack, "remaining_boxes", 0);
    cJSON_Delete(taken_ack);

    if (remaining <= 0) {
        if (UartCommand::GetInstance().WaitForAsyncMessage("medicine_session_result", sequence, 10000, message)) {
            cJSON* session = cJSON_Parse(message.c_str());
            auto status = JsonString(session, "status");
            bool taken = cJSON_IsTrue(cJSON_GetObjectItem(session, "taken"));
            cJSON_Delete(session);
            if (status == "completed" || taken) {
                cJSON_AddStringToObject(result, "status", "completed");
                cJSON_AddStringToObject(result, "speech", "取药完成。");
                ResetMedicineSession();
                return result;
            }
        }
        cJSON_AddStringToObject(result, "status", "session_result_timeout");
        cJSON_AddStringToObject(result, "speech", "药盒已关闭，正在等待用药完成确认");
        return result;
    }

    MedicineItem next;
    {
        std::lock_guard<std::mutex> lock(medicine_mutex_);
        if (current_medicine_index_ + 1 >= current_medicines_.size()) {
            cJSON_AddStringToObject(result, "status", "medicine_plan_mismatch");
            return result;
        }
        ++current_medicine_index_;
        next = current_medicines_[current_medicine_index_];
        current_medicine_box_id_ = next.box_id;
        medicine_flow_state_ = MedicineFlowState::kWaitBoxOpened;
    }

    args = cJSON_CreateObject();
    cJSON_AddNumberToObject(args, "plan_slot", plan_slot);
    cJSON_AddNumberToObject(args, "box_id", next.box_id);
    payload = JsonToString(args);
    cJSON_Delete(args);
    sequence = UartCommand::GetInstance().GetAsyncMessageSequence();
    if (!UartCommand::GetInstance().SendJsonCommand("medicine_open_request", payload) ||
        !UartCommand::GetInstance().WaitForAsyncMessage("medicine_box_result", sequence, 10000, message)) {
        cJSON_AddStringToObject(result, "status", "open_next_box_timeout");
        return result;
    }
    cJSON* box_result = cJSON_Parse(message.c_str());
    if (box_result == nullptr) {
        cJSON_AddStringToObject(result, "status", "invalid_medicine_box_result");
        cJSON_AddStringToObject(result, "speech", "下一个药盒打开结果格式错误。");
        return result;
    }
    auto box_status = JsonString(box_result, "status");
    cJSON_Delete(box_result);
    if (box_status != "opened") {
        cJSON_AddStringToObject(result, "status", "open_next_box_failed");
        return result;
    }
    {
        std::lock_guard<std::mutex> lock(medicine_mutex_);
        medicine_flow_state_ = MedicineFlowState::kWaitUserTaken;
    }
    cJSON_AddStringToObject(result, "status", "next_box_opened");
    cJSON_AddNumberToObject(result, "box_id", next.box_id);
    cJSON_AddStringToObject(result, "medicine_name", next.name.c_str());
    cJSON_AddNumberToObject(result, "dose_count", next.dose_count);
    cJSON_AddNumberToObject(result, "remaining_boxes", remaining - 1);
    std::string speech = "请取 " + std::to_string(next.box_id) + " 号药盒";
    if (!next.name.empty()) speech += "，" + next.name;
    if (next.dose_count > 0) speech += " " + std::to_string(next.dose_count) + " 粒";
    speech += "。取完请说取完了。";
    cJSON_AddStringToObject(result, "speech", speech.c_str());
    return result;
#endif
}

cJSON* Application::ConfirmCurrentMedicinePut(int put_count) {
    cJSON* result = cJSON_CreateObject();
#ifndef CONFIG_UART_COMMAND_ENABLED
    cJSON_AddStringToObject(result, "status", "uart_disabled");
    return result;
#else
    int plan_slot = 0;
    int box_id = 0;
    MedicineItem current;
    std::string put_mode;
    {
        std::lock_guard<std::mutex> lock(medicine_mutex_);
        if (medicine_flow_state_ != MedicineFlowState::kWaitUserTaken || medicine_flow_mode_ != "put") {
            cJSON_AddStringToObject(result, "status", "no_open_put_box");
            cJSON_AddStringToObject(result, "speech", "当前没有等待放药的药盒。");
            return result;
        }
        plan_slot = current_medicine_plan_slot_;
        box_id = current_medicine_box_id_;
        if (current_medicine_index_ < current_medicines_.size()) {
            current = current_medicines_[current_medicine_index_];
        }
        put_mode = current_put_mode_.empty() ? "refill" : current_put_mode_;
        medicine_flow_state_ = MedicineFlowState::kWaitBoxClosed;
    }
    if (put_count < 0) {
        put_count = current.put_count > 0 ? current.put_count :
            (current.target_count > current.stock_count ? current.target_count - current.stock_count : current.target_count);
    }
    if (put_count < 0) {
        put_count = 0;
    }

    cJSON* args = cJSON_CreateObject();
    cJSON_AddNumberToObject(args, "plan_slot", plan_slot);
    cJSON_AddNumberToObject(args, "box_id", box_id);
    cJSON_AddNumberToObject(args, "put_count", put_count);
    cJSON_AddStringToObject(args, "mode", put_mode.c_str());
    cJSON_AddStringToObject(args, "action", current.action.c_str());
    cJSON_AddStringToObject(args, "medicine_name", current.name.c_str());
    cJSON_AddBoolToObject(args, "confirm_binding", current.confirm_binding);
    auto payload = JsonToString(args);
    cJSON_Delete(args);
    auto sequence = UartCommand::GetInstance().GetAsyncMessageSequence();
    std::string message;
    std::string message_tool;
    bool put_ack_received = UartCommand::GetInstance().SendJsonCommand("put_medicine_done", payload) &&
        WaitForAsyncMessageAny({"put_medicine_ack", "medicine_put_ack", "medicine_taken_ack"}, sequence, 10000,
            message_tool, message);
    if (!put_ack_received) {
        sequence = UartCommand::GetInstance().GetAsyncMessageSequence();
        put_ack_received = UartCommand::GetInstance().SendJsonCommand("medicine_put_done", payload) &&
            WaitForAsyncMessageAny({"medicine_put_ack", "medicine_taken_ack"}, sequence, 10000, message_tool, message);
    }
    if (!put_ack_received) {
        cJSON_AddStringToObject(result, "status", "put_ack_timeout");
        cJSON_AddStringToObject(result, "speech", "放药确认超时。");
        ResetMedicineSession();
        return result;
    }

    cJSON* put_ack = cJSON_Parse(message.c_str());
    if (put_ack == nullptr) {
        cJSON_AddStringToObject(result, "status", "invalid_put_ack");
        cJSON_AddStringToObject(result, "speech", "放药确认格式错误。");
        ResetMedicineSession();
        return result;
    }
    int remaining = JsonInt(put_ack, "remaining_boxes", 0);
    int stock_count = JsonInt(put_ack, "stock_count", current.stock_count + put_count);
    cJSON_Delete(put_ack);

    if (remaining <= 0) {
        if (WaitForAsyncMessageAny({"put_session_result", "medicine_session_result"}, sequence, 10000, message_tool, message)) {
            cJSON* session = cJSON_Parse(message.c_str());
            if (session == nullptr) {
                cJSON_AddStringToObject(result, "status", "invalid_put_session_result");
                cJSON_AddStringToObject(result, "speech", "放药最终结果格式错误。");
                ResetMedicineSession();
                return result;
            }
            auto status = JsonString(session, "status");
            auto mode = JsonString(session, "mode", put_mode.c_str());
            cJSON_Delete(session);
            if (status == "completed" || status == "put_completed") {
                cJSON_AddStringToObject(result, "status", "completed");
                cJSON_AddStringToObject(result, "mode", mode.c_str());
                cJSON_AddStringToObject(result, "speech", mode == "initial_fill" ? "首次放药完成。" : "补药完成。");
                ResetMedicineSession();
                return result;
            }
            if (status == "partial_completed") {
                cJSON_AddStringToObject(result, "status", "partial_completed");
                cJSON_AddStringToObject(result, "mode", mode.c_str());
                cJSON_AddStringToObject(result, "speech", "部分药盒已完成，仍有药盒需要人工处理。");
                ResetMedicineSession();
                return result;
            }
        }
        cJSON_AddStringToObject(result, "status", "session_result_timeout");
        cJSON_AddNumberToObject(result, "stock_count", stock_count);
        cJSON_AddStringToObject(result, "speech", "放药已记录，正在等待最终确认。");
        ResetMedicineSession();
        return result;
    }

    MedicineItem next;
    bool plan_mismatch = false;
    {
        std::lock_guard<std::mutex> lock(medicine_mutex_);
        if (current_medicine_index_ + 1 >= current_medicines_.size()) {
            plan_mismatch = true;
        } else {
            ++current_medicine_index_;
            next = current_medicines_[current_medicine_index_];
            if (next.put_count <= 0 && next.target_count > next.stock_count) {
                next.put_count = next.target_count - next.stock_count;
                current_medicines_[current_medicine_index_].put_count = next.put_count;
            }
            current_medicine_box_id_ = next.box_id;
            medicine_flow_state_ = MedicineFlowState::kWaitBoxOpened;
        }
    }
    if (plan_mismatch) {
        cJSON_AddStringToObject(result, "status", "medicine_plan_mismatch");
        ResetMedicineSession();
        return result;
    }

    args = cJSON_CreateObject();
    cJSON_AddNumberToObject(args, "plan_slot", plan_slot);
    cJSON_AddNumberToObject(args, "box_id", next.box_id);
    cJSON_AddStringToObject(args, "mode", put_mode.c_str());
    cJSON_AddStringToObject(args, "action", next.action.c_str());
    cJSON_AddStringToObject(args, "medicine_name", next.name.c_str());
    cJSON_AddNumberToObject(args, "target_count", next.target_count);
    cJSON_AddNumberToObject(args, "put_count", next.put_count);
    cJSON_AddBoolToObject(args, "confirm_binding", next.confirm_binding);
    payload = JsonToString(args);
    cJSON_Delete(args);
    sequence = UartCommand::GetInstance().GetAsyncMessageSequence();
    bool open_received = UartCommand::GetInstance().SendJsonCommand("put_open_request", payload) &&
        WaitForAsyncMessageAny({"put_box_result", "medicine_box_result"}, sequence, 10000, message_tool, message);
    if (!open_received) {
        sequence = UartCommand::GetInstance().GetAsyncMessageSequence();
        open_received = UartCommand::GetInstance().SendJsonCommand("medicine_open_request", payload) &&
            WaitForAsyncMessageAny({"medicine_box_result"}, sequence, 10000, message_tool, message);
    }
    if (!open_received) {
        cJSON_AddStringToObject(result, "status", "open_next_box_timeout");
        cJSON_AddStringToObject(result, "speech", "下一个药盒打开失败。");
        return result;
    }
    cJSON* box_result = cJSON_Parse(message.c_str());
    if (box_result == nullptr) {
        cJSON_AddStringToObject(result, "status", "invalid_put_box_result");
        cJSON_AddStringToObject(result, "speech", "下一个药盒打开结果格式错误。");
        return result;
    }
    auto box_status = JsonString(box_result, "status");
    cJSON_Delete(box_result);
    if (box_status != "opened") {
        cJSON_AddStringToObject(result, "status", "open_next_box_failed");
        return result;
    }
    {
        std::lock_guard<std::mutex> lock(medicine_mutex_);
        medicine_flow_state_ = MedicineFlowState::kWaitUserTaken;
    }
    cJSON_AddStringToObject(result, "status", "next_box_opened");
    cJSON_AddStringToObject(result, "mode", put_mode.c_str());
    cJSON_AddStringToObject(result, "action", next.action.c_str());
    cJSON_AddNumberToObject(result, "box_id", next.box_id);
    cJSON_AddStringToObject(result, "medicine_name", next.name.c_str());
    cJSON_AddNumberToObject(result, "stock_count", next.stock_count);
    cJSON_AddNumberToObject(result, "put_count", next.put_count);
    cJSON_AddNumberToObject(result, "target_count", next.target_count);
    cJSON_AddNumberToObject(result, "remaining_boxes", remaining - 1);
    std::string speech;
    if (put_mode == "initial_fill" || next.action == "bind_and_fill" || next.action == "initial_fill") {
        speech = "请向 " + std::to_string(next.box_id) + " 号药盒放入";
        speech += next.name.empty() ? "药品" : next.name;
        if (next.put_count > 0) speech += " " + std::to_string(next.put_count) + " 颗";
        speech += "。放好后请说放好了或放了几颗。";
    } else {
        speech = std::to_string(next.box_id) + " 号药盒";
        speech += next.name.empty() ? "药品" : next.name;
        if (next.put_count > 0) speech += "请补 " + std::to_string(next.put_count) + " 颗";
        else speech += "请按实际需要补药";
        speech += "。放好后请说放了几颗。";
    }
    cJSON_AddStringToObject(result, "speech", speech.c_str());
    return result;
#endif
}

void Application::PromptCurrentMedicine() {
    int box_id = 0;
    int dose_count = 0;
    std::string name;
    {
        std::lock_guard<std::mutex> lock(medicine_mutex_);
        if (current_medicine_index_ >= current_medicines_.size()) return;
        const auto& item = current_medicines_[current_medicine_index_];
        box_id = item.box_id;
        dose_count = item.dose_count;
        name = item.name;
        current_medicine_box_id_ = box_id;
        medicine_flow_state_ = MedicineFlowState::kWaitMedicinePromptDone;
    }
    std::string message = "请取 " + std::to_string(box_id) + " 号药盒";
    if (!name.empty()) message += "，" + name;
    if (dose_count > 0) message += " " + std::to_string(dose_count) + " 粒";
    ShowStarfireMessage(message.c_str(), 10000);
}

void Application::HandleMedicineAuthRequired(const cJSON* root) {
    int plan_slot = JsonInt(root, "plan_slot", JsonInt(root, "slot", 0));
    ResetMedicineSession();
    {
        std::lock_guard<std::mutex> lock(medicine_mutex_);
        current_medicine_plan_slot_ = plan_slot;
    }
    ShowStarfireMessage("到了吃药时间，请说我要吃药开始用药", 10000);
}

void Application::HandleMedicineAlreadyTaken(const cJSON* root) {
    int plan_slot = JsonInt(root, "plan_slot", JsonInt(root, "slot", 0));
    int box_id = JsonInt(root, "box_id", 0);
    ESP_LOGI(TAG, "Medicine already taken: plan_slot=%d, box_id=%d", plan_slot, box_id);
    ResetMedicineSession();
    ShowStarfireMessage("当前时间段已经服药，请勿重复服药。", 10000);
}

void Application::HandleMedicineAuthAck(const cJSON* root) {
    auto status = JsonString(root, "status");
    if (status != "accepted") {
        ShowStarfireMessage("当前不在用药时间段内");
        ResetMedicineSession();
        return;
    }
    int plan_slot = JsonInt(root, "plan_slot", JsonInt(root, "slot", 0));
    {
        std::lock_guard<std::mutex> lock(medicine_mutex_);
        medicine_flow_state_ = MedicineFlowState::kWaitAuthPromptDone;
        current_medicine_plan_slot_ = plan_slot;
        current_medicine_box_id_ = 0;
        current_medicine_index_ = 0;
        current_medicines_.clear();
    }
    ShowStarfireMessage("正在进行人脸认证，请看向摄像头");
}

void Application::HandleFaceAuthResult(const cJSON* root) {
    auto status = JsonString(root, "status");
    if (status == "success") {
        std::lock_guard<std::mutex> lock(medicine_mutex_);
        medicine_flow_state_ = MedicineFlowState::kWaitFaceBroadcastDone;
        int slot = JsonInt(root, "plan_slot", JsonInt(root, "slot", current_medicine_plan_slot_));
        if (slot > 0) current_medicine_plan_slot_ = slot;
        ShowStarfireMessage("人脸认证成功");
    } else if (status == "busy") {
        ShowStarfireMessage("当前正在处理用药流程，请稍后再试");
        ResetMedicineSession();
    } else {
        ShowStarfireMessage("人脸认证失败，无法打开药盒");
        ResetMedicineSession();
    }
}

void Application::HandleMedicinePlan(const cJSON* root) {
    std::vector<MedicineItem> medicines;
    auto array = cJSON_GetObjectItem(root, "medicines");
    if (cJSON_IsArray(array)) {
        cJSON* medicine = nullptr;
        cJSON_ArrayForEach(medicine, array) {
            MedicineItem item;
            item.box_id = JsonInt(medicine, "box_id", JsonInt(medicine, "boxId", 0));
            item.name = JsonString(medicine, "name");
            item.dose_count = JsonInt(medicine, "dose_count", 0);
            if (item.box_id > 0) medicines.push_back(std::move(item));
        }
    }
    if (medicines.empty()) {
        ShowStarfireMessage("当前没有可打开的用药计划");
        ResetMedicineSession();
        return;
    }
    {
        std::lock_guard<std::mutex> lock(medicine_mutex_);
        current_medicine_plan_slot_ = JsonInt(root, "plan_slot", JsonInt(root, "slot", current_medicine_plan_slot_));
        current_medicine_index_ = 0;
        current_medicines_ = std::move(medicines);
    }
    PromptCurrentMedicine();
}

void Application::HandleMedicineBoxResult(const cJSON* root) {
    auto status = JsonString(root, "status");
    int remaining = JsonInt(root, "remaining_boxes", 0);
    if (status != "opened") {
        std::string message = "药盒状态：" + status;
        ShowStarfireMessage(message.c_str());
        return;
    }
    {
        std::lock_guard<std::mutex> lock(medicine_mutex_);
        medicine_flow_state_ = MedicineFlowState::kWaitUserTaken;
        int box_id = JsonInt(root, "box_id", 0);
        if (box_id > 0) current_medicine_box_id_ = box_id;
    }
    std::string message = "药盒已打开，请取药。取完后请说吃完了";
    if (remaining > 0) message += "或下一个";
    message += "。";
    ShowStarfireMessage(message.c_str(), 10000);
}

void Application::HandleMedicineTakenAck(const cJSON* root) {
    int remaining = JsonInt(root, "remaining_boxes", 0);
    if (remaining > 0) {
        bool next = false;
        {
            std::lock_guard<std::mutex> lock(medicine_mutex_);
            if (current_medicine_index_ + 1 < current_medicines_.size()) {
                ++current_medicine_index_;
                next = true;
            }
        }
        if (next) PromptCurrentMedicine();
    } else {
        std::lock_guard<std::mutex> lock(medicine_mutex_);
        medicine_flow_state_ = MedicineFlowState::kWaitSessionResult;
        ShowStarfireMessage("药盒已关闭，等待用药完成结果");
    }
}

void Application::HandleMedicineSessionResult(const cJSON* root) {
    auto status = JsonString(root, "status");
    bool taken = cJSON_IsTrue(cJSON_GetObjectItem(root, "taken"));
    ShowStarfireMessage((status == "completed" || taken) ? "本次用药已完成" :
        "用药流程已结束，请重新开始");
    ResetMedicineSession();
}

cJSON* Application::MeasureHeartSpo2() {
    cJSON* result = cJSON_CreateObject();
#ifndef CONFIG_UART_COMMAND_ENABLED
    cJSON_AddStringToObject(result, "status", "uart_disabled");
    cJSON_AddStringToObject(result, "speech", "当前未启用串口，无法测量心率和血氧。");
    return result;
#else
    if (body_temperature_measurement_in_progress_.load()) {
        cJSON_AddStringToObject(result, "status", "measuring");
        cJSON_AddStringToObject(result, "speech", "体温正在检测中，请等当前检测结束后再测心率血氧。");
        return result;
    }
    if (vitals_measurement_in_progress_.exchange(true)) {
        cJSON_AddStringToObject(result, "status", "measuring");
        cJSON_AddStringToObject(result, "speech", "心率血氧正在检测中，请保持手指稳定。");
        return result;
    }
    last_vitals_result_valid_ = false;
    last_vitals_heart_rate_ = 0;
    last_vitals_spo2_ = 0;
    last_vitals_result_time_us_ = 0;

    SetDeviceState(kDeviceStateSpeaking);
    vTaskDelay(pdMS_TO_TICKS(50));
    ShowStarfireMessage("请准备好，3秒后开始检测", 5000);
    audio_service_.PlaySound(LocalVitalsPrepareSound());
    audio_service_.WaitForPlaybackQueueEmpty();
    vTaskDelay(pdMS_TO_TICKS(3000));

    ShowStarfireMessage("开始检测", 5000);
    audio_service_.PlaySound(LocalVitalsStartSound());
    audio_service_.WaitForPlaybackQueueEmpty();

    cJSON* args = cJSON_CreateObject();
    auto payload = JsonToString(args);
    cJSON_Delete(args);
    auto sequence = UartCommand::GetInstance().GetAsyncMessageSequence();
    if (!UartCommand::GetInstance().SendJsonCommand("measure_heart_spo2", payload)) {
        vitals_measurement_in_progress_.store(false);
        cJSON_AddStringToObject(result, "status", "request_failed");
        cJSON_AddStringToObject(result, "speech", "心率血氧检测请求发送失败。");
        return result;
    }

    auto* task_arg = new VitalsMeasurementTaskArg{this, sequence};
    BaseType_t task_ret = xTaskCreate([](void* arg) {
        auto* task_arg = static_cast<VitalsMeasurementTaskArg*>(arg);
        auto app = task_arg->app;
        uint64_t sequence = task_arg->sequence;
        delete task_arg;
        app->WaitForHeartSpo2Result(sequence);
        vTaskDelete(nullptr);
    }, "vitals_wait", 4096, task_arg, 5, nullptr);
    if (task_ret != pdPASS) {
        delete task_arg;
        vitals_measurement_in_progress_.store(false);
        cJSON_AddStringToObject(result, "status", "task_failed");
        cJSON_AddStringToObject(result, "speech", "心率血氧检测任务启动失败。");
        return result;
    }

    cJSON_AddStringToObject(result, "status", "measuring");
    cJSON_AddStringToObject(result, "speech", "正在检测心率和血氧，请保持手指稳定。听到测量结束后，可以问我结果是多少。");
    return result;
#endif
}

void Application::WaitForHeartSpo2Result(uint64_t sequence) {
#ifndef CONFIG_UART_COMMAND_ENABLED
    vitals_measurement_in_progress_.store(false);
#else
    std::string message;
    while (!UartCommand::GetInstance().WaitForAsyncMessage("measurement_result", sequence, 60000, message)) {
        ESP_LOGI(TAG, "Still waiting for heart/spo2 measurement_result");
    }

    cJSON* measurement = cJSON_Parse(message.c_str());
    if (measurement == nullptr) {
        ESP_LOGW(TAG, "Invalid heart/spo2 measurement_result: %s", message.c_str());
        vitals_measurement_in_progress_.store(false);
        return;
    }

    auto heart = cJSON_GetObjectItem(measurement, "heartRate");
    auto spo2 = cJSON_GetObjectItem(measurement, "spo2");
    auto status = JsonString(measurement, "status", "success");
    if (!cJSON_IsNumber(heart) || !cJSON_IsNumber(spo2)) {
        ESP_LOGW(TAG, "Heart/spo2 measurement_result missing values, status=%s", status.c_str());
        cJSON_Delete(measurement);
        vitals_measurement_in_progress_.store(false);
        return;
    }

    int heart_rate = heart->valueint;
    int spo2_value = spo2->valueint;
    cJSON_Delete(measurement);

    Schedule([this, heart_rate, spo2_value]() {
        last_vitals_heart_rate_ = heart_rate;
        last_vitals_spo2_ = spo2_value;
        last_vitals_result_time_us_ = esp_timer_get_time();
        last_vitals_result_valid_ = true;
        vitals_measurement_in_progress_.store(false);
        std::string message = "测量结束，请问我结果。心率 " + std::to_string(heart_rate) +
            "，血氧 " + std::to_string(spo2_value) + "%";
        ShowStarfireMessage(message.c_str(), 10000);
        audio_service_.PlaySound(LocalVitalsSuccessSound());
    });
#endif
}

cJSON* Application::GetLastHeartSpo2Result() {
    cJSON* result = cJSON_CreateObject();
    if (vitals_measurement_in_progress_.load()) {
        cJSON_AddStringToObject(result, "status", "measuring");
        cJSON_AddStringToObject(result, "speech", "还在检测中，请保持手指稳定。听到测量结束后再问我结果。");
        return result;
    }

    if (!last_vitals_result_valid_) {
        cJSON_AddStringToObject(result, "status", "no_result");
        cJSON_AddStringToObject(result, "speech", "目前还没有心率血氧检测结果。你可以说我要测心率血氧。");
        return result;
    }

    constexpr int64_t kVitalsResultExpireUs = 5LL * 60 * 1000 * 1000;
    auto age_us = esp_timer_get_time() - last_vitals_result_time_us_;
    if (age_us > kVitalsResultExpireUs) {
        cJSON_AddStringToObject(result, "status", "expired");
        cJSON_AddStringToObject(result, "speech", "上一次心率血氧结果已经超过五分钟，建议重新测量。");
        return result;
    }

    cJSON_AddStringToObject(result, "status", "completed");
    cJSON_AddNumberToObject(result, "heartRate", last_vitals_heart_rate_);
    cJSON_AddNumberToObject(result, "spo2", last_vitals_spo2_);
    cJSON_AddStringToObject(result, "unit_heartRate", "bpm");
    cJSON_AddStringToObject(result, "unit_spo2", "%");
    std::string speech = "刚才测得心率 " + std::to_string(last_vitals_heart_rate_) +
        " 次每分钟，血氧饱和度 " + std::to_string(last_vitals_spo2_) + "%。";
    cJSON_AddStringToObject(result, "speech", speech.c_str());
    return result;
}

cJSON* Application::MeasureBodyTemperature() {
    cJSON* result = cJSON_CreateObject();
#ifndef CONFIG_UART_COMMAND_ENABLED
    cJSON_AddStringToObject(result, "status", "uart_disabled");
    cJSON_AddStringToObject(result, "speech", "当前未启用串口，无法测量体温。");
    return result;
#else
    if (vitals_measurement_in_progress_.load()) {
        cJSON_AddStringToObject(result, "status", "measuring");
        cJSON_AddStringToObject(result, "speech", "心率血氧正在检测中，请等当前检测结束后再测体温。");
        return result;
    }
    if (body_temperature_measurement_in_progress_.exchange(true)) {
        cJSON_AddStringToObject(result, "status", "measuring");
        cJSON_AddStringToObject(result, "speech", "体温正在检测中，请保持稳定。");
        return result;
    }
    last_body_temperature_result_valid_ = false;
    last_body_temperature_ = 0.0;
    last_body_temperature_result_time_us_ = 0;

    SetDeviceState(kDeviceStateSpeaking);
    vTaskDelay(pdMS_TO_TICKS(50));
    ShowStarfireMessage("请准备好，3秒后开始检测", 5000);
    audio_service_.PlaySound(LocalVitalsPrepareSound());
    audio_service_.WaitForPlaybackQueueEmpty();
    vTaskDelay(pdMS_TO_TICKS(3000));

    ShowStarfireMessage("开始检测体温", 5000);
    audio_service_.PlaySound(LocalVitalsStartSound());
    audio_service_.WaitForPlaybackQueueEmpty();

    cJSON* args = cJSON_CreateObject();
    auto payload = JsonToString(args);
    cJSON_Delete(args);
    auto sequence = UartCommand::GetInstance().GetAsyncMessageSequence();
    if (!UartCommand::GetInstance().SendJsonCommand("measure_body_temperature", payload)) {
        body_temperature_measurement_in_progress_.store(false);
        cJSON_AddStringToObject(result, "status", "request_failed");
        cJSON_AddStringToObject(result, "speech", "体温检测请求发送失败。");
        return result;
    }

    auto* task_arg = new VitalsMeasurementTaskArg{this, sequence};
    BaseType_t task_ret = xTaskCreate([](void* arg) {
        auto* task_arg = static_cast<VitalsMeasurementTaskArg*>(arg);
        auto app = task_arg->app;
        uint64_t sequence = task_arg->sequence;
        delete task_arg;
        app->WaitForBodyTemperatureResult(sequence);
        vTaskDelete(nullptr);
    }, "temp_wait", 4096, task_arg, 5, nullptr);
    if (task_ret != pdPASS) {
        delete task_arg;
        body_temperature_measurement_in_progress_.store(false);
        cJSON_AddStringToObject(result, "status", "task_failed");
        cJSON_AddStringToObject(result, "speech", "体温检测任务启动失败。");
        return result;
    }

    cJSON_AddStringToObject(result, "status", "measuring");
    cJSON_AddStringToObject(result, "speech", "正在检测体温，请保持稳定。听到测量结束后，可以问我结果是多少。");
    return result;
#endif
}

void Application::WaitForBodyTemperatureResult(uint64_t sequence) {
#ifndef CONFIG_UART_COMMAND_ENABLED
    body_temperature_measurement_in_progress_.store(false);
#else
    std::string message;
    while (!UartCommand::GetInstance().WaitForAsyncMessage("measurement_result", sequence, 60000, message)) {
        ESP_LOGI(TAG, "Still waiting for body temperature measurement_result");
    }

    cJSON* measurement = cJSON_Parse(message.c_str());
    if (measurement == nullptr) {
        ESP_LOGW(TAG, "Invalid body temperature measurement_result: %s", message.c_str());
        body_temperature_measurement_in_progress_.store(false);
        return;
    }

    auto type = JsonString(measurement, "type");
    auto status = JsonString(measurement, "status", "success");
    auto temperature = cJSON_GetObjectItem(measurement, "bodyTemperature");
    if (type != "body_temperature" || status != "success" || !cJSON_IsNumber(temperature)) {
        ESP_LOGW(TAG, "Body temperature measurement_result missing value, type=%s, status=%s",
                 type.c_str(), status.c_str());
        cJSON_Delete(measurement);
        Schedule([this]() {
            last_body_temperature_result_valid_ = false;
            body_temperature_measurement_in_progress_.store(false);
            ShowStarfireMessage("体温检测未成功，请稍后重试", 10000);
            audio_service_.PlaySound(LocalVitalsSuccessSound());
        });
        return;
    }

    double body_temperature = temperature->valuedouble;
    cJSON_Delete(measurement);

    Schedule([this, body_temperature]() {
        last_body_temperature_ = body_temperature;
        last_body_temperature_result_time_us_ = esp_timer_get_time();
        last_body_temperature_result_valid_ = true;
        body_temperature_measurement_in_progress_.store(false);
        char value[24];
        snprintf(value, sizeof(value), "%.2f", body_temperature);
        std::string message = "测量结束，请问我结果。体温 ";
        message += value;
        message += " 摄氏度";
        ShowStarfireMessage(message.c_str(), 10000);
        audio_service_.PlaySound(LocalVitalsSuccessSound());
    });
#endif
}

cJSON* Application::GetLastBodyTemperatureResult() {
    cJSON* result = cJSON_CreateObject();
    if (body_temperature_measurement_in_progress_.load()) {
        cJSON_AddStringToObject(result, "status", "measuring");
        cJSON_AddStringToObject(result, "speech", "还在检测体温，请保持稳定。听到测量结束后再问我结果。");
        return result;
    }

    if (!last_body_temperature_result_valid_) {
        cJSON_AddStringToObject(result, "status", "no_result");
        cJSON_AddStringToObject(result, "speech", "目前还没有体温检测结果。你可以说我要测体温。");
        return result;
    }

    constexpr int64_t kBodyTemperatureResultExpireUs = 5LL * 60 * 1000 * 1000;
    auto age_us = esp_timer_get_time() - last_body_temperature_result_time_us_;
    if (age_us > kBodyTemperatureResultExpireUs) {
        cJSON_AddStringToObject(result, "status", "expired");
        cJSON_AddStringToObject(result, "speech", "上一次体温结果已经超过五分钟，建议重新测量。");
        return result;
    }

    cJSON_AddStringToObject(result, "status", "completed");
    cJSON_AddNumberToObject(result, "bodyTemperature", last_body_temperature_);
    cJSON_AddStringToObject(result, "unit_bodyTemperature", "C");
    char value[24];
    snprintf(value, sizeof(value), "%.2f", last_body_temperature_);
    std::string speech = "刚才测得体温 ";
    speech += value;
    speech += " 摄氏度。";
    cJSON_AddStringToObject(result, "speech", speech.c_str());
    return result;
}

void Application::HandleMeasurementMessage(const std::string& tool, const cJSON* root) {
    auto type = JsonString(root, "type");
    if (tool == "measurement_ack") {
        ShowStarfireMessage(type == "body_temperature" ? "正在测量体温，请保持稳定" :
            "正在测量心率和血氧，请保持手指稳定");
        return;
    }
    std::string message = "测量结果";
    auto heart = cJSON_GetObjectItem(root, "heartRate");
    auto spo2 = cJSON_GetObjectItem(root, "spo2");
    auto temperature = cJSON_GetObjectItem(root, "bodyTemperature");
    if (cJSON_IsNumber(heart) && cJSON_IsNumber(spo2)) {
        message += "：心率 " + std::to_string(heart->valueint) + "，血氧 " + std::to_string(spo2->valueint);
    } else if (cJSON_IsNumber(temperature)) {
        char value[24];
        snprintf(value, sizeof(value), "%.2f", temperature->valuedouble);
        message += "：体温 ";
        message += value;
    }
    ShowStarfireMessage(message.c_str(), 10000);
}

void Application::HandleStarfireAsyncMessage(const std::string& tool, const std::string& payload) {
    SendMcpMessage(BuildSlaveMcpNotification(tool, payload));
    cJSON* root = cJSON_Parse(payload.c_str());
    if (root == nullptr) {
        auto message = BuildSlaveDisplayMessage(tool, payload);
        ShowStarfireMessage(message.c_str());
        return;
    }
    if (tool == "medicine_auth_required") HandleMedicineAuthRequired(root);
    else if (tool == "medicine_already_taken") HandleMedicineAlreadyTaken(root);
    else if (tool == "voice_alarm_stop" || JsonString(root, "event") == "medicine_reminder_stop") StopLocalMedicineReminderAnnouncement(root);
    else if (tool == "measurement_ack" || tool == "measurement_result") HandleMeasurementMessage(tool, root);
    else {
        auto message = BuildSlaveDisplayMessage(tool, payload);
        ShowStarfireMessage(message.c_str());
    }
    cJSON_Delete(root);
}

void Application::HandleToggleChatEvent() {
    auto state = GetDeviceState();
    
    if (state == kDeviceStateActivating) {
        SetDeviceState(kDeviceStateIdle);
        return;
    } else if (state == kDeviceStateWifiConfiguring) {
        audio_service_.EnableAudioTesting(true);
        SetDeviceState(kDeviceStateAudioTesting);
        return;
    } else if (state == kDeviceStateAudioTesting) {
        audio_service_.EnableAudioTesting(false);
        SetDeviceState(kDeviceStateWifiConfiguring);
        return;
    }

    if (!protocol_) {
        ESP_LOGE(TAG, "Protocol not initialized");
        return;
    }

    if (state == kDeviceStateIdle) {
        ListeningMode mode = GetDefaultListeningMode();
        if (!protocol_->IsAudioChannelOpened()) {
            SetDeviceState(kDeviceStateConnecting);
            // Schedule to let the state change be processed first (UI update)
            Schedule([this, mode]() {
                ContinueOpenAudioChannel(mode);
            });
            return;
        }
        SetListeningMode(mode);
    } else if (state == kDeviceStateSpeaking) {
        AbortSpeaking(kAbortReasonNone);
    } else if (state == kDeviceStateListening) {
        protocol_->CloseAudioChannel();
    }
}

void Application::ContinueOpenAudioChannel(ListeningMode mode) {
    // Check state again in case it was changed during scheduling
    if (GetDeviceState() != kDeviceStateConnecting) {
        return;
    }

    if (!protocol_->IsAudioChannelOpened()) {
        if (!protocol_->OpenAudioChannel()) {
            return;
        }
    }

    SetListeningMode(mode);
}

void Application::HandleStartListeningEvent() {
    auto state = GetDeviceState();
    
    if (state == kDeviceStateActivating) {
        SetDeviceState(kDeviceStateIdle);
        return;
    } else if (state == kDeviceStateWifiConfiguring) {
        audio_service_.EnableAudioTesting(true);
        SetDeviceState(kDeviceStateAudioTesting);
        return;
    }

    if (!protocol_) {
        ESP_LOGE(TAG, "Protocol not initialized");
        return;
    }
    
    if (state == kDeviceStateIdle) {
        if (!protocol_->IsAudioChannelOpened()) {
            SetDeviceState(kDeviceStateConnecting);
            // Schedule to let the state change be processed first (UI update)
            Schedule([this]() {
                ContinueOpenAudioChannel(kListeningModeManualStop);
            });
            return;
        }
        SetListeningMode(kListeningModeManualStop);
    } else if (state == kDeviceStateSpeaking) {
        AbortSpeaking(kAbortReasonNone);
        SetListeningMode(kListeningModeManualStop);
    }
}

void Application::HandleStopListeningEvent() {
    auto state = GetDeviceState();
    
    if (state == kDeviceStateAudioTesting) {
        audio_service_.EnableAudioTesting(false);
        SetDeviceState(kDeviceStateWifiConfiguring);
        return;
    } else if (state == kDeviceStateListening) {
        if (protocol_) {
            protocol_->SendStopListening();
        }
        SetDeviceState(kDeviceStateIdle);
    }
}

void Application::HandleWakeWordDetectedEvent() {
    if (!protocol_) {
        return;
    }

    auto state = GetDeviceState();
    auto wake_word = audio_service_.GetLastWakeWord();
    ESP_LOGI(TAG, "Wake word detected: %s (state: %d)", wake_word.c_str(), (int)state);

    if (state == kDeviceStateIdle) {
        audio_service_.EncodeWakeWord();
        auto wake_word = audio_service_.GetLastWakeWord();

        if (!protocol_->IsAudioChannelOpened()) {
            SetDeviceState(kDeviceStateConnecting);
            // Schedule to let the state change be processed first (UI update),
            // then continue with OpenAudioChannel which may block for ~1 second
            Schedule([this, wake_word]() {
                ContinueWakeWordInvoke(wake_word);
            });
            return;
        }
        // Channel already opened, continue directly
        ContinueWakeWordInvoke(wake_word);
    } else if (state == kDeviceStateSpeaking || state == kDeviceStateListening) {
        AbortSpeaking(kAbortReasonWakeWordDetected);
        // Clear send queue to avoid sending residues to server
        while (audio_service_.PopPacketFromSendQueue());

        if (state == kDeviceStateListening) {
            protocol_->SendStartListening(GetDefaultListeningMode());
            audio_service_.ResetDecoder();
            audio_service_.PlaySound(Lang::Sounds::OGG_POPUP);
            // Re-enable wake word detection as it was stopped by the detection itself
            audio_service_.EnableWakeWordDetection(true);
        } else {
            // Play popup sound and start listening again
            play_popup_on_listening_ = true;
            SetListeningMode(GetDefaultListeningMode());
        }
    } else if (state == kDeviceStateActivating) {
        // Restart the activation check if the wake word is detected during activation
        SetDeviceState(kDeviceStateIdle);
    }
}

void Application::ContinueWakeWordInvoke(const std::string& wake_word) {
    // Check state again in case it was changed during scheduling
    if (GetDeviceState() != kDeviceStateConnecting) {
        return;
    }

    if (!protocol_->IsAudioChannelOpened()) {
        if (!protocol_->OpenAudioChannel()) {
            audio_service_.EnableWakeWordDetection(true);
            return;
        }
    }

    ESP_LOGI(TAG, "Wake word detected: %s", wake_word.c_str());
#if CONFIG_SEND_WAKE_WORD_DATA
    // Encode and send the wake word data to the server
    while (auto packet = audio_service_.PopWakeWordPacket()) {
        protocol_->SendAudio(std::move(packet));
    }
    // Set the chat state to wake word detected
    protocol_->SendWakeWordDetected(wake_word);

    // Set flag to play popup sound after state changes to listening
    play_popup_on_listening_ = true;
    SetListeningMode(GetDefaultListeningMode());
#else
    // Set flag to play popup sound after state changes to listening
    // (PlaySound here would be cleared by ResetDecoder in EnableVoiceProcessing)
    play_popup_on_listening_ = true;
    SetListeningMode(GetDefaultListeningMode());
#endif
}

void Application::HandleStateChangedEvent() {
    DeviceState new_state = state_machine_.GetState();
    clock_ticks_ = 0;

    auto& board = Board::GetInstance();
    auto display = board.GetDisplay();
    auto led = board.GetLed();
    led->OnStateChanged();
    
    switch (new_state) {
        case kDeviceStateUnknown:
        case kDeviceStateIdle:
            display->SetStatus(Lang::Strings::STANDBY);
            display->ClearChatMessages();  // Clear messages first
            display->SetEmotion("neutral"); // Then set emotion (wechat mode checks child count)
            audio_service_.EnableVoiceProcessing(false);
            audio_service_.EnableWakeWordDetection(true);
            break;
        case kDeviceStateConnecting:
            display->SetStatus(Lang::Strings::CONNECTING);
            display->SetEmotion("neutral");
            display->SetChatMessage("system", "");
            break;
        case kDeviceStateListening:
            display->SetStatus(Lang::Strings::LISTENING);
            display->SetEmotion("neutral");

            // Make sure the audio processor is running
            if (play_popup_on_listening_ || !audio_service_.IsAudioProcessorRunning()) {
                // For auto mode, wait for playback queue to be empty before enabling voice processing
                // This prevents audio truncation when STOP arrives late due to network jitter
                if (listening_mode_ == kListeningModeAutoStop) {
                    audio_service_.WaitForPlaybackQueueEmpty();
                }
                
                // Send the start listening command
                protocol_->SendStartListening(listening_mode_);
                audio_service_.EnableVoiceProcessing(true);
            }

#ifdef CONFIG_WAKE_WORD_DETECTION_IN_LISTENING
            // Enable wake word detection in listening mode (configured via Kconfig)
            audio_service_.EnableWakeWordDetection(audio_service_.IsAfeWakeWord());
#else
            // Disable wake word detection in listening mode
            audio_service_.EnableWakeWordDetection(false);
#endif
            
            // Play popup sound after ResetDecoder (in EnableVoiceProcessing) has been called
            if (play_popup_on_listening_) {
                play_popup_on_listening_ = false;
                audio_service_.PlaySound(Lang::Sounds::OGG_POPUP);
            }
            break;
        case kDeviceStateSpeaking:
            display->SetStatus(Lang::Strings::SPEAKING);

            if (listening_mode_ != kListeningModeRealtime) {
                audio_service_.EnableVoiceProcessing(false);
                // Only AFE wake word can be detected in speaking mode
                audio_service_.EnableWakeWordDetection(audio_service_.IsAfeWakeWord());
            }
            audio_service_.ResetDecoder();
            break;
        case kDeviceStateWifiConfiguring:
            audio_service_.EnableVoiceProcessing(false);
            audio_service_.EnableWakeWordDetection(false);
            break;
        default:
            // Do nothing
            break;
    }

}

void Application::Schedule(std::function<void()>&& callback) {
    {
        std::lock_guard<std::mutex> lock(mutex_);
        main_tasks_.push_back(std::move(callback));
    }
    xEventGroupSetBits(event_group_, MAIN_EVENT_SCHEDULE);
}

void Application::AbortSpeaking(AbortReason reason) {
    ESP_LOGI(TAG, "Abort speaking");
    aborted_ = true;
    if (protocol_) {
        protocol_->SendAbortSpeaking(reason);
    }
}

void Application::SetListeningMode(ListeningMode mode) {
    listening_mode_ = mode;
    SetDeviceState(kDeviceStateListening);
}

ListeningMode Application::GetDefaultListeningMode() const {
    return aec_mode_ == kAecOff ? kListeningModeAutoStop : kListeningModeRealtime;
}

void Application::Reboot() {
    ESP_LOGI(TAG, "Rebooting...");
    // Disconnect the audio channel
    if (protocol_ && protocol_->IsAudioChannelOpened()) {
        protocol_->CloseAudioChannel();
    }
    protocol_.reset();
    audio_service_.Stop();

    vTaskDelay(pdMS_TO_TICKS(1000));
    esp_restart();
}

bool Application::UpgradeFirmware(const std::string& url, const std::string& version) {
    auto& board = Board::GetInstance();
    auto display = board.GetDisplay();

    std::string upgrade_url = url;
    std::string version_info = version.empty() ? "(Manual upgrade)" : version;

    // Close audio channel if it's open
    if (protocol_ && protocol_->IsAudioChannelOpened()) {
        ESP_LOGI(TAG, "Closing audio channel before firmware upgrade");
        protocol_->CloseAudioChannel();
    }
    ESP_LOGI(TAG, "Starting firmware upgrade from URL: %s", upgrade_url.c_str());

    Alert(Lang::Strings::OTA_UPGRADE, Lang::Strings::UPGRADING, "download", Lang::Sounds::OGG_UPGRADE);
    vTaskDelay(pdMS_TO_TICKS(3000));

    SetDeviceState(kDeviceStateUpgrading);

    std::string message = std::string(Lang::Strings::NEW_VERSION) + version_info;
    display->SetChatMessage("system", message.c_str());

    board.SetPowerSaveLevel(PowerSaveLevel::PERFORMANCE);
    audio_service_.Stop();
    vTaskDelay(pdMS_TO_TICKS(1000));

    bool upgrade_success = Ota::Upgrade(upgrade_url, [this, display](int progress, size_t speed) {
        char buffer[32];
        snprintf(buffer, sizeof(buffer), "%d%% %uKB/s", progress, speed / 1024);
        Schedule([display, message = std::string(buffer)]() {
            display->SetChatMessage("system", message.c_str());
        });
    });

    if (!upgrade_success) {
        // Upgrade failed, restart audio service and continue running
        ESP_LOGE(TAG, "Firmware upgrade failed, restarting audio service and continuing operation...");
        audio_service_.Start(); // Restart audio service
        board.SetPowerSaveLevel(PowerSaveLevel::LOW_POWER); // Restore power save level
        Alert(Lang::Strings::ERROR, Lang::Strings::UPGRADE_FAILED, "circle_xmark", Lang::Sounds::OGG_EXCLAMATION);
        vTaskDelay(pdMS_TO_TICKS(3000));
        return false;
    } else {
        // Upgrade success, reboot immediately
        ESP_LOGI(TAG, "Firmware upgrade successful, rebooting...");
        display->SetChatMessage("system", "Upgrade successful, rebooting...");
        vTaskDelay(pdMS_TO_TICKS(1000)); // Brief pause to show message
        Reboot();
        return true;
    }
}

void Application::WakeWordInvoke(const std::string& wake_word) {
    if (!protocol_) {
        return;
    }

    auto state = GetDeviceState();
    
    if (state == kDeviceStateIdle) {
        audio_service_.EncodeWakeWord();

        if (!protocol_->IsAudioChannelOpened()) {
            SetDeviceState(kDeviceStateConnecting);
            // Schedule to let the state change be processed first (UI update)
            Schedule([this, wake_word]() {
                ContinueWakeWordInvoke(wake_word);
            });
            return;
        }
        // Channel already opened, continue directly
        ContinueWakeWordInvoke(wake_word);
    } else if (state == kDeviceStateSpeaking) {
        Schedule([this]() {
            AbortSpeaking(kAbortReasonNone);
        });
    } else if (state == kDeviceStateListening) {   
        Schedule([this]() {
            if (protocol_) {
                protocol_->CloseAudioChannel();
            }
        });
    }
}

bool Application::CanEnterSleepMode() {
    if (GetDeviceState() != kDeviceStateIdle) {
        return false;
    }

    if (protocol_ && protocol_->IsAudioChannelOpened()) {
        return false;
    }

    if (!audio_service_.IsIdle()) {
        return false;
    }

    // Now it is safe to enter sleep mode
    return true;
}

void Application::SendMcpMessage(const std::string& payload) {
    // Always schedule to run in main task for thread safety
    Schedule([this, payload = std::move(payload)]() {
        if (protocol_) {
            protocol_->SendMcpMessage(payload);
        }
    });
}

void Application::SetAecMode(AecMode mode) {
    aec_mode_ = mode;
    Schedule([this]() {
        auto& board = Board::GetInstance();
        auto display = board.GetDisplay();
        switch (aec_mode_) {
        case kAecOff:
            audio_service_.EnableDeviceAec(false);
            display->ShowNotification(Lang::Strings::RTC_MODE_OFF);
            break;
        case kAecOnServerSide:
            audio_service_.EnableDeviceAec(false);
            display->ShowNotification(Lang::Strings::RTC_MODE_ON);
            break;
        case kAecOnDeviceSide:
            audio_service_.EnableDeviceAec(true);
            display->ShowNotification(Lang::Strings::RTC_MODE_ON);
            break;
        }

        // If the AEC mode is changed, close the audio channel
        if (protocol_ && protocol_->IsAudioChannelOpened()) {
            protocol_->CloseAudioChannel();
        }
    });
}

void Application::PlaySound(const std::string_view& sound) {
    audio_service_.PlaySound(sound);
}

void Application::ResetProtocol() {
    Schedule([this]() {
        // Close audio channel if opened
        if (protocol_ && protocol_->IsAudioChannelOpened()) {
            protocol_->CloseAudioChannel();
        }
        // Reset protocol
        protocol_.reset();
    });
}
